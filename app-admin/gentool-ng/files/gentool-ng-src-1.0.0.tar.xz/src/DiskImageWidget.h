#pragma once
#include <QCheckBox>
#include <QComboBox>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QPlainTextEdit>
#include <QSpinBox>
#include <QWidget>

class DiskImageWidget : public QWidget {
    Q_OBJECT
public:
    explicit DiskImageWidget(QWidget* parent = nullptr);
public Q_SLOTS:
    void refreshImages();
private:
    QString selectedImage() const;
    void createImage();
    void mountImage();
    void unmountImage();
    void zeroAndCompress();
    void deleteImage();
    void buildSysextImage();
    void runCmd(const QString& prog, const QStringList& args);

    QLineEdit *m_dirIn = nullptr, *m_nameIn = nullptr, *m_mntIn = nullptr;
    QLineEdit *m_sxSrcIn = nullptr, *m_sxNameIn = nullptr, *m_sxOsIdIn = nullptr;
    QComboBox *m_fmtCb = nullptr, *m_partCb = nullptr, *m_sxFmtCb = nullptr;
    QSpinBox* m_sizeSpin = nullptr;
    QCheckBox *m_chrootChk = nullptr, *m_archChk = nullptr, *m_sxDeployChk = nullptr;
    QListWidget* m_imgList = nullptr;
    QPlainTextEdit* m_log = nullptr;
};
