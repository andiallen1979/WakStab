#include "DiskImageWidget.h"
#include <QDateTime>
#include <QDir>
#include <QRegularExpression>
#include <QFileDialog>
#include <QFileInfo>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QMessageBox>
#include <QProcess>
#include <QPushButton>
#include <QSplitter>
#include <QVBoxLayout>

namespace {
QPushButton* imgIconBtn(const QString& icon, const QString& fb, const QString& tip, QWidget* p) {
    auto* b = new QPushButton(p); b->setToolTip(tip); b->setIconSize(QSize(18, 18)); b->setFixedSize(28, 28);
    QIcon ic = QIcon::fromTheme(icon); if (!ic.isNull()) b->setIcon(ic); else b->setText(fb);
    return b;
}
} // namespace

DiskImageWidget::DiskImageWidget(QWidget* parent) : QWidget(parent) {
    auto* root = new QVBoxLayout(this); root->setContentsMargins(6, 6, 6, 6);
    auto* sp = new QSplitter(Qt::Horizontal, this); root->addWidget(sp, 1);

    auto* lw = new QWidget(sp); auto* ll = new QVBoxLayout(lw); ll->setContentsMargins(0, 0, 0, 0);
    auto* dbar = new QHBoxLayout();
    m_dirIn = new QLineEdit("/var/lib/libvirt/images", lw);
    auto* bDir = imgIconBtn("folder-open", "📂", "Select Image Directory", lw);
    auto* bRef = imgIconBtn("view-refresh", "↻", "Refresh Image List", lw);
    dbar->addWidget(m_dirIn, 1); dbar->addWidget(bDir); dbar->addWidget(bRef); ll->addLayout(dbar);
    m_imgList = new QListWidget(lw); ll->addWidget(m_imgList, 1);

    auto* rw = new QWidget(sp); auto* rl = new QVBoxLayout(rw); rl->setContentsMargins(0, 0, 0, 0);
    sp->setSizes({340, 820});

    auto* gbNew = new QGroupBox("Create Virtual Disk Image", rw); auto* lNew = new QHBoxLayout(gbNew);
    m_nameIn = new QLineEdit("fragtoo-deck", gbNew); m_nameIn->setPlaceholderText("image-name");
    m_fmtCb = new QComboBox(gbNew); m_fmtCb->addItems({"qcow2", "raw", "vhdx", "vpc", "vmdk", "vdi"});
    m_sizeSpin = new QSpinBox(gbNew); m_sizeSpin->setRange(1, 4096); m_sizeSpin->setValue(32); m_sizeSpin->setSuffix(" GiB");
    auto* bNew = imgIconBtn("document-new", "+", "Create Disk Image", gbNew);
    lNew->addWidget(new QLabel("Name:")); lNew->addWidget(m_nameIn, 1); lNew->addWidget(new QLabel("Format:")); lNew->addWidget(m_fmtCb);
    lNew->addWidget(new QLabel("Size:")); lNew->addWidget(m_sizeSpin); lNew->addWidget(bNew); rl->addWidget(gbNew);

    auto* gbMnt = new QGroupBox("Mount, Chroot & Maintenance", rw); auto* lMnt = new QHBoxLayout(gbMnt);
    m_mntIn = new QLineEdit("/mnt/wakstab-chroot", gbMnt);
    m_partCb = new QComboBox(gbMnt); m_partCb->addItems({"p2", "p1", "p3", "whole"});
    m_chrootChk = new QCheckBox("Chroot binds", gbMnt); m_chrootChk->setChecked(true);
    m_archChk = new QCheckBox("arch-chroot mode", gbMnt);
    auto* bMnt = imgIconBtn("network-connect", "🔌", "Mount Image & Bind Chroot", gbMnt);
    auto* bUmnt = imgIconBtn("network-disconnect", "⏏", "Unmount & Detach NBD/Loop", gbMnt);
    auto* bComp = imgIconBtn("application-x-archive", "🗜", "Zero Empty Space & Compress", gbMnt);
    auto* bDel = imgIconBtn("edit-delete", "🗑", "Delete Selected Image", gbMnt);
    lMnt->addWidget(new QLabel("Mount:")); lMnt->addWidget(m_mntIn, 1); lMnt->addWidget(new QLabel("Part:")); lMnt->addWidget(m_partCb);
    lMnt->addWidget(m_chrootChk); lMnt->addWidget(m_archChk); lMnt->addWidget(bMnt); lMnt->addWidget(bUmnt); lMnt->addWidget(bComp); lMnt->addWidget(bDel);
    rl->addWidget(gbMnt);

    auto* gbSx = new QGroupBox("Build systemd-sysext Extension Image (.raw)", rw); auto* lSx = new QHBoxLayout(gbSx);
    m_sxSrcIn = new QLineEdit("/var/tmp/sysext-root", gbSx);
    auto* bSxDir = imgIconBtn("folder-open", "📂", "Select Sysext Overlay Directory", gbSx);
    m_sxNameIn = new QLineEdit("fragtoo-extra", gbSx); m_sxNameIn->setMaximumWidth(140);
    m_sxOsIdIn = new QLineEdit("gentoo", gbSx); m_sxOsIdIn->setMaximumWidth(95);
    m_sxFmtCb = new QComboBox(gbSx); m_sxFmtCb->addItems({"squashfs-zstd", "erofs-lz4hc"});
    auto* bSxBuild = imgIconBtn("run-build", "⚙", "Build Sysext .raw Image", gbSx);
    m_bSxInst = imgIconBtn("folder-download", "📥", "Install Built Sysext to /var/lib/extensions & Refresh", gbSx);
    m_bSxExp = imgIconBtn("document-export", "💾", "Export Built Sysext .raw to Custom Location...", gbSx);
    m_bSxInst->setEnabled(false); m_bSxExp->setEnabled(false);
    lSx->addWidget(new QLabel("Root:")); lSx->addWidget(m_sxSrcIn, 1); lSx->addWidget(bSxDir);
    lSx->addWidget(new QLabel("Name:")); lSx->addWidget(m_sxNameIn); lSx->addWidget(new QLabel("ID:")); lSx->addWidget(m_sxOsIdIn);
    lSx->addWidget(m_sxFmtCb); lSx->addWidget(bSxBuild); lSx->addWidget(m_bSxInst); lSx->addWidget(m_bSxExp);
    rl->addWidget(gbSx);

    m_log = new QPlainTextEdit(rw); m_log->setReadOnly(true); m_log->setPlaceholderText("Virtual disk & chroot command log...");
    rl->addWidget(m_log, 1);

    connect(bDir, &QPushButton::clicked, this, [this]() {
        QString d = QFileDialog::getExistingDirectory(this, "Select Image Directory", m_dirIn->text());
        if (!d.isEmpty()) { m_dirIn->setText(d); refreshImages(); }
    });
    connect(bRef, &QPushButton::clicked, this, &DiskImageWidget::refreshImages);
    connect(bNew, &QPushButton::clicked, this, &DiskImageWidget::createImage);
    connect(bMnt, &QPushButton::clicked, this, &DiskImageWidget::mountImage);
    connect(bUmnt, &QPushButton::clicked, this, &DiskImageWidget::unmountImage);
    connect(bComp, &QPushButton::clicked, this, &DiskImageWidget::zeroAndCompress);
    connect(bDel, &QPushButton::clicked, this, &DiskImageWidget::deleteImage);
    connect(bSxDir, &QPushButton::clicked, this, [this]() {
        QString d = QFileDialog::getExistingDirectory(this, "Select Sysext Overlay Directory", m_sxSrcIn->text());
        if (!d.isEmpty()) m_sxSrcIn->setText(d);
    });
    connect(bSxBuild, &QPushButton::clicked, this, &DiskImageWidget::buildSysextImage);
    connect(m_bSxInst, &QPushButton::clicked, this, &DiskImageWidget::installSysextImage);
    connect(m_bSxExp, &QPushButton::clicked, this, &DiskImageWidget::exportSysextImage);
    refreshImages();
}

bool DiskImageWidget::runCmd(const QString& prog, const QStringList& args) {
    m_log->appendPlainText("$ " + prog + " " + args.join(' '));
    QProcess pr; pr.setProcessChannelMode(QProcess::MergedChannels);
    pr.start(prog, args); pr.waitForFinished(-1);
    QString out = QString::fromUtf8(pr.readAllStandardOutput()).trimmed();
    if (!out.isEmpty()) m_log->appendPlainText(out);
    if (pr.exitCode() != 0) m_log->appendPlainText(QString("[exit %1]").arg(pr.exitCode()));
    return pr.exitCode() == 0;
}
QString DiskImageWidget::selectedImage() const {
    auto* it = m_imgList->currentItem();
    return it ? (m_dirIn->text().trimmed() + "/" + it->text()) : QString();
}
void DiskImageWidget::refreshImages() {
    m_imgList->clear(); QDir d(m_dirIn->text().trimmed());
    if (!d.exists()) return;
    for (const QString& fn : d.entryList({"*.qcow2", "*.raw", "*.img", "*.vhdx", "*.vhd", "*.vmdk", "*.vdi"}, QDir::Files, QDir::Name))
        m_imgList->addItem(fn);
}
void DiskImageWidget::createImage() {
    QString nm = QFileInfo(m_nameIn->text().trimmed()).fileName();
    if (nm.isEmpty()) return;
    QString fmt = m_fmtCb->currentText(), ext = (fmt == "vpc") ? "vhd" : fmt;
    if (nm.endsWith("." + ext)) nm.chop(ext.size() + 1);
    nm = QString("%1-%2.%3").arg(nm).arg(QDateTime::currentSecsSinceEpoch()).arg(ext);
    QDir().mkpath(m_dirIn->text().trimmed());
    QString dst = m_dirIn->text().trimmed() + "/" + nm;
    runCmd("qemu-img", {"create", "-f", fmt, dst, QString("%1G").arg(m_sizeSpin->value())});
    refreshImages();
}
void DiskImageWidget::mountImage() {
    QString img = selectedImage(); if (img.isEmpty()) return;
    QString mnt = m_mntIn->text().trimmed(), part = m_partCb->currentText(); QDir().mkpath(mnt);
    bool isRaw = img.endsWith(".raw") || img.endsWith(".img");
    QString script = isRaw
        ? QString("LOOP=$(losetup --find --show --partscan '%1'); DEV=\"${LOOP}%2\"; [ '%2' = 'whole' ] && DEV=\"$LOOP\"; mount \"$DEV\" '%3'").arg(img, part, mnt)
        : QString("modprobe nbd max_part=16; qemu-nbd -d /dev/nbd0 >/dev/null 2>&1 || true; qemu-nbd -c /dev/nbd0 '%1'; sleep 1; partprobe /dev/nbd0; DEV=\"/dev/nbd0%2\"; [ '%2' = 'whole' ] && DEV=\"/dev/nbd0\"; mount \"$DEV\" '%3'").arg(img, part, mnt);
    if (m_chrootChk->isChecked() || m_archChk->isChecked())
        script += QString("; mkdir -p '%1'/{proc,sys,dev,dev/pts,run,etc}; mount -t proc /proc '%1/proc'; mount --rbind /sys '%1/sys'; mount --make-rslave '%1/sys'; mount --rbind /dev '%1/dev'; mount --make-rslave '%1/dev'; mount --bind /run '%1/run'; cp -L /etc/resolv.conf '%1/etc/resolv.conf' 2>/dev/null || true").arg(mnt);
    runCmd("sh", {"-c", script});
}
void DiskImageWidget::unmountImage() {
    QString mnt = m_mntIn->text().trimmed(); if (mnt.isEmpty()) return;
    QString script = QString("for sub in dev/pts dev sys proc run; do umount -lf '%1/'\"$sub\" 2>/dev/null || true; done; SRC=$(findmnt -n -o SOURCE '%1' 2>/dev/null); umount -lf '%1' 2>/dev/null || true; case \"$SRC\" in /dev/nbd0*) qemu-nbd -d /dev/nbd0 2>/dev/null || true ;; /dev/loop*) losetup -d \"${SRC%%p[0-9]*}\" 2>/dev/null || true ;; esac").arg(mnt);
    runCmd("sh", {"-c", script});
}
void DiskImageWidget::zeroAndCompress() {
    QString img = selectedImage(); if (img.isEmpty()) return;
    if (QMessageBox::question(this, "Zero & Compress", "Zero free space inside " + QFileInfo(img).fileName() + " and compress?") != QMessageBox::Yes) return;
    unmountImage();
    QString mnt = m_mntIn->text().trimmed(), part = m_partCb->currentText(); QDir().mkpath(mnt);
    bool isRaw = img.endsWith(".raw") || img.endsWith(".img");
    QString fmt = img.endsWith(".vhd") ? "vpc" : QFileInfo(img).suffix();
    QString zeroStep = isRaw
        ? QString("LOOP=$(losetup --find --show --partscan '%1'); DEV=\"${LOOP}%2\"; [ '%2' = 'whole' ] && DEV=\"$LOOP\"; mount \"$DEV\" '%3' && { fstrim -v '%3' 2>/dev/null || true; dd if=/dev/zero of='%3/.zero.fill' bs=16M status=none 2>/dev/null || true; rm -f '%3/.zero.fill'; sync; umount '%3'; }; losetup -d \"$LOOP\"; fallocate -d '%1'").arg(img, part, mnt)
        : QString("modprobe nbd max_part=16; qemu-nbd -c /dev/nbd0 '%1'; sleep 1; partprobe /dev/nbd0; DEV=\"/dev/nbd0%2\"; [ '%2' = 'whole' ] && DEV=\"/dev/nbd0\"; mount \"$DEV\" '%3' && { fstrim -v '%3' 2>/dev/null || true; dd if=/dev/zero of='%3/.zero.fill' bs=16M status=none 2>/dev/null || true; rm -f '%3/.zero.fill'; sync; umount '%3'; }; qemu-nbd -d /dev/nbd0; qemu-img convert -p -O %4 -c '%1' '%1.tmp' && mv -f '%1.tmp' '%1'").arg(img, part, mnt, fmt);
    runCmd("sh", {"-c", zeroStep}); refreshImages();
}
void DiskImageWidget::deleteImage() {
    QString img = selectedImage(); if (img.isEmpty()) return;
    if (QMessageBox::question(this, "Delete Image", "Permanently delete " + QFileInfo(img).fileName() + "?") != QMessageBox::Yes) return;
    unmountImage(); QFile::remove(img); refreshImages();
}

void DiskImageWidget::buildSysextImage() {
    QString src = m_sxSrcIn->text().trimmed(), nm = m_sxNameIn->text().trimmed(), osId = m_sxOsIdIn->text().trimmed();
    if (src.isEmpty() || nm.isEmpty() || !QDir(src).exists()) {
        QMessageBox::warning(this, "Invalid Sysext Source", "Ensure source overlay directory and extension name exist."); return;
    }
    QString relDir = src + "/usr/lib/extension-release.d"; QDir().mkpath(relDir);
    QFile rf(relDir + "/extension-release." + nm);
    if (rf.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
        rf.write(QString("ID=%1\nSYSEXT_LEVEL=1.0\nARCHITECTURE=x86-64\n").arg(osId.isEmpty() ? "_any" : osId).toUtf8());
        rf.close();
    }
    QString outDir = m_dirIn->text().trimmed(); QDir().mkpath(outDir);
    QString outImg = QString("%1/%2-%3.raw").arg(outDir, nm).arg(QDateTime::currentSecsSinceEpoch());
    QString cmd = (m_sxFmtCb->currentText() == "erofs-lz4hc")
        ? QString("chown -R root:root '%1' && rm -f '%2' && mkfs.erofs -zlz4hc '%2' '%1'").arg(src, outImg)
        : QString("chown -R root:root '%1' && rm -f '%2' && mksquashfs '%1' '%2' -comp zstd -Xcompression-level 19 -noappend").arg(src, outImg);
    if (runCmd("sh", {"-c", cmd})) { m_lastSysextImg = outImg; m_bSxInst->setEnabled(true); m_bSxExp->setEnabled(true); }
    refreshImages();
}
void DiskImageWidget::installSysextImage() {
    if (m_lastSysextImg.isEmpty() || !QFile::exists(m_lastSysextImg)) return;
    QString base = QFileInfo(m_lastSysextImg).fileName().replace(QRegularExpression("-[0-9]+\\.raw$"), ".raw");
    QString dst = "/var/lib/extensions/" + base;
    runCmd("sh", {"-c", QString("mkdir -p /var/lib/extensions && cp -f '%1' '%2' && systemd-sysext refresh").arg(m_lastSysextImg, dst)});
}
void DiskImageWidget::exportSysextImage() {
    if (m_lastSysextImg.isEmpty() || !QFile::exists(m_lastSysextImg)) return;
    QString dst = QFileDialog::getSaveFileName(this, "Export Sysext Extension Image", QDir::homePath() + "/" + QFileInfo(m_lastSysextImg).fileName(), "Raw Sysext Image (*.raw)");
    if (!dst.isEmpty()) runCmd("cp", {"-f", m_lastSysextImg, dst});
}
