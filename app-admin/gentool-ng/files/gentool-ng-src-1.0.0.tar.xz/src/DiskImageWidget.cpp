#include "DiskImageWidget.h"
#include <QDateTime>
#include <QDir>
#include <QFileDialog>
#include <QFileInfo>
#include <QFormLayout>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QMessageBox>
#include <QProcess>
#include <QPushButton>
#include <QRegularExpression>
#include <QSplitter>
#include <QVBoxLayout>

DiskImageWidget::DiskImageWidget(QWidget* parent) : QWidget(parent) {
    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(8, 8, 8, 8);
    auto* sp = new QSplitter(Qt::Horizontal, this);
    root->addWidget(sp, 1);

    auto* lw = new QWidget(sp);
    auto* ll = new QVBoxLayout(lw);
    ll->setContentsMargins(0, 0, 0, 0);
    ll->setSpacing(6);

    auto* dbar = new QHBoxLayout();
    m_dirIn = new QLineEdit(QStringLiteral("/var/lib/libvirt/images"), lw);
    auto* bDir = new QPushButton(QIcon::fromTheme(QStringLiteral("folder-open")), QString(), lw);
    auto* bRef = new QPushButton(QIcon::fromTheme(QStringLiteral("view-refresh")), QString(), lw);
    dbar->addWidget(m_dirIn, 1);
    dbar->addWidget(bDir);
    dbar->addWidget(bRef);
    ll->addLayout(dbar);

    m_imgList = new QListWidget(lw);
    ll->addWidget(m_imgList, 1);

    auto* listActs = new QHBoxLayout();
    auto* bPartSel = new QPushButton(QIcon::fromTheme(QStringLiteral("drive-harddisk")), QStringLiteral("Partition"), lw);
    auto* bComp = new QPushButton(QIcon::fromTheme(QStringLiteral("application-x-archive")), QStringLiteral("Compress"), lw);
    auto* bDel = new QPushButton(QIcon::fromTheme(QStringLiteral("edit-delete")), QStringLiteral("Delete"), lw);
    listActs->addWidget(bPartSel);
    listActs->addWidget(bComp);
    listActs->addWidget(bDel);
    ll->addLayout(listActs);
    auto* rw = new QWidget(sp);
    auto* rl = new QVBoxLayout(rw);
    rl->setContentsMargins(0, 0, 0, 0);
    rl->setSpacing(8);
    sp->setSizes({340, 820});

    auto* gbNew = new QGroupBox(QStringLiteral("1. New Disk Image"), rw);
    auto* fNew = new QFormLayout(gbNew);
    fNew->setFieldGrowthPolicy(QFormLayout::ExpandingFieldsGrow);
    m_nameIn = new QLineEdit(QStringLiteral("fragtoo-deck"), gbNew);
    m_nameIn->setPlaceholderText(QStringLiteral("e.g. gentoo-root"));

    auto* specRow = new QHBoxLayout();
    m_fmtCb = new QComboBox(gbNew);
    m_fmtCb->addItems({QStringLiteral("qcow2"), QStringLiteral("raw"), QStringLiteral("vhdx"), QStringLiteral("vpc"), QStringLiteral("vmdk"), QStringLiteral("vdi")});
    m_sizeSpin = new QSpinBox(gbNew);
    m_sizeSpin->setRange(1, 4096);
    m_sizeSpin->setValue(32);
    m_sizeSpin->setSuffix(QStringLiteral(" GiB"));
    specRow->addWidget(m_fmtCb);
    specRow->addWidget(m_sizeSpin);
    specRow->addStretch(1);

    auto* createRow = new QHBoxLayout();
    m_autoPartChk = new QCheckBox(QStringLiteral("Open Partition Manager && Guide"), gbNew);
    m_autoPartChk->setChecked(true);
    auto* bNew = new QPushButton(QIcon::fromTheme(QStringLiteral("drive-harddisk")), QStringLiteral("Create && Partition"), gbNew);
    bNew->setMinimumHeight(30);
    createRow->addWidget(m_autoPartChk);
    createRow->addStretch(1);
    createRow->addWidget(bNew);

    fNew->addRow(QStringLiteral("Name:"), m_nameIn);
    fNew->addRow(QStringLiteral("Format / Size:"), specRow);
    fNew->addRow(QString(), createRow);
    rl->addWidget(gbNew);

    auto* gbMnt = new QGroupBox(QStringLiteral("2. Mount && Chroot"), rw);
    auto* fMnt = new QFormLayout(gbMnt);
    fMnt->setFieldGrowthPolicy(QFormLayout::ExpandingFieldsGrow);
    auto* mntRow = new QHBoxLayout();
    m_mntIn = new QLineEdit(QStringLiteral("/mnt/wakstab-chroot"), gbMnt);
    m_partCb = new QComboBox(gbMnt);
    m_partCb->addItems({QStringLiteral("p2"), QStringLiteral("p1"), QStringLiteral("p3"), QStringLiteral("whole")});
    mntRow->addWidget(m_mntIn, 1);
    mntRow->addWidget(new QLabel(QStringLiteral("Partition:"), gbMnt));
    mntRow->addWidget(m_partCb);
    auto* mntActRow = new QHBoxLayout();
    m_chrootChk = new QCheckBox(QStringLiteral("Bind /proc, /sys, /dev"), gbMnt);
    m_chrootChk->setChecked(true);
    m_archChk = new QCheckBox(QStringLiteral("arch-chroot"), gbMnt);
    auto* bMnt = new QPushButton(QIcon::fromTheme(QStringLiteral("network-connect")), QStringLiteral("Mount"), gbMnt);
    auto* bUmnt = new QPushButton(QIcon::fromTheme(QStringLiteral("network-disconnect")), QStringLiteral("Unmount"), gbMnt);
    mntActRow->addWidget(m_chrootChk); mntActRow->addWidget(m_archChk); mntActRow->addStretch(1); mntActRow->addWidget(bMnt); mntActRow->addWidget(bUmnt);
    fMnt->addRow(QStringLiteral("Target:"), mntRow); fMnt->addRow(QString(), mntActRow);
    rl->addWidget(gbMnt);

    auto* gbSx = new QGroupBox(QStringLiteral("3. System Extension (.raw)"), rw);
    auto* fSx = new QFormLayout(gbSx);
    fSx->setFieldGrowthPolicy(QFormLayout::ExpandingFieldsGrow);
    auto* sxSrcRow = new QHBoxLayout();
    m_sxSrcIn = new QLineEdit(QStringLiteral("/var/tmp/sysext-root"), gbSx);
    auto* bSxDir = new QPushButton(QIcon::fromTheme(QStringLiteral("folder-open")), QString(), gbSx);
    sxSrcRow->addWidget(m_sxSrcIn, 1); sxSrcRow->addWidget(bSxDir);

    auto* sxMetaRow = new QHBoxLayout();
    m_sxNameIn = new QLineEdit(QStringLiteral("fragtoo-extra"), gbSx);
    m_sxOsIdIn = new QLineEdit(QStringLiteral("gentoo"), gbSx); m_sxOsIdIn->setMaximumWidth(110);
    m_sxFmtCb = new QComboBox(gbSx); m_sxFmtCb->addItems({QStringLiteral("squashfs-zstd"), QStringLiteral("erofs-lz4hc")});
    auto* bSxBuild = new QPushButton(QIcon::fromTheme(QStringLiteral("run-build")), QStringLiteral("Build"), gbSx);
    m_bSxInst = new QPushButton(QIcon::fromTheme(QStringLiteral("folder-download")), QStringLiteral("Install"), gbSx);
    m_bSxExp = new QPushButton(QIcon::fromTheme(QStringLiteral("document-export")), QStringLiteral("Export"), gbSx);
    m_bSxInst->setEnabled(false); m_bSxExp->setEnabled(false);
    sxMetaRow->addWidget(m_sxNameIn, 1); sxMetaRow->addWidget(new QLabel(QStringLiteral("OS:"), gbSx)); sxMetaRow->addWidget(m_sxOsIdIn);
    sxMetaRow->addWidget(m_sxFmtCb); sxMetaRow->addWidget(bSxBuild); sxMetaRow->addWidget(m_bSxInst); sxMetaRow->addWidget(m_bSxExp);
    fSx->addRow(QStringLiteral("Root:"), sxSrcRow); fSx->addRow(QStringLiteral("Name:"), sxMetaRow);
    rl->addWidget(gbSx);

    m_log = new QPlainTextEdit(rw); m_log->setReadOnly(true); m_log->setPlaceholderText(QStringLiteral("Command output..."));
    rl->addWidget(m_log, 1);

    connect(bDir, &QPushButton::clicked, this, [this]() {
        QString d = QFileDialog::getExistingDirectory(this, QStringLiteral("Select Image Folder"), m_dirIn->text());
        if (!d.isEmpty()) { m_dirIn->setText(d); refreshImages(); }
    });
    connect(bRef, &QPushButton::clicked, this, &DiskImageWidget::refreshImages);
    connect(bNew, &QPushButton::clicked, this, &DiskImageWidget::createImage);
    connect(bPartSel, &QPushButton::clicked, this, [this]() { attachAndPartition(selectedImage()); });
    connect(bMnt, &QPushButton::clicked, this, &DiskImageWidget::mountImage);
    connect(bUmnt, &QPushButton::clicked, this, &DiskImageWidget::unmountImage);
    connect(bComp, &QPushButton::clicked, this, &DiskImageWidget::zeroAndCompress);
    connect(bDel, &QPushButton::clicked, this, &DiskImageWidget::deleteImage);
    connect(bSxDir, &QPushButton::clicked, this, [this]() {
        QString d = QFileDialog::getExistingDirectory(this, QStringLiteral("Select Sysext Root"), m_sxSrcIn->text());
        if (!d.isEmpty()) m_sxSrcIn->setText(d);
    });
    connect(bSxBuild, &QPushButton::clicked, this, &DiskImageWidget::buildSysextImage);
    connect(m_bSxInst, &QPushButton::clicked, this, &DiskImageWidget::installSysextImage);
    connect(m_bSxExp, &QPushButton::clicked, this, &DiskImageWidget::exportSysextImage);
    refreshImages();
}

bool DiskImageWidget::runCmd(const QString& prog, const QStringList& args) {
    m_log->appendPlainText(QStringLiteral("$ ") + prog + QLatin1Char(' ') + args.join(QLatin1Char(' ')));
    QProcess pr; pr.setProcessChannelMode(QProcess::MergedChannels);
    pr.start(prog, args); pr.waitForFinished(-1);
    QString out = QString::fromUtf8(pr.readAllStandardOutput()).trimmed();
    if (!out.isEmpty()) m_log->appendPlainText(out);
    if (pr.exitCode() != 0) m_log->appendPlainText(QStringLiteral("[exit %1]").arg(pr.exitCode()));
    return pr.exitCode() == 0;
}

QString DiskImageWidget::selectedImage() const {
    auto* it = m_imgList->currentItem();
    return it ? (m_dirIn->text().trimmed() + QLatin1Char('/') + it->text()) : QString();
}

void DiskImageWidget::refreshImages() {
    m_imgList->clear(); QDir d(m_dirIn->text().trimmed());
    if (!d.exists()) return;
    for (const QString& fn : d.entryList({QStringLiteral("*.qcow2"), QStringLiteral("*.raw"), QStringLiteral("*.img"), QStringLiteral("*.vhdx"), QStringLiteral("*.vhd"), QStringLiteral("*.vmdk"), QStringLiteral("*.vdi")}, QDir::Files, QDir::Name))
        m_imgList->addItem(fn);
}

void DiskImageWidget::createImage() {
    QString nm = QFileInfo(m_nameIn->text().trimmed()).fileName();
    if (nm.isEmpty()) return;
    QString fmt = m_fmtCb->currentText(), ext = (fmt == QStringLiteral("vpc")) ? QStringLiteral("vhd") : fmt;
    if (nm.endsWith(QLatin1Char('.') + ext)) nm.chop(ext.size() + 1);
    nm = QStringLiteral("%1-%2.%3").arg(nm).arg(QDateTime::currentSecsSinceEpoch()).arg(ext);
    QDir().mkpath(m_dirIn->text().trimmed());
    QString dst = m_dirIn->text().trimmed() + QLatin1Char('/') + nm;
    if (!runCmd(QStringLiteral("qemu-img"), {QStringLiteral("create"), QStringLiteral("-f"), fmt, dst, QStringLiteral("%1G").arg(m_sizeSpin->value())})) return;
    refreshImages();
    for (int i = 0; i < m_imgList->count(); ++i) {
        if (m_imgList->item(i)->text() == nm) { m_imgList->setCurrentRow(i); break; }
    }
    if (m_autoPartChk && m_autoPartChk->isChecked()) attachAndPartition(dst);
}

void DiskImageWidget::attachAndPartition(const QString& imgPath) {
    if (imgPath.isEmpty()) return;
    bool isRaw = imgPath.endsWith(QStringLiteral(".raw")) || imgPath.endsWith(QStringLiteral(".img"));
    QProcess pr;
    if (isRaw) pr.start(QStringLiteral("losetup"), {QStringLiteral("--find"), QStringLiteral("--show"), QStringLiteral("--partscan"), imgPath});
    else pr.start(QStringLiteral("sh"), {QStringLiteral("-c"), QStringLiteral("modprobe nbd max_part=16 2>/dev/null || true; for n in /dev/nbd0 /dev/nbd1 /dev/nbd2 /dev/nbd3 /dev/nbd4 /dev/nbd5; do b=$(basename $n); [ -b $n ] || continue; [ $(cat /sys/block/$b/size 2>/dev/null || echo 1) -eq 0 ] || continue; if qemu-nbd -c $n '%1'; then sleep 1; partprobe $n 2>/dev/null || true; echo $n; break; fi; done").arg(imgPath)});
    pr.waitForFinished(10000);
    QString dev = QString::fromUtf8(pr.readAllStandardOutput()).trimmed().section(QLatin1Char('\n'), -1);
    if (!QRegularExpression(QStringLiteral("^/dev/(nbd|loop)[0-9]+$")).match(dev).hasMatch()) {
        QMessageBox::critical(this, QStringLiteral("Safety Lockout"), QStringLiteral("Refusing non-virtual block device '%1'. Only /dev/nbd* or /dev/loop* are permitted.").arg(dev));
        return;
    }
    m_log->appendPlainText(QStringLiteral("Safely attached virtual device %1 -> %2").arg(imgPath, dev));
    Q_EMIT openInPartitionManagerRequested(dev, imgPath);
}

void DiskImageWidget::mountImage() {
    QString img = selectedImage(); if (img.isEmpty()) return;
    QString mnt = m_mntIn->text().trimmed(), part = m_partCb->currentText(); QDir().mkpath(mnt);
    bool isRaw = img.endsWith(QStringLiteral(".raw")) || img.endsWith(QStringLiteral(".img"));
    QString script = isRaw
        ? QStringLiteral("LOOP=$(losetup --find --show --partscan '%1'); DEV=\"${LOOP}%2\"; [ '%2' = 'whole' ] && DEV=\"$LOOP\"; mount \"$DEV\" '%3'").arg(img, part, mnt)
        : QStringLiteral("modprobe nbd max_part=16; qemu-nbd -d /dev/nbd0 >/dev/null 2>&1 || true; qemu-nbd -c /dev/nbd0 '%1'; sleep 1; partprobe /dev/nbd0; DEV=\"/dev/nbd0%2\"; [ '%2' = 'whole' ] && DEV=\"/dev/nbd0\"; mount \"$DEV\" '%3'").arg(img, part, mnt);
    if (m_chrootChk->isChecked() || m_archChk->isChecked())
        script += QStringLiteral("; mkdir -p '%1'/{proc,sys,dev,dev/pts,run,etc}; mount -t proc /proc '%1/proc'; mount --rbind /sys '%1/sys'; mount --make-rslave '%1/sys'; mount --rbind /dev '%1/dev'; mount --make-rslave '%1/dev'; mount --bind /run '%1/run'; cp -L /etc/resolv.conf '%1/etc/resolv.conf' 2>/dev/null || true").arg(mnt);
    runCmd(QStringLiteral("sh"), {QStringLiteral("-c"), script});
}

void DiskImageWidget::unmountImage() {
    QString mnt = m_mntIn->text().trimmed(); if (mnt.isEmpty()) return;
    QString script = QStringLiteral("for sub in dev/pts dev sys proc run; do umount -lf '%1/'\"$sub\" 2>/dev/null || true; done; SRC=$(findmnt -n -o SOURCE '%1' 2>/dev/null); umount -lf '%1' 2>/dev/null || true; case \"$SRC\" in /dev/nbd0*) qemu-nbd -d /dev/nbd0 2>/dev/null || true ;; /dev/loop*) losetup -d \"${SRC%%p[0-9]*}\" 2>/dev/null || true ;; esac").arg(mnt);
    runCmd(QStringLiteral("sh"), {QStringLiteral("-c"), script});
}

void DiskImageWidget::zeroAndCompress() {
    QString img = selectedImage(); if (img.isEmpty()) return;
    if (QMessageBox::question(this, QStringLiteral("Compress Image"), QStringLiteral("Zero free space inside %1 and compress?").arg(QFileInfo(img).fileName())) != QMessageBox::Yes) return;
    unmountImage();
    QString mnt = m_mntIn->text().trimmed(), part = m_partCb->currentText(); QDir().mkpath(mnt);
    bool isRaw = img.endsWith(QStringLiteral(".raw")) || img.endsWith(QStringLiteral(".img"));
    QString fmt = img.endsWith(QStringLiteral(".vhd")) ? QStringLiteral("vpc") : QFileInfo(img).suffix();
    QString zeroStep = isRaw
        ? QStringLiteral("LOOP=$(losetup --find --show --partscan '%1'); DEV=\"${LOOP}%2\"; [ '%2' = 'whole' ] && DEV=\"$LOOP\"; mount \"$DEV\" '%3' && { fstrim -v '%3' 2>/dev/null || true; dd if=/dev/zero of='%3/.zero.fill' bs=16M status=none 2>/dev/null || true; rm -f '%3/.zero.fill'; sync; umount '%3'; }; losetup -d \"$LOOP\"; fallocate -d '%1'").arg(img, part, mnt)
        : QStringLiteral("modprobe nbd max_part=16; qemu-nbd -c /dev/nbd0 '%1'; sleep 1; partprobe /dev/nbd0; DEV=\"/dev/nbd0%2\"; [ '%2' = 'whole' ] && DEV=\"/dev/nbd0\"; mount \"$DEV\" '%3' && { fstrim -v '%3' 2>/dev/null || true; dd if=/dev/zero of='%3/.zero.fill' bs=16M status=none 2>/dev/null || true; rm -f '%3/.zero.fill'; sync; umount '%3'; }; qemu-nbd -d /dev/nbd0; qemu-img convert -p -O %4 -c '%1' '%1.tmp' && mv -f '%1.tmp' '%1'").arg(img, part, mnt, fmt);
    runCmd(QStringLiteral("sh"), {QStringLiteral("-c"), zeroStep}); refreshImages();
}

void DiskImageWidget::deleteImage() {
    QString img = selectedImage(); if (img.isEmpty()) return;
    if (QMessageBox::question(this, QStringLiteral("Delete Image"), QStringLiteral("Delete %1?").arg(QFileInfo(img).fileName())) != QMessageBox::Yes) return;
    unmountImage(); QFile::remove(img); refreshImages();
}

void DiskImageWidget::buildSysextImage() {
    QString src = m_sxSrcIn->text().trimmed(), nm = m_sxNameIn->text().trimmed(), osId = m_sxOsIdIn->text().trimmed();
    if (src.isEmpty() || nm.isEmpty() || !QDir(src).exists()) {
        QMessageBox::warning(this, QStringLiteral("Invalid Source"), QStringLiteral("Check source directory and name.")); return;
    }
    QString relDir = src + QStringLiteral("/usr/lib/extension-release.d"); QDir().mkpath(relDir);
    QFile rf(relDir + QStringLiteral("/extension-release.") + nm);
    if (rf.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
        rf.write(QStringLiteral("ID=%1\nSYSEXT_LEVEL=1.0\nARCHITECTURE=x86-64\n").arg(osId.isEmpty() ? QStringLiteral("_any") : osId).toUtf8());
        rf.close();
    }
    QString outDir = m_dirIn->text().trimmed(); QDir().mkpath(outDir);
    QString outImg = QStringLiteral("%1/%2-%3.raw").arg(outDir, nm).arg(QDateTime::currentSecsSinceEpoch());
    QString cmd = (m_sxFmtCb->currentText() == QStringLiteral("erofs-lz4hc"))
        ? QStringLiteral("chown -R root:root '%1' && rm -f '%2' && mkfs.erofs -zlz4hc '%2' '%1'").arg(src, outImg)
        : QStringLiteral("chown -R root:root '%1' && rm -f '%2' && mksquashfs '%1' '%2' -comp zstd -Xcompression-level 19 -noappend").arg(src, outImg);
    if (runCmd(QStringLiteral("sh"), {QStringLiteral("-c"), cmd})) { m_lastSysextImg = outImg; m_bSxInst->setEnabled(true); m_bSxExp->setEnabled(true); }
    refreshImages();
}

void DiskImageWidget::installSysextImage() {
    if (m_lastSysextImg.isEmpty() || !QFile::exists(m_lastSysextImg)) return;
    QString base = QFileInfo(m_lastSysextImg).fileName().replace(QRegularExpression(QStringLiteral("-[0-9]+\\.raw$")), QStringLiteral(".raw"));
    QString dst = QStringLiteral("/var/lib/extensions/") + base;
    runCmd(QStringLiteral("sh"), {QStringLiteral("-c"), QStringLiteral("mkdir -p /var/lib/extensions && cp -f '%1' '%2' && systemd-sysext refresh").arg(m_lastSysextImg, dst)});
}

void DiskImageWidget::exportSysextImage() {
    if (m_lastSysextImg.isEmpty() || !QFile::exists(m_lastSysextImg)) return;
    QString dst = QFileDialog::getSaveFileName(this, QStringLiteral("Export Sysext Image"), QDir::homePath() + QLatin1Char('/') + QFileInfo(m_lastSysextImg).fileName(), QStringLiteral("Raw Image (*.raw)"));
    if (!dst.isEmpty()) runCmd(QStringLiteral("cp"), {QStringLiteral("-f"), m_lastSysextImg, dst});
}

void DiskImageWidget::prepareAndMountChroot(const QString& rootPart, bool bindChroot) {
    int idx = m_partCb->findText(rootPart);
    if (idx >= 0) m_partCb->setCurrentIndex(idx);
    if (m_chrootChk) m_chrootChk->setChecked(bindChroot);
    mountImage();
}
