#pragma once
#include <QWidget>
#include <QTreeWidget>
#include <QPlainTextEdit>
#include <QLineEdit>
#include <QComboBox>
#include <QPushButton>
#include <QSettings>
#include <QSyntaxHighlighter>
#include <QRegularExpression>

class LogHighlighter : public QSyntaxHighlighter {
    Q_OBJECT
public:
    explicit LogHighlighter(QTextDocument *parent);
protected:
    void highlightBlock(const QString &text) override;
};

class LogManagerWidget : public QWidget {
    Q_OBJECT
public:
    explicit LogManagerWidget(QWidget *parent = nullptr);
public Q_SLOTS:
    void configureCustomLogs();
private Q_SLOTS:
    void refreshSources();
    void onSourceSelected(QTreeWidgetItem *item);
    void loadJournald(const QString &unitFilter = QString());
    void applyFilter();
    
private:
    void loadFileTail(const QString &path);
    QTreeWidget *m_tree;
    QPlainTextEdit *m_viewer;
    QLineEdit *m_searchEdit;
    QComboBox *m_levelCombo;
    QPushButton *m_refreshBtn, *m_customBtn;
    QString m_fullContent;
    QSettings m_settings;
};
