#pragma once
#include <QString>
#include <QList>
#include <QJsonObject>

struct GtSnapPackage {
    QString uuid;
    QString name;
    QString createdIso;
    QString initSystem;
    QString arch;
    QString pkgDir;
    QString rawImagePath;
    QString mountDir;
    bool hasRootfs = false;
    bool hasEsp = false;
};

class GtSnapManager {
public:
    static QString baseStoreDir();
    static GtSnapPackage initWizardWorkspace(const QString &name, const QString &initSystem, const QString &variant, const QString &bootloader, const QString &hostname, const QString &timezone);
    static GtSnapPackage createPackage(const QString &name, const QString &initSystem, const QString &sourceRoot = QStringLiteral("/"));
    static QList<GtSnapPackage> listPackages();
    static bool exportConfigBundle(const QString &uuid, const QString &targetRoot);
    static bool deletePackage(const QString &uuid);
    static void cleanupStaleMountsAndLoops();
};
