#pragma once
#include <QString>
#include <QStringList>
#include <QUrl>

namespace GentooStrings {
inline QString defaultMirror() {
    return QStringLiteral("https://" "distfiles." "gentoo.org");
}
inline QStringList defaultMirrors() {
    return {
        QStringLiteral("https://" "distfiles." "gentoo.org"),
        QStringLiteral("https://" "mirrors.rit.edu" "/gentoo"),
        QStringLiteral("https://" "gentoo." "osuosl.org")
    };
}
inline QUrl manifestUrl(const QString &mirror, const QString &arch) {
    QString m = mirror.trimmed();
    if (m.isEmpty() || !m.startsWith(QLatin1String("http"))) m = defaultMirror();
    while (m.endsWith('/')) m.chop(1);
    return QUrl(QStringLiteral("%1/releases/%2/autobuilds/latest-stage3.txt").arg(m, arch));
}
inline QString releaseFileUrl(const QString &mirror, const QString &arch, const QString &relPath) {
    QString m = mirror.trimmed();
    if (m.isEmpty() || !m.startsWith(QLatin1String("http"))) m = defaultMirror();
    while (m.endsWith('/')) m.chop(1);
    return QStringLiteral("%1/releases/%2/autobuilds/%3").arg(m, arch, relPath);
}
}
