#include <QInputDialog>
#include "DiskImageWidget.h"
#include <QDateTime>
#include <QDir>
#include <QFileDialog>
#include <QFileInfo>
#include <QFormLayout>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QMessageBox>
#include <QProcess>
#include <QPushButton>
#include <QRegularExpression>
#include <QSplitter>
#include <QVBoxLayout>

DiskImageWidget::DiskImageWidget(QWidget* parent) : QWidget(parent) {
    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(8, 8, 8, 8);
    auto* sp = new QSplitter(Qt::Horizontal, this);
    root->addWidget(sp, 1);

    auto* lw = new QWidget(sp);
    auto* ll = new QVBoxLayout(lw);
    ll->setContentsMargins(0, 0, 0, 0);
    ll->setSpacing(6);

    auto* dbar = new QHBoxLayout();
    m_dirIn = new QLineEdit(QStringLiteral("/var/lib/libvirt/images"), lw);
    auto* bDir = new QPushButton(QIcon::fromTheme(QStringLiteral("folder-open")), QString(), lw);
    auto* bRef = new QPushButton(QIcon::fromTheme(QStringLiteral("view-refresh")), QString(), lw);
    dbar->addWidget(m_dirIn, 1);
    dbar->addWidget(bDir);
    dbar->addWidget(bRef);
    ll->addLayout(dbar);

    m_imgList = new QListWidget(lw);
    ll->addWidget(m_imgList, 1);

    auto* listActs = new QHBoxLayout();
    auto* bPartSel = new QPushButton(QIcon::fromTheme(QStringLiteral("drive-harddisk")), QStringLiteral("Partition"), lw);
    auto* bComp = new QPushButton(QIcon::fromTheme(QStringLiteral("application-x-archive")), QStringLiteral("Compress"), lw);
    auto* bDel = new QPushButton(QIcon::fromTheme(QStringLiteral("edit-delete")), QStringLiteral("Delete"), lw);
    listActs->addWidget(bPartSel);
    listActs->addWidget(bComp);
    listActs->addWidget(bDel);
    ll->addLayout(listActs);
    auto* rw = new QWidget(sp);
    auto* rl = new QVBoxLayout(rw);
    rl->setContentsMargins(0, 0, 0, 0);
    rl->setSpacing(8);
    sp->setSizes({340, 820});

    auto* gbNew = new QGroupBox(QStringLiteral("1. New Disk Image"), rw);
    auto* fNew = new QFormLayout(gbNew);
    fNew->setFieldGrowthPolicy(QFormLayout::ExpandingFieldsGrow);
    m_nameIn = new QLineEdit(QStringLiteral("fragtoo-deck"), gbNew);
    m_nameIn->setPlaceholderText(QStringLiteral("e.g. gentoo-root"));

    auto* specRow = new QHBoxLayout();
    m_fmtCb = new QComboBox(gbNew);
    m_fmtCb->addItems({QStringLiteral("qcow2"), QStringLiteral("raw"), QStringLiteral("vhdx"), QStringLiteral("vpc"), QStringLiteral("vmdk"), QStringLiteral("vdi")});
    m_sizeSpin = new QSpinBox(gbNew);
    m_sizeSpin->setRange(1, 4096);
    m_sizeSpin->setValue(32);
    m_sizeSpin->setSuffix(QStringLiteral(" GiB"));
    specRow->addWidget(m_fmtCb);
    specRow->addWidget(m_sizeSpin);
    specRow->addStretch(1);

    auto* createRow = new QHBoxLayout();
    m_autoPartChk = new QCheckBox(QStringLiteral("Open Partition Manager && Guide"), gbNew);
    m_autoPartChk->setChecked(true);
    auto* bNew = new QPushButton(QIcon::fromTheme(QStringLiteral("drive-harddisk")), QStringLiteral("Create && Partition"), gbNew);
    bNew->setMinimumHeight(30);
    createRow->addWidget(m_autoPartChk);
    createRow->addStretch(1);
    createRow->addWidget(bNew);

    fNew->addRow(QStringLiteral("Name:"), m_nameIn);
    fNew->addRow(QStringLiteral("Format / Size:"), specRow);
    fNew->addRow(QString(), createRow);
    rl->addWidget(gbNew);

    auto* gbMnt = new QGroupBox(QStringLiteral("2. Mount && Chroot"), rw);
    auto* fMnt = new QFormLayout(gbMnt);
    fMnt->setFieldGrowthPolicy(QFormLayout::ExpandingFieldsGrow);
    auto* mntRow = new QHBoxLayout();
    m_mntIn = new QLineEdit(QStringLiteral("/mnt/wakstab-chroot"), gbMnt);
    m_partCb = new QComboBox(gbMnt);
    m_partCb->addItems({QStringLiteral("p2"), QStringLiteral("p1"), QStringLiteral("p3"), QStringLiteral("whole")});
    mntRow->addWidget(m_mntIn, 1);
    mntRow->addWidget(new QLabel(QStringLiteral("Partition:"), gbMnt));
    mntRow->addWidget(m_partCb);
    auto* mntActRow = new QHBoxLayout();
    m_chrootChk = new QCheckBox(QStringLiteral("Bind /proc, /sys, /dev"), gbMnt);
    m_chrootChk->setChecked(true);
    m_archChk = new QCheckBox(QStringLiteral("arch-chroot"), gbMnt);
    auto* bMnt = new QPushButton(QIcon::fromTheme(QStringLiteral("network-connect")), QStringLiteral("Mount"), gbMnt);
    auto* bUmnt = new QPushButton(QIcon::fromTheme(QStringLiteral("network-disconnect")), QStringLiteral("Unmount"), gbMnt);
    mntActRow->addWidget(m_chrootChk); mntActRow->addWidget(m_archChk); mntActRow->addStretch(1); mntActRow->addWidget(bMnt); mntActRow->addWidget(bUmnt);
    fMnt->addRow(QStringLiteral("Target:"), mntRow); fMnt->addRow(QString(), mntActRow);
    rl->addWidget(gbMnt);

    auto* gbSx = new QGroupBox(QStringLiteral("3. System Extension (.raw)"), rw);
    auto* fSx = new QFormLayout(gbSx);
    fSx->setFieldGrowthPolicy(QFormLayout::ExpandingFieldsGrow);
    auto* sxSrcRow = new QHBoxLayout();
    m_sxSrcIn = new QLineEdit(QStringLiteral("/var/tmp/sysext-root"), gbSx);
    auto* bSxDir = new QPushButton(QIcon::fromTheme(QStringLiteral("folder-open")), QString(), gbSx);
    sxSrcRow->addWidget(m_sxSrcIn, 1); sxSrcRow->addWidget(bSxDir);

    auto* sxMetaRow = new QHBoxLayout();
    m_sxNameIn = new QLineEdit(QStringLiteral("fragtoo-extra"), gbSx);
    m_sxOsIdIn = new QLineEdit(QStringLiteral("gentoo"), gbSx); m_sxOsIdIn->setMaximumWidth(110);
    m_sxFmtCb = new QComboBox(gbSx); m_sxFmtCb->addItems({QStringLiteral("squashfs-zstd"), QStringLiteral("erofs-lz4hc")});
    auto* bSxBuild = new QPushButton(QIcon::fromTheme(QStringLiteral("run-build")), QStringLiteral("Build"), gbSx);
    m_bSxInst = new QPushButton(QIcon::fromTheme(QStringLiteral("folder-download")), QStringLiteral("Install"), gbSx);
    m_bSxExp = new QPushButton(QIcon::fromTheme(QStringLiteral("document-export")), QStringLiteral("Export"), gbSx);
    m_bSxInst->setEnabled(false); m_bSxExp->setEnabled(false);
    sxMetaRow->addWidget(m_sxNameIn, 1); sxMetaRow->addWidget(new QLabel(QStringLiteral("OS:"), gbSx)); sxMetaRow->addWidget(m_sxOsIdIn);
    sxMetaRow->addWidget(m_sxFmtCb); sxMetaRow->addWidget(bSxBuild); sxMetaRow->addWidget(m_bSxInst); sxMetaRow->addWidget(m_bSxExp);
    fSx->addRow(QStringLiteral("Root:"), sxSrcRow); fSx->addRow(QStringLiteral("Name:"), sxMetaRow);
    rl->addWidget(gbSx);

    m_log = new QPlainTextEdit(rw); m_log->setReadOnly(true); m_log->setPlaceholderText(QStringLiteral("Command output..."));
    rl->addWidget(m_log, 1);

    connect(bDir, &QPushButton::clicked, this, [this]() {
        QString d = QFileDialog::getExistingDirectory(this, QStringLiteral("Select Image Folder"), m_dirIn->text());
        if (!d.isEmpty()) { m_dirIn->setText(d); refreshImages(); }
    });
    connect(bRef, &QPushButton::clicked, this, &DiskImageWidget::refreshImages);
    connect(bNew, &QPushButton::clicked, this, &DiskImageWidget::createImage);
    connect(bPartSel, &QPushButton::clicked, this, [this]() { attachAndPartition(selectedImage()); });
    connect(bMnt, &QPushButton::clicked, this, &DiskImageWidget::mountImage);
    connect(bUmnt, &QPushButton::clicked, this, &DiskImageWidget::unmountImage);
    connect(bComp, &QPushButton::clicked, this, &DiskImageWidget::zeroAndCompress);
    connect(bDel, &QPushButton::clicked, this, &DiskImageWidget::deleteImage);
    connect(bSxDir, &QPushButton::clicked, this, [this]() {
        QString d = QFileDialog::getExistingDirectory(this, QStringLiteral("Select Sysext Root"), m_sxSrcIn->text());
        if (!d.isEmpty()) m_sxSrcIn->setText(d);
    });
    connect(bSxBuild, &QPushButton::clicked, this, &DiskImageWidget::buildSysextImage);
    connect(m_bSxInst, &QPushButton::clicked, this, &DiskImageWidget::installSysextImage);
    connect(m_bSxExp, &QPushButton::clicked, this, &DiskImageWidget::exportSysextImage);

    auto* advBar = new QHBoxLayout();
    advBar->setSpacing(4);
    auto* bClone = new QPushButton(QIcon::fromTheme(QStringLiteral("drive-harddisk")), QStringLiteral("Clone Disk (New UUIDs)..."), rw);
    auto* bEspSq = new QPushButton(QIcon::fromTheme(QStringLiteral("media-flash")), QStringLiteral("SquashFS ESP Manager..."), rw);
    for (QPushButton* b : {bClone, bEspSq}) {
        b->setMaximumHeight(24);
        b->setSizePolicy(QSizePolicy::Maximum, QSizePolicy::Fixed);
        b->setStyleSheet(QStringLiteral("QPushButton { padding: 2px 8px; font-size: 11px; }"));
        advBar->addWidget(b);
    }
    advBar->addStretch(1);
    rl->addLayout(advBar);
    connect(bClone, &QPushButton::clicked, this, &DiskImageWidget::cloneDiskWithNewUuids);
    connect(bEspSq, &QPushButton::clicked, this, &DiskImageWidget::manageSquashfsEsp);
    refreshImages();
}

bool DiskImageWidget::runCmd(const QString& prog, const QStringList& args) {
    m_log->appendPlainText(QStringLiteral("$ ") + prog + QLatin1Char(' ') + args.join(QLatin1Char(' ')));
    QProcess pr; pr.setProcessChannelMode(QProcess::MergedChannels);
    pr.start(prog, args); pr.waitForFinished(-1);
    QString out = QString::fromUtf8(pr.readAllStandardOutput()).trimmed();
    if (!out.isEmpty()) m_log->appendPlainText(out);
    if (pr.exitCode() != 0) m_log->appendPlainText(QStringLiteral("[exit %1]").arg(pr.exitCode()));
    return pr.exitCode() == 0;
}

QString DiskImageWidget::selectedImage() const {
    auto* it = m_imgList->currentItem();
    return it ? (m_dirIn->text().trimmed() + QLatin1Char('/') + it->text()) : QString();
}

void DiskImageWidget::refreshImages() {
    m_imgList->clear(); QDir d(m_dirIn->text().trimmed());
    if (!d.exists()) return;
    for (const QString& fn : d.entryList({QStringLiteral("*.qcow2"), QStringLiteral("*.raw"), QStringLiteral("*.img"), QStringLiteral("*.vhdx"), QStringLiteral("*.vhd"), QStringLiteral("*.vmdk"), QStringLiteral("*.vdi")}, QDir::Files, QDir::Name))
        m_imgList->addItem(fn);
}

void DiskImageWidget::createImage() {
    QString nm = QFileInfo(m_nameIn->text().trimmed()).fileName();
    if (nm.isEmpty()) return;
    QString fmt = m_fmtCb->currentText(), ext = (fmt == QStringLiteral("vpc")) ? QStringLiteral("vhd") : fmt;
    if (nm.endsWith(QLatin1Char('.') + ext)) nm.chop(ext.size() + 1);
    nm = QStringLiteral("%1-%2.%3").arg(nm).arg(QDateTime::currentSecsSinceEpoch()).arg(ext);
    QDir().mkpath(m_dirIn->text().trimmed());
    QString dst = m_dirIn->text().trimmed() + QLatin1Char('/') + nm;
    if (!runCmd(QStringLiteral("qemu-img"), {QStringLiteral("create"), QStringLiteral("-f"), fmt, dst, QStringLiteral("%1G").arg(m_sizeSpin->value())})) return;
    refreshImages();
    for (int i = 0; i < m_imgList->count(); ++i) {
        if (m_imgList->item(i)->text() == nm) { m_imgList->setCurrentRow(i); break; }
    }
    if (m_autoPartChk && m_autoPartChk->isChecked()) attachAndPartition(dst);
}

DiskImageWidget::~DiskImageWidget() {
    unmountImage();
    detachImageDevices();
}

void DiskImageWidget::detachImageDevices(const QString& imgPath) {
    QString target = imgPath;
    target.replace(QLatin1Char('\''), QStringLiteral("'\\''"));
    QString script = target.isEmpty()
        ? QStringLiteral(R"SH(
            for n in /dev/nbd[0-9]*; do [ -b "$n" ] || continue;
              for mp in $(findmnt -rn -o TARGET -S "$n" 2>/dev/null; findmnt -rn -o TARGET | grep -E '^/mnt/wakstab' || true); do umount -lf "$mp" 2>/dev/null || true; done;
              for pt in "${n}"p*; do [ -b "$pt" ] && umount -lf "$pt" 2>/dev/null || true; done;
              qemu-nbd -d "$n" >/dev/null 2>&1 || true; partx -d "$n" >/dev/null 2>&1 || blockdev --rereadpt "$n" >/dev/null 2>&1 || true;
            done;
            losetup -D >/dev/null 2>&1 || true
          )SH")
        : QStringLiteral(R"SH(
            IMG='%1';
            for pid in $(pgrep -f "qemu-nbd.*$IMG" 2>/dev/null || true); do
              NBD=$(tr '\0' ' ' < /proc/$pid/cmdline 2>/dev/null | grep -oE '/dev/nbd[0-9]+' | head -n1);
              if [ -n "$NBD" ]; then
                for pt in "${NBD}"p* "$NBD"; do [ -b "$pt" ] && umount -lf "$pt" 2>/dev/null || true; done;
                qemu-nbd -d "$NBD" >/dev/null 2>&1 || true; partx -d "$NBD" >/dev/null 2>&1 || blockdev --rereadpt "$NBD" >/dev/null 2>&1 || true;
              fi;
              kill -TERM "$pid" 2>/dev/null || true;
            done;
            for l in $(losetup -j "$IMG" -O NAME --noheadings 2>/dev/null || true); do
              for pt in "${l}"p* "$l"; do [ -b "$pt" ] && umount -lf "$pt" 2>/dev/null || true; done;
              losetup -d "$l" >/dev/null 2>&1 || true;
            done
          )SH").arg(target);
    QProcess::execute(QStringLiteral("sh"), {QStringLiteral("-c"), script});
}

void DiskImageWidget::attachAndPartition(const QString& imgPath) {
    if (imgPath.isEmpty()) return;
    detachImageDevices(imgPath);
    bool isRaw = imgPath.endsWith(QStringLiteral(".raw")) || imgPath.endsWith(QStringLiteral(".img"));
    QProcess pr;
    if (isRaw) pr.start(QStringLiteral("losetup"), {QStringLiteral("--find"), QStringLiteral("--show"), QStringLiteral("--partscan"), imgPath});
    else pr.start(QStringLiteral("sh"), {QStringLiteral("-c"), QStringLiteral(R"SH(modprobe nbd max_part=16 2>/dev/null || true; for n in /dev/nbd0 /dev/nbd1 /dev/nbd2 /dev/nbd3 /dev/nbd4 /dev/nbd5 /dev/nbd6 /dev/nbd7; do b=$(basename $n); [ -b $n ] || continue; [ $(cat /sys/block/$b/size 2>/dev/null || echo 1) -eq 0 ] || continue; if qemu-nbd -c $n '%1'; then sleep 1; partprobe $n 2>/dev/null || true; echo $n; break; fi; done)SH").arg(imgPath)});
    pr.waitForFinished(10000);
    QString dev = QString::fromUtf8(pr.readAllStandardOutput()).trimmed().section(QLatin1Char('\n'), -1);
    if (!QRegularExpression(QStringLiteral("^/dev/(nbd|loop)[0-9]+$")).match(dev).hasMatch()) {
        detachImageDevices(imgPath);
        QMessageBox::critical(this, QStringLiteral("Safety Lockout"), QStringLiteral("Refusing non-virtual block device '%1'. Only /dev/nbd* or /dev/loop* are permitted.").arg(dev));
        return;
    }
    m_log->appendPlainText(QStringLiteral("Safely attached virtual device %1 -> %2").arg(imgPath, dev));
    Q_EMIT openInPartitionManagerRequested(dev, imgPath);
}

void DiskImageWidget::mountImage() {
    QString img = selectedImage(); if (img.isEmpty()) return;
    unmountImage();
    detachImageDevices(img);
    QString mnt = m_mntIn->text().trimmed(), part = m_partCb->currentText(); QDir().mkpath(mnt);
    bool isRaw = img.endsWith(QStringLiteral(".raw")) || img.endsWith(QStringLiteral(".img"));
    QString script = isRaw
        ? QStringLiteral(R"SH(set -e; DEV=''; LOOP=''; cleanup(){ umount -lf '%3' 2>/dev/null || true; [ -n "$LOOP" ] && losetup -d "$LOOP" 2>/dev/null || true; }; trap cleanup ERR; LOOP=$(losetup --find --show --partscan '%1'); DEV="${LOOP}%2"; [ '%2' = 'whole' ] && DEV="$LOOP"; mount "$DEV" '%3')SH").arg(img, part, mnt)
        : QStringLiteral(R"SH(set -e; NBD=''; cleanup(){ for sub in dev/pts dev sys proc run; do umount -lf '%3/'"$sub" 2>/dev/null || true; done; umount -lf '%3' 2>/dev/null || true; [ -n "$NBD" ] && qemu-nbd -d "$NBD" 2>/dev/null || true; }; trap cleanup ERR; modprobe nbd max_part=16; for n in /dev/nbd0 /dev/nbd1 /dev/nbd2 /dev/nbd3 /dev/nbd4 /dev/nbd5 /dev/nbd6 /dev/nbd7; do b=$(basename $n); [ -b $n ] || continue; [ $(cat /sys/block/$b/size 2>/dev/null || echo 1) -eq 0 ] || continue; qemu-nbd -c $n '%1' && NBD=$n && break; done; [ -n "$NBD" ]; sleep 1; partprobe "$NBD" 2>/dev/null || true; DEV="${NBD}%2"; [ '%2' = 'whole' ] && DEV="$NBD"; mount "$DEV" '%3')SH").arg(img, part, mnt);
    if (m_chrootChk->isChecked() || m_archChk->isChecked())
        script += QStringLiteral(R"SH(; mkdir -p '%1'/{proc,sys,dev,dev/pts,run,etc}; mount -t proc /proc '%1/proc'; mount --rbind /sys '%1/sys'; mount --make-rslave '%1/sys'; mount --rbind /dev '%1/dev'; mount --make-rslave '%1/dev'; mount --bind /run '%1/run'; cp -L /etc/resolv.conf '%1/etc/resolv.conf' 2>/dev/null || true)SH").arg(mnt);
    if (!runCmd(QStringLiteral("sh"), {QStringLiteral("-c"), script})) {
        unmountImage();
        detachImageDevices(img);
    }
}

void DiskImageWidget::unmountImage() {
    QString mnt = m_mntIn->text().trimmed();
    if (!mnt.isEmpty()) {
        QString script = QStringLiteral(R"SH(for sub in dev/pts dev sys proc run; do umount -lf '%1/'"$sub" 2>/dev/null || true; done; SRC=$(findmnt -n -o SOURCE '%1' 2>/dev/null); umount -lf '%1' 2>/dev/null || true; case "$SRC" in /dev/nbd*) qemu-nbd -d "${SRC%%p[0-9]*}" 2>/dev/null || true ;; /dev/loop*) losetup -d "${SRC%%p[0-9]*}" 2>/dev/null || true ;; esac)SH").arg(mnt);
        runCmd(QStringLiteral("sh"), {QStringLiteral("-c"), script});
    }
    QString img = selectedImage();
    if (!img.isEmpty()) detachImageDevices(img);
}

void DiskImageWidget::zeroAndCompress() {
    QString img = selectedImage(); if (img.isEmpty()) return;
    if (QMessageBox::question(this, QStringLiteral("Compress Image"), QStringLiteral("Zero free space inside %1 and compress?").arg(QFileInfo(img).fileName())) != QMessageBox::Yes) return;
    unmountImage();
    detachImageDevices(img);
    QString mnt = m_mntIn->text().trimmed(), part = m_partCb->currentText(); QDir().mkpath(mnt);
    bool isRaw = img.endsWith(QStringLiteral(".raw")) || img.endsWith(QStringLiteral(".img"));
    QString fmt = img.endsWith(QStringLiteral(".vhd")) ? QStringLiteral("vpc") : QFileInfo(img).suffix();
    QString zeroStep = isRaw
        ? QStringLiteral(R"SH(set -e; LOOP=''; cleanup(){ umount -lf '%3' 2>/dev/null || true; [ -n "$LOOP" ] && losetup -d "$LOOP" 2>/dev/null || true; }; trap cleanup EXIT; LOOP=$(losetup --find --show --partscan '%1'); DEV="${LOOP}%2"; [ '%2' = 'whole' ] && DEV="$LOOP"; mount "$DEV" '%3' && { fstrim -v '%3' 2>/dev/null || true; dd if=/dev/zero of='%3/.zero.fill' bs=16M status=none 2>/dev/null || true; rm -f '%3/.zero.fill'; sync; umount '%3'; }; losetup -d "$LOOP"; LOOP=''; fallocate -d '%1')SH").arg(img, part, mnt)
        : QStringLiteral(R"SH(set -e; NBD=''; cleanup(){ umount -lf '%3' 2>/dev/null || true; [ -n "$NBD" ] && qemu-nbd -d "$NBD" 2>/dev/null || true; rm -f '%1.tmp'; }; trap cleanup EXIT; modprobe nbd max_part=16; for n in /dev/nbd0 /dev/nbd1 /dev/nbd2 /dev/nbd3 /dev/nbd4 /dev/nbd5 /dev/nbd6 /dev/nbd7; do b=$(basename $n); [ -b $n ] || continue; [ $(cat /sys/block/$b/size 2>/dev/null || echo 1) -eq 0 ] || continue; qemu-nbd -c $n '%1' && NBD=$n && break; done; [ -n "$NBD" ]; sleep 1; partprobe "$NBD" 2>/dev/null || true; DEV="${NBD}%2"; [ '%2' = 'whole' ] && DEV="$NBD"; mount "$DEV" '%3' && { fstrim -v '%3' 2>/dev/null || true; dd if=/dev/zero of='%3/.zero.fill' bs=16M status=none 2>/dev/null || true; rm -f '%3/.zero.fill'; sync; umount '%3'; }; qemu-nbd -d "$NBD"; NBD=''; qemu-img convert -p -O %4 -c '%1' '%1.tmp' && mv -f '%1.tmp' '%1')SH").arg(img, part, mnt, fmt);
    runCmd(QStringLiteral("sh"), {QStringLiteral("-c"), zeroStep}); refreshImages();
}

void DiskImageWidget::deleteImage() {
    QString img = selectedImage(); if (img.isEmpty()) return;
    if (QMessageBox::question(this, QStringLiteral("Delete Image"), QStringLiteral("Unmount, detach NBD/loop devices, and delete %1?").arg(QFileInfo(img).fileName())) != QMessageBox::Yes) return;
    unmountImage();
    detachImageDevices(img);
    if (!QFile::remove(img)) {
        QMessageBox::warning(this, QStringLiteral("Delete Failed"), QStringLiteral("Could not delete %1 — device may still be busy.").arg(img));
    }
    refreshImages();
}

void DiskImageWidget::buildSysextImage() {
    QString src = m_sxSrcIn->text().trimmed(), nm = m_sxNameIn->text().trimmed(), osId = m_sxOsIdIn->text().trimmed();
    if (src.isEmpty() || nm.isEmpty() || !QDir(src).exists()) {
        QMessageBox::warning(this, QStringLiteral("Invalid Source"), QStringLiteral("Check source directory and name.")); return;
    }
    QString relDir = src + QStringLiteral("/usr/lib/extension-release.d"); QDir().mkpath(relDir);
    QFile rf(relDir + QStringLiteral("/extension-release.") + nm);
    if (rf.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
        rf.write(QStringLiteral("ID=%1\nSYSEXT_LEVEL=1.0\nARCHITECTURE=x86-64\n").arg(osId.isEmpty() ? QStringLiteral("_any") : osId).toUtf8());
        rf.close();
    }
    QString outDir = m_dirIn->text().trimmed(); QDir().mkpath(outDir);
    QString outImg = QStringLiteral("%1/%2-%3.raw").arg(outDir, nm).arg(QDateTime::currentSecsSinceEpoch());
    QString cmd = (m_sxFmtCb->currentText() == QStringLiteral("erofs-lz4hc"))
        ? QStringLiteral("chown -R root:root '%1' && rm -f '%2' && mkfs.erofs -zlz4hc '%2' '%1'").arg(src, outImg)
        : QStringLiteral("chown -R root:root '%1' && rm -f '%2' && mksquashfs '%1' '%2' -comp zstd -Xcompression-level 19 -noappend").arg(src, outImg);
    if (runCmd(QStringLiteral("sh"), {QStringLiteral("-c"), cmd})) { m_lastSysextImg = outImg; m_bSxInst->setEnabled(true); m_bSxExp->setEnabled(true); }
    refreshImages();
}

void DiskImageWidget::installSysextImage() {
    if (m_lastSysextImg.isEmpty() || !QFile::exists(m_lastSysextImg)) return;
    QString base = QFileInfo(m_lastSysextImg).fileName().replace(QRegularExpression(QStringLiteral("-[0-9]+\\.raw$")), QStringLiteral(".raw"));
    QString dst = QStringLiteral("/var/lib/extensions/") + base;
    runCmd(QStringLiteral("sh"), {QStringLiteral("-c"), QStringLiteral("mkdir -p /var/lib/extensions && cp -f '%1' '%2' && systemd-sysext refresh").arg(m_lastSysextImg, dst)});
}

void DiskImageWidget::exportSysextImage() {
    if (m_lastSysextImg.isEmpty() || !QFile::exists(m_lastSysextImg)) return;
    QString dst = QFileDialog::getSaveFileName(this, QStringLiteral("Export Sysext Image"), QDir::homePath() + QLatin1Char('/') + QFileInfo(m_lastSysextImg).fileName(), QStringLiteral("Raw Image (*.raw)"));
    if (!dst.isEmpty()) runCmd(QStringLiteral("cp"), {QStringLiteral("-f"), m_lastSysextImg, dst});
}

void DiskImageWidget::prepareAndMountChroot(const QString& rootPart, bool bindChroot) {
    int idx = m_partCb->findText(rootPart);
    if (idx >= 0) m_partCb->setCurrentIndex(idx);
    if (m_chrootChk) m_chrootChk->setChecked(bindChroot);
    mountImage();
}

void DiskImageWidget::provisionHandsOffVirtualDisk() {
    QDialog dlg(this);
    dlg.setWindowTitle(QStringLiteral("Hands-Off NBD Virtual Disk Provisioner"));
    auto *fl = new QFormLayout(&dlg);
    auto *fmtCb = new QComboBox(&dlg); fmtCb->addItems({QStringLiteral("qcow2"), QStringLiteral("raw"), QStringLiteral("vmdk"), QStringLiteral("vhdx"), QStringLiteral("vdi")});
    auto *szSp = new QSpinBox(&dlg); szSp->setRange(4, 2048); szSp->setValue(32); szSp->setSuffix(QStringLiteral(" GiB"));
    auto *fsCb = new QComboBox(&dlg); fsCb->addItems({QStringLiteral("ext4"), QStringLiteral("btrfs"), QStringLiteral("xfs")});
    auto *nmIn = new QLineEdit(QStringLiteral("gentoo-root"), &dlg);
    fl->addRow(QStringLiteral("Image Name:"), nmIn);
    fl->addRow(QStringLiteral("Container Format:"), fmtCb);
    fl->addRow(QStringLiteral("Virtual Size:"), szSp);
    fl->addRow(QStringLiteral("Root Filesystem:"), fsCb);
    auto *bb = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, &dlg);
    connect(bb, &QDialogButtonBox::accepted, &dlg, &QDialog::accept);
    connect(bb, &QDialogButtonBox::rejected, &dlg, &QDialog::reject);
    fl->addRow(bb);
    if (dlg.exec() != QDialog::Accepted) return;

    const QString outDir = m_dirIn->text().trimmed(); QDir().mkpath(outDir);
    const QString fmt = fmtCb->currentText();
    const QString dst = QStringLiteral("%1/%2.%3").arg(outDir, nmIn->text().trimmed(), fmt);
    const QString fs = fsCb->currentText();
    const int gb = szSp->value();
    const QString mnt = m_mntIn->text().trimmed(); QDir().mkpath(mnt);
    detachImageDevices(dst);

    QString script = (fmt == QStringLiteral("raw"))
        ? QStringLiteral(R"SH(set -e; LOOP=''; cleanup(){ umount -lf '%4' 2>/dev/null || true; [ -n "$LOOP" ] && losetup -d "$LOOP" 2>/dev/null || true; }; trap cleanup ERR; truncate -s %2G '%1'; LOOP=$(losetup --find --show --partscan '%1'); parted -s "$LOOP" mklabel gpt mkpart ESP fat32 1MiB 513MiB set 1 esp on mkpart primary %3 513MiB 100%%; partprobe "$LOOP"; sleep 1; mkfs.vfat -F32 "${LOOP}p1"; mkfs.%3 -F "${LOOP}p2" 2>/dev/null || mkfs.%3 -f "${LOOP}p2"; mount "${LOOP}p2" '%4'; mkdir -p '%4/boot/efi'; mount "${LOOP}p1" '%4/boot/efi')SH").arg(dst).arg(gb).arg(fs, mnt)
        : QStringLiteral(R"SH(set -e; NBD=''; cleanup(){ umount -lf '%4/boot/efi' 2>/dev/null || true; umount -lf '%4' 2>/dev/null || true; [ -n "$NBD" ] && qemu-nbd -d "$NBD" 2>/dev/null || true; }; trap cleanup ERR; qemu-img create -f %5 '%1' %2G; modprobe nbd max_part=16; for n in /dev/nbd0 /dev/nbd1 /dev/nbd2 /dev/nbd3 /dev/nbd4 /dev/nbd5 /dev/nbd6 /dev/nbd7; do b=$(basename $n); [ -b $n ] || continue; [ $(cat /sys/block/$b/size 2>/dev/null || echo 1) -eq 0 ] || continue; qemu-nbd -c $n '%1' && NBD=$n && break; done; [ -n "$NBD" ]; parted -s "$NBD" mklabel gpt mkpart ESP fat32 1MiB 513MiB set 1 esp on mkpart primary %3 513MiB 100%%; partprobe "$NBD"; sleep 1; mkfs.vfat -F32 "${NBD}p1"; mkfs.%3 -F "${NBD}p2" 2>/dev/null || mkfs.%3 -f "${NBD}p2"; mount "${NBD}p2" '%4'; mkdir -p '%4/boot/efi'; mount "${NBD}p1" '%4/boot/efi')SH").arg(dst).arg(gb).arg(fs, mnt, fmt);
    if (!runCmd(QStringLiteral("sh"), {QStringLiteral("-c"), script})) detachImageDevices(dst);
    refreshImages();
}

void DiskImageWidget::cloneDiskWithNewUuids() {
    QProcess ls; ls.start(QStringLiteral("lsblk"), {QStringLiteral("-dpno"), QStringLiteral("NAME,SIZE,MODEL")});
    ls.waitForFinished(2000);
    const QStringList disks = QString::fromUtf8(ls.readAllStandardOutput()).split(QLatin1Char('\n'), Qt::SkipEmptyParts);
    if (disks.size() < 2) { QMessageBox::warning(this, QStringLiteral("Clone Disk"), QStringLiteral("At least two block devices are required.")); return; }

    QDialog dlg(this); dlg.setWindowTitle(QStringLiteral("Clone Entire Disk (Randomize UUIDs & Fix fstab/Boot)"));
    auto* fl = new QFormLayout(&dlg);
    auto* srcCb = new QComboBox(&dlg); srcCb->addItems(disks);
    auto* dstCb = new QComboBox(&dlg); dstCb->addItems(disks); dstCb->setCurrentIndex(1);
    fl->addRow(QStringLiteral("Source Disk:"), srcCb);
    fl->addRow(QStringLiteral("Target SSD (WIPED):"), dstCb);
    auto* bb = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, &dlg);
    connect(bb, &QDialogButtonBox::accepted, &dlg, &QDialog::accept);
    connect(bb, &QDialogButtonBox::rejected, &dlg, &QDialog::reject);
    fl->addRow(bb);
    if (dlg.exec() != QDialog::Accepted) return;

    const QString src = srcCb->currentText().section(QLatin1Char(' '), 0, 0);
    const QString dst = dstCb->currentText().section(QLatin1Char(' '), 0, 0);
    if (src == dst) { QMessageBox::critical(this, QStringLiteral("Safety Lockout"), QStringLiteral("Source and target disk cannot be the same device.")); return; }
    if (QMessageBox::warning(this, QStringLiteral("Confirm Disk Wipe"), QStringLiteral("ALL DATA on %1 will be destroyed and replaced with a clone of %2 (with fresh UUIDs & PARTUUIDs). Continue?").arg(dst, src), QMessageBox::Yes | QMessageBox::No) != QMessageBox::Yes) return;

    QString script = QStringLiteral(R"SH(
set -e
SRC='%1'; DST='%2'
umount -lf "${DST}"* 2>/dev/null || true
swapoff "${DST}"* 2>/dev/null || true
sgdisk --zap-all "$DST"
sgdisk --replicate="$DST" "$SRC"
sgdisk --randomize-guids "$DST"
partprobe "$DST"; udevadm settle
mapfile -t SPARTS < <(lsblk -rno NAME "$SRC" | tail -n +2 | sed 's|^|/dev/|')
mapfile -t DPARTS < <(lsblk -rno NAME "$DST" | tail -n +2 | sed 's|^|/dev/|')
declare -A UUID_MAP PARTUUID_MAP
ROOT_DST=""; ESP_DST=""
for i in "${!SPARTS[@]}"; do
  SP="${SPARTS[$i]}"; DP="${DPARTS[$i]}"
  FST=$(blkid -s TYPE -o value "$SP" || true)
  OU=$(blkid -s UUID -o value "$SP" || true)
  OPU=$(blkid -s PARTUUID -o value "$SP" || true)
  case "$FST" in
    vfat) mkfs.vfat -F32 "$DP"; ESP_DST="$DP" ;;
    ext4) mkfs.ext4 -F "$DP" ;;
    btrfs) mkfs.btrfs -f "$DP" ;;
    xfs) mkfs.xfs -f "$DP" ;;
    swap) mkswap "$DP" ;;
  esac
  udevadm settle
  NU=$(blkid -s UUID -o value "$DP" || true)
  NPU=$(blkid -s PARTUUID -o value "$DP" || true)
  [ -n "$OU" ] && [ -n "$NU" ] && UUID_MAP["$OU"]="$NU"
  [ -n "$OPU" ] && [ -n "$NPU" ] && PARTUUID_MAP["$OPU"]="$NPU"
  SMP=$(findmnt -rn -o TARGET -S "$SP" | head -n1 || true)
  [ "$SMP" = "/" ] && ROOT_DST="$DP"
done
mkdir -p /mnt/gentool-clone-src /mnt/gentool-clone-dst
for i in "${!SPARTS[@]}"; do
  SP="${SPARTS[$i]}"; DP="${DPARTS[$i]}"
  FST=$(blkid -s TYPE -o value "$SP" || true)
  [ "$FST" = "swap" ] || [ -z "$FST" ] && continue
  mount -o ro "$SP" /mnt/gentool-clone-src
  mount "$DP" /mnt/gentool-clone-dst
  rsync -aHAXx --numeric-owner --exclude='/proc/*' --exclude='/sys/*' --exclude='/dev/*' --exclude='/run/*' --exclude='/tmp/*' --exclude='/mnt/*' --exclude='/var/tmp/portage/*' /mnt/gentool-clone-src/ /mnt/gentool-clone-dst/
  umount /mnt/gentool-clone-src; umount /mnt/gentool-clone-dst
done
if [ -n "$ROOT_DST" ]; then
  mount "$ROOT_DST" /mnt/gentool-clone-dst
  [ -n "$ESP_DST" ] && mkdir -p /mnt/gentool-clone-dst/boot/efi && mount "$ESP_DST" /mnt/gentool-clone-dst/boot/efi || true
  for f in /mnt/gentool-clone-dst/etc/fstab /mnt/gentool-clone-dst/boot/loader/entries/*.conf /mnt/gentool-clone-dst/boot/grub/grub.cfg; do
    [ -f "$f" ] || continue
    for k in "${!UUID_MAP[@]}"; do sed -i "s|$k|${UUID_MAP[$k]}|g" "$f"; done
    for k in "${!PARTUUID_MAP[@]}"; do sed -i "s|$k|${PARTUUID_MAP[$k]}|g" "$f"; done
  done
  umount -lf /mnt/gentool-clone-dst/boot/efi 2>/dev/null || true
  umount -lf /mnt/gentool-clone-dst
fi
echo "Clone complete with randomized UUIDs & updated fstab/boot entries!"
)SH").arg(src, dst);
    runCmd(QStringLiteral("sh"), {QStringLiteral("-c"), script});
}

void DiskImageWidget::manageSquashfsEsp() {
    const QString espDir = QDir(QStringLiteral("/boot/efi")).exists() ? QStringLiteral("/boot/efi") : QStringLiteral("/efi");
    const QString storeDir = QStringLiteral("/var/lib/gentool-ng/esp-profiles");
    QDir().mkpath(storeDir);

    QDialog dlg(this); dlg.setWindowTitle(QStringLiteral("SquashFS ESP Profile & Dual-Boot Manager"));
    auto* lay = new QVBoxLayout(&dlg);
    auto* info = new QLabel(QStringLiteral("Active ESP: %1  |  Profile Store: %2").arg(espDir, storeDir), &dlg);
    lay->addWidget(info);

    auto* list = new QListWidget(&dlg);
    list->addItems(QDir(storeDir).entryList({QStringLiteral("*.sqfs")}, QDir::Files));
    lay->addWidget(list);

    auto* row = new QHBoxLayout();
    auto* bPack = new QPushButton(QIcon::fromTheme(QStringLiteral("archive-insert")), QStringLiteral("Pack Current ESP -> .sqfs"), &dlg);
    auto* bMntLive = new QPushButton(QIcon::fromTheme(QStringLiteral("media-mount")), QStringLiteral("Mount .sqfs Over ESP (Live)"), &dlg);
    auto* bDeployBoot = new QPushButton(QIcon::fromTheme(QStringLiteral("system-reboot")), QStringLiteral("Deploy .sqfs to FAT32 ESP (Boot)"), &dlg);
    auto* bBootPersist = new QPushButton(QIcon::fromTheme(QStringLiteral("preferences-system")), QStringLiteral("Auto-Mount at Boot"), &dlg);
    for (QPushButton* b : {bPack, bMntLive, bDeployBoot, bBootPersist}) {
        b->setMaximumHeight(24);
        b->setStyleSheet(QStringLiteral("QPushButton { padding: 2px 8px; font-size: 11px; }"));
        row->addWidget(b);
    }
    lay->addLayout(row);

    connect(bPack, &QPushButton::clicked, &dlg, [&]() {
        bool ok = false;
        QString nm = QInputDialog::getText(&dlg, QStringLiteral("Pack ESP"), QStringLiteral("Profile name:"), QLineEdit::Normal, QStringLiteral("wakstab-default"), &ok);
        if (!ok || nm.trimmed().isEmpty()) return;
        const QString out = storeDir + QLatin1Char('/') + nm.trimmed() + QStringLiteral(".sqfs");
        runCmd(QStringLiteral("sh"), {QStringLiteral("-c"), QStringLiteral("rm -f '%1' && mksquashfs '%2' '%1' -comp zstd -noappend").arg(out, espDir)});
        list->clear(); list->addItems(QDir(storeDir).entryList({QStringLiteral("*.sqfs")}, QDir::Files));
    });
    connect(bMntLive, &QPushButton::clicked, &dlg, [&]() {
        if (!list->currentItem()) return;
        const QString sq = storeDir + QLatin1Char('/') + list->currentItem()->text();
        runCmd(QStringLiteral("sh"), {QStringLiteral("-c"), QStringLiteral("mountpoint -q '%1' && umount -lf '%1' || true; mount -t squashfs -o loop,ro '%2' '%1'").arg(espDir, sq)});
    });
    connect(bDeployBoot, &QPushButton::clicked, &dlg, [&]() {
        if (!list->currentItem()) return;
        const QString sq = storeDir + QLatin1Char('/') + list->currentItem()->text();
        runCmd(QStringLiteral("sh"), {QStringLiteral("-c"), QStringLiteral("set -e; TMP=$(mktemp -d); trap 'umount -lf \"$TMP\" 2>/dev/null; rmdir \"$TMP\" 2>/dev/null' EXIT; while mountpoint -q '%1' && [ \"$(findmnt -no FSTYPE '%1')\" = 'squashfs' ]; do umount -lf '%1'; done; mount '%1' 2>/dev/null || true; mount -t squashfs -o loop,ro '%2' \"$TMP\"; rsync -a --delete \"$TMP/\" '%1/'").arg(espDir, sq)});
    });
    connect(bBootPersist, &QPushButton::clicked, &dlg, [&]() {
        if (!list->currentItem()) return;
        const QString sq = storeDir + QLatin1Char('/') + list->currentItem()->text();
        QString script = QStringLiteral("#!/bin/sh\nmount -t squashfs -o loop,ro '%1' '%2'\n").arg(sq, espDir);
        QFile f(QStringLiteral("/etc/local.d/90-gentool-ng-esp.start"));
        if (f.open(QIODevice::WriteOnly | QIODevice::Truncate)) { f.write(script.toUtf8()); f.setPermissions(QFileDevice::ReadOwner | QFileDevice::WriteOwner | QFileDevice::ExeOwner | QFileDevice::ReadGroup | QFileDevice::ExeGroup | QFileDevice::ReadOther | QFileDevice::ExeOther); }
        QMessageBox::information(&dlg, QStringLiteral("Boot Hook Installed"), QStringLiteral("Installed /etc/local.d/90-gentool-ng-esp.start to mount %1 onto %2 at boot.").arg(sq, espDir));
    });
    dlg.exec();
}

void DiskImageWidget::runStreamlinedNoviceInstall() {
    QStringList drives;
    for (const QString& b : QDir(QStringLiteral("/sys/block")).entryList({QStringLiteral("nbd[0-9]*")}, QDir::Dirs)) {
        QFile szFile(QStringLiteral("/sys/block/%1/size").arg(b));
        if (szFile.open(QIODevice::ReadOnly)) {
            const quint64 sectors = szFile.readAll().trimmed().toULongLong();
            if (sectors > 0) {
                const double gib = (sectors * 512.0) / (1024.0 * 1024.0 * 1024.0);
                drives.append(QStringLiteral("/dev/%1  %2 GiB  [NBD Smoke-Test Target]").arg(b).arg(gib, 0, 'f', 1));
            }
        }
    }
    QProcess ls; ls.start(QStringLiteral("lsblk"), {QStringLiteral("-dpno"), QStringLiteral("NAME,SIZE,MODEL")});
    ls.waitForFinished(2000);
    for (const QString& ln : QString::fromUtf8(ls.readAllStandardOutput()).split(QLatin1Char('\n'), Qt::SkipEmptyParts)) {
        if (ln.startsWith(QStringLiteral("/dev/loop")) || ln.startsWith(QStringLiteral("/dev/nbd"))) continue;
        drives.append(ln.simplified());
    }
    if (drives.isEmpty()) { QMessageBox::warning(this, QStringLiteral("Guided Install"), QStringLiteral("No target physical drives detected.")); return; }

    QStringList tarballs = QDir(QStringLiteral("/tmp")).entryList({QStringLiteral("stage3-*.tar.*")}, QDir::Files, QDir::Time);
    QDialog dlg(this); dlg.setWindowTitle(QStringLiteral("Guided Gentoo Install (Safe Defaults)"));
    auto* fl = new QFormLayout(&dlg);
    auto* drvCb = new QComboBox(&dlg); drvCb->addItems(drives);
    auto* fsCb = new QComboBox(&dlg); fsCb->addItems({QStringLiteral("ext4"), QStringLiteral("btrfs"), QStringLiteral("xfs")});
    auto* szSp = new QSpinBox(&dlg); szSp->setRange(8, 512); szSp->setValue(24); szSp->setSuffix(QStringLiteral(" GiB"));
    auto* stgCb = new QComboBox(&dlg); stgCb->setEditable(true);
    for (const QString& t : tarballs) stgCb->addItem(QStringLiteral("/tmp/") + t);
    fl->addRow(QStringLiteral("Target Physical Drive:"), drvCb);
    fl->addRow(QStringLiteral("Root Filesystem:"), fsCb);
    fl->addRow(QStringLiteral("Image Build Size:"), szSp);
    fl->addRow(QStringLiteral("Stage3 Tarball:"), stgCb);
    auto* bb = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, &dlg);
    connect(bb, &QDialogButtonBox::accepted, &dlg, &QDialog::accept);
    connect(bb, &QDialogButtonBox::rejected, &dlg, &QDialog::reject);
    fl->addRow(bb);
    if (dlg.exec() != QDialog::Accepted) return;

    const QString drvFull = drvCb->currentText();
    const QString drvDev = drvFull.section(QLatin1Char(' '), 0, 0);
    const QString stage3 = stgCb->currentText().trimmed();
    if (stage3.isEmpty() || !QFile::exists(stage3)) {
        QMessageBox::warning(this, QStringLiteral("Missing Stage3"), QStringLiteral("Download & verify a Stage3 tarball in Step 3 first."));
        return;
    }

    const QString rawImg = QStringLiteral("/var/tmp/gentool-ng-novice.raw");
    const QString mnt = QStringLiteral("/mnt/gentool-novice-stage");
    QString buildScript = QStringLiteral(R"SH(
set -e
LOOP=''; MNT='%4'; RAW='%1'
cleanup(){ umount -lf "$MNT/boot/efi" 2>/dev/null || true; umount -lf "$MNT" 2>/dev/null || true; [ -n "$LOOP" ] && losetup -d "$LOOP" 2>/dev/null || true; }
trap cleanup EXIT
rm -f "$RAW"; mkdir -p "$MNT"
truncate -s %2G "$RAW"
LOOP=$(losetup --find --show --partscan "$RAW")
parted -s "$LOOP" mklabel gpt mkpart ESP fat32 1MiB 513MiB set 1 esp on mkpart primary %3 513MiB 100%%
partprobe "$LOOP"; udevadm settle
mkfs.vfat -F32 "${LOOP}p1"
mkfs.%3 -F "${LOOP}p2" 2>/dev/null || mkfs.%3 -f "${LOOP}p2"
udevadm settle
mount "${LOOP}p2" "$MNT"
mkdir -p "$MNT/boot/efi"
mount "${LOOP}p1" "$MNT/boot/efi"
tar xpf '%5' --xattrs-include='*.*' --numeric-owner -C "$MNT"
RUUID=$(blkid -s UUID -o value "${LOOP}p2")
EUUID=$(blkid -s UUID -o value "${LOOP}p1")
printf "UUID=%s\t/\t%3\tdefaults,noatime\t0 1\nUUID=%s\t/boot/efi\tvfat\tumask=0077\t0 2\n" "$RUUID" "$EUUID" > "$MNT/etc/fstab"
sync
)SH").arg(rawImg).arg(szSp->value()).arg(fsCb->currentText(), mnt, stage3);

    if (!runCmd(QStringLiteral("sh"), {QStringLiteral("-c"), buildScript})) { QFile::remove(rawImg); return; }

    auto confirm = QMessageBox::warning(this, QStringLiteral("Final Target Drive Confirmation"),
        QStringLiteral("Staging image built & verified cleanly.\n\nWrite image directly to target drive:\n%1\n\nALL EXISTING DATA ON %2 WILL BE OVERWRITTEN. Proceed with dd?").arg(drvFull, drvDev),
        QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
    if (confirm == QMessageBox::Yes) {
        runCmd(QStringLiteral("sh"), {QStringLiteral("-c"), QStringLiteral("umount -lf '%2'* 2>/dev/null || true; dd if='%1' of='%2' bs=16M status=progress conv=fsync && partprobe '%2'").arg(rawImg, drvDev)});
    }
    QFile::remove(rawImg);
}

void DiskImageWidget::runGuidedBaseSystemBuild(const QString& chrootDir, const QString& hostname, const QString& timezone, const QString& rootPass, const QString& bootLoader, bool useSystemd) {
    const QString dir = chrootDir.trimmed().isEmpty() ? QStringLiteral("/mnt/wakstab-chroot") : chrootDir.trimmed();
    const QString host = hostname.trimmed().isEmpty() ? QStringLiteral("gentoo-wakstab") : hostname.trimmed();
    const QString tz = timezone.trimmed().isEmpty() ? QStringLiteral("America/New_York") : timezone.trimmed();
    QString escPass = rootPass; escPass.replace(QLatin1Char('\''), QStringLiteral("'\\''"));

    QString script = QStringLiteral(R"SH(
set -e
MNT='%1'; HOST='%2'; TZ='%3'; PASS='%4'; BL='%5'; SYSD='%6'
mkdir -p "$MNT"/{proc,sys,dev,dev/pts,run,etc}
mountpoint -q "$MNT/proc" || mount -t proc /proc "$MNT/proc"
mountpoint -q "$MNT/sys" || { mount --rbind /sys "$MNT/sys"; mount --make-rslave "$MNT/sys"; }
mountpoint -q "$MNT/dev" || { mount --rbind /dev "$MNT/dev"; mount --make-rslave "$MNT/dev"; }
mountpoint -q "$MNT/run" || mount --bind /run "$MNT/run"
cp -L /etc/resolv.conf "$MNT/etc/resolv.conf" 2>/dev/null || true

chroot "$MNT" /bin/bash -c "
set -e
env-update && source /etc/profile
emerge-webrsync
echo '$TZ' > /etc/timezone
emerge --config sys-libs/timezone-data
sed -i 's/^#en_US.UTF-8/en_US.UTF-8/' /etc/locale.gen
locale-gen
eselect locale set en_US.utf8 || true
env-update && source /etc/profile
mkdir -p /etc/portage/package.license
echo '*/* @BINARY-REDISTRIBUTABLE' > /etc/portage/package.license/wakstab-wizard
emerge --getbinpkg --usepkg sys-kernel/linux-firmware sys-kernel/gentoo-kernel-bin net-misc/dhcpcd
echo '$HOST' > /etc/hostname
if [ '$SYSD' = '1' ]; then
  systemd-machine-id-setup || true
  systemctl enable systemd-networkd systemd-resolved dhcpcd 2>/dev/null || true
else
  echo 'hostname=\"$HOST\"' > /etc/conf.d/hostname
  rc-update add dhcpcd default 2>/dev/null || true
fi
[ -n '$PASS' ] && echo 'root:$PASS' | chpasswd
if [ '$BL' = 'systemd-boot' ]; then
  bootctl --esp-path=/boot/efi install || true
else
  emerge --getbinpkg --usepkg sys-boot/grub
  grub-install --target=x86_64-efi --efi-directory=/boot/efi --removable
  grub-mkconfig -o /boot/grub/grub.cfg
fi
"
echo "Guided Gentoo Base System build completed inside $MNT!"
)SH").arg(dir, host, tz, escPass, bootLoader, useSystemd ? QStringLiteral("1") : QStringLiteral("0"));
    runCmd(QStringLiteral("sh"), {QStringLiteral("-c"), script});
}

bool DiskImageWidget::prepareStagingRawMount(const QString& mntDir, const QString& fsType, int sizeGb) {
    const QString mnt = mntDir.trimmed().isEmpty() ? QStringLiteral("/mnt/wakstab-chroot") : mntDir.trimmed();
    const QString rawImg = QStringLiteral("/var/tmp/gentool-ng-novice.raw");
    QString script = QStringLiteral(R"SH(
set -e
RAW='%1'; MNT='%4'
for sub in boot/efi dev/pts dev sys proc run; do umount -lf "$MNT/$sub" 2>/dev/null || true; done
umount -lf "$MNT" 2>/dev/null || true
for l in $(losetup -j "$RAW" -O NAME --noheadings 2>/dev/null || true); do losetup -d "$l" 2>/dev/null || true; done
rm -f "$RAW"; mkdir -p "$MNT"
truncate -s %2G "$RAW"
LOOP=$(losetup --find --show --partscan "$RAW")
parted -s "$LOOP" mklabel gpt mkpart ESP fat32 1MiB 513MiB set 1 esp on mkpart primary %3 513MiB 100%%
partprobe "$LOOP"; udevadm settle
mkfs.vfat -F32 "${LOOP}p1"
mkfs.%3 -F "${LOOP}p2" 2>/dev/null || mkfs.%3 -f "${LOOP}p2"
udevadm settle
mount "${LOOP}p2" "$MNT"
mkdir -p "$MNT/boot/efi"
mount "${LOOP}p1" "$MNT/boot/efi"
echo "Staging raw disk mounted cleanly at $MNT ($LOOP)"
)SH").arg(rawImg).arg(sizeGb).arg(fsType, mnt);
    return runCmd(QStringLiteral("sh"), {QStringLiteral("-c"), script});
}

void DiskImageWidget::finalizeDdToTarget(const QString& mntDir) {
    const QString mnt = mntDir.trimmed().isEmpty() ? QStringLiteral("/mnt/wakstab-chroot") : mntDir.trimmed();
    const QString rawImg = QStringLiteral("/var/tmp/gentool-ng-novice.raw");
    if (!QFile::exists(rawImg)) { QMessageBox::warning(this, QStringLiteral("Missing Staging Image"), QStringLiteral("Run Step 1 (Prepare & Mount Storage) first.")); return; }

    QStringList drives;
    for (const QString& b : QDir(QStringLiteral("/sys/block")).entryList({QStringLiteral("nbd[0-9]*")}, QDir::Dirs)) {
        QFile szFile(QStringLiteral("/sys/block/%1/size").arg(b));
        if (szFile.open(QIODevice::ReadOnly)) {
            const quint64 sectors = szFile.readAll().trimmed().toULongLong();
            if (sectors > 0) {
                const double gib = (sectors * 512.0) / (1024.0 * 1024.0 * 1024.0);
                drives.append(QStringLiteral("/dev/%1  %2 GiB  [NBD Smoke-Test Target]").arg(b).arg(gib, 0, 'f', 1));
            }
        }
    }
    QProcess ls; ls.start(QStringLiteral("lsblk"), {QStringLiteral("-dpno"), QStringLiteral("NAME,SIZE,MODEL")});
    ls.waitForFinished(2000);
    for (const QString& ln : QString::fromUtf8(ls.readAllStandardOutput()).split(QLatin1Char('\n'), Qt::SkipEmptyParts)) {
        if (ln.startsWith(QStringLiteral("/dev/loop")) || ln.startsWith(QStringLiteral("/dev/nbd"))) continue;
        drives.append(ln.simplified());
    }
    bool ok = false;
    const QString picked = QInputDialog::getItem(this, QStringLiteral("Step 4: Select Final Target Drive for dd"), QStringLiteral("Write finished Gentoo system image to:"), drives, 0, false, &ok);
    if (!ok || picked.isEmpty()) return;
    const QString drvDev = picked.section(QLatin1Char(' '), 0, 0);

    if (QMessageBox::warning(this, QStringLiteral("Final Target Drive Confirmation"),
        QStringLiteral("Confirm writing complete Gentoo build to:\n\n%1\n\nALL DATA ON %2 WILL BE OVERWRITTEN. Proceed with dd?").arg(picked, drvDev),
        QMessageBox::Yes | QMessageBox::No, QMessageBox::No) != QMessageBox::Yes) return;

    QString flushScript = QStringLiteral(R"SH(
set -e
MNT='%1'; RAW='%2'; DST='%3'
sync
for sub in boot/efi dev/pts dev sys proc run; do umount -lf "$MNT/$sub" 2>/dev/null || true; done
umount -lf "$MNT" 2>/dev/null || true
for l in $(losetup -j "$RAW" -O NAME --noheadings 2>/dev/null || true); do losetup -d "$l" 2>/dev/null || true; done
dd if="$RAW" of="$DST" bs=16M status=progress conv=fsync
partprobe "$DST" 2>/dev/null || true
udevadm settle
rm -f "$RAW"
echo "Successfully wrote complete Gentoo system image to $DST!"
)SH").arg(mnt, rawImg, drvDev);
    runCmd(QStringLiteral("sh"), {QStringLiteral("-c"), flushScript});
}
