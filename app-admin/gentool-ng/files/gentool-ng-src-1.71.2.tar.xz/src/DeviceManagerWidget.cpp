#include "DeviceManagerWidget.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QSplitter>
#include <QGroupBox>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QProcess>
#include <QMessageBox>

DeviceManagerWidget::DeviceManagerWidget(QWidget *parent) : QWidget(parent) {
    auto *mainLayout = new QVBoxLayout(this);
    m_refreshBtn = new QPushButton("Scan Hardware Buses");
    mainLayout->addWidget(m_refreshBtn);

    auto *splitter = new QSplitter(Qt::Horizontal);
    m_tree = new QTreeWidget();
    m_tree->setHeaderLabels({"Device / Bus", "Driver", "Status"});
    splitter->addWidget(m_tree);

    auto *detailBox = new QGroupBox("Device Properties & Driver Control");
    auto *vbox = new QVBoxLayout(detailBox);
    auto *form = new QFormLayout();
    m_statusLbl = new QLabel("-");
    m_busLbl = new QLabel("-");
    m_sysfsLbl = new QLabel("-");
    m_sysfsLbl->setWordWrap(true);
    m_modaliasLbl = new QLabel("-");
    m_modaliasLbl->setWordWrap(true);
    m_driverLbl = new QLabel("-");
    m_altDriverCombo = new QComboBox();

    form->addRow("Status:", m_statusLbl);
    form->addRow("Bus Location:", m_busLbl);
    form->addRow("Sysfs Path:", m_sysfsLbl);
    form->addRow("Modalias:", m_modaliasLbl);
    form->addRow("Active Driver:", m_driverLbl);
    form->addRow("Compatible Modules:", m_altDriverCombo);
    vbox->addLayout(form);
    auto *btnRow = new QHBoxLayout();
    m_disableBtn = new QPushButton("Disable Device");
    m_enableBtn = new QPushButton("Enable Device");
    m_switchBtn = new QPushButton("Switch Driver");
    btnRow->addWidget(m_disableBtn);
    btnRow->addWidget(m_enableBtn);
    btnRow->addWidget(m_switchBtn);
    vbox->addLayout(btnRow);
    vbox->addStretch();

    splitter->addWidget(detailBox);
    mainLayout->addWidget(splitter, 1);

    connect(m_refreshBtn, &QPushButton::clicked, this, &DeviceManagerWidget::scanDevices);
    connect(m_tree, &QTreeWidget::itemClicked, this, &DeviceManagerWidget::onDeviceSelected);
    connect(m_disableBtn, &QPushButton::clicked, this, &DeviceManagerWidget::disableSelectedDevice);
    connect(m_enableBtn, &QPushButton::clicked, this, &DeviceManagerWidget::enableSelectedDevice);
    connect(m_switchBtn, &QPushButton::clicked, this, &DeviceManagerWidget::switchDriver);

    scanDevices();
}

void DeviceManagerWidget::scanDevices() {
    m_tree->clear();
    m_devices.clear();
    QList<QPair<QString, QString>> buses;
    for (const QString &b : QDir("/sys/bus").entryList(QDir::Dirs | QDir::NoDotAndDotDot)) {
        QString label = (b == "pci") ? "PCIe" : b.toUpper();
        if (QDir("/sys/bus/" + b + "/devices").exists())
            buses.append({label, "/sys/bus/" + b + "/devices"});
    }
    for (const auto &bus : buses) {
        QDir dir(bus.second);
        if (!dir.exists()) continue;
        auto *root = new QTreeWidgetItem(m_tree, {bus.first, "", ""});
        for (const QString &entry : dir.entryList(QDir::Dirs | QDir::NoDotAndDotDot)) {
            if (bus.first == "USB" && entry.contains(':')) continue;
            const QString sysPath = QFileInfo(dir.filePath(entry)).canonicalFilePath();
            LinuxDeviceInfo info;
            info.busType = bus.first;
            info.busId = entry;
            info.sysfsPath = sysPath;
            info.driverSubsysPath = QFileInfo(sysPath + "/subsystem").canonicalFilePath();
            info.activeDriver = QFileInfo(sysPath + "/driver").exists()
                ? QFileInfo(sysPath + "/driver").canonicalFilePath().section('/', -1) : "none";

            QFile modFile(sysPath + "/modalias");
            if (modFile.open(QIODevice::ReadOnly))
                info.modalias = QString::fromUtf8(modFile.readAll()).trimmed();

            QString safeId = entry;
            safeId.replace(':', '_').replace('/', '_');
            info.disabledByRule = QFile::exists("/etc/udev/rules.d/99-gentool-ng-disable-" + safeId + ".rules");
            info.name = resolveDeviceName(sysPath, bus.first, entry);

            const QString key = bus.first + ":" + entry;
            m_devices[key] = info;
            const QString status = info.disabledByRule ? "Disabled" : (info.activeDriver != "none" ? "Active" : "Unbound");
            auto *item = new QTreeWidgetItem(root, {info.name, info.activeDriver, status});
            item->setData(0, Qt::UserRole, key);
        }
        root->setExpanded(true);
    }
}
QString DeviceManagerWidget::resolveDeviceName(const QString &sysPath, const QString &bus, const QString &id) {
    for (const char *attr : {"/product", "/model", "/name"}) {
        QFile f(sysPath + attr);
        if (f.open(QIODevice::ReadOnly)) {
            const QString s = QString::fromUtf8(f.readAll()).trimmed();
            if (!s.isEmpty()) return QString("%1 [%2]").arg(s, id);
        }
    }
    if (bus == "PCIe") {
        QProcess p;
        p.start("lspci", {"-s", id});
        p.waitForFinished(500);
        const QString out = QString::fromUtf8(p.readAllStandardOutput()).trimmed();
        if (!out.isEmpty()) return out;
    }
    return id;
}

QStringList DeviceManagerWidget::resolveCompatibleModules(const QString &modalias) {
    if (modalias.isEmpty()) return {};
    QProcess p;
    p.start("modprobe", {"-R", modalias});
    p.waitForFinished(1000);
    return QString::fromUtf8(p.readAllStandardOutput()).split('\n', Qt::SkipEmptyParts);
}

void DeviceManagerWidget::onDeviceSelected(QTreeWidgetItem *item) {
    if (!item) return;
    m_selectedKey = item->data(0, Qt::UserRole).toString();
    if (!m_devices.contains(m_selectedKey)) return;
    const auto &d = m_devices[m_selectedKey];
    m_statusLbl->setText(d.disabledByRule ? "Disabled (udev rule + unbound)" : "Enabled");
    m_busLbl->setText(d.busType + " (" + d.busId + ")");
    m_sysfsLbl->setText(d.sysfsPath);
    m_modaliasLbl->setText(d.modalias.isEmpty() ? "N/A" : d.modalias);
    m_driverLbl->setText(d.activeDriver);
    m_altDriverCombo->clear();
    m_altDriverCombo->addItems(resolveCompatibleModules(d.modalias));
}
void DeviceManagerWidget::disableSelectedDevice() {
    if (!m_devices.contains(m_selectedKey)) return;
    const auto &d = m_devices[m_selectedKey];
    if (d.activeDriver != "none") {
        QFile unbind(d.sysfsPath + "/driver/unbind");
        if (unbind.open(QIODevice::WriteOnly)) unbind.write(d.busId.toUtf8());
    }
    QString safeId = d.busId;
    safeId.replace(':', '_').replace('/', '_');
    QFile rule("/etc/udev/rules.d/99-gentool-ng-disable-" + safeId + ".rules");
    if (rule.open(QIODevice::WriteOnly | QIODevice::Text)) {
        rule.write(QString("ACTION==\"add\", KERNEL==\"%1\", RUN+=\"/bin/sh -c 'echo %1 > $sys$devpath/driver/unbind'\"\n").arg(d.busId).toUtf8());
    }
    scanDevices();
}

void DeviceManagerWidget::enableSelectedDevice() {
    if (!m_devices.contains(m_selectedKey)) return;
    const auto &d = m_devices[m_selectedKey];
    QString safeId = d.busId;
    safeId.replace(':', '_').replace('/', '_');
    QFile::remove("/etc/udev/rules.d/99-gentool-ng-disable-" + safeId + ".rules");
    QFile probe(d.driverSubsysPath + "/drivers_probe");
    if (probe.open(QIODevice::WriteOnly)) probe.write(d.busId.toUtf8());
    scanDevices();
}

void DeviceManagerWidget::switchDriver() {
    if (!m_devices.contains(m_selectedKey)) return;
    const auto &d = m_devices[m_selectedKey];
    const QString targetMod = m_altDriverCombo->currentText().trimmed();
    if (targetMod.isEmpty()) return;
    QProcess::execute("modprobe", {targetMod});
    if (d.activeDriver != "none") {
        QFile unbind(d.sysfsPath + "/driver/unbind");
        if (unbind.open(QIODevice::WriteOnly)) unbind.write(d.busId.toUtf8());
    }
    QFile override(d.sysfsPath + "/driver_override");
    if (override.open(QIODevice::WriteOnly)) override.write(targetMod.toUtf8());
    QFile probe(d.driverSubsysPath + "/drivers_probe");
    if (probe.open(QIODevice::WriteOnly)) probe.write(d.busId.toUtf8());
    scanDevices();
}
