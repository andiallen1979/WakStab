#pragma once
#include <QPoint>
#include <QString>
#include <QTabWidget>
#include <QWidget>

class TerminalWidget : public QWidget {
    Q_OBJECT
public:
    explicit TerminalWidget(QWidget* parent = nullptr);
public Q_SLOTS:
    void addTerminalTab(const QString& workDir = QString(), const QString& title = QString());
    void sendCommand(const QString& cmd);
private Q_SLOTS:
    void onTerminalFinished();
    void showTerminalContextMenu(const QPoint& pos);
private:
    QTabWidget* m_tabs = nullptr;
    int m_historyLines = 10000;
};
