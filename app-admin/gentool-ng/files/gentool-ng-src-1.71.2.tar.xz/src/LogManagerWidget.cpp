#include <QTimer>
#include "LogManagerWidget.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QSplitter>
#include <QDirIterator>
#include <QFile>
#include <QTextStream>
#include <QProcess>
#include <QFileDialog>
#include <QInputDialog>
#include <QMessageBox>

static bool isLikelyTextFile(const QString &path) {
    QFileInfo fi(path);
    if (!fi.exists() || !fi.isFile() || !fi.isReadable() || fi.size() == 0) return false;
    static const QStringList skipExt = {"gz","xz","zst","bz2","lz4","journal","db","sqlite","bin","dat","pid","lock"};
    if (skipExt.contains(fi.suffix().toLower())) return false;
    const QString fn = fi.fileName();
    if (fn == "wtmp" || fn == "btmp" || fn == "lastlog" || fn == "faillog") return false;
    QFile f(path);
    if (!f.open(QIODevice::ReadOnly)) return false;
    const QByteArray sample = f.read(512);
    if (sample.contains('\0')) return false;
    int ctrl = 0;
    for (unsigned char c : sample)
        if (c < 0x09 || (c > 0x0D && c < 0x20 && c != 0x1B)) ctrl++;
    return sample.isEmpty() || (double(ctrl) / sample.size()) < 0.05;
}

LogHighlighter::LogHighlighter(QTextDocument *parent) : QSyntaxHighlighter(parent) {}

void LogHighlighter::highlightBlock(const QString &text) {
    QTextCharFormat errFmt;
    errFmt.setForeground(QColor("#ff5555"));
    errFmt.setFontWeight(QFont::Bold);

    QTextCharFormat warnFmt;
    warnFmt.setForeground(QColor("#ffb86c"));

    static const QRegularExpression errRx("\\b(error|err|fail|failed|fatal|critical|panic|segfault|denied)\\b", QRegularExpression::CaseInsensitiveOption);
    static const QRegularExpression warnRx("\\b(warn|warning|deprecated|timeout|retry)\\b", QRegularExpression::CaseInsensitiveOption);

    auto it = errRx.globalMatch(text);
    while (it.hasNext()) {
        auto m = it.next();
        setFormat(m.capturedStart(), m.capturedLength(), errFmt);
    }
    auto wit = warnRx.globalMatch(text);
    while (wit.hasNext()) {
        auto m = wit.next();
        setFormat(m.capturedStart(), m.capturedLength(), warnFmt);
    }
}

LogManagerWidget::LogManagerWidget(QWidget *parent)
    : QWidget(parent), m_settings("WakStab", "gentool-ng") {
    auto *mainLayout = new QVBoxLayout(this);
    auto *topBar = new QHBoxLayout();

    m_searchEdit = new QLineEdit();
    m_searchEdit->setPlaceholderText("Live search / regex filter...");
    m_levelCombo = new QComboBox();
    m_levelCombo->addItems({"All Lines", "Errors Only", "Warnings & Errors"});
    m_refreshBtn = new QPushButton("Refresh");
    m_customBtn = new QPushButton("Custom Logs...");

    topBar->addWidget(m_searchEdit, 1);
    topBar->addWidget(m_levelCombo);
    topBar->addWidget(m_refreshBtn);
    topBar->addWidget(m_customBtn);
    mainLayout->addLayout(topBar);

    auto *splitter = new QSplitter(Qt::Horizontal);
    m_tree = new QTreeWidget();
    m_tree->setHeaderLabel("Log Sources");
    m_tree->setMaximumWidth(320);

    m_viewer = new QPlainTextEdit();
    m_viewer->setReadOnly(true);
    m_viewer->setFont(QFont("Monospace", 9));
    new LogHighlighter(m_viewer->document());

    splitter->addWidget(m_tree);
    splitter->addWidget(m_viewer);
    mainLayout->addWidget(splitter);

    connect(m_refreshBtn, &QPushButton::clicked, this, &LogManagerWidget::refreshSources);
    connect(m_customBtn, &QPushButton::clicked, this, &LogManagerWidget::configureCustomLogs);
    connect(m_tree, &QTreeWidget::itemClicked, this, &LogManagerWidget::onSourceSelected);
    connect(m_searchEdit, &QLineEdit::textChanged, this, &LogManagerWidget::applyFilter);
    connect(m_levelCombo, &QComboBox::currentIndexChanged, this, &LogManagerWidget::applyFilter);

    QTimer::singleShot(120, this, [this]() { refreshSources(); });
}

void LogManagerWidget::refreshSources() {
    m_tree->clear();

    if (QDir("/run/systemd/system").exists()) {
        auto *sysdRoot = new QTreeWidgetItem(m_tree, {"systemd Journal"});
        auto *allItem = new QTreeWidgetItem(sysdRoot, {"Current Boot (All)"});
        allItem->setData(0, Qt::UserRole, "journald:all");
        auto *errItem = new QTreeWidgetItem(sysdRoot, {"Current Boot (Errors)"});
        errItem->setData(0, Qt::UserRole, "journald:err");
        sysdRoot->setExpanded(true);
    }

    auto *varLogRoot = new QTreeWidgetItem(m_tree, {"/var/log"});
    QDirIterator it("/var/log", QDir::Files | QDir::Readable, QDirIterator::Subdirectories);
    while (it.hasNext()) {
        const QString path = it.next();
        if (!isLikelyTextFile(path)) continue;
        auto *item = new QTreeWidgetItem(varLogRoot, {path.mid(9)});
        item->setData(0, Qt::UserRole, "file:" + path);
    }
    varLogRoot->setExpanded(true);

    const QStringList customPaths = m_settings.value("logs/customPaths").toStringList();
    if (!customPaths.isEmpty()) {
        auto *customRoot = new QTreeWidgetItem(m_tree, {"Custom Assigned Logs"});
        for (const QString &cp : customPaths) {
            auto *item = new QTreeWidgetItem(customRoot, {QFileInfo(cp).fileName()});
            item->setToolTip(0, cp);
            item->setData(0, Qt::UserRole, "file:" + cp);
        }
        customRoot->setExpanded(true);
    }
}

void LogManagerWidget::onSourceSelected(QTreeWidgetItem *item) {
    if (!item) return;
    const QString tag = item->data(0, Qt::UserRole).toString();
    if (tag == "journald:all") {
        loadJournald("");
    } else if (tag == "journald:err") {
        loadJournald("-p err");
    } else if (tag.startsWith("file:")) {
        loadFileTail(tag.mid(5));
    }
}

void LogManagerWidget::loadJournald(const QString &extraArgs) {
    QProcess proc;
    QStringList args = {"-b", "-n", "1500", "--no-pager"};
    if (!extraArgs.isEmpty()) args << extraArgs.split(' ');
    proc.start("journalctl", args);
    proc.waitForFinished(5000);
    m_fullContent = QString::fromUtf8(proc.readAllStandardOutput());
    if (m_fullContent.isEmpty())
        m_fullContent = QString::fromUtf8(proc.readAllStandardError());
    applyFilter();
}

void LogManagerWidget::loadFileTail(const QString &path) {
    QFileInfo fi(path);
    if (!fi.exists() || !fi.isFile() || !fi.isReadable()) {
        m_fullContent = "Skipped (not a regular readable file): " + path;
        applyFilter(); return;
    }
    if (!isLikelyTextFile(path)) {
        m_fullContent = "Skipped binary or empty file: " + path;
        applyFilter(); return;
    }
    QFile f(path);
    if (!f.open(QIODevice::ReadOnly)) {
        m_fullContent = "Unable to open: " + path;
        applyFilter(); return;
    }
    const qint64 maxBytes = 512 * 1024;
    if (f.size() > maxBytes) f.seek(f.size() - maxBytes);
    const QByteArray raw = f.read(maxBytes);
    if (raw.contains('\0')) {
        m_fullContent = "Aborted: binary NUL bytes detected in " + path;
        applyFilter(); return;
    }
    QStringList safeLines;
    for (const QString &ln : QString::fromUtf8(raw).split('\n'))
        safeLines.append(ln.size() > 4096 ? ln.left(4096) + " ...[truncated]" : ln);
    m_fullContent = safeLines.join('\n');
    applyFilter();
}

void LogManagerWidget::applyFilter() {
    const QString query = m_searchEdit->text();
    const int mode = m_levelCombo->currentIndex();
    if (query.isEmpty() && mode == 0) {
        m_viewer->setPlainText(m_fullContent);
        return;
    }
    static const QRegularExpression errRx("\\b(error|err|fail|failed|fatal|critical|panic|segfault)\\b", QRegularExpression::CaseInsensitiveOption);
    static const QRegularExpression warnErrRx("\\b(error|err|fail|failed|fatal|critical|panic|segfault|warn|warning)\\b", QRegularExpression::CaseInsensitiveOption);

    QStringList out;
    for (const QString &line : m_fullContent.split('\n')) {
        if (mode == 1 && !errRx.match(line).hasMatch()) continue;
        if (mode == 2 && !warnErrRx.match(line).hasMatch()) continue;
        if (!query.isEmpty() && !line.contains(query, Qt::CaseInsensitive)) continue;
        out.append(line);
    }
    m_viewer->setPlainText(out.join('\n'));
}

void LogManagerWidget::configureCustomLogs() {
    QStringList current = m_settings.value("logs/customPaths").toStringList();
    QStringList picked = QFileDialog::getOpenFileNames(this, "Select Custom Log Files", "/var/log");
    if (!picked.isEmpty()) {
        for (const QString &p : picked) {
            if (!current.contains(p)) current.append(p);
        }
        m_settings.setValue("logs/customPaths", current);
        refreshSources();
    } else if (!current.isEmpty()) {
        auto reply = QMessageBox::question(this, "Clear Custom Logs", "Clear all custom assigned log paths?");
        if (reply == QMessageBox::Yes) {
            m_settings.remove("logs/customPaths");
            refreshSources();
        }
    }
}
