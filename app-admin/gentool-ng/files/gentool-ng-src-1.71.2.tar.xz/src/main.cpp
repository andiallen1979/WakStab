#include <QFont>
#include <QSettings>
#include "MainWindow.h"
#include <KAboutData>
#include <KColorSchemeManager>
#include <KLocalizedString>
#include <QApplication>
int main(int argc, char* argv[]) {
QApplication app(argc, argv);
{
QSettings st(QStringLiteral("WakStab"), QStringLiteral("gentool-ng"));
QFont f = app.font();
QString fam = st.value(QStringLiteral("ui/fontFamily")).toString();
if (!fam.isEmpty()) f.setFamily(fam);
int pt = st.value(QStringLiteral("ui/fontSize"), 11).toInt();
if (pt >= 6 && pt <= 36) f.setPointSize(pt);
app.setFont(f);
}
KColorSchemeManager::instance();
KLocalizedString::setApplicationDomain("gentool-ng");
KAboutData about(
QStringLiteral("gentool-ng"),
i18n("gentool-ng"),
QStringLiteral("1.71.2"),
i18n("Native Qt6 / KDE Plasma Partition Editor"),
KAboutLicense::GPL_V2,
i18n("(c) 2026 WakStab Repository / GParted Authors"),
QString(),
QStringLiteral("https://codeberg.org"));
KAboutData::setApplicationData(about);
app.setDesktopFileName(QStringLiteral("gentool-ng"));
const bool expertOverride = QCoreApplication::arguments().contains(QStringLiteral("--expert-override"));
QSettings(QStringLiteral("WakStab"), QStringLiteral("gentool-ng")).setValue(QStringLiteral("roleMode"), expertOverride ? 2 : 0);
QSettings(QStringLiteral("WakStab"), QStringLiteral("gentool-ng")).setValue(QStringLiteral("expertRole"), expertOverride);
MainWindow win;
win.show();
return app.exec();
}
