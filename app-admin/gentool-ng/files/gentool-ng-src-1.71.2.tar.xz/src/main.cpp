#include <QFont>
#include <QSettings>
#include "MainWindow.h"
#include <KAboutData>
#include <KColorSchemeManager>
#include <KLocalizedString>
#include <QApplication>
int main(int argc, char* argv[]) {
QApplication app(argc, argv);
{
QSettings st(QStringLiteral("WakStab"), QStringLiteral("gentool-ng"));
QFont f = app.font();
QString fam = st.value(QStringLiteral("ui/fontFamily")).toString();
if (!fam.isEmpty()) f.setFamily(fam);
int pt = st.value(QStringLiteral("ui/fontSize"), 11).toInt();
if (pt >= 6 && pt <= 36) f.setPointSize(pt);
app.setFont(f);
}
KColorSchemeManager::instance();
KLocalizedString::setApplicationDomain("gentool-ng");
KAboutData about(
QStringLiteral("gentool-ng"),
i18n("gentool-ng"),
QStringLiteral("1.71.2"),
i18n("Native Qt6 / KDE Plasma Partition Editor"),
KAboutLicense::GPL_V2,
i18n("(c) 2026 WakStab Repository / GParted Authors"),
QString(),
QStringLiteral("https://fragtoo.com"));
KAboutData::setApplicationData(about);
app.setDesktopFileName(QStringLiteral("gentool-ng"));
const bool expertOverride = QCoreApplication::arguments().contains(QStringLiteral("--expert-override"));
QSettings(QStringLiteral("WakStab"), QStringLiteral("gentool-ng")).setValue(QStringLiteral("roleMode"), expertOverride ? 2 : 0);
QSettings(QStringLiteral("WakStab"), QStringLiteral("gentool-ng")).setValue(QStringLiteral("expertRole"), expertOverride);
const int bootPt = QSettings(QStringLiteral("WakStab"), QStringLiteral("gentool-ng")).value(QStringLiteral("ui/fontSize"), 11).toInt();
const QString bootFam = app.font().family();
app.setStyleSheet(QStringLiteral("QWidget:not(QTermWidget):not(QTermWidget *), QMenu, QMenuBar, QPushButton, QPlainTextEdit { font-family: '%1'; font-size: %2pt; } ").arg(bootFam).arg(bootPt) + QStringLiteral(
    "QPushButton {"
    "  background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #31363f, stop:1 #252930);"
    "  color: #eff0f1;"
    "  border: 1px solid #3e4451;"
    "  border-bottom: 2px solid #16181d;"
    "  border-radius: 5px;"
    "  padding: 3px 10px;"
    "  "
    "}"
    "QPushButton:hover {"
    "  background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #3a404b, stop:1 #2c313a);"
    "  border: 1px solid #3daee9;"
    "  border-bottom: 2px solid #1e6fa0;"
    "}"
    "QPushButton:pressed {"
    "  background: #1e2228;"
    "  border: 1px solid #3daee9;"
    "  padding-top: 4px;"
    "  padding-bottom: 2px;"
    "}"
    "QPushButton:disabled {"
    "  background: #1d2026;"
    "  color: #5c6370;"
    "  border: 1px solid #282c34;"
    "}"
));
MainWindow win;
win.show();
return app.exec();
}
