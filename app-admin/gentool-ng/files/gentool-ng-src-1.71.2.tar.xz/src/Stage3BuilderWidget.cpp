#include "Stage3BuilderWidget.h"
#include "GtSnapManager.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>
#include <QDir>
#include <QProcess>
#include <QDateTime>
#include <QMessageBox>

Stage3BuilderWidget::Stage3BuilderWidget(QWidget *parent) : QWidget(parent) {
    auto *lay = new QVBoxLayout(this);
    lay->setContentsMargins(6, 6, 6, 6); lay->setSpacing(6);

    auto *top = new QHBoxLayout();
    m_sourceCb = new QComboBox(); m_sourceCb->setMaximumHeight(24);
    auto *bRef = new QPushButton(QIcon::fromTheme("view-refresh"), "Refresh Sources");
    m_buildBtn = new QPushButton(QIcon::fromTheme("archive-insert"), "Build Custom Stage3 + Binpkgs");
    for (QPushButton *b : {bRef, m_buildBtn}) { b->setMaximumHeight(24); b->setSizePolicy(QSizePolicy::Maximum, QSizePolicy::Fixed); }
    top->addWidget(m_sourceCb, 1); top->addWidget(bRef); top->addWidget(m_buildBtn);
    lay->addLayout(top);

    auto *form = new QFormLayout();
    m_rootEdit = new QLineEdit("/mnt/wakstab-chroot");
    m_hostEdit = new QLineEdit("wakstab");
    m_verEdit = new QLineEdit(QDateTime::currentDateTimeUtc().toString("yyyyMMdd"));
    m_outDirEdit = new QLineEdit("/var/lib/gtsnap/releases");
    m_binhostUrlEdit = new QLineEdit("http://binhost.local");
    m_compCb = new QComboBox(); m_compCb->addItems({"zstd", "xz"});
    m_packBinpkgsChk = new QCheckBox("Pack @world into PKGDIR/<hostname>/<version> & inject into make.conf");
    m_packBinpkgsChk->setChecked(true);
    m_embedBinpkgsChk = new QCheckBox("Bundle scoped binpkgs tree inside resulting Stage3 tarball");
    m_embedBinpkgsChk->setChecked(false);
    for (QWidget *w : std::initializer_list<QWidget*>{m_rootEdit, m_hostEdit, m_verEdit, m_outDirEdit, m_binhostUrlEdit, m_compCb}) w->setMaximumHeight(24);

    form->addRow("Source Chroot / Mount:", m_rootEdit);
    form->addRow("Target Hostname Layer:", m_hostEdit);
    form->addRow("Release Version Layer:", m_verEdit);
    form->addRow("Output Release Dir:", m_outDirEdit);
    form->addRow("Binhost Base URL:", m_binhostUrlEdit);
    form->addRow("Tarball Compression:", m_compCb);
    form->addRow("", m_packBinpkgsChk);
    form->addRow("", m_embedBinpkgsChk);
    lay->addLayout(form);

    m_log = new QPlainTextEdit(); m_log->setReadOnly(true);
    lay->addWidget(m_log, 1);

    connect(bRef, &QPushButton::clicked, this, &Stage3BuilderWidget::reloadSources);
    connect(m_sourceCb, QOverload<int>::of(&QComboBox::currentIndexChanged), this, &Stage3BuilderWidget::onSourceChanged);
    connect(m_buildBtn, &QPushButton::clicked, this, &Stage3BuilderWidget::buildStage3Release);
    reloadSources();
}

void Stage3BuilderWidget::reloadSources() {
    m_sourceCb->clear();
    m_sourceCb->addItem("Custom Chroot Path (/mnt/wakstab-chroot)", "/mnt/wakstab-chroot");
    for (const GtSnapPackage &p : GtSnapManager::listPackages()) {
        const QString mnt = p.mountDir.isEmpty() ? (p.pkgDir + "/mnt") : p.mountDir;
        m_sourceCb->addItem(QString("GTSnap: %1 (%2)").arg(p.name, p.uuid.left(8)), mnt);
        m_sourceCb->setItemData(m_sourceCb->count() - 1, p.uuid, Qt::UserRole + 1);
    }
}

void Stage3BuilderWidget::onSourceChanged(int idx) {
    if (idx < 0) return;
    m_rootEdit->setText(m_sourceCb->itemData(idx).toString());
}

void Stage3BuilderWidget::buildStage3Release() {
    const QString root = m_rootEdit->text().trimmed();
    const QString host = m_hostEdit->text().trimmed();
    const QString ver = m_verEdit->text().trimmed();
    const QString outDir = m_outDirEdit->text().trimmed();
    const QString snapUuid = m_sourceCb->currentData(Qt::UserRole + 1).toString();
    if (root.isEmpty() || !QDir(root + "/etc/portage").exists()) {
        QMessageBox::warning(this, "Invalid Source Root", "Source root must contain a valid Gentoo filesystem (/etc/portage).");
        return;
    }
    if (!snapUuid.isEmpty()) GtSnapManager::exportConfigBundle(snapUuid, root);

    const QString pkgSubdir = QString("/var/cache/binpkgs/%1/%2").arg(host, ver);
    const QString ext = (m_compCb->currentText() == "zstd") ? "tar.zst" : "tar.xz";
    const QString compFlag = (m_compCb->currentText() == "zstd") ? "--zstd" : "-J";
    const QString outTar = QString("%1/stage3-amd64-%2-%3.%4").arg(outDir, host, ver, ext);
    const QString url = QString("%1/%2/%3").arg(m_binhostUrlEdit->text().trimmed(), host, ver);

    QString script = QStringLiteral(R"SH(
set -e
ROOT='%1'; PKGDIR_SCOPED='%2'; OUT_TAR='%3'; BINURL='%4'; PACK='%5'; EMBED='%6'; CFLAG='%7'
mkdir -p "$(dirname "$OUT_TAR")" "$PKGDIR_SCOPED" "$ROOT/etc/portage"
if [ "$PACK" = "1" ]; then
  ROOT="$ROOT" PKGDIR="$PKGDIR_SCOPED" quickpkg --include-config=y "*/*" || true
  PKGDIR="$PKGDIR_SCOPED" emaint binhost --fix || true
  sed -i '/^PKGDIR=/d;/^PORTAGE_BINHOST=/d' "$ROOT/etc/portage/make.conf" 2>/dev/null || true
  printf '\n# Configured by Gentool-NG Stage3 Release Builder\nPKGDIR="%s"\nPORTAGE_BINHOST="%s"\nFEATURES="${FEATURES} buildpkg getbinpkg"\n' "$PKGDIR_SCOPED" "$BINURL" >> "$ROOT/etc/portage/make.conf"
fi
EXCL_BIN="--exclude=./var/cache/binpkgs/*"
if [ "$EMBED" = "1" ]; then
  mkdir -p "$ROOT$PKGDIR_SCOPED"
  rsync -a --delete "$PKGDIR_SCOPED/" "$ROOT$PKGDIR_SCOPED/"
  EXCL_BIN=""
fi
tar --xattrs-include='*.*' --numeric-owner $CFLAG -cpf "$OUT_TAR" \
  --exclude='./proc/*' --exclude='./sys/*' --exclude='./dev/*' --exclude='./run/*' \
  --exclude='./tmp/*' --exclude='./var/tmp/portage/*' --exclude='./var/cache/distfiles/*' \
  --exclude='./etc/ssh/ssh_host_*' --exclude='./etc/machine-id' $EXCL_BIN -C "$ROOT" .
sha512sum "$OUT_TAR" > "${OUT_TAR}.DIGESTS"
b2sum "$OUT_TAR" >> "${OUT_TAR}.DIGESTS" 2>/dev/null || true
echo "Built Stage3 release: $OUT_TAR"
echo "Generated digests:    ${OUT_TAR}.DIGESTS"
echo "Scoped binpkgs:       $PKGDIR_SCOPED"
)SH").arg(root, pkgSubdir, outTar, url, m_packBinpkgsChk->isChecked() ? "1" : "0", m_embedBinpkgsChk->isChecked() ? "1" : "0", compFlag);

    m_log->clear();
    auto *proc = new QProcess(this);
    connect(proc, &QProcess::readyReadStandardOutput, this, [this, proc]() { m_log->appendPlainText(QString::fromUtf8(proc->readAllStandardOutput()).trimmed()); });
    connect(proc, &QProcess::readyReadStandardError, this, [this, proc]() { m_log->appendPlainText(QString::fromUtf8(proc->readAllStandardError()).trimmed()); });
    connect(proc, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished), this, [proc]() { proc->deleteLater(); });
    proc->start("/bin/sh", {"-c", script});
}
