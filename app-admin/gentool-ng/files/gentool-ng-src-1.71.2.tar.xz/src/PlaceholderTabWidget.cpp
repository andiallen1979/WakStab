#include "PlaceholderTabWidget.h"
#include <QLabel>
#include <QVBoxLayout>

PlaceholderTabWidget::PlaceholderTabWidget(const QString& title, const QString& subtitle, QWidget* parent)
    : QWidget(parent) {
    auto* lay = new QVBoxLayout(this);
    lay->addStretch(1);
    auto* h1 = new QLabel(QStringLiteral("<h2>%1</h2>").arg(title), this);
    h1->setAlignment(Qt::AlignCenter);
    auto* h2 = new QLabel(subtitle, this);
    h2->setAlignment(Qt::AlignCenter);
    lay->addWidget(h1);
    lay->addWidget(h2);
    lay->addStretch(1);
}

