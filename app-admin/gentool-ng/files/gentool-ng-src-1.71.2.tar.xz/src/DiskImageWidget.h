#pragma once
#include <QCheckBox>
#include <QComboBox>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QPlainTextEdit>
#include <QPushButton>
#include <QSpinBox>
#include <QWidget>

class DiskImageWidget : public QWidget {
    Q_OBJECT
public:
    explicit DiskImageWidget(QWidget* parent = nullptr);
    ~DiskImageWidget() override;
Q_SIGNALS:
    void openInPartitionManagerRequested(const QString& blockDevice, const QString& imagePath);
public Q_SLOTS:
    void refreshImages();
    void provisionHandsOffVirtualDisk();
    void prepareAndMountChroot(const QString& rootPart, bool bindChroot);
private:
    QString selectedImage() const;
    void createImage();
    void attachAndPartition(const QString& imgPath);
    QCheckBox* m_autoPartChk = nullptr;
    void mountImage();
    void unmountImage();
    void detachImageDevices(const QString& imgPath = QString());
    void zeroAndCompress();
    void deleteImage();
    void buildSysextImage();
    void installSysextImage();
    void exportSysextImage();
    bool runCmd(const QString& prog, const QStringList& args);

    QString m_lastSysextImg;
    QLineEdit *m_dirIn = nullptr, *m_nameIn = nullptr, *m_mntIn = nullptr;
    QLineEdit *m_sxSrcIn = nullptr, *m_sxNameIn = nullptr, *m_sxOsIdIn = nullptr;
    QComboBox *m_fmtCb = nullptr, *m_partCb = nullptr, *m_sxFmtCb = nullptr;
    QSpinBox* m_sizeSpin = nullptr;
    QCheckBox *m_chrootChk = nullptr, *m_archChk = nullptr;
    QPushButton *m_bSxInst = nullptr, *m_bSxExp = nullptr;
    QListWidget* m_imgList = nullptr;
    QPlainTextEdit* m_log = nullptr;
};
