#pragma once
#include <QWidget>
#include <QComboBox>
#include <QLineEdit>
#include <QCheckBox>
#include <QPlainTextEdit>
#include <QPushButton>

class Stage3BuilderWidget : public QWidget {
    Q_OBJECT
public:
    explicit Stage3BuilderWidget(QWidget *parent = nullptr);
private Q_SLOTS:
    void reloadSources();
    void onSourceChanged(int idx);
    void buildStage3Release();
private:
    QComboBox *m_sourceCb, *m_compCb;
    QLineEdit *m_rootEdit, *m_hostEdit, *m_verEdit, *m_outDirEdit, *m_binhostUrlEdit;
    QCheckBox *m_packBinpkgsChk, *m_embedBinpkgsChk;
    QPlainTextEdit *m_log;
    QPushButton *m_buildBtn;
};
