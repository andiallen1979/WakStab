#include "SystemInfoWidget.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>
#include <QGroupBox>
#include <QHeaderView>
#include <QPainter>
#include <QPainterPath>
#include <QFile>
#include <QDir>
#include <QProcess>
#include <QStorageInfo>
#include <QInputDialog>
#include <QMessageBox>
#include <QRegularExpression>
#include <sys/utsname.h>

SystemGraphWidget::SystemGraphWidget(QWidget *parent) : QWidget(parent) {
    setFixedHeight(150);
    setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
}

void SystemGraphWidget::pushSample(double totalCpu, const QVector<double> &threads) {
    m_totalHist.append(qBound(0.0, totalCpu, 100.0));
    if (m_totalHist.size() > 60) m_totalHist.removeFirst();
    if (m_threadHist.size() < threads.size()) m_threadHist.resize(threads.size());
    for (int i = 0; i < threads.size(); ++i) {
        m_threadHist[i].append(qBound(0.0, threads.at(i), 100.0));
        if (m_threadHist[i].size() > 60) m_threadHist[i].removeFirst();
    }
    update();
}
void SystemGraphWidget::paintEvent(QPaintEvent *) {
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);
    const QRect r = rect();
    p.fillRect(r, QColor("#181a1f"));
    p.setPen(QColor("#2c313a"));
    for (int i = 1; i < 4; ++i) {
        int y = r.top() + (r.height() * i) / 4;
        p.drawLine(r.left(), y, r.right(), y);
    }
    const double stepX = double(r.width()) / 59.0;
    const int nThreads = m_threadHist.size();
    for (int t = 0; t < nThreads; ++t) {
        const auto &hist = m_threadHist.at(t);
        if (hist.size() < 2) continue;
        QPainterPath path;
        for (int i = 0; i < hist.size(); ++i) {
            double x = r.right() - (hist.size() - 1 - i) * stepX;
            double y = r.bottom() - (hist.at(i) / 100.0) * r.height();
            if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
        }
        int hue = nThreads > 0 ? (t * 360) / nThreads : 180;
        p.setPen(QPen(QColor::fromHsl(hue, 210, 150, 185), 1.3));
        p.drawPath(path);
    }
    if (m_totalHist.size() >= 2) {
        QPainterPath totPath;
        for (int i = 0; i < m_totalHist.size(); ++i) {
            double x = r.right() - (m_totalHist.size() - 1 - i) * stepX;
            double y = r.bottom() - (m_totalHist.at(i) / 100.0) * r.height();
            if (i == 0) totPath.moveTo(x, y); else totPath.lineTo(x, y);
        }
        p.setPen(QPen(QColor("#ffffff"), 1.6, Qt::DashLine));
        p.drawPath(totPath);
    }
    p.setFont(QFont("Sans", 8, QFont::Bold));
    p.setPen(QColor("#abb2bf"));
    p.drawText(r.left() + 6, r.top() + 13, QString("Per-Thread Load (%1 threads) + Overall (dashed)").arg(nThreads));
}
static QString readFirstLine(const QString &path) {
    QFile f(path);
    return f.open(QIODevice::ReadOnly | QIODevice::Text) ? QString::fromUtf8(f.readLine()).trimmed() : QString();
}
static QString formatBytes(quint64 b) {
    const double gib = b / (1024.0 * 1024.0 * 1024.0);
    return gib >= 1.0 ? QString::number(gib, 'f', 2) + " GiB" : QString::number(b / (1024.0 * 1024.0), 'f', 1) + " MiB";
}

SystemInfoWidget::SystemInfoWidget(QWidget *parent) : QWidget(parent), m_timer(new QTimer(this)) {
    auto *mainLayout = new QVBoxLayout(this);
    auto *hwBox = new QGroupBox("System & Hardware Identity");
    auto *hwForm = new QFormLayout(hwBox);
    m_kernelLbl = new QLabel(); m_boardLbl = new QLabel();
    m_cpuModelLbl = new QLabel(); m_cpuCoresLbl = new QLabel(); m_gpuModelLbl = new QLabel();
    hwForm->addRow("Kernel / OS:", m_kernelLbl); hwForm->addRow("Motherboard:", m_boardLbl);
    hwForm->addRow("CPU Model:", m_cpuModelLbl); hwForm->addRow("Topology:", m_cpuCoresLbl);
    hwForm->addRow("GPU Adapter:", m_gpuModelLbl);
    mainLayout->addWidget(hwBox);

    auto *midRow = new QHBoxLayout();
    auto *leftBox = new QGroupBox("Resource Telemetry & Swap Controls");
    auto *utilForm = new QFormLayout(leftBox);
    utilForm->setContentsMargins(8, 8, 8, 8); utilForm->setSpacing(4);
    for (QProgressBar **b : {&m_ramBar, &m_swapBar, &m_tmpfsBar, &m_vramBar}) {
        *b = new QProgressBar(); (*b)->setFixedHeight(10); (*b)->setMaximumWidth(210);
    }
    m_ramDetailLbl = new QLabel(); utilForm->addRow("RAM:", m_ramBar); utilForm->addRow("", m_ramDetailLbl);

    auto *swapRow = new QHBoxLayout(); swapRow->setSpacing(4);
    m_createSwapBtn = new QPushButton("+Swap"); m_destroySwapBtn = new QPushButton("Del");
    m_createSwapBtn->setFixedSize(46, 18); m_destroySwapBtn->setFixedSize(36, 18);
    m_permSwapChk = new QCheckBox("Permanent");
    m_permSwapChk->setChecked(QFile("/etc/fstab").open(QIODevice::ReadOnly) && QFile("/etc/fstab").readAll().contains("gentool-ng.swap"));
    swapRow->addWidget(m_swapBar); swapRow->addWidget(m_createSwapBtn); swapRow->addWidget(m_destroySwapBtn); swapRow->addWidget(m_permSwapChk); swapRow->addStretch(1);
    m_swapDetailLbl = new QLabel(); utilForm->addRow("Swap:", swapRow); utilForm->addRow("", m_swapDetailLbl);

    auto *tmpfsRow = new QHBoxLayout(); tmpfsRow->setSpacing(4);
    m_resizeTmpfsBtn = new QPushButton("Resize"); m_resizeTmpfsBtn->setFixedSize(54, 18);
    tmpfsRow->addWidget(m_tmpfsBar); tmpfsRow->addWidget(m_resizeTmpfsBtn); tmpfsRow->addStretch(1);
    m_tmpfsDetailLbl = new QLabel(); utilForm->addRow("Tmpfs:", tmpfsRow); utilForm->addRow("", m_tmpfsDetailLbl);

    m_vramDetailLbl = new QLabel(); utilForm->addRow("VRAM:", m_vramBar); utilForm->addRow("", m_vramDetailLbl);
    midRow->addWidget(leftBox, 1);

    auto *rightBox = new QGroupBox("Live CPU & Thread Load Graph");
    auto *cpuStack = new QVBoxLayout(rightBox); cpuStack->setContentsMargins(8, 8, 8, 8); cpuStack->setSpacing(4);
    m_totalCpuBar = new QProgressBar(); m_totalCpuBar->setFixedHeight(6); m_totalCpuBar->setTextVisible(false);
    m_totalCpuBar->setStyleSheet("QProgressBar{border:none;background:#21252b;}QProgressBar::chunk{background:#e06c75;}");
    m_graph = new SystemGraphWidget(rightBox);
    m_cpuDetailLbl = new QLabel();
    cpuStack->addWidget(m_totalCpuBar); cpuStack->addWidget(m_graph, 1); cpuStack->addWidget(m_cpuDetailLbl);
    midRow->addWidget(rightBox, 1);
    mainLayout->addLayout(midRow);

    m_collapseBtn = new QPushButton("Collapse Thread Report (4 Lines)");
    mainLayout->addWidget(m_collapseBtn);
    m_threadTable = new QTableWidget(1, 4);
    m_threadTable->setHorizontalHeaderLabels({"Core / Thread", "Active %", "Idle %", "Current MHz"});
    m_threadTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    m_threadTable->verticalHeader()->setVisible(false);
    m_threadTable->verticalHeader()->setDefaultSectionSize(22);
    mainLayout->addWidget(m_threadTable, 1);

    connect(m_collapseBtn, &QPushButton::clicked, this, &SystemInfoWidget::toggleThreadsCollapsed);
    connect(m_createSwapBtn, &QPushButton::clicked, this, &SystemInfoWidget::createTempSwap);
    connect(m_destroySwapBtn, &QPushButton::clicked, this, &SystemInfoWidget::destroyTempSwap);
    connect(m_resizeTmpfsBtn, &QPushButton::clicked, this, &SystemInfoWidget::resizeTmpfs);
    loadStaticHardwareInfo(); updateTelemetry();
    connect(m_timer, &QTimer::timeout, this, &SystemInfoWidget::updateTelemetry);
    m_timer->start(1000);
}
void SystemInfoWidget::toggleThreadsCollapsed() {
    m_collapsed = !m_collapsed;
    m_threadTable->setMaximumHeight(m_collapsed ? m_threadTable->horizontalHeader()->height() + 4 * 22 + 4 : 16777215);
    m_collapseBtn->setText(m_collapsed ? "Expand All Threads" : "Collapse Thread Report (4 Lines)");
}

void SystemInfoWidget::createTempSwap() {
    bool ok = false;
    int gb = QInputDialog::getInt(this, "Create Temporary Swap", "Swap file size (GiB) at /var/tmp/gentool-ng.swap:", 16, 1, 256, 1, &ok);
    if (!ok) return;
    const QString path = "/var/tmp/gentool-ng.swap";
    QString fstabCmd = (m_permSwapChk && m_permSwapChk->isChecked()) ? QString(" && (grep -q '%1' /etc/fstab || echo '%1 none swap sw 0 0' >> /etc/fstab)").arg(path) : QString(" && sed -i '\\|%1|d' /etc/fstab").arg(path);
    const QString cmd = QString("(fallocate -l %1G %2 || dd if=/dev/zero of=%2 bs=1G count=%1 status=none) && chmod 0600 %2 && mkswap %2 && swapon %2").arg(gb).arg(path) + fstabCmd;
    int rc = QProcess::execute("/bin/sh", {"-c", cmd});
    if (rc != 0) QMessageBox::warning(this, "Swap Setup Failed", "Failed to create or activate swap file (requires root).");
    updateTelemetry();
}

void SystemInfoWidget::destroyTempSwap() {
    const QString path = "/var/tmp/gentool-ng.swap";
    QProcess::execute("/bin/sh", {"-c", QString("swapoff %1 2>/dev/null; sed -i '\\|%1|d' /etc/fstab; rm -f %1").arg(path)});
    updateTelemetry();
}

void SystemInfoWidget::resizeTmpfs() {
    const QString target = QDir("/var/tmp/notmpfs").exists() ? "/var/tmp/notmpfs" : "/var/tmp/portage";
    const QStringList sizes = {"8G", "16G", "24G", "32G", "48G", "64G", "96G", "128G"};
    bool ok = false;
    QString sz = QInputDialog::getItem(this, "Resize / Mount Tmpfs", QString("Select new size for %1:").arg(target), sizes, 2, true, &ok);
    if (!ok || sz.trimmed().isEmpty()) return;
    QDir().mkpath(target);
    QStorageInfo st(target);
    QString cmd = (st.isValid() && st.fileSystemType() == "tmpfs")
        ? QString("mount -o remount,size=%1 %2").arg(sz.trimmed(), target)
        : QString("mount -t tmpfs -o size=%1,mode=0775,uid=portage,gid=portage tmpfs %2").arg(sz.trimmed(), target);
    if (QProcess::execute("/bin/sh", {"-c", cmd}) != 0)
        QMessageBox::warning(this, "Tmpfs Remount Failed", "Could not remount/mount tmpfs on " + target);
    updateTelemetry();
}
void SystemInfoWidget::loadStaticHardwareInfo() {
    struct utsname uts {};
    if (uname(&uts) == 0) m_kernelLbl->setText(QString("%1 %2 (%3)").arg(uts.sysname, uts.release, uts.machine));
    m_boardLbl->setText(QString("%1 %2 (BIOS %3)").arg(readFirstLine("/sys/class/dmi/id/board_vendor"),
        readFirstLine("/sys/class/dmi/id/board_name"), readFirstLine("/sys/class/dmi/id/bios_version")).trimmed());
    QFile cpuInfo("/proc/cpuinfo"); QString model = "Unknown CPU", curPhys, curCore; int logical = 0; QSet<QString> physSet;
    if (cpuInfo.open(QIODevice::ReadOnly | QIODevice::Text)) {
        for (const QString &line : QString::fromUtf8(cpuInfo.readAll()).split('\n')) {
            if (line.startsWith("model name") && model == "Unknown CPU") model = line.section(':', 1).trimmed();
            else if (line.startsWith("processor")) logical++;
            else if (line.startsWith("physical id")) curPhys = line.section(':', 1).trimmed();
            else if (line.startsWith("core id")) { curCore = line.section(':', 1).trimmed(); physSet.insert(curPhys + ":" + curCore); }
        }
    }
    m_cpuModelLbl->setText(model);
    m_cpuCoresLbl->setText(QString("%1 Physical Cores / %2 Logical Threads").arg(physSet.isEmpty() ? logical : physSet.size()).arg(logical));
    QProcess lspci; lspci.start("lspci", {"-mm"}); lspci.waitForFinished(1500);
    for (const QString &line : QString::fromUtf8(lspci.readAllStandardOutput()).split('\n')) {
        if (line.contains("\"VGA") || line.contains("\"3D") || line.contains("\"Display")) {
            QString clean = line; clean.remove('"'); m_gpuModelLbl->setText(clean.split(' ').mid(1).join(' ')); break;
        }
    }
    if (m_gpuModelLbl->text().isEmpty()) m_gpuModelLbl->setText("DRM / Framebuffer Device");
}

void SystemInfoWidget::updateTelemetry() { updateCpuUsage(); updateMemoryUsage(); updateTmpfsUsage(); updateGpuInfo(); }
void SystemInfoWidget::updateCpuUsage() {
    QFile f("/proc/stat"); if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) return;
    QStringList mhzList; double avgMhz = 0.0; QFile fInfo("/proc/cpuinfo");
    if (fInfo.open(QIODevice::ReadOnly | QIODevice::Text))
        for (const QString &l : QString::fromUtf8(fInfo.readAll()).split('\n'))
            if (l.startsWith("cpu MHz")) { double m = l.section(':', 1).trimmed().toDouble(); avgMhz += m; mhzList.append(QString::number(m, 'f', 1) + " MHz"); }
    if (!mhzList.isEmpty()) avgMhz /= mhzList.size();
    int row = 1; double totalPct = 0.0; QVector<double> threadPcts;
    for (const QString &line : QString::fromUtf8(f.readAll()).split('\n', Qt::SkipEmptyParts)) {
        if (!line.startsWith("cpu")) continue;
        const QStringList p = line.split(QRegularExpression("\\s+"), Qt::SkipEmptyParts);
        if (p.size() < 5) continue;
        CpuTimes cur{p.at(1).toULongLong() + p.at(2).toULongLong() + p.at(3).toULongLong(), p.at(4).toULongLong() + (p.size() > 5 ? p.at(5).toULongLong() : 0)};
        CpuTimes prev = m_prevCpu.value(p.at(0), cur); m_prevCpu[p.at(0)] = cur;
        quint64 dAct = cur.active - prev.active, dTot = dAct + (cur.idle - prev.idle);
        double pct = dTot > 0 ? (100.0 * dAct / dTot) : 0.0;
        if (p.at(0) == "cpu") {
            totalPct = pct; m_totalCpuBar->setValue(int(pct));
            m_cpuDetailLbl->setText(QString("Active: %1% | Idle: %2%").arg(pct, 0, 'f', 1).arg(100.0 - pct, 0, 'f', 1));
            m_threadTable->setItem(0, 0, new QTableWidgetItem("Overall CPU"));
            m_threadTable->setItem(0, 1, new QTableWidgetItem(QString::number(pct, 'f', 1) + "%"));
            m_threadTable->setItem(0, 2, new QTableWidgetItem(QString::number(100.0 - pct, 'f', 1) + "%"));
            m_threadTable->setItem(0, 3, new QTableWidgetItem(QString::number(avgMhz, 'f', 1) + " MHz (avg)"));
        } else {
            threadPcts.append(pct);
            if (m_threadTable->rowCount() <= row) m_threadTable->insertRow(row);
            m_threadTable->setItem(row, 0, new QTableWidgetItem(p.at(0)));
            m_threadTable->setItem(row, 1, new QTableWidgetItem(QString::number(pct, 'f', 1) + "%"));
            m_threadTable->setItem(row, 2, new QTableWidgetItem(QString::number(100.0 - pct, 'f', 1) + "%"));
            m_threadTable->setItem(row, 3, new QTableWidgetItem(row - 1 < mhzList.size() ? mhzList.at(row - 1) : "N/A"));
            row++;
        }
    }
    m_graph->pushSample(totalPct, threadPcts);
}

void SystemInfoWidget::updateMemoryUsage() {
    QFile f("/proc/meminfo"); if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) return;
    QMap<QString, quint64> m;
    for (const QString &l : QString::fromUtf8(f.readAll()).split('\n', Qt::SkipEmptyParts))
        m[l.section(':', 0, 0)] = l.section(':', 1).trimmed().section(' ', 0, 0).toULongLong() * 1024ULL;
    quint64 tot = m.value("MemTotal"), free = m.value("MemFree"), cache = m.value("Cached") + m.value("Buffers") + m.value("SReclaimable");
    quint64 used = tot > (free + cache) ? (tot - free - cache) : 0;
    m_ramBar->setValue(tot > 0 ? int((used * 100) / tot) : 0);
    m_ramDetailLbl->setText(QString("Total: %1 | Used: %2 | Cached: %3 | Free: %4").arg(formatBytes(tot), formatBytes(used), formatBytes(cache), formatBytes(free)));
    quint64 sTot = m.value("SwapTotal"), sFree = m.value("SwapFree"), sUsed = sTot > sFree ? (sTot - sFree) : 0;
    m_swapBar->setValue(sTot > 0 ? int((sUsed * 100) / sTot) : 0);
    m_swapDetailLbl->setText(sTot > 0 ? QString("Total: %1 | Used: %2 | Free: %3").arg(formatBytes(sTot), formatBytes(sUsed), formatBytes(sFree)) : "No swap found");
    m_destroySwapBtn->setEnabled(QFile::exists("/var/tmp/gentool-ng.swap"));
}

void SystemInfoWidget::updateTmpfsUsage() {
    const QString path = QDir("/var/tmp/notmpfs").exists() ? "/var/tmp/notmpfs" : "/var/tmp/portage";
    QStorageInfo st(path);
    if (st.isValid() && st.isReady()) {
        quint64 tot = st.bytesTotal(), free = st.bytesAvailable(), used = tot > free ? (tot - free) : 0;
        m_tmpfsBar->setValue(tot > 0 ? int((used * 100) / tot) : 0);
        m_tmpfsDetailLbl->setText(QString("%1 (%2) — Total: %3 | Used: %4 | Free: %5")
            .arg(path, QString::fromLatin1(st.fileSystemType()), formatBytes(tot), formatBytes(used), formatBytes(free)));
    } else {
        m_tmpfsBar->setValue(0); m_tmpfsDetailLbl->setText(path + " not mounted");
    }
}

void SystemInfoWidget::updateGpuInfo() {
    for (const QString &card : QDir("/sys/class/drm").entryList({"card[0-9]"}, QDir::Dirs)) {
        const QString totStr = readFirstLine("/sys/class/drm/" + card + "/device/mem_info_vram_total");
        if (!totStr.isEmpty()) {
            quint64 tot = totStr.toULongLong(), used = readFirstLine("/sys/class/drm/" + card + "/device/mem_info_vram_used").toULongLong();
            m_vramBar->setValue(tot > 0 ? int((used * 100) / tot) : 0);
            m_vramDetailLbl->setText(QString("Total: %1 | Used: %2 | Free: %3").arg(formatBytes(tot), formatBytes(used), formatBytes(tot > used ? tot - used : 0)));
            return;
        }
    }
    m_vramBar->setValue(0); m_vramDetailLbl->setText("Shared / Driver VRAM telemetry unavailable");
}
