#include "EselectWidget.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QSplitter>
#include <QProcess>
#include <QRegularExpression>

EselectWidget::EselectWidget(QWidget *parent) : QWidget(parent) {
    auto *lay = new QVBoxLayout(this);
    auto *top = new QHBoxLayout();
    m_statusLbl = new QLabel("Select an eselect module to view or switch active targets:");
    m_refreshBtn = new QPushButton(QIcon::fromTheme("view-refresh"), "Refresh");
    m_setBtn = new QPushButton(QIcon::fromTheme("dialog-ok-apply"), "Set Active");
    for (QPushButton *b : {m_refreshBtn, m_setBtn}) { b->setMaximumHeight(24); b->setSizePolicy(QSizePolicy::Maximum, QSizePolicy::Fixed); b->setStyleSheet("QPushButton { padding: 2px 8px; font-size: 11px; }"); }
    m_setBtn->setEnabled(false);
    top->addWidget(m_statusLbl, 1);
    top->addWidget(m_refreshBtn);
    top->addWidget(m_setBtn);
    lay->addLayout(top);

    auto *split = new QSplitter(Qt::Horizontal);
    m_modList = new QListWidget();
    m_modList->setMaximumWidth(260);
    m_optTree = new QTreeWidget();
    m_optTree->setHeaderLabels({"Index", "Target / Profile", "State"});
    split->addWidget(m_modList);
    split->addWidget(m_optTree);
    lay->addWidget(split, 1);

    connect(m_refreshBtn, &QPushButton::clicked, this, &EselectWidget::loadModules);
    connect(m_modList, &QListWidget::itemClicked, this, &EselectWidget::onModuleSelected);
    connect(m_setBtn, &QPushButton::clicked, this, &EselectWidget::applySelection);
    loadModules();
}
void EselectWidget::loadModules() {
    m_modList->clear();
    QProcess p;
    p.start("eselect", {"modules", "list"});
    p.waitForFinished(3000);
    const QString out = QString::fromUtf8(p.readAllStandardOutput());
    for (const QString &line : out.split('\n', Qt::SkipEmptyParts)) {
        if (line.startsWith("Built-in") || line.startsWith("Extra")) continue;
        const QString mod = line.trimmed().section(' ', 0, 0);
        if (!mod.isEmpty() && mod != "help" && mod != "usage" && mod != "version")
            m_modList->addItem(mod);
    }
}

void EselectWidget::onModuleSelected(QListWidgetItem *item) {
    if (!item) return;
    m_currentModule = item->text();
    m_optTree->clear();
    m_setBtn->setEnabled(false);

    QProcess p;
    p.start("eselect", {m_currentModule, "list"});
    p.waitForFinished(3000);
    const QString out = QString::fromUtf8(p.readAllStandardOutput());
    static const QRegularExpression rx("^\\s*\\[(\\d+)\\]\\s+(.+?)(?:\\s+(\\*))?$");
    for (const QString &line : out.split('\n', Qt::SkipEmptyParts)) {
        auto m = rx.match(line);
        if (!m.hasMatch()) continue;
        const bool active = (m.captured(3) == "*");
        auto *row = new QTreeWidgetItem(m_optTree, {m.captured(1), m.captured(2).trimmed(), active ? "Active (*)" : ""});
        if (active) {
            QFont f = row->font(1); f.setBold(true);
            row->setFont(1, f); row->setForeground(2, QColor("#98c379"));
        }
    }
    m_setBtn->setEnabled(m_optTree->topLevelItemCount() > 0);
}

void EselectWidget::applySelection() {
    auto *cur = m_optTree->currentItem();
    if (!cur || m_currentModule.isEmpty()) return;
    QProcess p;
    p.start("eselect", {m_currentModule, "set", cur->text(0)});
    p.waitForFinished(4000);
    m_statusLbl->setText(p.exitCode() == 0
        ? QString("Updated eselect %1 -> [%2] %3").arg(m_currentModule, cur->text(0), cur->text(1))
        : QString("Failed: %1").arg(QString::fromUtf8(p.readAllStandardError()).trimmed()));
    onModuleSelected(m_modList->currentItem());
}
