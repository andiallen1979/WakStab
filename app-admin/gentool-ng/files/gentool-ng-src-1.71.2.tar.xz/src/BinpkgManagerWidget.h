#pragma once
#include <QWidget>
#include <QTreeWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QLabel>
#include <QPlainTextEdit>

class BinpkgManagerWidget : public QWidget {
    Q_OBJECT
public:
    explicit BinpkgManagerWidget(QWidget *parent = nullptr);
private Q_SLOTS:
    void scanBinpkgs();
    void filterTree(const QString &text);
    void installSelected();
    void buildQuickpkg();
    void rebuildIndex();
    void deleteSelected();
private:
    QString resolvePkgDir() const;
    QString m_pkgDir;
    QLineEdit *m_searchEdit;
    QTreeWidget *m_tree;
    QPushButton *m_rescanBtn, *m_installBtn, *m_quickBtn, *m_indexBtn, *m_delBtn;
    QLabel *m_summaryLbl;
    QPlainTextEdit *m_outLog;
};
