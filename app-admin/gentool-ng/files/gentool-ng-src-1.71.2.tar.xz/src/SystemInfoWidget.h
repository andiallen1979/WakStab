#pragma once
#include <QCheckBox>
#include <QLabel>
#include <QMap>
#include <QProgressBar>
#include <QPushButton>
#include <QTableWidget>
#include <QTimer>
#include <QVector>
#include <QWidget>

struct CpuTimes { quint64 active = 0; quint64 idle = 0; };

class SystemGraphWidget : public QWidget {
    Q_OBJECT
public:
    explicit SystemGraphWidget(QWidget *parent = nullptr);
    void pushSample(double totalCpu, const QVector<double> &threads);
protected:
    void paintEvent(QPaintEvent *event) override;
private:
    QVector<double> m_totalHist;
    QVector<QVector<double>> m_threadHist;
};

class SystemInfoWidget : public QWidget {
    Q_OBJECT
public:
    explicit SystemInfoWidget(QWidget *parent = nullptr);
private Q_SLOTS:
    void updateTelemetry();
    void toggleThreadsCollapsed();
    void createTempSwap();
    void destroyTempSwap();
    void resizeTmpfs();
private:
    void loadStaticHardwareInfo();
    void updateCpuUsage();
    void updateMemoryUsage();
    void updateTmpfsUsage();
    void updateGpuInfo();
    void updateMountsTable();
    QLabel *m_cpuModelLbl, *m_cpuCoresLbl, *m_kernelLbl, *m_boardLbl, *m_gpuModelLbl;
    QProgressBar *m_totalCpuBar, *m_ramBar, *m_swapBar, *m_tmpfsBar, *m_vramBar;
    QLabel *m_cpuDetailLbl, *m_ramDetailLbl, *m_swapDetailLbl, *m_tmpfsDetailLbl, *m_vramDetailLbl;
    QCheckBox *m_permSwapChk = nullptr;
    QPushButton *m_createSwapBtn, *m_destroySwapBtn, *m_resizeTmpfsBtn, *m_collapseBtn;
    SystemGraphWidget *m_graph;
    QTableWidget *m_threadTable, *m_mountTable = nullptr;
    QTimer *m_timer;
    QMap<QString, CpuTimes> m_prevCpu;
    bool m_collapsed = false;
};
