#include "GtSnapManager.h"
#include <QUuid>
#include <QDir>
#include <QFile>
#include <QDateTime>
#include <QJsonDocument>
#include <QProcess>
#include <sys/utsname.h>

QString GtSnapManager::baseStoreDir() {
    const QString dir = QStringLiteral("/var/lib/gtsnap/packages");
    QDir().mkpath(dir);
    return dir;
}

GtSnapPackage GtSnapManager::initWizardWorkspace(const QString &name, const QString &initSystem, const QString &variant, const QString &bootloader, const QString &timezone) {
    GtSnapPackage pkg;
    pkg.uuid = QUuid::createUuid().toString(QUuid::Id128).left(8);
    pkg.name = name.trimmed().isEmpty() ? QStringLiteral("gtsnap-") + pkg.uuid : name.trimmed();
    pkg.hostname = QStringLiteral("gt-") + pkg.uuid;
    pkg.ephemeralPass = QUuid::createUuid().toString(QUuid::Id128).left(16);
    pkg.createdIso = QDateTime::currentDateTimeUtc().toString(Qt::ISODate);
    pkg.initSystem = initSystem;
    pkg.pkgDir = baseStoreDir() + QLatin1Char('/') + pkg.uuid;
    pkg.rawImagePath = pkg.pkgDir + QStringLiteral("/staging.raw");
    pkg.mountDir = pkg.pkgDir + QStringLiteral("/mnt");
    QDir().mkpath(pkg.mountDir);
    QDir().mkpath(pkg.pkgDir + QStringLiteral("/config"));

    QJsonObject meta;
    meta[QStringLiteral("format")] = QStringLiteral("gtsnap-v1");
    meta[QStringLiteral("uuid")] = pkg.uuid;
    meta[QStringLiteral("name")] = pkg.name;
    meta[QStringLiteral("created")] = pkg.createdIso;
    meta[QStringLiteral("init")] = initSystem;
    meta[QStringLiteral("variant")] = variant;
    meta[QStringLiteral("bootloader")] = bootloader;
    meta[QStringLiteral("hostname")] = pkg.hostname;
    meta[QStringLiteral("ephemeralRootPass")] = pkg.ephemeralPass;
    meta[QStringLiteral("timezone")] = timezone;
    meta[QStringLiteral("rawImage")] = pkg.rawImagePath;
    meta[QStringLiteral("mountDir")] = pkg.mountDir;

    QFile mf(pkg.pkgDir + QStringLiteral("/manifest.json"));
    if (mf.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
        mf.write(QJsonDocument(meta).toJson(QJsonDocument::Indented));
        mf.close();
    }
    return pkg;
}

GtSnapPackage GtSnapManager::createPackage(const QString &name, const QString &initSystem, const QString &sourceRoot) {
    GtSnapPackage pkg = initWizardWorkspace(name, initSystem, QString(), QString(), QString());
    struct utsname uts {};
    pkg.arch = (uname(&uts) == 0) ? QString::fromLatin1(uts.machine) : QStringLiteral("x86_64");
    QString root = sourceRoot;
    while (root.size() > 1 && root.endsWith(QLatin1Char('/'))) root.chop(1);
    const QString prefix = (root == QStringLiteral("/")) ? QString() : root;
    const QString cfgDir = pkg.pkgDir + QStringLiteral("/config");
    QString snapCmd = QStringLiteral(
        "cp -a '%1/etc/portage' '%2/portage' 2>/dev/null || true; "
        "cp -f '%1/var/lib/portage/world' '%2/world' 2>/dev/null || true; "
        "cp -f '%1/etc/fstab' '%2/fstab.template' 2>/dev/null || true"
    ).arg(prefix, cfgDir);
    QProcess::execute(QStringLiteral("/bin/sh"), {QStringLiteral("-c"), snapCmd});
    return pkg;
}

QList<GtSnapPackage> GtSnapManager::listPackages() {
    QList<GtSnapPackage> out;
    QDir base(baseStoreDir());
    for (const QString &sub : base.entryList(QDir::Dirs | QDir::NoDotAndDotDot, QDir::Time)) {
        const QString dirPath = base.filePath(sub);
        QFile mf(dirPath + QStringLiteral("/manifest.json"));
        if (!mf.open(QIODevice::ReadOnly)) continue;
        const QJsonObject obj = QJsonDocument::fromJson(mf.readAll()).object();
        GtSnapPackage p;
        p.uuid = obj.value(QStringLiteral("uuid")).toString(sub);
        p.name = obj.value(QStringLiteral("name")).toString(sub);
        p.createdIso = obj.value(QStringLiteral("created")).toString();
        p.initSystem = obj.value(QStringLiteral("init")).toString();
        p.arch = obj.value(QStringLiteral("arch")).toString();
        p.pkgDir = dirPath;
        p.rawImagePath = obj.value(QStringLiteral("rawImage")).toString();
        p.mountDir = obj.value(QStringLiteral("mountDir")).toString();
        p.hasRootfs = QFile::exists(dirPath + QStringLiteral("/rootfs.sqfs"));
        p.hasEsp = QFile::exists(dirPath + QStringLiteral("/esp.sqfs"));
        out.append(p);
    }
    return out;
}

bool GtSnapManager::exportConfigBundle(const QString &uuid, const QString &targetRoot) {
    const QString cfgDir = baseStoreDir() + QLatin1Char('/') + uuid + QStringLiteral("/config");
    if (!QDir(cfgDir).exists()) return false;
    QString dst = targetRoot.trimmed();
    while (dst.size() > 1 && dst.endsWith(QLatin1Char('/'))) dst.chop(1);
    const QString prefix = (dst == QStringLiteral("/")) ? QString() : dst;
    QString cmd = QStringLiteral(
        "mkdir -p '%1/etc' '%1/var/lib/portage'; "
        "[ -d '%2/portage' ] && cp -a '%2/portage/.' '%1/etc/portage/'; "
        "[ -f '%2/world' ] && cp -f '%2/world' '%1/var/lib/portage/world'"
    ).arg(prefix, cfgDir);
    return QProcess::execute(QStringLiteral("/bin/sh"), {QStringLiteral("-c"), cmd}) == 0;
}

bool GtSnapManager::deletePackage(const QString &uuid) {
    if (uuid.isEmpty() || uuid.contains(QLatin1Char('/')) || uuid.contains(QStringLiteral(".."))) return false;
    return QDir(baseStoreDir() + QLatin1Char('/') + uuid).removeRecursively();
}

void GtSnapManager::cleanupStaleMountsAndLoops() {
    const QString script = QStringLiteral(R"SH(
set +e
for base in /var/lib/gtsnap/packages/*/mnt /mnt/wakstab-chroot /mnt/gentool-novice-stage /mnt/gentool-clone-src /mnt/gentool-clone-dst; do
  [ -d "$base" ] || continue
  for mp in $(findmnt -R -r -n -o TARGET "$base" 2>/dev/null | sort -r); do
    umount -lf "$mp" 2>/dev/null || true
  done
done
for img in /var/lib/gtsnap/packages/*/staging.raw /var/tmp/gentool-ng-novice.raw; do
  [ -e "$img" ] || continue
  for l in $(losetup -j "$img" -O NAME --noheadings 2>/dev/null || true); do
    for pt in "${l}"p* "$l"; do umount -lf "$pt" 2>/dev/null || true; done
    losetup -d "$l" 2>/dev/null || true
  done
done
if mountpoint -q /var/lib/gtsnap/cache/mnt; then
  HDEV=$(findmnt -no SOURCE /var/lib/gtsnap/cache/mnt 2>/dev/null || true)
  umount -lf /var/lib/gtsnap/cache/mnt 2>/dev/null || true
  [ -n "$HDEV" ] && qemu-nbd --disconnect "$HDEV" 2>/dev/null || true
fi
udevadm settle 2>/dev/null || true
)SH");
    QProcess::execute(QStringLiteral("/bin/sh"), {QStringLiteral("-c"), script});
}

QList<GtSnapPackage> GtSnapManager::findActiveStagingPackages() {
    QList<GtSnapPackage> active;
    for (const GtSnapPackage &pkg : listPackages()) {
        if (QFile::exists(pkg.pkgDir + QStringLiteral("/staging.raw"))) {
            active.append(pkg);
        }
    }
    return active;
}

void GtSnapManager::destroyStagingPackages(const QList<GtSnapPackage> &pkgs) {
    cleanupStaleMountsAndLoops();
    for (const GtSnapPackage &pkg : pkgs) {
        deletePackage(pkg.uuid);
    }
}

QString GtSnapManager::ensureCacheHordeMounted(int sizeGb) {
    const QString cacheBase = baseStoreDir() + QStringLiteral("/cache");
    const QString qcowPath = cacheBase + QStringLiteral("/gentool-data-horde.qcow2");
    const QString mntDir = cacheBase + QStringLiteral("/mnt");
    const QString script = QStringLiteral(R"SH(
set -e
QCOW='%1'; MNT='%2'; GB='%3'
mkdir -p "$(dirname "$QCOW")" "$MNT"
if ! mountpoint -q "$MNT"; then
  modprobe nbd max_part=8 2>/dev/null || true
  if [ ! -f "$QCOW" ]; then
    qemu-img create -f qcow2 "$QCOW" "${GB}G"
  fi
  NBD=""
  for dev in $(ls -1 /dev/nbd[0-9]* 2>/dev/null | grep -E '^/dev/nbd[0-9]+$' | sort -Vr); do
    [ -b "$dev" ] || continue
    SZ=$(cat "/sys/block/$(basename "$dev")/size" 2>/dev/null || echo 0)
    if [ "$SZ" = "0" ]; then NBD="$dev"; break; fi
  done
  [ -n "$NBD" ] || { echo "No free /dev/nbd12-15 device for Data Horde" >&2; exit 1; }
  qemu-nbd --connect="$NBD" "$QCOW"
  udevadm settle
  if ! blkid "$NBD" >/dev/null 2>&1; then
    mkfs.ext4 -F -L gentool-horde "$NBD"
  fi
  mount "$NBD" "$MNT"
fi
mkdir -p "$MNT/binpkgs" "$MNT/distfiles" "$MNT/portage-tmp" "$MNT/stage3"
echo "$MNT"
)SH").arg(qcowPath, mntDir).arg(sizeGb);
    QProcess::execute(QStringLiteral("/bin/sh"), {QStringLiteral("-c"), script});
    return mntDir;
}

void GtSnapManager::archiveStage3ToProfile(const QString &tarPath, const QString &pkgDir) {
    if (tarPath.isEmpty() || !QFile::exists(tarPath) || pkgDir.isEmpty()) return;
    const QString cacheS3 = baseStoreDir() + QStringLiteral("/cache/mnt/stage3");
    QDir().mkpath(pkgDir);
    QDir().mkpath(cacheS3);
    const QString fname = QFileInfo(tarPath).fileName();
    const QString profDest = pkgDir + QLatin1Char('/') + fname;
    if (!QFile::exists(profDest)) QFile::copy(tarPath, profDest);
    const QString cacheDest = cacheS3 + QLatin1Char('/') + fname;
    if (!QFile::exists(cacheDest)) QFile::copy(tarPath, cacheDest);
    if (QFile::exists(tarPath + QStringLiteral(".DIGESTS")) && !QFile::exists(profDest + QStringLiteral(".DIGESTS"))) {
        QFile::copy(tarPath + QStringLiteral(".DIGESTS"), profDest + QStringLiteral(".DIGESTS"));
    }
}
