#pragma once
#include <QWidget>
#include <QComboBox>
#include <QLineEdit>
#include <QPushButton>
#include <QProgressBar>
#include <QTextEdit>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QProcess>

class Stage3Widget : public QWidget {
    Q_OBJECT
public:
    explicit Stage3Widget(QWidget *parent = nullptr);
Q_SIGNALS:
    void enterChrootRequested(const QString &targetDir);
    void extractionCompleted(const QString &targetDir);
private Q_SLOTS:
    void fetchManifest();
    void onManifestFetched();
    void onInitChanged();
    void filterReleases();
    void onReleaseSelected();
    void startDownload();
    void onDownloadProgress(qint64 rec, qint64 tot);
    void onDownloadFinished();
    void verifyTarball();
    void extractTarball();
    void runFullSequence();
private:
    QNetworkAccessManager *m_nam;
    QComboBox *m_mirrorCombo, *m_archCombo, *m_initCombo, *m_releaseCombo;
    QLineEdit *m_targetDirEdit;
    QPushButton *m_downloadBtn, *m_verifyBtn, *m_extractBtn, *m_chrootBtn, *m_continueBtn;
    bool m_autoSequence = false;
    QProgressBar *m_progress;
    QTextEdit *m_log;
    QStringList m_rawEntries;
    QString m_downloadedTarball, m_expectedSha512;
};
