#include "Stage3Widget.h"
#include "GentooStrings.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>
#include <QFile>
#include <QCryptographicHash>
#include <QRegularExpression>
#include <QDir>
#include <QFileDialog>

Stage3Widget::Stage3Widget(QWidget *parent)
    : QWidget(parent), m_nam(new QNetworkAccessManager(this)) {
    m_nam->setRedirectPolicy(QNetworkRequest::NoLessSafeRedirectPolicy);
    auto *mainLayout = new QVBoxLayout(this);
    auto *form = new QFormLayout();
    m_mirrorCombo = new QComboBox();
    m_mirrorCombo->setEditable(true);
    m_mirrorCombo->addItems(GentooStrings::defaultMirrors());
    m_mirrorCombo->setCurrentText(GentooStrings::defaultMirror());
    m_archCombo = new QComboBox();
    m_archCombo->addItems({"amd64", "arm64", "riscv", "x86"});
    m_initCombo = new QComboBox();
    m_initCombo->addItems({"openrc", "systemd", "desktop-openrc", "desktop-systemd", "musl", "All"});
    m_releaseCombo = new QComboBox();
    m_targetDirEdit = new QLineEdit("/mnt/wakstab-chroot");

    form->addRow("Gentoo Mirror:", m_mirrorCombo);
    form->addRow("Architecture:", m_archCombo);
    form->addRow("Init / Variant:", m_initCombo);
    form->addRow("Available Stage3:", m_releaseCombo);
    auto *targetRow = new QHBoxLayout();
    targetRow->setContentsMargins(0, 0, 0, 0);
    targetRow->setSpacing(4);
    auto *browseTargetBtn = new QPushButton("Browse...");
    browseTargetBtn->setMaximumHeight(24);
    browseTargetBtn->setStyleSheet("QPushButton { padding: 2px 8px; font-size: 11px; }");
    targetRow->addWidget(m_targetDirEdit, 1);
    targetRow->addWidget(browseTargetBtn);
    connect(browseTargetBtn, &QPushButton::clicked, this, [this]() {
        const QString dir = QFileDialog::getExistingDirectory(this, "Select Extract Mount Point", "/mnt");
        if (!dir.isEmpty()) m_targetDirEdit->setText(dir);
    });
    form->addRow("Extract Target:", targetRow);
    mainLayout->addLayout(form);

    m_progress = new QProgressBar();
    m_log = new QTextEdit();
    m_log->setReadOnly(true);
    mainLayout->addWidget(m_progress);
    mainLayout->addWidget(m_log, 1);
    auto *btnRow = new QHBoxLayout();
    btnRow->setSpacing(6);
    m_downloadBtn = new QPushButton("Download");
    m_verifyBtn = new QPushButton("Verify");
    m_extractBtn = new QPushButton("Extract");
    m_chrootBtn = new QPushButton("Enter Chroot");
    m_continueBtn = new QPushButton("Continue");
    for (QPushButton *b : {m_downloadBtn, m_verifyBtn, m_extractBtn, m_chrootBtn, m_continueBtn}) {
        b->setMaximumHeight(24);
        b->setStyleSheet("QPushButton { padding: 2px 10px; font-size: 11px; }");
        b->setEnabled(false);
    }
    for (QPushButton *b : {m_downloadBtn, m_verifyBtn, m_extractBtn, m_chrootBtn}) btnRow->addWidget(b);
    btnRow->addStretch(1);
    btnRow->addWidget(m_continueBtn);
    mainLayout->addLayout(btnRow);

    connect(m_mirrorCombo, &QComboBox::currentTextChanged, this, &Stage3Widget::fetchManifest);
    connect(m_archCombo, &QComboBox::currentTextChanged, this, &Stage3Widget::fetchManifest);
    connect(m_initCombo, &QComboBox::currentTextChanged, this, &Stage3Widget::onInitChanged);
    connect(m_releaseCombo, &QComboBox::currentTextChanged, this, &Stage3Widget::onReleaseSelected);
    connect(m_downloadBtn, &QPushButton::clicked, this, &Stage3Widget::startDownload);
    connect(m_verifyBtn, &QPushButton::clicked, this, &Stage3Widget::verifyTarball);
    connect(m_extractBtn, &QPushButton::clicked, this, &Stage3Widget::extractTarball);
    connect(m_chrootBtn, &QPushButton::clicked, this, [this]() { Q_EMIT enterChrootRequested(m_targetDirEdit->text().trimmed()); });
    connect(m_continueBtn, &QPushButton::clicked, this, &Stage3Widget::runFullSequence);

    fetchManifest();
}
void Stage3Widget::onInitChanged() {
    if (m_rawEntries.isEmpty()) fetchManifest();
    else filterReleases();
    if (m_autoChain && m_releaseCombo->count() > 0) startDownload();
}

void Stage3Widget::fetchManifest() {
    m_rawEntries.clear(); m_releaseCombo->clear();
    m_downloadBtn->setEnabled(false); m_verifyBtn->setEnabled(false); m_extractBtn->setEnabled(false);
    const QUrl url = GentooStrings::manifestUrl(m_mirrorCombo->currentText(), m_archCombo->currentText());
    Q_EMIT statusMessage(m_log->toPlainText().section('\n', -1)); m_log->append("Fetching: " + url.toString());
    auto *reply = m_nam->get(QNetworkRequest(url));
    connect(reply, &QNetworkReply::finished, this, &Stage3Widget::onManifestFetched);
}

void Stage3Widget::onManifestFetched() {
    auto *reply = qobject_cast<QNetworkReply*>(sender());
    if (!reply) return; reply->deleteLater();
    if (reply->error() != QNetworkReply::NoError) { Q_EMIT statusMessage(m_log->toPlainText().section('\n', -1)); m_log->append("Error: " + reply->errorString()); return; }
    for (const QString &line : QString::fromUtf8(reply->readAll()).split('\n', Qt::SkipEmptyParts)) {
        if (line.startsWith('#') || line.startsWith("-----")) continue;
        const QString path = line.section(' ', 0, 0).trimmed();
        if (path.endsWith(".tar.xz") || path.endsWith(".tar.zst")) m_rawEntries.append(path);
    }
    Q_EMIT statusMessage(m_log->toPlainText().section('\n', -1)); m_log->append(QString("Found %1 stage3 builds.").arg(m_rawEntries.size()));
    filterReleases();
    if (m_autoChain && m_releaseCombo->count() > 0) startDownload();
}

void Stage3Widget::filterReleases() {
    m_releaseCombo->clear();
    const QString filter = m_initCombo->currentText();
    for (const QString &e : m_rawEntries)
        if (filter == "All" || e.contains(filter, Qt::CaseInsensitive)) m_releaseCombo->addItem(e);
    onReleaseSelected();
}

void Stage3Widget::onReleaseSelected() {
    const QString rel = m_releaseCombo->currentText();
    const bool hasRel = !rel.isEmpty();
    m_downloadBtn->setEnabled(hasRel); m_continueBtn->setEnabled(hasRel);
    if (hasRel) {
        m_downloadedTarball = "/tmp/" + rel.section('/', -1);
        const bool exists = QFile::exists(m_downloadedTarball);
        m_verifyBtn->setEnabled(exists);
        m_extractBtn->setEnabled(exists);
    }
}
void Stage3Widget::startDownload() {
    const QString rel = m_releaseCombo->currentText(); if (rel.isEmpty()) return;
    m_downloadBtn->setEnabled(false); m_verifyBtn->setEnabled(false); m_extractBtn->setEnabled(false);
    const QString fullUrl = GentooStrings::releaseFileUrl(m_mirrorCombo->currentText(), m_archCombo->currentText(), rel);
    const QString fileName = rel.section('/', -1); m_downloadedTarball = "/tmp/" + fileName;
    auto *digReply = m_nam->get(QNetworkRequest(QUrl(fullUrl + ".DIGESTS")));
    connect(digReply, &QNetworkReply::finished, this, [this, digReply, fullUrl, fileName]() {
        digReply->deleteLater();
        QRegularExpression rx(QString("([0-9a-fA-F]{128})\\s+%1").arg(QRegularExpression::escape(fileName)));
        auto m = rx.match(QString::fromUtf8(digReply->readAll()));
        m_expectedSha512 = m.hasMatch() ? m.captured(1).toLower() : QString();
        Q_EMIT statusMessage(m_log->toPlainText().section('\n', -1)); m_log->append("Downloading: " + fullUrl);
        auto *tarReply = m_nam->get(QNetworkRequest(QUrl(fullUrl)));
        connect(tarReply, &QNetworkReply::downloadProgress, this, &Stage3Widget::onDownloadProgress);
        connect(tarReply, &QNetworkReply::finished, this, &Stage3Widget::onDownloadFinished);
    });
}
void Stage3Widget::onDownloadProgress(qint64 r, qint64 t) { if (t > 0) { m_progress->setMaximum(100); int pct = int((r * 100) / t); m_progress->setValue(pct); Q_EMIT progressUpdated(pct); } }
void Stage3Widget::onDownloadFinished() {
    auto *reply = qobject_cast<QNetworkReply*>(sender()); if (!reply) return; reply->deleteLater();
    m_downloadBtn->setEnabled(true);
    if (reply->error() != QNetworkReply::NoError) { Q_EMIT statusMessage(m_log->toPlainText().section('\n', -1)); m_log->append("Failed: " + reply->errorString()); return; }
    QFile out(m_downloadedTarball); if (!out.open(QIODevice::WriteOnly)) return; out.write(reply->readAll()); out.close();
    Q_EMIT statusMessage(m_log->toPlainText().section('\n', -1)); m_log->append("Download saved to " + m_downloadedTarball + ". Ready to verify.");
    m_verifyBtn->setEnabled(true); m_extractBtn->setEnabled(true);
    if (m_autoChain) verifyTarball();
    if (m_autoSequence) verifyTarball();
}
void Stage3Widget::verifyTarball() {
    const QString rel = m_releaseCombo->currentText();
    if (rel.isEmpty()) return;
    const QString fileName = rel.section('/', -1);
    const QString digUrl = GentooStrings::releaseFileUrl(m_mirrorCombo->currentText(), m_archCombo->currentText(), rel) + ".DIGESTS";
    Q_EMIT statusMessage(m_log->toPlainText().section('\n', -1)); m_log->append("Fetching DIGESTS: " + digUrl);
    auto *digReply = m_nam->get(QNetworkRequest(QUrl(digUrl)));
    connect(digReply, &QNetworkReply::finished, this, [this, digReply, fileName]() {
        digReply->deleteLater();
        if (digReply->error() != QNetworkReply::NoError) {
            Q_EMIT statusMessage(m_log->toPlainText().section('\n', -1)); m_log->append("DIGESTS fetch failed: " + digReply->errorString());
            return;
        }
        const QString digText = QString::fromUtf8(digReply->readAll());
        QRegularExpression rx(QString("# SHA512 HASH\\s+([0-9a-fA-F]{128})\\s+\\*?%1").arg(QRegularExpression::escape(fileName)));
        auto m = rx.match(digText);
        m_expectedSha512 = m.hasMatch() ? m.captured(1).toLower() : QString();
        QFile f(m_downloadedTarball);
        if (!f.open(QIODevice::ReadOnly)) { Q_EMIT statusMessage(m_log->toPlainText().section('\n', -1)); m_log->append("Cannot open " + m_downloadedTarball); return; }
        QCryptographicHash h(QCryptographicHash::Sha512);
        h.addData(&f);
        const QString actual = QString::fromLatin1(h.result().toHex()).toLower();
        Q_EMIT statusMessage(m_log->toPlainText().section('\n', -1)); m_log->append("Expected SHA-512: " + (m_expectedSha512.isEmpty() ? "NOT FOUND" : m_expectedSha512));
        Q_EMIT statusMessage(m_log->toPlainText().section('\n', -1)); m_log->append("Actual   SHA-512: " + actual);
        if (m_expectedSha512.isEmpty() || actual != m_expectedSha512) {
            Q_EMIT statusMessage(m_log->toPlainText().section('\n', -1)); m_log->append("CRITICAL: SHA-512 mismatch!");
            m_extractBtn->setEnabled(false);
            return;
        }
        Q_EMIT statusMessage(m_log->toPlainText().section('\n', -1)); m_log->append("SHA-512 verified OK!");
        m_extractBtn->setEnabled(true);
        if (m_autoChain) extractTarball();
    });
}

void Stage3Widget::extractTarball() {
    m_extractBtn->setEnabled(false);
    Q_EMIT statusMessage(m_log->toPlainText().section('\n', -1)); m_log->append("Extracting to " + m_targetDirEdit->text().trimmed() + "..."); QDir().mkpath(m_targetDirEdit->text().trimmed());
    auto *proc = new QProcess(this);
    connect(proc, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished), this, [this, proc](int c) {
        proc->deleteLater(); Q_EMIT statusMessage(m_log->toPlainText().section('\n', -1)); m_log->append(c == 0 ? "Extraction complete!" : QString("tar error %1").arg(c));
        m_chrootBtn->setEnabled(c == 0); m_extractBtn->setEnabled(true); m_continueBtn->setEnabled(true);
        bool goChroot = m_autoSequence && (c == 0); m_autoSequence = false;
        if (goChroot) Q_EMIT enterChrootRequested(m_targetDirEdit->text().trimmed());
    });
    proc->start("tar", {"xpf", m_downloadedTarball, "--xattrs-include=*.*", "--numeric-owner", "-C", m_targetDirEdit->text().trimmed()});
}

void Stage3Widget::runFullSequence() {
    m_autoSequence = true; m_continueBtn->setEnabled(false); startDownload();
}

void Stage3Widget::startAutomatedStage3(const QString &initVariant, const QString &targetDir) {
    m_autoChain = true;
    m_targetDirEdit->setText(targetDir);
    int idx = m_initCombo->findText(initVariant, Qt::MatchFixedString);
    if (idx >= 0) m_initCombo->setCurrentIndex(idx);
    fetchManifest();
}
