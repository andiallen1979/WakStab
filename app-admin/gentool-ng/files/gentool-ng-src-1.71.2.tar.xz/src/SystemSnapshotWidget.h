#pragma once
#include <QCheckBox>
#include <QLabel>
#include <QLineEdit>
#include <QPlainTextEdit>
#include <QPushButton>
#include <QString>
#include <QWidget>

class SystemSnapshotWidget : public QWidget {
    Q_OBJECT
public:
    explicit SystemSnapshotWidget(QWidget* parent = nullptr);
Q_SIGNALS:
    void runInTerminalRequested(const QString& command);
private Q_SLOTS:
    void createSnapshot();
    void loadSnapshotFile();
    void restoreSnapshot();
private:
    bool verifyAndDecodeSnapshot(const QString& snapPath, QByteArray& outTarZst, QString& outManifest, bool& outHashOk);
    void logLine(const QString& msg);

    QLineEdit *m_outDirIn = nullptr, *m_snapNameIn = nullptr, *m_loadPathIn = nullptr;
    QCheckBox *m_chkPortage = nullptr, *m_chkWorld = nullptr, *m_chkOverlay = nullptr, *m_chkKernel = nullptr, *m_chkServices = nullptr;
    QCheckBox *m_rstPortage = nullptr, *m_rstWorld = nullptr, *m_rstOverlay = nullptr, *m_rstKernel = nullptr, *m_rstServices = nullptr;
    QLabel *m_verifyLbl = nullptr;
    QPushButton *m_btnRestore = nullptr, *m_btnRebuild = nullptr;
    QPlainTextEdit *m_manifestView = nullptr, *m_logView = nullptr;
    QString m_loadedSnapPath;
    bool m_loadedHashValid = false;
};
