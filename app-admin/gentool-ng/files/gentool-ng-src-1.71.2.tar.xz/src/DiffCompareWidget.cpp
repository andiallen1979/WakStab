#include "DiffCompareWidget.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>
#include <QFileDialog>
#include <QProcess>
#include <QFile>
#include <QMessageBox>

DiffHighlighter::DiffHighlighter(QTextDocument *parent) : QSyntaxHighlighter(parent) {}

void DiffHighlighter::highlightBlock(const QString &text) {
    QTextCharFormat fmt;
    if (text.startsWith("+++") || text.startsWith("---")) {
        fmt.setForeground(QColor("#e5c07b")); fmt.setFontWeight(QFont::Bold);
    } else if (text.startsWith("@@")) {
        fmt.setForeground(QColor("#61afef"));
    } else if (text.startsWith('+')) {
        fmt.setForeground(QColor("#98c379"));
    } else if (text.startsWith('-')) {
        fmt.setForeground(QColor("#e06c75"));
    } else return;
    setFormat(0, text.length(), fmt);
}

static QPushButton *mkBtn(const QString &ic, const QString &tx, QWidget *p) {
    auto *b = new QPushButton(QIcon::fromTheme(ic), tx, p);
    b->setMaximumHeight(24);
    b->setSizePolicy(QSizePolicy::Maximum, QSizePolicy::Fixed);
    b->setStyleSheet("QPushButton { padding: 2px 8px;  }");
    return b;
}
DiffCompareWidget::DiffCompareWidget(QWidget *parent) : QWidget(parent) {
    auto *lay = new QVBoxLayout(this);
    lay->setContentsMargins(4, 4, 4, 4); lay->setSpacing(4);

    auto *top = new QHBoxLayout();
    m_presetCb = new QComboBox(); m_presetCb->setMaximumHeight(24);
    m_presetCb->addItems({
        "Custom File / Directory Comparison...",
        "Gentoo: /etc/portage/make.conf vs make.conf.example",
        "Kernel: /usr/src/linux/.config vs .config.old",
        "System: /etc/fstab vs /proc/mounts"
    });
    auto *bDiff = mkBtn("view-refresh", "Compare (diff -u)", this);
    auto *bSave = mkBtn("document-save-as", "Export .patch...", this);
    top->addWidget(m_presetCb, 1); top->addWidget(bDiff); top->addWidget(bSave);
    lay->addLayout(top);

    auto *form = new QFormLayout();
    auto mkPathRow = [&](QLineEdit *&ed, const QString &lbl) {
        auto *r = new QHBoxLayout(); r->setSpacing(4);
        ed = new QLineEdit(); ed->setMaximumHeight(24);
        auto *bf = mkBtn("document-open", "File...", this);
        auto *bd = mkBtn("folder-open", "Dir...", this);
        r->addWidget(ed, 1); r->addWidget(bf); r->addWidget(bd);
        connect(bf, &QPushButton::clicked, this, [this, ed]() {
            QString f = QFileDialog::getOpenFileName(this, "Select File", "/etc/portage");
            if (!f.isEmpty()) ed->setText(f);
        });
        connect(bd, &QPushButton::clicked, this, [this, ed]() {
            QString d = QFileDialog::getExistingDirectory(this, "Select Directory", "/etc/portage");
            if (!d.isEmpty()) ed->setText(d);
        });
        form->addRow(lbl, r);
    };
    mkPathRow(m_leftEdit, "Original (A):");
    mkPathRow(m_rightEdit, "Modified (B):");
    lay->addLayout(form);

    m_diffView = new QPlainTextEdit();
    m_diffView->setReadOnly(true);
    m_diffView->setFont(QFont("Monospace", 9));
    new DiffHighlighter(m_diffView->document());
    lay->addWidget(m_diffView, 1);

    connect(m_presetCb, QOverload<int>::of(&QComboBox::currentIndexChanged), this, &DiffCompareWidget::loadPreset);
    connect(bDiff, &QPushButton::clicked, this, &DiffCompareWidget::runDiff);
    connect(bSave, &QPushButton::clicked, this, &DiffCompareWidget::saveAsPatch);
}

void DiffCompareWidget::loadPreset(int idx) {
    if (idx == 1) { m_leftEdit->setText("/usr/share/portage/config/make.conf.example"); m_rightEdit->setText("/etc/portage/make.conf"); runDiff(); }
    else if (idx == 2) { m_leftEdit->setText("/usr/src/linux/.config.old"); m_rightEdit->setText("/usr/src/linux/.config"); runDiff(); }
    else if (idx == 3) { m_leftEdit->setText("/etc/fstab"); m_rightEdit->setText("/proc/mounts"); runDiff(); }
}

void DiffCompareWidget::runDiff() {
    const QString a = m_leftEdit->text().trimmed(), b = m_rightEdit->text().trimmed();
    if (a.isEmpty() || b.isEmpty()) return;
    QProcess p; p.start("diff", {"-ruN", a, b}); p.waitForFinished(10000);
    const QString out = QString::fromUtf8(p.readAllStandardOutput() + p.readAllStandardError());
    m_diffView->setPlainText(out.isEmpty() ? "Files/directories are identical (no differences)." : out);
}

void DiffCompareWidget::saveAsPatch() {
    const QString txt = m_diffView->toPlainText();
    if (txt.isEmpty() || txt.startsWith("Files/directories are identical")) return;
    const QString dst = QFileDialog::getSaveFileName(this, "Save Unified Patch", "/etc/portage/patches/custom.patch", "Patch Files (*.patch *.diff)");
    if (dst.isEmpty()) return;
    QFile f(dst);
    if (f.open(QIODevice::WriteOnly | QIODevice::Truncate)) { f.write(txt.toUtf8()); f.close(); }
}
