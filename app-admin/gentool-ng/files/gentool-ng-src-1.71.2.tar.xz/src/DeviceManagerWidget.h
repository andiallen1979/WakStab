#pragma once
#include <QWidget>
#include <QTreeWidget>
#include <QFormLayout>
#include <QLabel>
#include <QComboBox>
#include <QPushButton>

struct LinuxDeviceInfo {
    QString busType;
    QString sysfsPath;
    QString busId;
    QString name;
    QString modalias;
    QString activeDriver;
    QString driverSubsysPath;
    bool disabledByRule = false;
};

class DeviceManagerWidget : public QWidget {
    Q_OBJECT
public:
    explicit DeviceManagerWidget(QWidget *parent = nullptr);
private Q_SLOTS:
    void scanDevices();
    void onDeviceSelected(QTreeWidgetItem *item);
    void disableSelectedDevice();
    void enableSelectedDevice();
    void switchDriver();
private:
    QString resolveDeviceName(const QString &sysPath, const QString &bus, const QString &id);
    QStringList resolveCompatibleModules(const QString &modalias);
    QTreeWidget *m_tree;
    QLabel *m_statusLbl, *m_busLbl, *m_sysfsLbl, *m_modaliasLbl, *m_driverLbl;
    QComboBox *m_altDriverCombo;
    QPushButton *m_disableBtn, *m_enableBtn, *m_switchBtn, *m_refreshBtn;
    QMap<QString, LinuxDeviceInfo> m_devices;
    QString m_selectedKey;
};
