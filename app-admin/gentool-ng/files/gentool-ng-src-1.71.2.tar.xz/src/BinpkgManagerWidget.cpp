#include <QTimer>
#include "BinpkgManagerWidget.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QDirIterator>
#include <QFileInfo>
#include <QDateTime>
#include <QProcess>
#include <QInputDialog>
#include <QMessageBox>

static QPushButton *makeCompactBtn(const QString &icon, const QString &text, QWidget *parent) {
    auto *b = new QPushButton(QIcon::fromTheme(icon), text, parent);
    b->setMaximumHeight(24);
    b->setSizePolicy(QSizePolicy::Maximum, QSizePolicy::Fixed);
    b->setStyleSheet("QPushButton { padding: 2px 8px; font-size: 11px; }");
    return b;
}

BinpkgManagerWidget::BinpkgManagerWidget(QWidget *parent) : QWidget(parent) {
    auto *lay = new QVBoxLayout(this);
    lay->setContentsMargins(4, 4, 4, 4);
    lay->setSpacing(4);

    auto *bar = new QHBoxLayout();
    bar->setSpacing(4);
    m_searchEdit = new QLineEdit();
    m_searchEdit->setMaximumHeight(24);
    m_searchEdit->setPlaceholderText("Filter category/atom/version...");
    m_rescanBtn = makeCompactBtn("view-refresh", "Rescan", this);
    m_installBtn = makeCompactBtn("system-software-install", "Install (-K)", this);
    m_quickBtn = makeCompactBtn("package-x-generic", "Quickpkg...", this);
    m_indexBtn = makeCompactBtn("document-edit-sign", "Fix Index", this);
    m_delBtn = makeCompactBtn("edit-delete", "Delete", this);

    bar->addWidget(m_searchEdit, 1);
    bar->addWidget(m_rescanBtn);
    bar->addWidget(m_installBtn);
    bar->addWidget(m_quickBtn);
    bar->addWidget(m_indexBtn);
    bar->addWidget(m_delBtn);
    lay->addLayout(bar);
    m_tree = new QTreeWidget();
    m_tree->setHeaderLabels({"Category / Package", "Version & Build", "Format", "Size", "Modified"});
    m_tree->setAlternatingRowColors(true);
    m_tree->setRootIsDecorated(true);
    m_tree->header()->setSectionResizeMode(0, QHeaderView::Stretch);
    lay->addWidget(m_tree, 4);

    m_outLog = new QPlainTextEdit();
    m_outLog->setReadOnly(true);
    m_outLog->setMaximumHeight(85);
    m_outLog->setFont(QFont("Monospace", 8));
    lay->addWidget(m_outLog);

    m_summaryLbl = new QLabel();
    m_summaryLbl->setStyleSheet("font-size: 11px;");
    lay->addWidget(m_summaryLbl);

    connect(m_rescanBtn, &QPushButton::clicked, this, &BinpkgManagerWidget::scanBinpkgs);
    connect(m_searchEdit, &QLineEdit::textChanged, this, &BinpkgManagerWidget::filterTree);
    connect(m_installBtn, &QPushButton::clicked, this, &BinpkgManagerWidget::installSelected);
    connect(m_quickBtn, &QPushButton::clicked, this, &BinpkgManagerWidget::buildQuickpkg);
    connect(m_indexBtn, &QPushButton::clicked, this, &BinpkgManagerWidget::rebuildIndex);
    connect(m_delBtn, &QPushButton::clicked, this, &BinpkgManagerWidget::deleteSelected);

    QTimer::singleShot(120, this, [this]() { scanBinpkgs(); });
}

QString BinpkgManagerWidget::resolvePkgDir() const {
    QProcess p;
    p.start("portageq", {"envvar", "PKGDIR"});
    p.waitForFinished(2000);
    const QString d = QString::fromUtf8(p.readAllStandardOutput()).trimmed();
    return (!d.isEmpty() && QDir(d).exists()) ? d : QStringLiteral("/var/cache/binpkgs");
}
void BinpkgManagerWidget::scanBinpkgs() {
    m_tree->clear();
    m_pkgDir = resolvePkgDir();
    QMap<QString, QTreeWidgetItem*> catNodes;
    int count = 0; quint64 totalBytes = 0;

    QDirIterator it(m_pkgDir, {"*.gpkg.tar", "*.xpak", "*.tbz2"}, QDir::Files, QDirIterator::Subdirectories);
    while (it.hasNext()) {
        const QString full = it.next();
        QFileInfo fi(full);
        const QString rel = QDir(m_pkgDir).relativeFilePath(full);
        const QString cat = rel.section('/', 0, 0);
        const QString fn = fi.fileName();
        QString fmt = fn.endsWith(".gpkg.tar") ? "GPKG" : (fn.endsWith(".xpak") ? "XPAK" : "TBZ2");
        QString stem = fn;
        stem.remove(".gpkg.tar"); stem.remove(".xpak"); stem.remove(".tbz2");

        if (!catNodes.contains(cat)) {
            auto *cItem = new QTreeWidgetItem(m_tree, {cat, "", "", "", ""});
            cItem->setIcon(0, QIcon::fromTheme("folder"));
            catNodes[cat] = cItem;
        }
        const QString szStr = QString::number(fi.size() / 1024.0, 'f', 1) + " KiB";
        const QString dtStr = fi.lastModified().toString("yyyy-MM-dd HH:mm");
        auto *item = new QTreeWidgetItem(catNodes[cat], {cat + "/" + stem, stem, fmt, szStr, dtStr});
        item->setIcon(0, QIcon::fromTheme("package-x-generic"));
        item->setData(0, Qt::UserRole, full);
        item->setData(0, Qt::UserRole + 1, "=" + cat + "/" + stem);
        count++; totalBytes += fi.size();
    }
    m_tree->expandAll();
    m_summaryLbl->setText(QString("PKGDIR: %1  |  %2 binary packages  |  %3 MiB total")
        .arg(m_pkgDir).arg(count).arg(totalBytes / (1024.0 * 1024.0), 0, 'f', 1));
}

void BinpkgManagerWidget::filterTree(const QString &text) {
    for (int i = 0; i < m_tree->topLevelItemCount(); ++i) {
        auto *cat = m_tree->topLevelItem(i);
        bool anyVis = false;
        for (int j = 0; j < cat->childCount(); ++j) {
            auto *ch = cat->child(j);
            bool vis = text.isEmpty() || ch->text(0).contains(text, Qt::CaseInsensitive);
            ch->setHidden(!vis);
            if (vis) anyVis = true;
        }
        cat->setHidden(!anyVis);
    }
}

void BinpkgManagerWidget::installSelected() {
    auto *cur = m_tree->currentItem();
    if (!cur || cur->data(0, Qt::UserRole + 1).toString().isEmpty()) return;
    const QString atom = cur->data(0, Qt::UserRole + 1).toString();
    QProcess p; p.start("emerge", {"-K", "--oneshot", atom}); p.waitForFinished(-1);
    m_outLog->setPlainText(QString::fromUtf8(p.readAllStandardOutput() + p.readAllStandardError()));
}

void BinpkgManagerWidget::buildQuickpkg() {
    bool ok = false;
    const QString atom = QInputDialog::getText(this, "Build Binary Package (quickpkg)", "Installed atom (e.g. sys-apps/portage):", QLineEdit::Normal, "", &ok);
    if (!ok || atom.trimmed().isEmpty()) return;
    QProcess p; p.start("quickpkg", {"--include-config=y", atom.trimmed()}); p.waitForFinished(-1);
    m_outLog->setPlainText(QString::fromUtf8(p.readAllStandardOutput() + p.readAllStandardError()));
    scanBinpkgs();
}

void BinpkgManagerWidget::rebuildIndex() {
    QProcess p; p.start("emaint", {"binhost", "--fix"}); p.waitForFinished(15000);
    m_outLog->setPlainText(QString::fromUtf8(p.readAllStandardOutput() + p.readAllStandardError()));
}

void BinpkgManagerWidget::deleteSelected() {
    auto *cur = m_tree->currentItem();
    if (!cur) return;
    const QString path = cur->data(0, Qt::UserRole).toString();
    if (path.isEmpty()) return;
    if (QMessageBox::question(this, "Delete Binary Package", "Remove " + path + "?") != QMessageBox::Yes) return;
    QFile::remove(path);
    rebuildIndex();
    scanBinpkgs();
}
