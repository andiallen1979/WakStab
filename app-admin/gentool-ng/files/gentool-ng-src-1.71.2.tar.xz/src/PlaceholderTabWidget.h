#pragma once
#include <QString>
#include <QWidget>

class PlaceholderTabWidget : public QWidget {
    Q_OBJECT
public:
    explicit PlaceholderTabWidget(const QString& title, const QString& subtitle, QWidget* parent = nullptr);
};
