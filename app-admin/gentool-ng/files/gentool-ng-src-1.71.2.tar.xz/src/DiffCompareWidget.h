#pragma once
#include <QWidget>
#include <QLineEdit>
#include <QComboBox>
#include <QPlainTextEdit>
#include <QPushButton>
#include <QSyntaxHighlighter>

class DiffHighlighter : public QSyntaxHighlighter {
    Q_OBJECT
public:
    explicit DiffHighlighter(QTextDocument *parent);
protected:
    void highlightBlock(const QString &text) override;
};

class DiffCompareWidget : public QWidget {
    Q_OBJECT
public:
    explicit DiffCompareWidget(QWidget *parent = nullptr);
private Q_SLOTS:
    void runDiff();
    void saveAsPatch();
    void loadPreset(int idx);
private:
    QLineEdit *m_leftEdit, *m_rightEdit;
    QComboBox *m_presetCb;
    QPlainTextEdit *m_diffView;
};
