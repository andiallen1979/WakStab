#include "GtSnapManager.h"
#include <QGuiApplication>
#include <QScreen>
#include <QActionGroup>
#include "DiffCompareWidget.h"
#include "EselectWidget.h"
#include "BinpkgManagerWidget.h"
#include <QStackedWidget>
#include <QListWidget>
#include "Stage3Widget.h"
#include "LogManagerWidget.h"
#include "SystemInfoWidget.h"
#include "DeviceManagerWidget.h"
#include <QFileInfo>
#include "FsGuideOverlay.h"
#include "SystemSnapshotWidget.h"
#include "TerminalWidget.h"
#include "PlaceholderTabWidget.h"
#include "QemuVmWidget.h"
#include "DiskImageWidget.h"
#include "PortageConfigWidget.h"
#include <QTabWidget>
#include "RestoreDialog.h"
#include "VirtualDiskDialog.h"
#include <QApplication>
#include <QDialog>
#include <QDialogButtonBox>
#include <QFontComboBox>
#include <QFormLayout>
#include <QSettings>
#include <QSpinBox>
#include "ImageDialog.h"
#include "RescueDialog.h"
#include <QToolBar>
#include "ResizeMoveDialog.h"
#include <QMenuBar>
#include "MainWindow.h"
#include "ApplyDialog.h"
#include "FeaturesDialog.h"
#include "FlagsDialog.h"
#include "NewPartitionDialog.h"
#include "Utils.h"
#include <KActionCollection>
#include <KLocalizedString>
#include <KMessageBox>
#include <KStandardAction>
#include <KToolBar>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QIcon>
#include <QInputDialog>
#include <QLabel>
#include <QPainter>
#include <QPixmap>
#include <QSplitter>
#include <QStatusBar>
#include <QVBoxLayout>
#include <QWidget>
#include <glibmm/shell.h>
namespace {
QIcon makeSwatchIcon(const QColor& color, bool locked) {
QPixmap pm(16, 16);
pm.fill(Qt::transparent);
QPainter p(&pm);
p.setRenderHint(QPainter::Antialiasing, true);
p.setPen(QPen(Qt::darkGray, 1.0));
p.setBrush(color);
p.drawRoundedRect(1, 1, 14, 14, 3.0, 3.0);
if (locked)
QIcon::fromTheme(QStringLiteral("emblem-locked")).paint(&p, 4, 4, 11, 11);
return QIcon(pm);
}
} // namespace
MainWindow::MainWindow(QWidget* parent)
: QMainWindow(parent) {
setWindowTitle(QStringLiteral("Gentool-NG"));
setWindowIcon(QIcon::fromTheme(QStringLiteral("drive-harddisk")));
resize(1160, 740);
m_core.find_supported_filesystems();
m_core.set_user_devices({});
auto* central = new QWidget(this);
auto* rootLayout = new QVBoxLayout(central);
rootLayout->setContentsMargins(6, 6, 6, 6);
rootLayout->setSpacing(6);
m_diskBar = new DiskBarWidget(this);
rootLayout->addWidget(m_diskBar);
auto* hSplit = new QSplitter(Qt::Horizontal, this);
m_deviceInfoPane = new DeviceInfoPane(hSplit);
m_deviceInfoPane->setVisible(false);
auto* vSplit = new QSplitter(Qt::Vertical, hSplit);
m_partitionTree = new QTreeWidget(vSplit);
m_partitionTree->setRootIsDecorated(false);
m_partitionTree->setAlternatingRowColors(true);
m_partitionTree->setSelectionMode(QAbstractItemView::SingleSelection);
m_partitionTree->setContextMenuPolicy(Qt::CustomContextMenu);
m_partitionTree->setHeaderLabels({
i18n("Partition"), i18n("Name"), i18n("File System"), i18n("Mount Point"),
i18n("Label"), i18n("Size"), i18n("Used"), i18n("Unused"), i18n("Flags")
});
m_partitionTree->header()->setSectionResizeMode(QHeaderView::Interactive);
m_partitionTree->header()->setSectionsMovable(true);
m_partitionTree->header()->setStretchLastSection(true);
m_partitionTree->setUniformRowHeights(false);
m_opsList = new QListWidget(vSplit);
m_opsList->setMaximumHeight(std::max(130, fontMetrics().lineSpacing() * 6 + 24));
m_opsList->setVisible(false);
vSplit->setStretchFactor(0, 4);
vSplit->setStretchFactor(1, 1);
hSplit->setStretchFactor(1, 1);
rootLayout->addWidget(hSplit, 1);
auto* suiteMenu = menuBar()->addMenu(i18n("&Suite"));
auto* modeGroup = new QActionGroup(this);
modeGroup->setExclusive(true);
const bool hasExpertFlag = QCoreApplication::arguments().contains(QStringLiteral("--expert-override"));
auto* wizAct = suiteMenu->addAction(QIcon::fromTheme(QStringLiteral("tools-wizard")), i18n("&Wizard Mode (Guided Safe Defaults)"));
auto* novAct = suiteMenu->addAction(QIcon::fromTheme(QStringLiteral("user-info")), i18n("&Normal Mode (Handbook Guided)"));
QAction* expAct = nullptr;
wizAct->setObjectName(QStringLiteral("wizard_mode"));
novAct->setObjectName(QStringLiteral("normal_mode"));
wizAct->setCheckable(true); modeGroup->addAction(wizAct);
novAct->setCheckable(true); modeGroup->addAction(novAct);
if (hasExpertFlag) {
    expAct = suiteMenu->addAction(QIcon::fromTheme(QStringLiteral("preferences-system")), i18n("&Expert Mode (Full Unrestricted)"));
    expAct->setObjectName(QStringLiteral("expert_mode"));
    expAct->setCheckable(true); modeGroup->addAction(expAct);
}
int initMode = QSettings(QStringLiteral("WakStab"), QStringLiteral("gentool-ng")).value(QStringLiteral("roleMode"), 0).toInt();
if (initMode == 2 && !hasExpertFlag) initMode = 0;
if (initMode == 2 && expAct) expAct->setChecked(true);
else if (initMode == 1) novAct->setChecked(true);
else wizAct->setChecked(true);
suiteMenu->addSeparator();
suiteMenu->addAction(QIcon::fromTheme(QStringLiteral("application-exit")), i18n("&Quit"), this, &QWidget::close, QKeySequence::Quit);

auto* suiteTabs = new QTabWidget(this);
suiteTabs->setUsesScrollButtons(true);
auto* portagePage = new QWidget(this);
auto* portagePageLay = new QVBoxLayout(portagePage);
portagePageLay->setContentsMargins(0, 0, 0, 0); portagePageLay->setSpacing(0);
auto* viewMenu = menuBar()->addMenu(i18n("&View"));
auto* pSet = menuBar()->addMenu(i18n("&Settings"));
auto* pMenu = new QMenuBar(portagePage);
pMenu->hide();
auto* actDark = viewMenu->addAction(QIcon::fromTheme(QStringLiteral("preferences-desktop-theme")), i18n("Dark Theme"));
actDark->setCheckable(true); actDark->setChecked(true);
connect(actDark, &QAction::toggled, this, [this, actDark](bool dark) {
    actDark->setText(dark ? i18n("Switch to Light Theme") : i18n("Switch to Dark Theme"));
    QPalette pal = QApplication::style()->standardPalette();
    if (dark) {
        pal.setColor(QPalette::Window, QColor("#232629")); pal.setColor(QPalette::WindowText, QColor("#eff0f1"));
        pal.setColor(QPalette::Base, QColor("#181a1f")); pal.setColor(QPalette::Text, QColor("#eff0f1"));
        pal.setColor(QPalette::Button, QColor("#31363b")); pal.setColor(QPalette::ButtonText, QColor("#eff0f1"));
        pal.setColor(QPalette::Highlight, QColor("#3daee9")); pal.setColor(QPalette::HighlightedText, QColor("#ffffff"));
    }
    QApplication::setPalette(pal);
});
auto* fontAct = pSet->addAction(QIcon::fromTheme(QStringLiteral("preferences-desktop-font")), i18n("Application Font..."), this, [this]() {
    QDialog dlg(this); dlg.setWindowTitle(QStringLiteral("Gentool-NG"));
    auto* form = new QFormLayout(&dlg); auto* familyBox = new QFontComboBox(&dlg); auto* sizeSpin = new QSpinBox(&dlg);
    sizeSpin->setRange(6, 36); sizeSpin->setSuffix(QStringLiteral(" pt"));
    QFont cur = QApplication::font(); familyBox->setCurrentFont(cur); sizeSpin->setValue(cur.pointSize() > 0 ? cur.pointSize() : 11);
    form->addRow(i18n("Font family:"), familyBox); form->addRow(i18n("Font size:"), sizeSpin);
    auto* btns = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, &dlg);
    connect(btns, &QDialogButtonBox::accepted, &dlg, &QDialog::accept); connect(btns, &QDialogButtonBox::rejected, &dlg, &QDialog::reject);
    form->addRow(btns);
    if (dlg.exec() != QDialog::Accepted) return;
    QFont next = familyBox->currentFont(); next.setPointSize(sizeSpin->value());
    QApplication::setFont(next); setFont(next); rebuildCurrentView();
});

portagePageLay->addWidget(pMenu);
portagePageLay->addWidget(new PortageConfigWidget(portagePage), 1);

auto* qpPage = new QWidget(this);
auto* qpPageLay = new QVBoxLayout(qpPage);
qpPageLay->setContentsMargins(0, 0, 0, 0); qpPageLay->setSpacing(0);
setupActions();
auto* ac = findChild<KActionCollection*>();
statusBar();
QMenu* diskMgrM = menuBar()->addMenu(i18n("&Disk Manager"));
diskMgrM->addAction(ac->action(QStringLiteral("refresh_devices")));
diskMgrM->addMenu(m_devicesMenu)->setText(i18n("Devices"));
diskMgrM->addSeparator();
QMenu* devM = diskMgrM->addMenu(i18n("&Device"));
devM->addAction(m_disklabelAct);
devM->addAction(ac->action(QStringLiteral("attempt_rescue")));
QMenu* partM = diskMgrM->addMenu(i18n("&Partition"));
partM->addAction(m_newAct); partM->addAction(m_delAct); partM->addSeparator();
partM->addAction(m_resizeAct); partM->addAction(m_flagsAct); partM->addAction(m_checkAct);
partM->addAction(m_labelAct); partM->addAction(m_nameAct); partM->addAction(m_uuidAct);
partM->addSeparator(); partM->addAction(m_unmountAct);
diskMgrM->addSeparator();
diskMgrM->addAction(ac->action(QStringLiteral("view_fs_support")));

QMenu* helpTopM = menuBar()->addMenu(i18n("&Help"));
helpTopM->addAction(QIcon::fromTheme(QStringLiteral("help-about")), i18n("&About gentool-ng"), this, [this]() {
    KMessageBox::information(this,
        i18n("gentool-ng 1.71.2\n\nUnified Gentoo System Suite: Portage Configurator, Disk & Partition Manager, Virtual Disks, Stage3 Retriever, Log Manager, System Telemetry, and Hardware Device Manager.\n\nWakStab System Suite"),
        i18n("About gentool-ng"));
});
if (auto* tb = findChild<QToolBar*>()) { removeToolBar(tb); tb->setParent(qpPage); tb->show(); qpPageLay->addWidget(tb); }
auto* qpMainSplit = new QSplitter(Qt::Horizontal, qpPage);
qpMainSplit->addWidget(central);
auto* qpRightSplit = new QSplitter(Qt::Vertical, qpMainSplit);
qpRightSplit->setObjectName(QStringLiteral("qpRightSplit"));
auto* fsGuide = new FsGuideOverlay(qpRightSplit);
auto* inlineApplyHost = new QWidget(qpRightSplit);
inlineApplyHost->setObjectName(QStringLiteral("inlineApplyHost"));
auto* inlineApplyLay = new QVBoxLayout(inlineApplyHost);
inlineApplyLay->setContentsMargins(0, 0, 0, 0);
inlineApplyHost->hide();
qpRightSplit->addWidget(fsGuide);
qpRightSplit->addWidget(inlineApplyHost);
qpMainSplit->addWidget(qpRightSplit);
qpMainSplit->setStretchFactor(0, 3);
qpMainSplit->setStretchFactor(1, 1);
qpPageLay->addWidget(qpMainSplit, 1);
fsGuide->hide();
if (auto* qpTb = qpPage->findChild<QToolBar*>()) {
    qpTb->addSeparator();
    auto* virtOnlyAct = qpTb->addAction(QIcon::fromTheme(QStringLiteral("security-high")), i18n("Virtual Disks Only"));
    virtOnlyAct->setObjectName(QStringLiteral("virtual_disks_only"));
    virtOnlyAct->setCheckable(true);
    virtOnlyAct->setChecked(true);
    virtOnlyAct->setToolTip(i18n("Safety Lock: Hide physical NVMe/SATA/eMMC drives and allow only /dev/nbd* and /dev/loop*"));
    connect(virtOnlyAct, &QAction::toggled, this, [this]() { refreshDevices(); });
    auto* guideAct = qpTb->addAction(QIcon::fromTheme(QStringLiteral("help-contents")), i18n("Filesystem Guide"));
    connect(guideAct, &QAction::triggered, this, [fsGuide]() {
        if (fsGuide->isVisible()) fsGuide->hide();
        else fsGuide->showForDisk(QString());
    });
    connect(fsGuide, &FsGuideOverlay::applyLayoutRequested, this, [this, fsGuide, wizAct](int idx) {
        int devIdx = m_deviceCombo->currentIndex();
        if (devIdx < 0 || devIdx >= static_cast<int>(m_devices.size())) return;
        GParted::Device& dev = *m_devices[static_cast<size_t>(devIdx)];
        QString dPath = QString::fromStdString(dev.get_path().raw());
        if (!dPath.startsWith(QStringLiteral("/dev/nbd")) && !dPath.startsWith(QStringLiteral("/dev/loop"))) {
            KMessageBox::error(this, i18n("Safety Lockout: Automated wizard partitioning is restricted to /dev/nbd* and /dev/loop* devices. Refusing %1.", dPath));
            return;
        }
        // Automated virtual-disk GPT initialization (no redundant modal warning)
        if (!m_core.set_disklabel(dev, "gpt")) {
            KMessageBox::error(this, i18n("Failed to write GPT label. Ensure all partitions on %1 are unmounted.", QString::fromStdString(dev.get_path().raw())));
            return;
        }
        refreshDevices();
        if (devIdx < m_deviceCombo->count()) m_deviceCombo->setCurrentIndex(devIdx);
        GParted::Device& freshDev = *m_devices[static_cast<size_t>(m_deviceCombo->currentIndex())];
        struct Spec { qint64 mib; GParted::FSType fs; const char* lbl; };
        std::vector<Spec> plan;
        switch (idx) {
            case 0: plan = {{1024, GParted::FS_FAT32, "EFI"}, {16384, GParted::FS_LINUX_SWAP, "SWAP"}, {-1, GParted::FS_BTRFS, "GENTOO"}}; break;
            case 1: plan = {{1024, GParted::FS_FAT32, "EFI"}, {16384, GParted::FS_LINUX_SWAP, "SWAP"}, {49152, GParted::FS_BTRFS, "GENTOO"}, {-1, GParted::FS_XFS, "GAMES"}}; break;
            case 2: plan = {{512, GParted::FS_FAT32, "EFI"}, {8192, GParted::FS_LINUX_SWAP, "SWAP"}, {-1, GParted::FS_BTRFS, "HANDHELD"}}; break;
            case 3: plan = {{512, GParted::FS_FAT32, "EFI"}, {4096, GParted::FS_LINUX_SWAP, "SWAP"}, {20480, GParted::FS_EXT4, "ROOT"}, {-1, GParted::FS_XFS, "VAR"}}; break;
            case 4: plan = {{512, GParted::FS_FAT32, "EFI"}, {4096, GParted::FS_LINUX_SWAP, "SWAP"}, {24576, GParted::FS_EXT4, "OS"}, {-1, GParted::FS_BTRFS, "DATA"}}; break;
            case 5: plan = {{512, GParted::FS_FAT32, "EFI"}, {32768, GParted::FS_LINUX_SWAP, "SWAP"}, {32768, GParted::FS_BTRFS, "BUILDHOST"}, {-1, GParted::FS_XFS, "BINPKGS"}}; break;
            default: plan = {{512, GParted::FS_FAT32, "EFI"}, {-1, GParted::FS_EXT4, "RESCUE"}}; break;
        }
        GParted::Sector alignSec = std::max<GParted::Sector>(1, GParted::MEBIBYTE / freshDev.sector_size);
        GParted::Sector cur = alignSec;
        GParted::Sector maxEnd = ((freshDev.length) / alignSec) * alignSec - 1;
        int num = 1;
        for (const auto& s : plan) {
            if (cur >= maxEnd) break;
            GParted::Sector end = (s.mib < 0) ? maxEnd : std::min(maxEnd, cur + ((s.mib * GParted::MEBIBYTE) / freshDev.sector_size) - 1);
            GParted::Partition unalloc, p;
            unalloc.Set_Unallocated(freshDev.get_path(), cur, end, freshDev.sector_size, false);
            p.Set(freshDev.get_path(), QStringLiteral("New Partition #%1").arg(num++).toUtf8().constData(),
                  num - 1, GParted::TYPE_PRIMARY, s.fs, cur, end, freshDev.sector_size, false, false);
            p.alignment = GParted::ALIGN_CYLINDER;
            p.set_filesystem_label(s.lbl);
            m_queue.addCreate(freshDev, unalloc, p);
            cur = end + 1;
        }
        updateQueueUI(); rebuildCurrentView();
        if (wizAct->isChecked()) fsGuide->showConfirmApply(m_queue.count(), idx);
        else fsGuide->hide();
    });
}

auto* diskPage = new DiskImageWidget(this);
auto* vmPage = new QemuVmWidget(this);
auto* termPage = new TerminalWidget(this);
auto* snapPage = new SystemSnapshotWidget(this);
auto* stage3Page = new Stage3Widget(this);
auto* logPage = new LogManagerWidget(this);
auto* sysInfoPage = new SystemInfoWidget(this);
auto* devMgrPage = new DeviceManagerWidget(this);

suiteTabs->addTab(portagePage, QIcon::fromTheme(QStringLiteral("preferences-system")), i18n("Portage Config"));
suiteTabs->addTab(qpPage, QIcon::fromTheme(QStringLiteral("drive-harddisk")), i18n("Partition Manager"));
suiteTabs->addTab(diskPage, QIcon::fromTheme(QStringLiteral("media-optical")), i18n("Virtual Disks"));
auto* mountGuide = new FsGuideOverlay(diskPage);
mountGuide->hide();
connect(fsGuide, &FsGuideOverlay::confirmApplyRequested, this, [this, suiteTabs, diskPage, fsGuide, mountGuide, wizAct](int profIdx) {
    fsGuide->hide();
    if (m_applyAct) m_applyAct->trigger();
    if (wizAct->isChecked()) {
        suiteTabs->setCurrentWidget(diskPage);
        mountGuide->showMountStage(QStringLiteral("virtual-disk"), profIdx);
    }
});
connect(mountGuide, &FsGuideOverlay::mountAndEnterChrootRequested, this, [suiteTabs, diskPage, termPage](const QString& part, const QString&, bool bind) {
    diskPage->prepareAndMountChroot(part, bind);
    suiteTabs->setCurrentWidget(termPage);
    termPage->addTerminalTab(QStringLiteral("/mnt/wakstab-chroot"), QStringLiteral("Chroot"));
    termPage->sendCommand(QStringLiteral("chroot /mnt/wakstab-chroot /bin/bash -c 'env-update; source /etc/profile; export PS1=\"\\[\\e[1;31m\\](gentool-chroot)\\[\\e[0m\\] \\w # \"; exec /bin/bash --norc -i'\n"));
});
connect(diskPage, &DiskImageWidget::openInPartitionManagerRequested, this, [this, suiteTabs, qpPage, fsGuide, wizAct](const QString& devPath, const QString& imgPath) {
    if (auto* vAct = findChild<QAction*>(QStringLiteral("virtual_disks_only")); vAct && !vAct->isChecked()) vAct->setChecked(true);
    suiteTabs->setCurrentWidget(qpPage);
    refreshDevices();
    if (!devPath.isEmpty()) {
        for (int i = 0; i < m_deviceCombo->count(); ++i) {
            if (m_deviceCombo->itemText(i).contains(devPath)) { m_deviceCombo->setCurrentIndex(i); break; }
        }
    }
    if (wizAct->isChecked()) fsGuide->showForDisk(devPath.isEmpty() ? imgPath : QStringLiteral("%1 (%2)").arg(devPath, QFileInfo(imgPath).fileName()));
});
suiteTabs->addTab(vmPage, QIcon::fromTheme(QStringLiteral("computer")), i18n("QEMU VMs"));
suiteTabs->addTab(termPage, QIcon::fromTheme(QStringLiteral("utilities-terminal")), i18n("Terminal"));
suiteTabs->addTab(snapPage, QIcon::fromTheme(QStringLiteral("document-save-as")), i18n("System Snapshot"));
connect(snapPage, &SystemSnapshotWidget::runInTerminalRequested, this, [suiteTabs, termPage](const QString& cmd) {
    suiteTabs->setCurrentWidget(termPage);
    termPage->sendCommand(cmd);
});
    auto* eselectPage = new EselectWidget(this);
    auto* binpkgPage = new BinpkgManagerWidget(this);
    auto* diffPage = new DiffCompareWidget(this);
    suiteTabs->addTab(stage3Page, QIcon::fromTheme(QStringLiteral("archive-extract")), i18n("Stage3 & Chroot"));
    suiteTabs->addTab(eselectPage, QIcon::fromTheme(QStringLiteral("preferences-other")), i18n("eselect Profiles"));
    suiteTabs->addTab(binpkgPage, QIcon::fromTheme(QStringLiteral("package-x-generic")), i18n("Binary Packages"));
    suiteTabs->addTab(diffPage, QIcon::fromTheme(QStringLiteral("vcs-diff")), i18n("Diff & Compare"));
    suiteTabs->addTab(logPage, QIcon::fromTheme(QStringLiteral("utilities-log-viewer")), i18n("Log Manager"));
    suiteTabs->addTab(sysInfoPage, QIcon::fromTheme(QStringLiteral("hwinfo")), i18n("System & Hardware"));
    suiteTabs->addTab(devMgrPage, QIcon::fromTheme(QStringLiteral("preferences-desktop-peripherals")), i18n("Device Manager"));
    auto* logCfgAct = pSet->addAction(QIcon::fromTheme(QStringLiteral("configure")), i18n("Configure &Custom Logs..."));
    connect(logCfgAct, &QAction::triggered, logPage, &LogManagerWidget::configureCustomLogs);
    connect(stage3Page, &Stage3Widget::enterChrootRequested, this, [suiteTabs, termPage](const QString& dir) {
        suiteTabs->setCurrentWidget(termPage);
        termPage->addTerminalTab(dir, QStringLiteral("Chroot"));
        termPage->sendCommand(QStringLiteral("chroot ") + dir + QStringLiteral(" /bin/bash -c 'env-update; source /etc/profile; export PS1=\"\\[\\e[1;31m\\](gentool-chroot)\\[\\e[0m\\] \\w # \"; exec /bin/bash --norc -i'\n"));
    });

    suiteTabs->tabBar()->hide();
    auto* shell = new QWidget(this);
    auto* shellLay = new QHBoxLayout(shell);
    shellLay->setContentsMargins(2, 2, 2, 2); shellLay->setSpacing(4);

    auto* navCol = new QWidget(shell);
    navCol->setMaximumWidth(215);
    auto* navLay = new QVBoxLayout(navCol);
    navLay->setContentsMargins(0, 0, 0, 0); navLay->setSpacing(4);



    auto* stepList = new QListWidget(navCol);
    stepList->setIconSize(QSize(16, 16));
    struct StepDef { QString title; QWidget* page; QString hint; bool expertOnly; };
    const QList<StepDef> steps = {
        {i18n("0. System Overview"), sysInfoPage, i18n("Verify CPU topology, RAM, tmpfs, and swap before building."), false},
        {i18n("1. NBD Disks & Sysext"), diskPage, i18n("Create/mount NBD virtual disks (qcow2/raw/vmdk/vhdx/vdi) or build systemd-sysext images."), false},
        {i18n("2. Partition Manager"), qpPage, i18n("Inspect or modify GPT/MBR partitions and filesystems on virtual devices."), true},
        {i18n("3. Stage3 & Chroot"), stage3Page, i18n("Select Gentoo mirror/init, verify SHA-512, extract Stage3, and enter chroot."), false},
        {i18n("4. Portage & make.conf"), portagePage, i18n("Configure CFLAGS, USE flags, ACCEPT_KEYWORDS, and package overrides."), false},
        {i18n("5. eselect Profiles"), eselectPage, i18n("Select active Gentoo system profile, kernel, python, and compiler targets."), false},
        {i18n("6. Binary Packages"), binpkgPage, i18n("Browse deep PKGDIR binpkgs, pack quickpkgs, or install prebuilt binaries."), false},
        {i18n("7. Hardware & Buses"), devMgrPage, i18n("Inspect PCIe/USB/I2C/SPI devices, switch drivers, or disable via udev rules."), true},
        {i18n("8. System & Build Logs"), logPage, i18n("Inspect /var/log, Portage build logs, and systemd journal."), true},
        {i18n("9. Diff & File Compare"), diffPage, i18n("Compare configuration files, kernel configs, or directories and export unified patches."), true},
        {i18n("9. QEMU & Terminal"), termPage, i18n("Run chroot commands, test-boot virtual disks in QEMU, or manage snapshots."), false},
    };
    for (const auto& st : steps) {
        auto* it = new QListWidgetItem(st.title, stepList);
        it->setData(Qt::UserRole, QVariant::fromValue<QWidget*>(st.page));
    }
    navLay->addWidget(stepList, 1);
    shellLay->addWidget(navCol);

    auto* rightCol = new QWidget(shell);
    auto* rightLay = new QVBoxLayout(rightCol);
    rightLay->setContentsMargins(0, 0, 0, 0); rightLay->setSpacing(4);

    auto* guideBar = new QFrame(rightCol);
    guideBar->setFrameShape(QFrame::StyledPanel);
    auto* gLay = new QHBoxLayout(guideBar);
    gLay->setContentsMargins(6, 3, 6, 3); gLay->setSpacing(6);
    auto* hintLbl = new QLabel(steps.first().hint, guideBar);
    hintLbl->setStyleSheet(QStringLiteral("font-size: 11px;"));
    auto* autoNbdBtn = new QPushButton(QIcon::fromTheme(QStringLiteral("tools-wizard")), i18n("Hands-Off NBD Disk..."), guideBar);
    auto* nextStepBtn = new QPushButton(QIcon::fromTheme(QStringLiteral("go-next")), i18n("Next Step"), guideBar);
    for (QPushButton* b : {autoNbdBtn, nextStepBtn}) {
        b->setMaximumHeight(24);
        b->setSizePolicy(QSizePolicy::Maximum, QSizePolicy::Fixed);
        b->setStyleSheet(QStringLiteral("QPushButton { padding: 2px 8px; font-size: 11px; }"));
    }
    autoNbdBtn->setVisible(false);
    gLay->addWidget(hintLbl, 1);
    gLay->addWidget(autoNbdBtn);
    gLay->addWidget(nextStepBtn);
    rightLay->addWidget(guideBar);
    auto* modeStack = new QStackedWidget(rightCol);
    auto* wizardCard = new QWidget(modeStack);
    auto* wLay = new QVBoxLayout(wizardCard);
    wLay->setContentsMargins(16, 12, 16, 12); wLay->setSpacing(8);
    auto* wTitle = new QLabel(i18n("<h3>Gentool-NG — Complete Guided Gentoo Base System Wizard</h3>"), wizardCard);
    auto* wStepStatus = new QLabel(i18n("<b>Current Stage:</b> Step 1 — Fetch & Extract Stage3 (or Launch Staging Raw Image)"), wizardCard);

    auto* wForm = new QFormLayout();
    auto* wSnapNameIn = new QLineEdit(QStringLiteral("wakstab-gentoo"), wizardCard);
    auto* wTargetIn = new QLineEdit(wizardCard); wTargetIn->hide();
    auto* wHostIn = new QLineEdit(QStringLiteral("gentoo-wakstab"), wizardCard);
    auto* wTzIn = new QLineEdit(QStringLiteral("America/New_York"), wizardCard);
    auto* wPassIn = new QLineEdit(wizardCard); wPassIn->setEchoMode(QLineEdit::Password); wPassIn->setPlaceholderText(i18n("Root password for new system"));
    auto* wInitCb = new QComboBox(wizardCard); wInitCb->addItems({QStringLiteral("OpenRC"), QStringLiteral("systemd")});
    auto* wProfCb = new QComboBox(wizardCard); wProfCb->addItems({QStringLiteral("Minimal / Server"), QStringLiteral("Desktop Profile")});
    auto* wBootCb = new QComboBox(wizardCard); wBootCb->addItems({QStringLiteral("GRUB2 (UEFI)"), QStringLiteral("systemd-boot")});
    auto* progBox = new QWidget(wizardCard);
    auto* progStack = new QVBoxLayout(progBox);
    progStack->setContentsMargins(0, 0, 0, 0); progStack->setSpacing(2);
    auto* wTotalProg = new QProgressBar(progBox); wTotalProg->setFixedHeight(14); wTotalProg->setValue(0); wTotalProg->setFormat(i18n("Total Wizard: %p%"));
    auto* wStepProg = new QProgressBar(progBox); wStepProg->setFixedHeight(14); wStepProg->setValue(0); wStepProg->setFormat(i18n("Current Step: %p%"));
    progStack->addWidget(wTotalProg);
    progStack->addWidget(wStepProg);

    auto* drawerBox = new QWidget(wizardCard);
    auto* drawerLay = new QVBoxLayout(drawerBox);
    drawerLay->setContentsMargins(0, 0, 0, 0); drawerLay->setSpacing(0);
    auto* tabRow = new QHBoxLayout(); tabRow->setContentsMargins(0, 0, 0, 0);
    auto* wLogToggle = new QPushButton(i18n("▴  Step Feedback  ▴"), drawerBox);
    wLogToggle->setCheckable(true); wLogToggle->setFixedHeight(16);
    wLogToggle->setSizePolicy(QSizePolicy::Maximum, QSizePolicy::Fixed);
    wLogToggle->setStyleSheet(QStringLiteral("QPushButton { padding: 0px 16px; margin-bottom: -3px; font-size: 10px; border: 1px solid #2c313a; border-bottom: none; border-top-left-radius: 6px; border-top-right-radius: 6px; background-color: #0b0d10; color: #abb2bf; } QPushButton:checked { background-color: #0b0d10; }"));
    tabRow->addStretch(1); tabRow->addWidget(wLogToggle); tabRow->addStretch(1);
    auto* wLiveLog = new QPlainTextEdit(drawerBox);
    wLiveLog->setReadOnly(true); wLiveLog->setFont(QFont(QStringLiteral("Monospace"), 8));
    wLiveLog->setStyleSheet(QStringLiteral("QPlainTextEdit { background-color: #0b0d10; color: #abb2bf; border: 1px solid #2c313a; }"));
    drawerLay->addLayout(tabRow); drawerLay->addWidget(wLiveLog, 1); wLogToggle->raise();

    const QScreen* scr = QGuiApplication::primaryScreen();
    const QSize res = scr ? scr->size() : QSize(1920, 1080);
    const int longSide = qMax(res.width(), res.height());
    const int shortSide = qMin(res.width(), res.height());
    const double aspect = shortSide > 0 ? double(longSide) / double(shortSide) : 1.77;
    const bool hasRoom = (shortSide > ((aspect <= 1.65) ? 800 : 720));
    drawerBox->setVisible(hasRoom);
    wLogToggle->setChecked(false);
    wLiveLog->setFixedHeight(22);
    wLiveLog->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    for (QWidget* w : std::initializer_list<QWidget*>{wSnapNameIn, wHostIn, wTzIn, wPassIn, wInitCb, wProfCb, wBootCb}) w->setMaximumHeight(24);
    wForm->addRow(i18n("GTSnap Package Name:"), wSnapNameIn);
    wForm->addRow(i18n("System Hostname:"), wHostIn);
    wForm->addRow(i18n("Timezone:"), wTzIn);
    wForm->addRow(i18n("Root Password:"), wPassIn);
    wForm->addRow(i18n("Init System:"), wInitCb);
    wForm->addRow(i18n("Stage3 Variant:"), wProfCb);
    wForm->addRow(i18n("UEFI Bootloader:"), wBootCb);
    wForm->addRow(i18n("Progress:"), progBox);

    auto* wBtnRow = new QHBoxLayout(); wBtnRow->setSpacing(6);
    auto* wPrepDiskBtn = new QPushButton(QIcon::fromTheme(QStringLiteral("drive-harddisk")), i18n("1. Prepare & Mount Storage"), wizardCard);
    auto* wStage3Btn = new QPushButton(QIcon::fromTheme(QStringLiteral("archive-extract")), i18n("2. Fetch, Verify & Extract Stage3"), wizardCard);
    auto* wBuildBaseBtn = new QPushButton(QIcon::fromTheme(QStringLiteral("system-run")), i18n("3. Build Kernel & Base System"), wizardCard);
    auto* wFinalDdBtn = new QPushButton(QIcon::fromTheme(QStringLiteral("media-flash")), i18n("4. Confirm & Write to Target (dd)"), wizardCard);
    auto* wChrootTermBtn = new QPushButton(QIcon::fromTheme(QStringLiteral("utilities-terminal")), i18n("Chroot Shell"), wizardCard);
    wBtnRow->setSpacing(8);
    for (QPushButton* b : {wPrepDiskBtn, wStage3Btn, wBuildBaseBtn, wFinalDdBtn, wChrootTermBtn}) {
        b->setMinimumHeight(31);
        b->setMaximumHeight(31);
        b->setStyleSheet(QStringLiteral("QPushButton { padding: 5px 15px; font-size: 11px; }"));
        b->setSizePolicy(QSizePolicy::Maximum, QSizePolicy::Fixed);
        wBtnRow->addWidget(b);
    }
    wBtnRow->addStretch(1);
    wLay->addWidget(wTitle);
    wLay->addWidget(wStepStatus);
    wLay->addLayout(wForm);
    wLay->setContentsMargins(16, 12, 16, 4);
    wLay->addLayout(wBtnRow);
    wLay->addStretch(1);
    wLay->addWidget(drawerBox, 0);
    drawerBox->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
    connect(wLogToggle, &QPushButton::toggled, this, [wLay, drawerBox, wLogToggle, wLiveLog](bool on) {
        wLogToggle->setText(on ? i18n("▾  Step Feedback  ▾") : i18n("▴  Step Feedback  ▴"));
        if (on) {
            wLiveLog->appendPlainText(QStringLiteral("[Feedback Active] Streaming step output..."));
            drawerBox->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
            wLiveLog->setMinimumHeight(120); wLiveLog->setMaximumHeight(16777215);
            wLiveLog->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
            wLay->setStretch(4, 0);
            wLay->setStretch(5, 1);
        } else {
            wLiveLog->clear();
            wLiveLog->setFixedHeight(22);
            wLiveLog->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
            drawerBox->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
            wLay->setStretch(5, 0);
            wLay->setStretch(4, 1);
        }
    });
    modeStack->addWidget(wizardCard);
    modeStack->addWidget(suiteTabs);
    rightLay->addWidget(modeStack, 1);
    shellLay->addWidget(rightCol, 1);

    connect(autoNbdBtn, &QPushButton::clicked, diskPage, &DiskImageWidget::runStreamlinedNoviceInstall);
    connect(stepList, &QListWidget::currentRowChanged, this, [suiteTabs, steps, hintLbl, autoNbdBtn, diskPage](int r) {
        if (r < 0 || r >= steps.size()) return;
        suiteTabs->setCurrentWidget(steps.at(r).page);
        hintLbl->setText(steps.at(r).hint);
        autoNbdBtn->setVisible(steps.at(r).page == diskPage);
    });
    connect(nextStepBtn, &QPushButton::clicked, this, [stepList]() {
        for (int r = stepList->currentRow() + 1; r < stepList->count(); ++r) {
            if (!stepList->item(r)->isHidden()) { stepList->setCurrentRow(r); break; }
        }
    });
    auto applyRole = [this, navCol, stepList, steps, guideBar, modeStack, wizardCard, suiteTabs, wizAct, novAct, expAct](int idx) {
        bool wizard = (idx == 0);
        bool expert = (idx == 2);
        QSettings st(QStringLiteral("WakStab"), QStringLiteral("gentool-ng"));
        st.setValue(QStringLiteral("roleMode"), idx);
        st.setValue(QStringLiteral("expertRole"), expert);
        st.setValue(QStringLiteral("wizardMode"), wizard);
        if (idx == 2 && !expAct) idx = 0;
        if (idx == 0) wizAct->setChecked(true);
        else if (idx == 1) novAct->setChecked(true);
        else if (expAct) expAct->setChecked(true);
        navCol->setVisible(!wizard);
        guideBar->setVisible(idx == 1);
        modeStack->setCurrentWidget(wizard ? wizardCard : static_cast<QWidget*>(suiteTabs));
        if (auto* vAct = findChild<QAction*>(QStringLiteral("virtual_disks_only"))) vAct->setChecked(!expert);
        for (int i = 0; i < steps.size(); ++i) stepList->item(i)->setHidden(!expert && steps.at(i).expertOnly);
        QTimer::singleShot(10, this, &MainWindow::refreshDevices);
    };
    auto appendWizLog = [drawerBox, wLogToggle, wLiveLog](const QString& line) {
        if (!drawerBox->isVisible() || !wLogToggle->isChecked()) return;
        if (!line.trimmed().isEmpty()) wLiveLog->appendPlainText(line.trimmed());
    };
    connect(diskPage, &DiskImageWidget::commandOutput, this, appendWizLog);
    connect(stage3Page, &Stage3Widget::statusMessage, this, [wStepStatus, appendWizLog](const QString& msg) {
        if (!msg.trimmed().isEmpty()) { wStepStatus->setText(msg); appendWizLog(QStringLiteral("[Stage3] ") + msg); }
    });
    connect(stage3Page, &Stage3Widget::progressUpdated, this, [wStepProg, wTotalProg](int pct) {
        wStepProg->setValue(pct);
        wTotalProg->setValue(25 + (pct / 4));
    });
    connect(wPrepDiskBtn, &QPushButton::clicked, this, [diskPage, wSnapNameIn, wTargetIn, wHostIn, wTzIn, wInitCb, wProfCb, wBootCb, wStepStatus, wStepProg, wTotalProg, appendWizLog]() {
        bool ok = false;
        int gb = QInputDialog::getInt(nullptr, i18n("Step 1: GTSnap Staging Disk Size"), i18n("Virtual staging size (GiB) before dd to target:"), 24, 8, 512, 1, &ok);
        if (!ok) return;
        const GtSnapPackage snap = GtSnapManager::initWizardWorkspace(
            wSnapNameIn->text(), wInitCb->currentText(), wProfCb->currentText(),
            wBootCb->currentText(), wHostIn->text(), wTzIn->text());
        wTargetIn->setText(snap.mountDir);
        wStepProg->setValue(15);
        appendWizLog(QStringLiteral("=== [Step 1/4] GTSnap Package %1 (UUID: %2) -> %3 GiB staging image ===").arg(snap.name, snap.uuid).arg(gb));
        wStepStatus->setText(i18n("<b>Step 1:</b> Creating GTSnap <b>%1</b> (%2)...").arg(snap.name, snap.uuid.left(8)));
        if (diskPage->prepareStagingRawMount(snap.mountDir, QStringLiteral("ext4"), gb)) {
            wStepProg->setValue(100); wTotalProg->setValue(25);
            appendWizLog(QStringLiteral("[Step 1/4] Complete: Mounted at %1").arg(snap.mountDir));
            wStepStatus->setText(i18n("<b>Step 1 Complete:</b> GTSnap <b>%1</b> ready. Proceed to <b>2. Fetch, Verify & Extract Stage3</b>.").arg(snap.name));
        }
    });
    connect(wStage3Btn, &QPushButton::clicked, this, [stage3Page, wInitCb, wProfCb, wTargetIn, wStepStatus, wStepProg, appendWizLog]() {
        const bool sysd = (wInitCb->currentIndex() == 1);
        const bool desk = (wProfCb->currentIndex() == 1);
        const QString variant = desk ? (sysd ? QStringLiteral("desktop-systemd") : QStringLiteral("desktop-openrc"))
                                     : (sysd ? QStringLiteral("systemd") : QStringLiteral("openrc"));
        wStepProg->setValue(0);
        appendWizLog(QStringLiteral("=== [Step 2/4] Fetching, verifying SHA-512 & extracting %1 Stage3 ===").arg(variant));
        wStepStatus->setText(i18n("<b>Step 2:</b> Fetching, verifying SHA-512, and extracting %1 Stage3 into %2...").arg(variant, wTargetIn->text()));
        stage3Page->startAutomatedStage3(variant, wTargetIn->text().trimmed());
    });
    connect(stage3Page, &Stage3Widget::extractionCompleted, this, [wStepStatus, wTargetIn, wStepProg, wTotalProg, appendWizLog](const QString& dir) {
        wStepProg->setValue(100); wTotalProg->setValue(50); wTargetIn->setText(dir);
        appendWizLog(QStringLiteral("[Step 2/4] Complete: Stage3 extracted into %1").arg(dir));
        wStepStatus->setText(i18n("<b>Step 2 Complete:</b> Stage3 extracted into %1. Proceed to <b>3. Build Kernel & Base System</b>.").arg(dir));
    });
    connect(wBuildBaseBtn, &QPushButton::clicked, this, [diskPage, wTargetIn, wHostIn, wTzIn, wPassIn, wInitCb, wBootCb, wStepStatus, wStepProg, wTotalProg, appendWizLog]() {
        wStepProg->setValue(10);
        appendWizLog(QStringLiteral("=== [Step 3/4] Building Kernel, Firmware, Locale & Bootloader in %1 ===").arg(wTargetIn->text()));
        wStepStatus->setText(i18n("<b>Step 3:</b> Building Base System in %1...").arg(wTargetIn->text()));
        diskPage->runGuidedBaseSystemBuild(
            wTargetIn->text(), wHostIn->text(), wTzIn->text(), wPassIn->text(),
            wBootCb->currentIndex() == 1 ? QStringLiteral("systemd-boot") : QStringLiteral("grub"),
            wInitCb->currentIndex() == 1
        );
        wStepProg->setValue(100); wTotalProg->setValue(75);
        appendWizLog(QStringLiteral("[Step 3/4] Complete: Base system & bootloader configured."));
        wStepStatus->setText(i18n("<b>Step 3 Complete:</b> Base system ready. Click <b>4. Confirm & Write to Target (dd)</b>."));
    });
    connect(wFinalDdBtn, &QPushButton::clicked, this, [diskPage, wTargetIn, wStepStatus, wStepProg, wTotalProg, appendWizLog]() {
        wStepProg->setValue(10);
        appendWizLog(QStringLiteral("=== [Step 4/4] Final confirmation & writing image to target drive ==="));
        diskPage->finalizeDdToTarget(wTargetIn->text());
        wStepProg->setValue(100); wTotalProg->setValue(100);
        appendWizLog(QStringLiteral("[Step 4/4] Wizard finished!"));
        wStepStatus->setText(i18n("<b>Wizard Complete (100%):</b> System image written to target device."));
    });
    connect(wChrootTermBtn, &QPushButton::clicked, this, [applyRole, stepList, steps, termPage, wTargetIn]() {
        applyRole(1);
        for (int i = 0; i < steps.size(); ++i) if (steps.at(i).page == termPage) stepList->setCurrentRow(i);
        termPage->addTerminalTab(wTargetIn->text(), QStringLiteral("Chroot"));
        termPage->sendCommand(QStringLiteral("chroot ") + wTargetIn->text() + QStringLiteral(" /bin/bash -c 'env-update; source /etc/profile; exec /bin/bash -i'\n"));
    });
    connect(wizAct, &QAction::triggered, this, [applyRole]() { applyRole(0); });
    connect(novAct, &QAction::triggered, this, [applyRole]() { applyRole(1); });
    if (expAct) connect(expAct, &QAction::triggered, this, [applyRole]() { applyRole(2); });
    applyRole(initMode);
    stepList->setCurrentRow(0);
    setCentralWidget(shell);

connect(m_deviceCombo, QOverload<int>::of(&QComboBox::currentIndexChanged), this, &MainWindow::onDeviceChanged);
connect(m_partitionTree, &QTreeWidget::itemSelectionChanged, this, &MainWindow::onTreeSelectionChanged);
connect(m_partitionTree, &QTreeWidget::customContextMenuRequested, this, &MainWindow::onTreeContextMenu);
connect(m_diskBar, &DiskBarWidget::partitionSelected, this, &MainWindow::onBarPartitionSelected);
}
void MainWindow::setupActions() {
auto* ac = new KActionCollection(this);
KStandardAction::quit(this, &QWidget::close, ac);
auto* refreshAct = ac->addAction(QStringLiteral("refresh_devices"), this, &MainWindow::refreshDevices);
refreshAct->setText(i18n("Refresh Devices"));
refreshAct->setIcon(QIcon::fromTheme(QStringLiteral("view-refresh")));
KActionCollection::setDefaultShortcut(refreshAct, QKeySequence::Refresh);
auto* devSubAct = ac->addAction(QStringLiteral("devices_submenu"));
devSubAct->setText(i18n("Devices"));
m_devicesMenu = new QMenu(this);
devSubAct->setMenu(m_devicesMenu);
m_undoAct = ac->addAction(QStringLiteral("undo_last"), this, &MainWindow::undoLastOperation);
m_undoAct->setText(i18n("Undo Last Operation"));
m_undoAct->setIcon(QIcon::fromTheme(QStringLiteral("edit-undo")));
KActionCollection::setDefaultShortcut(m_undoAct, QKeySequence::Undo);
m_clearAct = ac->addAction(QStringLiteral("clear_all"), this, &MainWindow::clearAllOperations);
m_clearAct->setText(i18n("Clear All Operations"));
m_clearAct->setIcon(QIcon::fromTheme(QStringLiteral("edit-clear")));
m_applyAct = ac->addAction(QStringLiteral("apply_all"), this, &MainWindow::applyAllOperations);
m_applyAct->setText(i18n("Apply All Operations"));
m_applyAct->setIcon(QIcon::fromTheme(QStringLiteral("dialog-ok-apply")));
m_viewInfoAct = ac->addAction(QStringLiteral("view_device_info"));
m_viewInfoAct->setText(i18n("Device Information"));
m_viewInfoAct->setCheckable(true);
connect(m_viewInfoAct, &QAction::toggled, m_deviceInfoPane, &QWidget::setVisible);
m_viewOpsAct = ac->addAction(QStringLiteral("view_pending_ops"));
m_viewOpsAct->setText(i18n("Pending Operations"));
m_viewOpsAct->setCheckable(true);
connect(m_viewOpsAct, &QAction::toggled, m_opsList, &QWidget::setVisible);
auto* fsSupportAct = ac->addAction(QStringLiteral("view_fs_support"));
fsSupportAct->setText(i18n("File System Support"));
connect(fsSupportAct, &QAction::triggered, this, [this]() { FeaturesDialog(m_core, this).exec(); });
m_disklabelAct = ac->addAction(QStringLiteral("create_disklabel"), this, &MainWindow::createPartitionTable);
m_disklabelAct->setText(i18n("Create Partition Table..."));
auto* rescueAct = ac->addAction(QStringLiteral("attempt_rescue"), this, &MainWindow::attemptDataRescue);
rescueAct->setText(i18n("Attempt Data Rescue..."));
rescueAct->setIcon(QIcon::fromTheme(QStringLiteral("system-search")));
m_resizeAct = ac->addAction(QStringLiteral("part_resize"));
m_resizeAct->setText(i18n("Resize/Move..."));
m_resizeAct->setIcon(QIcon::fromTheme(QStringLiteral("transform-scale")));
m_uuidAct = ac->addAction(QStringLiteral("part_uuid"));
m_uuidAct->setText(i18n("New UUID"));
m_newAct = ac->addAction(QStringLiteral("part_new"));
m_newAct->setText(i18n("New..."));
m_newAct->setIcon(QIcon::fromTheme(QStringLiteral("list-add")));
m_delAct = ac->addAction(QStringLiteral("part_delete"));
m_delAct->setText(i18n("Delete"));
m_delAct->setIcon(QIcon::fromTheme(QStringLiteral("edit-delete")));
KActionCollection::setDefaultShortcut(m_delAct, QKeySequence::Delete);
auto* fmtSubAct = ac->addAction(QStringLiteral("part_format"));
fmtSubAct->setText(i18n("Format to"));
fmtSubAct->setIcon(QIcon::fromTheme(QStringLiteral("edit-clear-all")));
m_formatMenu = new QMenu(this);
fmtSubAct->setMenu(m_formatMenu);
m_unmountAct = ac->addAction(QStringLiteral("part_unmount"));
m_unmountAct->setText(i18n("Unmount"));
m_unmountAct->setIcon(QIcon::fromTheme(QStringLiteral("media-eject")));
m_flagsAct = ac->addAction(QStringLiteral("part_flags"));
m_flagsAct->setText(i18n("Manage Flags...")); m_flagsAct->setIcon(QIcon::fromTheme(QStringLiteral("flag")));
m_checkAct = ac->addAction(QStringLiteral("part_check"));
m_checkAct->setText(i18n("Check")); m_checkAct->setIcon(QIcon::fromTheme(QStringLiteral("checkmark")));
m_labelAct = ac->addAction(QStringLiteral("part_label"));
m_labelAct->setText(i18n("Label File System...")); m_labelAct->setIcon(QIcon::fromTheme(QStringLiteral("tag")));
m_nameAct = ac->addAction(QStringLiteral("part_name"));
m_nameAct->setText(i18n("Name Partition..."));
m_partImgAct = ac->addAction(QStringLiteral("part_image"));
m_partImgAct->setText(i18n("Create Sparse Partition Image..."));
m_partImgAct->setIcon(QIcon::fromTheme(QStringLiteral("drive-harddisk")));
m_partRestoreAct = ac->addAction(QStringLiteral("part_restore"));
m_partRestoreAct->setText(i18n("Restore Image to Partition..."));
m_partRestoreAct->setIcon(QIcon::fromTheme(QStringLiteral("document-revert")));
m_partInfoAct = ac->addAction(QStringLiteral("part_info"));
m_partInfoAct->setText(i18n("Information"));
m_partInfoAct->setIcon(QIcon::fromTheme(QStringLiteral("dialog-information")));
auto* mainBar = addToolBar(i18n("Main Toolbar"));
mainBar->setWindowTitle(QStringLiteral("Gentool-NG"));
mainBar->addAction(m_newAct);
mainBar->addAction(m_delAct);
mainBar->addSeparator();
mainBar->addAction(m_resizeAct);
mainBar->addSeparator();
mainBar->addAction(m_undoAct);
mainBar->addAction(m_applyAct);
mainBar->addSeparator();
mainBar->addWidget(new QLabel(i18n(" Device: "), this));
m_deviceCombo = new QComboBox(this);
m_deviceCombo->setMinimumWidth(std::max(340, fontMetrics().horizontalAdvance(QLatin1Char('M')) * 28));
mainBar->addWidget(m_deviceCombo);
}
void MainWindow::refreshDevices() {
statusBar()->showMessage(i18n("Scanning all devices..."));
m_queue.clear();
updateQueueUI();
m_deviceCombo->blockSignals(true);
m_deviceCombo->clear();
m_devicesMenu->clear();
m_partitionTree->clear();
m_diskBar->setDeviceAndPartitions(nullptr, nullptr);
m_deviceInfoPane->setDevice(nullptr);
const int curRole = QSettings(QStringLiteral("WakStab"), QStringLiteral("gentool-ng")).value(QStringLiteral("roleMode"), 0).toInt();
if (curRole == 0) { if (statusBar()) statusBar()->clearMessage(); return; }
static bool s_refreshing = false;
if (s_refreshing) return;
struct Guard { bool& f; ~Guard(){ f = false; } } guard{s_refreshing};
s_refreshing = true;
QProcess::execute(QStringLiteral("sh"), {QStringLiteral("-c"), QStringLiteral("for n in /dev/nbd[0-9]*; do [ -b \"$n\" ] || continue; b=$(basename \"$n\"); if [ $(cat /sys/block/$b/size 2>/dev/null || echo 1) -eq 0 ]; then partx -d --nr 1:16 \"$n\" 2>/dev/null || true; for pt in \"${n}\"p*; do [ -b \"$pt\" ] && delpart \"$n\" \"${pt##*p}\" 2>/dev/null || true; done; fi; done")});
m_core.set_devices(m_devices);
auto* vAct = findChild<QAction*>(QStringLiteral("virtual_disks_only"));
if (!vAct || vAct->isChecked()) {
    m_devices.erase(std::remove_if(m_devices.begin(), m_devices.end(), [](const std::unique_ptr<GParted::Device>& d) {
        QString p = QString::fromStdString(d->get_path().raw());
        return !p.startsWith(QStringLiteral("/dev/nbd")) && !p.startsWith(QStringLiteral("/dev/loop"));
    }), m_devices.end());
}
for (size_t i = 0; i < m_devices.size(); ++i) {
const auto& dev = *m_devices[i];
QString path = QString::fromStdString(dev.get_path().raw());
QString model = QString::fromStdString(dev.model.raw()).trimmed();
QString sizeStr = QString::fromStdString(GParted::Utils::format_size(dev.length, dev.sector_size).raw());
QString label = QStringLiteral("%1 (%2) — %3").arg(path, model, sizeStr);
m_deviceCombo->addItem(QIcon::fromTheme(QStringLiteral("drive-harddisk")), label);
m_devicesMenu->addAction(QIcon::fromTheme(QStringLiteral("drive-harddisk")), label, this, [this, i]() {
m_deviceCombo->setCurrentIndex(static_cast<int>(i));
});
}
m_deviceCombo->blockSignals(false);
if (!m_devices.empty()) {
m_deviceCombo->setCurrentIndex(0);
onDeviceChanged(0);
statusBar()->showMessage(i18np("1 device detected", "%1 devices detected", static_cast<int>(m_devices.size())), 4000);
}
updateActionStates();
}
void MainWindow::onDeviceChanged(int index) {
if (index < 0 || index >= static_cast<int>(m_devices.size())) return;
m_deviceInfoPane->setDevice(m_devices[static_cast<size_t>(index)].get());
rebuildCurrentView();
}
void MainWindow::rebuildCurrentView() {
int idx = m_deviceCombo->currentIndex();
if (idx < 0 || idx >= static_cast<int>(m_devices.size())) return;
const auto& dev = *m_devices[static_cast<size_t>(idx)];
m_queue.applyVisualToDevice(dev, m_visualParts);
m_diskBar->setDeviceAndPartitions(&dev, &m_visualParts);
populatePartitionTree(m_visualParts);
updateActionStates();
}
void MainWindow::createPartitionTable() {
int idx = m_deviceCombo->currentIndex();
if (idx < 0 || idx >= static_cast<int>(m_devices.size())) return;
const auto& dev = *m_devices[static_cast<size_t>(idx)];
QStringList types;
for (const auto& t : GParted::GParted_Core::get_disklabeltypes())
types << QString::fromStdString(t.raw());
bool ok = false;
QString chosen = QInputDialog::getItem(this, i18n("Create Partition Table on %1", QString::fromStdString(dev.get_path().raw())),
i18n("WARNING: This will ERASE ALL DATA on the entire disk!\nSelect new partition table type:"), types, 0, false, &ok);
if (!ok || chosen.isEmpty()) return;
if (m_core.set_disklabel(dev, chosen.toUtf8().constData()))
refreshDevices();
else
KMessageBox::error(this, i18n("Failed to create partition table. Ensure all partitions are unmounted."), i18n("Error"));
}
void MainWindow::populatePartitionTree(const GParted::PartitionVector& parts) {
m_partitionTree->clear();
for (size_t i = 0; i < parts.size(); ++i) {
const auto& part = parts[i];
auto* item = new QTreeWidgetItem(m_partitionTree);
QString partPath = (part.fstype == GParted::FS_UNALLOCATED) ? i18n("unallocated") : QString::fromStdString(part.get_path().raw());
QColor fsColor(QString::fromStdString(GParted::Utils::get_color(part.fstype).raw()));
if (!fsColor.isValid()) fsColor = palette().color(QPalette::Button);
QStringList mounts, flags;
for (const auto& mp : part.get_mountpoints()) mounts << QString::fromStdString(mp.raw());
for (const auto& fl : part.get_flags()) flags << QString::fromStdString(fl.raw());
item->setText(0, partPath);
item->setText(1, QString::fromStdString(part.name.raw()));
item->setIcon(2, makeSwatchIcon(fsColor, part.busy));
item->setText(2, QString::fromStdString(part.get_filesystem_string().raw()));
item->setText(3, mounts.join(QStringLiteral(", ")));
item->setText(4, QString::fromStdString(part.get_filesystem_label().raw()));
item->setText(5, QString::fromStdString(GParted::Utils::format_size(part.get_sector_length(), part.sector_size).raw()));
item->setText(6, (part.sectors_used >= 0) ? QString::fromStdString(GParted::Utils::format_size(part.sectors_used, part.sector_size).raw()) : QStringLiteral("—"));
item->setText(7, (part.sectors_unused >= 0) ? QString::fromStdString(GParted::Utils::format_size(part.sectors_unused, part.sector_size).raw()) : QStringLiteral("—"));
item->setText(8, flags.join(QStringLiteral(", ")));
}
for (int c = 0; c < m_partitionTree->columnCount() - 1; ++c)
m_partitionTree->resizeColumnToContents(c);
}
void MainWindow::onTreeSelectionChanged() {
auto items = m_partitionTree->selectedItems();
m_diskBar->setSelectedIndex(items.isEmpty() ? -1 : m_partitionTree->indexOfTopLevelItem(items.first()));
updateActionStates();
}
void MainWindow::onBarPartitionSelected(int index) {
if (index >= 0 && index < m_partitionTree->topLevelItemCount())
m_partitionTree->setCurrentItem(m_partitionTree->topLevelItem(index));
}
void MainWindow::updateActionStates() {
for (QAction* a : {m_newAct, m_delAct, m_resizeAct, m_unmountAct, m_flagsAct, m_checkAct, m_labelAct, m_nameAct, m_uuidAct, m_partImgAct, m_partRestoreAct, m_partInfoAct}) {
QObject::disconnect(a, &QAction::triggered, nullptr, nullptr);
a->setEnabled(false);
}
m_formatMenu->clear();
m_formatMenu->setEnabled(false);
int devIdx = m_deviceCombo->currentIndex();
auto items = m_partitionTree->selectedItems();
if (devIdx < 0 || devIdx >= static_cast<int>(m_devices.size()) || items.isEmpty()) return;
int row = m_partitionTree->indexOfTopLevelItem(items.first());
if (row < 0 || row >= static_cast<int>(m_visualParts.size())) return;
const auto& dev = *m_devices[static_cast<size_t>(devIdx)];
const auto& part = m_visualParts[static_cast<size_t>(row)];
bool isUnalloc = (part.fstype == GParted::FS_UNALLOCATED);
bool isReal = (!isUnalloc && part.type != GParted::TYPE_EXTENDED);
if (!isUnalloc && part.type != GParted::TYPE_EXTENDED) {
m_partImgAct->setEnabled(true);
connect(m_partImgAct, &QAction::triggered, this, [this, part]() {
ImageDialog(QString::fromStdString(part.get_path().raw()), part.get_byte_length(), ImageDialog::Mode::Sparse, QString(), this).exec();
});
}
if (!isUnalloc && !part.busy && part.type != GParted::TYPE_EXTENDED) {
m_partRestoreAct->setEnabled(true);
connect(m_partRestoreAct, &QAction::triggered, this, [this, part]() {
RestoreDialog dlg(QString::fromStdString(part.get_path().raw()), part.get_byte_length(), false, this);
dlg.exec();
if (dlg.restored()) refreshDevices();
});
}
m_partInfoAct->setEnabled(true);
connect(m_partInfoAct, &QAction::triggered, this, [this, part]() {
QString info = i18n("Path: %1\nFile system: %2\nFirst sector: %3\nLast sector: %4\nTotal sectors: %5\nUUID: %6",
QString::fromStdString(part.get_path().raw()), QString::fromStdString(part.get_filesystem_string().raw()),
QString::number(part.sector_start), QString::number(part.sector_end),
QString::number(part.get_sector_length()), QString::fromStdString(part.uuid.raw()));
KMessageBox::information(this, info, i18n("Partition Information"));
});
if (isUnalloc) {
m_newAct->setEnabled(true);
connect(m_newAct, &QAction::triggered, this, [this, &dev, part]() {
NewPartitionDialog dlg(dev, part, this);
if (dlg.exec() == QDialog::Accepted) { m_queue.addCreate(dev, part, dlg.buildPartition()); updateQueueUI(); rebuildCurrentView(); }
});
return;
}
if (part.busy) {
m_unmountAct->setEnabled(true);
m_unmountAct->setText((part.fstype == GParted::FS_LINUX_SWAP) ? i18n("Swapoff") : i18n("Unmount"));
connect(m_unmountAct, &QAction::triggered, this, [this, part]() {
Glib::ustring out, err;
Glib::ustring cmd = ((part.fstype == GParted::FS_LINUX_SWAP) ? "swapoff -v " : "umount -v ") + Glib::shell_quote(part.get_path());
if (GParted::Utils::execute_command(cmd, out, err, true) == 0) refreshDevices();
else KMessageBox::error(this, QString::fromStdString(err.raw()), i18n("Operation Failed"));
});
return;
}
m_delAct->setEnabled(true);
connect(m_delAct, &QAction::triggered, this, [this, &dev, part]() { m_queue.addDelete(dev, part); updateQueueUI(); rebuildCurrentView(); });
GParted::Sector minStart = part.sector_start;
GParted::Sector maxEnd = part.sector_end;
if (row > 0 && m_visualParts[static_cast<size_t>(row - 1)].fstype == GParted::FS_UNALLOCATED)
minStart = m_visualParts[static_cast<size_t>(row - 1)].sector_start;
if (row + 1 < static_cast<int>(m_visualParts.size()) && m_visualParts[static_cast<size_t>(row + 1)].fstype == GParted::FS_UNALLOCATED)
maxEnd = m_visualParts[static_cast<size_t>(row + 1)].sector_end;
m_resizeAct->setEnabled(true);
connect(m_resizeAct, &QAction::triggered, this, [this, &dev, part, minStart, maxEnd]() {
ResizeMoveDialog dlg(dev, part, minStart, maxEnd, this);
if (dlg.exec() == QDialog::Accepted) {
m_queue.addResizeMove(dev, part, dlg.buildPartition());
updateQueueUI();
rebuildCurrentView();
}
});
m_flagsAct->setEnabled(true);
connect(m_flagsAct, &QAction::triggered, this, [this, part]() { FlagsDialog(m_core, part, this).exec(); refreshDevices(); });
if (dev.disktype == "gpt") {
m_nameAct->setEnabled(true);
connect(m_nameAct, &QAction::triggered, this, [this, &dev, part]() {
bool ok = false;
QString nm = QInputDialog::getText(this, i18n("Name Partition"), i18n("Name:"), QLineEdit::Normal, QString::fromStdString(part.name.raw()), &ok);
if (ok) { m_queue.addName(dev, part, nm); updateQueueUI(); rebuildCurrentView(); }
});
}
if (isReal) {
m_formatMenu->setEnabled(true);
for (const auto& [name, fs] : std::vector<std::pair<QString, GParted::FSType>>{
{"ext4", GParted::FS_EXT4}, {"btrfs", GParted::FS_BTRFS}, {"xfs", GParted::FS_XFS},
{"fat32", GParted::FS_FAT32}, {"exfat", GParted::FS_EXFAT}, {"ntfs", GParted::FS_NTFS}, {"linux-swap", GParted::FS_LINUX_SWAP}}) {
m_formatMenu->addAction(name, this, [this, &dev, part, fs]() { m_queue.addFormat(dev, part, fs); updateQueueUI(); rebuildCurrentView(); });
}
m_checkAct->setEnabled(true);
connect(m_checkAct, &QAction::triggered, this, [this, &dev, part]() { m_queue.addCheck(dev, part); updateQueueUI(); rebuildCurrentView(); });
m_uuidAct->setEnabled(true);
connect(m_uuidAct, &QAction::triggered, this, [this, &dev, part]() { m_queue.addNewUUID(dev, part); updateQueueUI(); rebuildCurrentView(); });
m_labelAct->setEnabled(true);
connect(m_labelAct, &QAction::triggered, this, [this, &dev, part]() {
bool ok = false;
QString lbl = QInputDialog::getText(this, i18n("Label File System"), i18n("New label:"), QLineEdit::Normal, QString::fromStdString(part.get_filesystem_label().raw()), &ok);
if (ok) { m_queue.addLabel(dev, part, lbl); updateQueueUI(); rebuildCurrentView(); }
});
}
}
void MainWindow::onTreeContextMenu(const QPoint& pos) {
if (!m_partitionTree->itemAt(pos)) return;
QMenu menu(this);
for (QAction* a : {m_newAct, m_delAct, m_resizeAct}) menu.addAction(a);
menu.addSeparator();
menu.addMenu(m_formatMenu);
menu.addAction(m_unmountAct);
menu.addSeparator();
for (QAction* a : {m_flagsAct, m_checkAct, m_labelAct, m_nameAct, m_uuidAct}) menu.addAction(a);
menu.addSeparator();
menu.addAction(m_partImgAct);
menu.addAction(m_partRestoreAct);
menu.addAction(m_partInfoAct);
menu.exec(m_partitionTree->viewport()->mapToGlobal(pos));
}
void MainWindow::undoLastOperation() { m_queue.undoLast(); updateQueueUI(); rebuildCurrentView(); }
void MainWindow::clearAllOperations() { m_queue.clear(); updateQueueUI(); rebuildCurrentView(); }
void MainWindow::applyAllOperations() {
if (m_queue.isEmpty()) return;
auto* wAct = findChild<QAction*>(QStringLiteral("wizard_mode"));
bool wiz = (wAct && wAct->isChecked());
if (!wiz) {
    if (KMessageBox::warningContinueCancel(this, i18n("Apply %1 pending operation(s)?", m_queue.count()), i18n("Apply Operations")) != KMessageBox::Continue) return;
    ApplyDialog(m_core, m_queue, this).exec();
    refreshDevices();
    return;
}
if (auto* host = findChild<QWidget*>(QStringLiteral("inlineApplyHost"))) {
    qDeleteAll(host->findChildren<ApplyDialog*>(QString(), Qt::FindDirectChildrenOnly));
    auto* inlineDlg = new ApplyDialog(m_core, m_queue, host, true);
    host->layout()->addWidget(inlineDlg);
    host->show();
    connect(inlineDlg, &ApplyDialog::operationsFinished, this, [this](bool) { refreshDevices(); });
}
}
void MainWindow::updateQueueUI() {
m_opsList->clear();
QStringList items = m_queue.descriptions();
for (int i = 0; i < items.size(); ++i) m_opsList->addItem(QStringLiteral("%1. %2").arg(i + 1).arg(items[i]));
bool hasOps = !m_queue.isEmpty();
m_opsList->setVisible(hasOps);
m_viewOpsAct->setChecked(hasOps);
m_undoAct->setEnabled(hasOps);
m_clearAct->setEnabled(hasOps);
m_applyAct->setEnabled(hasOps);
}
void MainWindow::attemptDataRescue() {
int idx = m_deviceCombo->currentIndex();
if (idx < 0 || idx >= static_cast<int>(m_devices.size())) return;
RescueDialog(*m_devices[static_cast<size_t>(idx)], this).exec();
}
