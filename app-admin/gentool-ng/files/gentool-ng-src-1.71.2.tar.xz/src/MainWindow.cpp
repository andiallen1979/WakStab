#include <QTransform>
#include <QRandomGenerator>
#include <QDirIterator>
#include <QGroupBox>
#include "Stage3BuilderWidget.h"
#include "GtSnapManager.h"
#include <QGuiApplication>
#include <QScreen>
#include <QActionGroup>
#include "DiffCompareWidget.h"
#include "EselectWidget.h"
#include "BinpkgManagerWidget.h"
#include <QStackedWidget>
#include <QListWidget>
#include "Stage3Widget.h"
#include "LogManagerWidget.h"
#include "SystemInfoWidget.h"
#include "DeviceManagerWidget.h"
#include <QFileInfo>
#include "FsGuideOverlay.h"
#include "SystemSnapshotWidget.h"
#include "TerminalWidget.h"
#include "PlaceholderTabWidget.h"
#include "QemuVmWidget.h"
#include "DiskImageWidget.h"
#include "PortageConfigWidget.h"
#include <QTabWidget>
#include "RestoreDialog.h"
#include "VirtualDiskDialog.h"
#include <QApplication>
#include <QDialog>
#include <QDialogButtonBox>
#include <QFontComboBox>
#include <QFormLayout>
#include <QSettings>
#include <QSpinBox>
#include "ImageDialog.h"
#include "RescueDialog.h"
#include <QToolBar>
#include "ResizeMoveDialog.h"
#include <QMenuBar>
#include "MainWindow.h"
#include "ApplyDialog.h"
#include "FeaturesDialog.h"
#include "FlagsDialog.h"
#include "NewPartitionDialog.h"
#include "Utils.h"
#include <KActionCollection>
#include <KLocalizedString>
#include <KMessageBox>
#include <KStandardAction>
#include <KToolBar>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QIcon>
#include <QInputDialog>
#include <QLabel>
#include <QPainter>
#include <QPixmap>
#include <QSplitter>
#include <QStatusBar>
#include <QVBoxLayout>
#include <QWidget>
#include <glibmm/shell.h>
namespace {
QIcon makeSwatchIcon(const QColor& color, bool locked) {
QPixmap pm(16, 16);
pm.fill(Qt::transparent);
QPainter p(&pm);
p.setRenderHint(QPainter::Antialiasing, true);
p.setPen(QPen(Qt::darkGray, 1.0));
p.setBrush(color);
p.drawRoundedRect(1, 1, 14, 14, 3.0, 3.0);
if (locked)
QIcon::fromTheme(QStringLiteral("emblem-locked")).paint(&p, 4, 4, 11, 11);
return QIcon(pm);
}
} // namespace
MainWindow::MainWindow(QWidget* parent)
: QMainWindow(parent) {
setWindowTitle(QStringLiteral("Gentool-NG"));
setWindowIcon(QIcon::fromTheme(QStringLiteral("drive-harddisk")));
resize(1160, 740);
m_core.find_supported_filesystems();
m_core.set_user_devices({});
auto* central = new QWidget(this);
auto* rootLayout = new QVBoxLayout(central);
rootLayout->setContentsMargins(6, 6, 6, 6);
rootLayout->setSpacing(6);
m_diskBar = new DiskBarWidget(this);
rootLayout->addWidget(m_diskBar);
auto* hSplit = new QSplitter(Qt::Horizontal, this);
m_deviceInfoPane = new DeviceInfoPane(hSplit);
m_deviceInfoPane->setVisible(false);
auto* vSplit = new QSplitter(Qt::Vertical, hSplit);
m_partitionTree = new QTreeWidget(vSplit);
m_partitionTree->setRootIsDecorated(false);
m_partitionTree->setAlternatingRowColors(true);
m_partitionTree->setSelectionMode(QAbstractItemView::SingleSelection);
m_partitionTree->setContextMenuPolicy(Qt::CustomContextMenu);
m_partitionTree->setHeaderLabels({
i18n("Partition"), i18n("Name"), i18n("File System"), i18n("Mount Point"),
i18n("Label"), i18n("Size"), i18n("Used"), i18n("Unused"), i18n("Flags")
});
m_partitionTree->header()->setSectionResizeMode(QHeaderView::Interactive);
m_partitionTree->header()->setSectionsMovable(true);
m_partitionTree->header()->setStretchLastSection(true);
m_partitionTree->setUniformRowHeights(false);
m_opsList = new QListWidget(vSplit);
m_opsList->setMaximumHeight(std::max(130, fontMetrics().lineSpacing() * 6 + 24));
m_opsList->setVisible(false);
vSplit->setStretchFactor(0, 4);
vSplit->setStretchFactor(1, 1);
hSplit->setStretchFactor(1, 1);
rootLayout->addWidget(hSplit, 1);
auto* suiteMenu = menuBar()->addMenu(i18n("&Menu"));
auto* modeGroup = new QActionGroup(this);
modeGroup->setExclusive(true);
const bool hasExpertFlag = QCoreApplication::arguments().contains(QStringLiteral("--expert-override"));
auto* viewMenu = suiteMenu->addMenu(QIcon::fromTheme(QStringLiteral("view-choose")), i18n("&View"));
auto* pSet = suiteMenu->addMenu(QIcon::fromTheme(QStringLiteral("configure")), i18n("&Settings"));
suiteMenu->addSeparator();
suiteMenu->addAction(QIcon::fromTheme(QStringLiteral("application-exit")), i18n("&Quit"), this, &QWidget::close, QKeySequence::Quit);

auto* modeMenu = viewMenu->addMenu(QIcon::fromTheme(QStringLiteral("system-switch-user")), i18n("&Mode"));
auto* wizAct = modeMenu->addAction(QIcon::fromTheme(QStringLiteral("tools-wizard")), i18n("&Wizard Mode (Guided Safe Defaults)"));
auto* novAct = modeMenu->addAction(QIcon::fromTheme(QStringLiteral("user-info")), i18n("&Normal Mode (Handbook Guided)"));
QAction* expAct = nullptr;
wizAct->setObjectName(QStringLiteral("wizard_mode"));
novAct->setObjectName(QStringLiteral("normal_mode"));
wizAct->setCheckable(true); modeGroup->addAction(wizAct);
novAct->setCheckable(true); modeGroup->addAction(novAct);
if (hasExpertFlag) {
    expAct = modeMenu->addAction(QIcon::fromTheme(QStringLiteral("preferences-system")), i18n("&Expert Mode (Raw / Experimenter)"));
    expAct->setObjectName(QStringLiteral("expert_mode"));
    expAct->setCheckable(true); modeGroup->addAction(expAct);
}
int initMode = QSettings(QStringLiteral("WakStab"), QStringLiteral("gentool-ng")).value(QStringLiteral("roleMode"), 0).toInt();
if (initMode == 2 && !hasExpertFlag) initMode = 0;
if (initMode == 2 && expAct) expAct->setChecked(true);
else if (initMode == 1) novAct->setChecked(true);
else wizAct->setChecked(true);
viewMenu->addSeparator();

auto* suiteTabs = new QTabWidget(this);
suiteTabs->setUsesScrollButtons(true);
auto* portagePage = new QWidget(this);
auto* portagePageLay = new QVBoxLayout(portagePage);
portagePageLay->setContentsMargins(0, 0, 0, 0); portagePageLay->setSpacing(0);
auto* pMenu = new QMenuBar(portagePage);
pMenu->hide();
auto* actDark = viewMenu->addAction(QIcon::fromTheme(QStringLiteral("preferences-desktop-theme")), i18n("Dark Theme"));
actDark->setCheckable(true); actDark->setChecked(true);
connect(actDark, &QAction::toggled, this, [this, actDark](bool dark) {
    actDark->setText(dark ? i18n("Switch to Light Theme") : i18n("Switch to Dark Theme"));
    QPalette pal = QApplication::style()->standardPalette();
    if (dark) {
        pal.setColor(QPalette::Window, QColor("#232629")); pal.setColor(QPalette::WindowText, QColor("#eff0f1"));
        pal.setColor(QPalette::Base, QColor("#181a1f")); pal.setColor(QPalette::Text, QColor("#eff0f1"));
        pal.setColor(QPalette::Button, QColor("#31363b")); pal.setColor(QPalette::ButtonText, QColor("#eff0f1"));
        pal.setColor(QPalette::Highlight, QColor("#3daee9")); pal.setColor(QPalette::HighlightedText, QColor("#ffffff"));
    }
    QApplication::setPalette(pal);
});
auto* fontAct = pSet->addAction(QIcon::fromTheme(QStringLiteral("preferences-desktop-font")), i18n("Application Font..."), this, [this]() {
    QDialog dlg(this); dlg.setWindowTitle(QStringLiteral("Gentool-NG"));
    auto* form = new QFormLayout(&dlg); auto* familyBox = new QFontComboBox(&dlg); auto* sizeSpin = new QSpinBox(&dlg);
    sizeSpin->setRange(6, 36); sizeSpin->setSuffix(QStringLiteral(" pt"));
    QFont cur = QApplication::font(); familyBox->setCurrentFont(cur); sizeSpin->setValue(cur.pointSize() > 0 ? cur.pointSize() : 11);
    form->addRow(i18n("Font family:"), familyBox); form->addRow(i18n("Font size:"), sizeSpin);
    auto* btns = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, &dlg);
    connect(btns, &QDialogButtonBox::accepted, &dlg, &QDialog::accept); connect(btns, &QDialogButtonBox::rejected, &dlg, &QDialog::reject);
    form->addRow(btns);
    if (dlg.exec() != QDialog::Accepted) return;
    QFont next = familyBox->currentFont(); next.setPointSize(sizeSpin->value());
    QSettings st(QStringLiteral("WakStab"), QStringLiteral("gentool-ng"));
    st.setValue(QStringLiteral("ui/fontFamily"), next.family());
    st.setValue(QStringLiteral("ui/fontSize"), next.pointSize());
    QApplication::setFont(next); setFont(next);
    for (QWidget* w : QApplication::allWidgets()) {
        const QByteArray cn = w->metaObject()->className();
        if (cn.contains("Term") || (w->parentWidget() && QByteArray(w->parentWidget()->metaObject()->className()).contains("Term"))) continue;
        QFont wf = next;
        if (qobject_cast<QPlainTextEdit*>(w)) wf.setFamily(QStringLiteral("Monospace"));
        w->setFont(wf);
        w->updateGeometry();
    }
    QString qss = qApp->styleSheet();
    qss.remove(QRegularExpression(QStringLiteral("QWidget,\s*QMenu[^}]*\}\s*")));
    qApp->setStyleSheet(QStringLiteral("QWidget:not(QTermWidget):not(QTermWidget *), QMenu, QMenuBar, QPushButton, QPlainTextEdit { font-family: '%1'; font-size: %2pt; } ").arg(next.family()).arg(next.pointSize()) + qss);
    rebuildCurrentView();
});

portagePageLay->addWidget(pMenu);
portagePageLay->addWidget(new PortageConfigWidget(portagePage), 1);

auto* qpPage = new QWidget(this);
auto* qpPageLay = new QVBoxLayout(qpPage);
qpPageLay->setContentsMargins(0, 0, 0, 0); qpPageLay->setSpacing(0);
setupActions();
auto* ac = findChild<KActionCollection*>();
setObjectName(QStringLiteral("gentoolRoot"));
statusBar();
QMenu* diskMgrM = menuBar()->addMenu(i18n("&Disk Manager"));
diskMgrM->addAction(ac->action(QStringLiteral("refresh_devices")));
diskMgrM->addMenu(m_devicesMenu)->setText(i18n("Devices"));
diskMgrM->addSeparator();
QMenu* devM = diskMgrM->addMenu(i18n("&Device"));
devM->addAction(m_disklabelAct);
devM->addAction(ac->action(QStringLiteral("attempt_rescue")));
QMenu* partM = diskMgrM->addMenu(i18n("&Partition"));
partM->addAction(m_newAct); partM->addAction(m_delAct); partM->addSeparator();
partM->addAction(m_resizeAct); partM->addAction(m_flagsAct); partM->addAction(m_checkAct);
partM->addAction(m_labelAct); partM->addAction(m_nameAct); partM->addAction(m_uuidAct);
partM->addSeparator(); partM->addAction(m_unmountAct);
diskMgrM->addSeparator();
diskMgrM->addAction(ac->action(QStringLiteral("view_fs_support")));

QMenu* helpTopM = menuBar()->addMenu(i18n("&Help"));
helpTopM->addAction(QIcon::fromTheme(QStringLiteral("help-about")), i18n("&About gentool-ng"), this, [this]() {
    KMessageBox::information(this,
        i18n("gentool-ng 1.71.2\n\nUnified Gentoo System Suite: Portage Configurator, Disk & Partition Manager, Virtual Disks, Stage3 Retriever, Log Manager, System Telemetry, and Hardware Device Manager.\n\nWakStab System Suite"),
        i18n("About gentool-ng"));
});
if (auto* tb = findChild<QToolBar*>()) { removeToolBar(tb); tb->setParent(qpPage); tb->show(); qpPageLay->addWidget(tb); }
auto* qpMainSplit = new QSplitter(Qt::Horizontal, qpPage);
qpMainSplit->addWidget(central);
auto* qpRightSplit = new QSplitter(Qt::Vertical, qpMainSplit);
qpRightSplit->setObjectName(QStringLiteral("qpRightSplit"));
auto* fsGuide = new FsGuideOverlay(qpRightSplit);
auto* inlineApplyHost = new QWidget(qpRightSplit);
inlineApplyHost->setObjectName(QStringLiteral("inlineApplyHost"));
auto* inlineApplyLay = new QVBoxLayout(inlineApplyHost);
inlineApplyLay->setContentsMargins(0, 0, 0, 0);
inlineApplyHost->hide();
qpRightSplit->addWidget(fsGuide);
qpRightSplit->addWidget(inlineApplyHost);
qpMainSplit->addWidget(qpRightSplit);
qpMainSplit->setStretchFactor(0, 3);
qpMainSplit->setStretchFactor(1, 1);
qpPageLay->addWidget(qpMainSplit, 1);
fsGuide->hide();
if (auto* qpTb = qpPage->findChild<QToolBar*>()) {
    qpTb->addSeparator();
    auto* virtOnlyAct = qpTb->addAction(QIcon::fromTheme(QStringLiteral("security-high")), i18n("Virtual Disks Only"));
    virtOnlyAct->setObjectName(QStringLiteral("virtual_disks_only"));
    virtOnlyAct->setCheckable(true);
    virtOnlyAct->setChecked(true);
    virtOnlyAct->setToolTip(i18n("Safety Lock: Hide physical NVMe/SATA/eMMC drives and allow only /dev/nbd* and /dev/loop*"));
    connect(virtOnlyAct, &QAction::toggled, this, [this]() { refreshDevices(); });
    auto* guideAct = qpTb->addAction(QIcon::fromTheme(QStringLiteral("help-contents")), i18n("Filesystem Guide"));
    connect(guideAct, &QAction::triggered, this, [fsGuide]() {
        if (fsGuide->isVisible()) fsGuide->hide();
        else fsGuide->showForDisk(QString());
    });
    connect(fsGuide, &FsGuideOverlay::applyLayoutRequested, this, [this, fsGuide, wizAct](int idx) {
        int devIdx = m_deviceCombo->currentIndex();
        if (devIdx < 0 || devIdx >= static_cast<int>(m_devices.size())) return;
        GParted::Device& dev = *m_devices[static_cast<size_t>(devIdx)];
        QString dPath = QString::fromStdString(dev.get_path().raw());
        if (!dPath.startsWith(QStringLiteral("/dev/nbd")) && !dPath.startsWith(QStringLiteral("/dev/loop"))) {
            KMessageBox::error(this, i18n("Safety Lockout: Automated wizard partitioning is restricted to /dev/nbd* and /dev/loop* devices. Refusing %1.", dPath));
            return;
        }
        // Automated virtual-disk GPT initialization (no redundant modal warning)
        if (!m_core.set_disklabel(dev, "gpt")) {
            KMessageBox::error(this, i18n("Failed to write GPT label. Ensure all partitions on %1 are unmounted.", QString::fromStdString(dev.get_path().raw())));
            return;
        }
        refreshDevices();
        if (devIdx < m_deviceCombo->count()) m_deviceCombo->setCurrentIndex(devIdx);
        GParted::Device& freshDev = *m_devices[static_cast<size_t>(m_deviceCombo->currentIndex())];
        struct Spec { qint64 mib; GParted::FSType fs; const char* lbl; };
        std::vector<Spec> plan;
        switch (idx) {
            case 0: plan = {{1024, GParted::FS_FAT32, "EFI"}, {16384, GParted::FS_LINUX_SWAP, "SWAP"}, {-1, GParted::FS_BTRFS, "GENTOO"}}; break;
            case 1: plan = {{1024, GParted::FS_FAT32, "EFI"}, {16384, GParted::FS_LINUX_SWAP, "SWAP"}, {49152, GParted::FS_BTRFS, "GENTOO"}, {-1, GParted::FS_XFS, "GAMES"}}; break;
            case 2: plan = {{512, GParted::FS_FAT32, "EFI"}, {8192, GParted::FS_LINUX_SWAP, "SWAP"}, {-1, GParted::FS_BTRFS, "HANDHELD"}}; break;
            case 3: plan = {{512, GParted::FS_FAT32, "EFI"}, {4096, GParted::FS_LINUX_SWAP, "SWAP"}, {20480, GParted::FS_EXT4, "ROOT"}, {-1, GParted::FS_XFS, "VAR"}}; break;
            case 4: plan = {{512, GParted::FS_FAT32, "EFI"}, {4096, GParted::FS_LINUX_SWAP, "SWAP"}, {24576, GParted::FS_EXT4, "OS"}, {-1, GParted::FS_BTRFS, "DATA"}}; break;
            case 5: plan = {{512, GParted::FS_FAT32, "EFI"}, {32768, GParted::FS_LINUX_SWAP, "SWAP"}, {32768, GParted::FS_BTRFS, "BUILDHOST"}, {-1, GParted::FS_XFS, "BINPKGS"}}; break;
            default: plan = {{512, GParted::FS_FAT32, "EFI"}, {-1, GParted::FS_EXT4, "RESCUE"}}; break;
        }
        GParted::Sector alignSec = std::max<GParted::Sector>(1, GParted::MEBIBYTE / freshDev.sector_size);
        GParted::Sector cur = alignSec;
        GParted::Sector maxEnd = ((freshDev.length) / alignSec) * alignSec - 1;
        int num = 1;
        for (const auto& s : plan) {
            if (cur >= maxEnd) break;
            GParted::Sector end = (s.mib < 0) ? maxEnd : std::min(maxEnd, cur + ((s.mib * GParted::MEBIBYTE) / freshDev.sector_size) - 1);
            GParted::Partition unalloc, p;
            unalloc.Set_Unallocated(freshDev.get_path(), cur, end, freshDev.sector_size, false);
            p.Set(freshDev.get_path(), QStringLiteral("New Partition #%1").arg(num++).toUtf8().constData(),
                  num - 1, GParted::TYPE_PRIMARY, s.fs, cur, end, freshDev.sector_size, false, false);
            p.alignment = GParted::ALIGN_CYLINDER;
            p.set_filesystem_label(s.lbl);
            m_queue.addCreate(freshDev, unalloc, p);
            cur = end + 1;
        }
        updateQueueUI(); rebuildCurrentView();
        if (wizAct->isChecked()) fsGuide->showConfirmApply(m_queue.count(), idx);
        else fsGuide->hide();
    });
}

auto* diskPage = new DiskImageWidget(this);
auto* vmPage = new QemuVmWidget(this);
auto* termPage = new TerminalWidget(this);
auto* snapPage = new SystemSnapshotWidget(this);
auto* stage3Page = new Stage3Widget(this);
auto* logPage = new LogManagerWidget(this);
auto* sysInfoPage = new SystemInfoWidget(this);
auto* devMgrPage = new DeviceManagerWidget(this);

suiteTabs->addTab(portagePage, QIcon::fromTheme(QStringLiteral("preferences-system")), i18n("Portage Config"));
suiteTabs->addTab(qpPage, QIcon::fromTheme(QStringLiteral("drive-harddisk")), i18n("Partition Manager"));
suiteTabs->addTab(diskPage, QIcon::fromTheme(QStringLiteral("media-optical")), i18n("Virtual Disks"));
auto* mountGuide = new FsGuideOverlay(diskPage);
mountGuide->hide();
connect(fsGuide, &FsGuideOverlay::confirmApplyRequested, this, [this, suiteTabs, diskPage, fsGuide, mountGuide, wizAct](int profIdx) {
    fsGuide->hide();
    if (m_applyAct) m_applyAct->trigger();
    if (wizAct->isChecked()) {
        suiteTabs->setCurrentWidget(diskPage);
        mountGuide->showMountStage(QStringLiteral("virtual-disk"), profIdx);
    }
});
connect(mountGuide, &FsGuideOverlay::mountAndEnterChrootRequested, this, [suiteTabs, diskPage, termPage](const QString& part, const QString&, bool bind) {
    diskPage->prepareAndMountChroot(part, bind);
    suiteTabs->setCurrentWidget(termPage);
    termPage->addTerminalTab(QStringLiteral("/mnt/wakstab-chroot"), QStringLiteral("Chroot"));
    termPage->sendCommand(QStringLiteral("chroot /mnt/wakstab-chroot /bin/bash -c 'env-update; source /etc/profile; export PS1=\"\\[\\e[1;31m\\](gentool-chroot)\\[\\e[0m\\] \\w # \"; exec /bin/bash --norc -i'\n"));
});
connect(diskPage, &DiskImageWidget::openInPartitionManagerRequested, this, [this, suiteTabs, qpPage, fsGuide, wizAct](const QString& devPath, const QString& imgPath) {
    if (auto* vAct = findChild<QAction*>(QStringLiteral("virtual_disks_only")); vAct && !vAct->isChecked()) vAct->setChecked(true);
    suiteTabs->setCurrentWidget(qpPage);
    refreshDevices();
    if (!devPath.isEmpty()) {
        for (int i = 0; i < m_deviceCombo->count(); ++i) {
            if (m_deviceCombo->itemText(i).contains(devPath)) { m_deviceCombo->setCurrentIndex(i); break; }
        }
    }
    if (wizAct->isChecked()) fsGuide->showForDisk(devPath.isEmpty() ? imgPath : QStringLiteral("%1 (%2)").arg(devPath, QFileInfo(imgPath).fileName()));
});
suiteTabs->addTab(vmPage, QIcon::fromTheme(QStringLiteral("computer")), i18n("QEMU VMs"));
suiteTabs->addTab(termPage, QIcon::fromTheme(QStringLiteral("utilities-terminal")), i18n("Terminal"));
suiteTabs->addTab(snapPage, QIcon::fromTheme(QStringLiteral("document-save-as")), i18n("System Snapshot"));
connect(snapPage, &SystemSnapshotWidget::runInTerminalRequested, this, [suiteTabs, termPage](const QString& cmd) {
    suiteTabs->setCurrentWidget(termPage);
    termPage->sendCommand(cmd);
});
    auto* eselectPage = new EselectWidget(this);
    auto* binpkgPage = new BinpkgManagerWidget(this);
    auto* diffPage = new DiffCompareWidget(this);
    auto* s3BuildPage = new Stage3BuilderWidget(this);
    suiteTabs->addTab(stage3Page, QIcon::fromTheme(QStringLiteral("archive-extract")), i18n("Stage3 & Chroot"));
    suiteTabs->addTab(eselectPage, QIcon::fromTheme(QStringLiteral("preferences-other")), i18n("eselect Profiles"));
    suiteTabs->addTab(binpkgPage, QIcon::fromTheme(QStringLiteral("package-x-generic")), i18n("Binary Packages"));
    suiteTabs->addTab(diffPage, QIcon::fromTheme(QStringLiteral("vcs-diff")), i18n("Diff & Compare"));
    suiteTabs->addTab(s3BuildPage, QIcon::fromTheme(QStringLiteral("archive-insert")), i18n("Stage3 Builder"));
    suiteTabs->addTab(logPage, QIcon::fromTheme(QStringLiteral("utilities-log-viewer")), i18n("Log Manager"));
    suiteTabs->addTab(sysInfoPage, QIcon::fromTheme(QStringLiteral("hwinfo")), i18n("System & Hardware"));
    suiteTabs->addTab(devMgrPage, QIcon::fromTheme(QStringLiteral("preferences-desktop-peripherals")), i18n("Device Manager"));
    auto* logCfgAct = pSet->addAction(QIcon::fromTheme(QStringLiteral("configure")), i18n("Configure &Custom Logs..."));
    connect(logCfgAct, &QAction::triggered, logPage, &LogManagerWidget::configureCustomLogs);
    connect(stage3Page, &Stage3Widget::enterChrootRequested, this, [suiteTabs, termPage](const QString& dir) {
        suiteTabs->setCurrentWidget(termPage);
        termPage->addTerminalTab(dir, QStringLiteral("Chroot"));
        termPage->sendCommand(QStringLiteral("chroot ") + dir + QStringLiteral(" /bin/bash -c 'env-update; source /etc/profile; exec /bin/bash -i'\n"));
    });

    suiteTabs->tabBar()->hide();
    auto* shell = new QWidget(this);
    auto* shellLay = new QHBoxLayout(shell);
    shellLay->setContentsMargins(2, 2, 2, 2); shellLay->setSpacing(4);

    auto* navCol = new QWidget(shell);
    navCol->setMaximumWidth(215);
    auto* navLay = new QVBoxLayout(navCol);
    navLay->setContentsMargins(0, 0, 0, 0); navLay->setSpacing(4);



    auto* stepList = new QListWidget(navCol);
    stepList->setIconSize(QSize(16, 16));
    struct StepDef { QString title; QWidget* page; QString hint; bool expertOnly; };
    const QList<StepDef> steps = {
        {i18n("0. System Overview"), sysInfoPage, i18n("Verify CPU topology, RAM, tmpfs, and swap before building."), false},
        {i18n("1. NBD Disks & Sysext"), diskPage, i18n("Create/mount NBD virtual disks (qcow2/raw/vmdk/vhdx/vdi) or build systemd-sysext images."), false},
        {i18n("2. Partition Manager"), qpPage, i18n("Inspect or modify GPT/MBR partitions and filesystems on virtual devices."), true},
        {i18n("3. Stage3 & Chroot"), stage3Page, i18n("Select Gentoo mirror/init, verify SHA-512, extract Stage3, and enter chroot."), false},
        {i18n("4. Portage & make.conf"), portagePage, i18n("Configure CFLAGS, USE flags, ACCEPT_KEYWORDS, and package overrides."), false},
        {i18n("5. eselect Profiles"), eselectPage, i18n("Select active Gentoo system profile, kernel, python, and compiler targets."), false},
        {i18n("6. Binary Packages"), binpkgPage, i18n("Browse deep PKGDIR binpkgs, pack quickpkgs, or install prebuilt binaries."), false},
        {i18n("7. Hardware & Buses"), devMgrPage, i18n("Inspect PCIe/USB/I2C/SPI devices, switch drivers, or disable via udev rules."), true},
        {i18n("8. System & Build Logs"), logPage, i18n("Inspect /var/log, Portage build logs, and systemd journal."), true},
        {i18n("9. Diff & File Compare"), diffPage, i18n("Compare configuration files, kernel configs, or directories and export unified patches."), true},
        {i18n("10. Stage3 Release Builder"), s3BuildPage, i18n("Build custom Stage3 tarballs from GTSnap or chroot with <hostname>/<version> scoped binpkgs."), true},
        {i18n("9. QEMU & Terminal"), termPage, i18n("Run chroot commands, test-boot virtual disks in QEMU, or manage snapshots."), false},
    };
    for (const auto& st : steps) {
        auto* it = new QListWidgetItem(st.title, stepList);
        it->setData(Qt::UserRole, QVariant::fromValue<QWidget*>(st.page));
    }
    navLay->addWidget(stepList, 1);
    shellLay->addWidget(navCol);

    auto* rightCol = new QWidget(shell);
    auto* rightLay = new QVBoxLayout(rightCol);
    rightLay->setContentsMargins(0, 0, 0, 0); rightLay->setSpacing(4);

    auto* guideBar = new QFrame(rightCol);
    guideBar->setFrameShape(QFrame::StyledPanel);
    auto* gLay = new QHBoxLayout(guideBar);
    gLay->setContentsMargins(6, 3, 6, 3); gLay->setSpacing(6);
    auto* hintLbl = new QLabel(steps.first().hint, guideBar);
    hintLbl->setStyleSheet(QStringLiteral(""));
    auto* autoNbdBtn = new QPushButton(QIcon::fromTheme(QStringLiteral("tools-wizard")), i18n("Hands-Off NBD Disk..."), guideBar);
    auto* nextStepBtn = new QPushButton(QIcon::fromTheme(QStringLiteral("go-next")), i18n("Next Step"), guideBar);
    for (QPushButton* b : {autoNbdBtn, nextStepBtn}) {
        b->setMaximumHeight(24);
        b->setSizePolicy(QSizePolicy::Maximum, QSizePolicy::Fixed);
        b->setStyleSheet(QStringLiteral("QPushButton { padding: 2px 8px;  }"));
    }
    autoNbdBtn->setVisible(false);
    gLay->addWidget(hintLbl, 1);
    gLay->addWidget(autoNbdBtn);
    gLay->addWidget(nextStepBtn);
    rightLay->addWidget(guideBar);
    auto* modeStack = new QStackedWidget(rightCol);
    auto* wizardCard = new QWidget(modeStack);
    auto* wLay = new QVBoxLayout(wizardCard);
    wLay->setContentsMargins(16, 12, 16, 12); wLay->setSpacing(8);
    auto* wTitle = new QLabel(i18n("<h3>Gentool-NG — Complete Guided Gentoo Base System Wizard</h3>"), wizardCard);
    auto* wStepStatus = new QLabel(i18n("<b>Current Stage:</b> Step 1 — Fetch & Extract Stage3 (or Launch Staging Raw Image)"), wizardCard);

    auto* wForm = new QFormLayout();
    auto makeRunOnName = []() -> QString {
        static const QStringList p1 = {
            QStringLiteral("jib"), QStringLiteral("fin"), QStringLiteral("en"), QStringLiteral("wob"),
            QStringLiteral("snick"), QStringLiteral("blun"), QStringLiteral("flim"), QStringLiteral("grib"),
            QStringLiteral("zop"), QStringLiteral("quib"), QStringLiteral("mump"), QStringLiteral("plink"),
            QStringLiteral("spork"), QStringLiteral("bambooz"), QStringLiteral("snarf"), QStringLiteral("crank")
        };
        static const QStringList p2 = {
            QStringLiteral("ron"), QStringLiteral("do"), QStringLiteral("wei"), QStringLiteral("ble"),
            QStringLiteral("der"), QStringLiteral("flam"), QStringLiteral("wick"), QStringLiteral("nock"),
            QStringLiteral("per"), QStringLiteral("zaz"), QStringLiteral("muf"), QStringLiteral("tink"),
            QStringLiteral("bop"), QStringLiteral("wump"), QStringLiteral("snout"), QStringLiteral("fud")
        };
        static const QStringList p3 = {
            QStringLiteral("way"), QStringLiteral("per"), QStringLiteral("t"), QStringLiteral("flank"),
            QStringLiteral("buss"), QStringLiteral("oodle"), QStringLiteral("snort"), QStringLiteral("winkle"),
            QStringLiteral("gadget"), QStringLiteral("sprocket"), QStringLiteral("widget"), QStringLiteral("fizz"),
            QStringLiteral("blat"), QStringLiteral("zorp"), QStringLiteral("noodle"), QStringLiteral("shack")
        };
        auto *rng = QRandomGenerator::global();
        return p1.at(rng->bounded(p1.size())) + p2.at(rng->bounded(p2.size())) + p3.at(rng->bounded(p3.size()));
    };
    auto* wSnapNameIn = new QLineEdit(makeRunOnName(), wizardCard);
    auto* wTargetIn = new QLineEdit(wizardCard); wTargetIn->hide();
    auto* wHostIn = new QLineEdit(wizardCard); wHostIn->hide();
    auto* wPassIn = new QLineEdit(wizardCard); wPassIn->hide();
    auto* wTzIn = new QLineEdit(QStringLiteral("America/New_York"), wizardCard);
    auto* wInitCb = new QComboBox(wizardCard); wInitCb->addItems({QStringLiteral("OpenRC"), QStringLiteral("systemd")});
    auto* wProfCb = new QComboBox(wizardCard); wProfCb->addItems({QStringLiteral("Minimal / Server"), QStringLiteral("Desktop Profile")});
    auto* wBootCb = new QComboBox(wizardCard); wBootCb->addItems({QStringLiteral("GRUB2 (UEFI)"), QStringLiteral("GRUB2 (Legacy BIOS / Non-UEFI)"), QStringLiteral("systemd-boot (UEFI)")});
    auto* progBox = new QWidget(wizardCard);
    auto* progStack = new QVBoxLayout(progBox);
    progStack->setContentsMargins(0, 0, 0, 0); progStack->setSpacing(2);
    auto* wTotalProg = new QProgressBar(progBox); wTotalProg->setFixedHeight(14); wTotalProg->setValue(0); wTotalProg->setFormat(i18n("Total Wizard: %p%"));
    auto* wStepProg = new QProgressBar(progBox); wStepProg->setFixedHeight(14); wStepProg->setValue(0); wStepProg->setFormat(i18n("Current Step: %p%"));
    progStack->addWidget(wTotalProg);
    progStack->addWidget(wStepProg);

    auto* drawerBox = new QWidget(wizardCard);
    auto* drawerLay = new QVBoxLayout(drawerBox);
    drawerLay->setContentsMargins(0, 0, 0, 0); drawerLay->setSpacing(0);
    auto* tabRow = new QHBoxLayout(); tabRow->setContentsMargins(0, 0, 0, 0);
    auto* wLogToggle = new QPushButton(i18n("▴  Feedback  ▴"), drawerBox);
    wLogToggle->setCheckable(true); wLogToggle->setFixedHeight(16);
    wLogToggle->setSizePolicy(QSizePolicy::Maximum, QSizePolicy::Fixed);
    wLogToggle->setStyleSheet(QStringLiteral("QPushButton { padding: 0px 16px; margin-bottom: -3px; font-size: 10px; border: 1px solid #2c313a; border-bottom: none; border-top-left-radius: 6px; border-top-right-radius: 6px; background-color: #0b0d10; color: #abb2bf; } QPushButton:checked { background-color: #0b0d10; }"));
    tabRow->addStretch(1); tabRow->addWidget(wLogToggle); tabRow->addStretch(1);
    auto* wLiveLog = new QPlainTextEdit(drawerBox);
    wLiveLog->setReadOnly(true);
    wLiveLog->setMaximumBlockCount(4000); 
    wLiveLog->setStyleSheet(QStringLiteral("QPlainTextEdit { background-color: #0b0d10; color: #abb2bf; border: 1px solid #2c313a; padding-top: 24px; }"));
    drawerLay->addLayout(tabRow); drawerLay->addWidget(wLiveLog, 1); wLogToggle->raise();

    const QScreen* scr = QGuiApplication::primaryScreen();
    const QSize res = scr ? scr->size() : QSize(1920, 1080);
    const int longSide = qMax(res.width(), res.height());
    const int shortSide = qMin(res.width(), res.height());
    const double aspect = shortSide > 0 ? double(longSide) / double(shortSide) : 1.77;
    const bool hasRoom = (shortSide > ((aspect <= 1.65) ? 800 : 720));
    drawerBox->setVisible(hasRoom);
    wLogToggle->setChecked(false);
            wLiveLog->setFixedHeight(22);
    wLiveLog->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    auto* centerFrame = new QFrame(wizardCard);
    centerFrame->setObjectName(QStringLiteral("wizardCenterBox"));
    centerFrame->setStyleSheet(QStringLiteral("QFrame#wizardCenterBox { border: 1px solid #3e4451; border-radius: 10px; background-color: rgba(24, 26, 31, 140); }"));
    auto* cfLay = new QVBoxLayout(centerFrame);
    cfLay->setContentsMargins(24, 20, 24, 20);
    cfLay->setSpacing(12);

    const QString subCardQss = QStringLiteral("QFrame.wizSubCard { border: 1px solid #353b45; border-radius: 8px; background-color: rgba(18, 20, 24, 180); }");
    auto* leftCard = new QFrame(centerFrame);
    leftCard->setProperty("class", QStringLiteral("wizSubCard"));
    leftCard->setStyleSheet(subCardQss);
    auto* leftLay = new QVBoxLayout(leftCard);
    leftLay->setContentsMargins(16, 14, 16, 14); leftLay->setSpacing(10);
    auto* leftHdr = new QLabel(i18n("<b>System && Build Configuration</b>"), leftCard);
    leftLay->addWidget(leftHdr);

    auto* leftForm = new QFormLayout();
    leftForm->setVerticalSpacing(8); leftForm->setHorizontalSpacing(12);
    leftForm->setFieldGrowthPolicy(QFormLayout::FieldsStayAtSizeHint);
    auto* wBootProfCb = new QComboBox(leftCard);
    wBootProfCb->addItem(QStringLiteral("UEFI 64-bit (x86_64)"), QStringLiteral("uefi-64"));
    wBootProfCb->addItem(QStringLiteral("UEFI 32-bit (IA32)"), QStringLiteral("uefi-32"));
    wBootProfCb->addItem(QStringLiteral("MBR + UEFI Hybrid"), QStringLiteral("mbr-uefi-hybrid"));
    wBootProfCb->addItem(QStringLiteral("MBR Legacy BIOS (No UEFI)"), QStringLiteral("mbr-bios"));
    auto* wPartTblCb = new QComboBox(leftCard);
    wPartTblCb->addItem(QStringLiteral("GPT (GUID Partition Table)"), QStringLiteral("gpt"));
    wPartTblCb->addItem(QStringLiteral("MBR / MS-DOS"), QStringLiteral("msdos"));
    auto* wFsTypeCb = new QComboBox(leftCard);
    wFsTypeCb->addItems({QStringLiteral("ext4"), QStringLiteral("btrfs"), QStringLiteral("xfs"), QStringLiteral("f2fs")});
    auto syncBootTriad = [wBootProfCb, wPartTblCb, wBootCb](int changedBy) {
        wBootProfCb->blockSignals(true);
        wPartTblCb->blockSignals(true);
        wBootCb->blockSignals(true);
        wBootCb->setEnabled(true);

        if (changedBy == 0) {
            const QString prof = wBootProfCb->currentData().toString();
            if (prof == QStringLiteral("mbr-bios")) {
                wPartTblCb->setCurrentIndex(1);
                wBootCb->setCurrentIndex(1);
            } else if (prof == QStringLiteral("mbr-uefi-hybrid") || prof == QStringLiteral("uefi-32")) {
                wPartTblCb->setCurrentIndex(0);
                wBootCb->setCurrentIndex(0);
            } else {
                wPartTblCb->setCurrentIndex(0);
                if (wBootCb->currentIndex() == 1) wBootCb->setCurrentIndex(0);
            }
        } else if (changedBy == 1) {
            if (wPartTblCb->currentIndex() == 1) {
                wBootProfCb->setCurrentIndex(3);
                wBootCb->setCurrentIndex(1);
            } else {
                if (wBootProfCb->currentIndex() == 3) wBootProfCb->setCurrentIndex(0);
                if (wBootCb->currentIndex() == 1) wBootCb->setCurrentIndex(0);
            }
        } else if (changedBy == 2) {
            const int bIdx = wBootCb->currentIndex();
            if (bIdx == 1) {
                wBootProfCb->setCurrentIndex(3);
                wPartTblCb->setCurrentIndex(1);
            } else if (bIdx == 2) {
                wBootProfCb->setCurrentIndex(0);
                wPartTblCb->setCurrentIndex(0);
            } else {
                wPartTblCb->setCurrentIndex(0);
                if (wBootProfCb->currentIndex() == 3) wBootProfCb->setCurrentIndex(0);
            }
        }

        wBootProfCb->blockSignals(false);
        wPartTblCb->blockSignals(false);
        wBootCb->blockSignals(false);
    };
    connect(wBootProfCb, QOverload<int>::of(&QComboBox::currentIndexChanged), this, [syncBootTriad](int) { syncBootTriad(0); });
    connect(wPartTblCb, QOverload<int>::of(&QComboBox::currentIndexChanged), this, [syncBootTriad](int) { syncBootTriad(1); });
    connect(wBootCb, QOverload<int>::of(&QComboBox::currentIndexChanged), this, [syncBootTriad](int) { syncBootTriad(2); });
    for (QWidget* w : std::initializer_list<QWidget*>{wInitCb, wProfCb, wBootProfCb, wPartTblCb, wFsTypeCb, wBootCb}) {
        w->setMinimumHeight(30); w->setMaximumHeight(30); w->setFixedWidth(250);
    }
    wSnapNameIn->setMinimumHeight(30); wSnapNameIn->setMaximumHeight(30); wSnapNameIn->setFixedWidth(214);
    auto renderDieFace = [](int face, qreal angleDeg) -> QIcon {
        QPixmap pm(26, 26); pm.fill(Qt::transparent);
        QPainter pt(&pm); pt.setRenderHint(QPainter::Antialiasing, true);
        pt.translate(13, 13); pt.rotate(angleDeg); pt.translate(-13, -13);
        QLinearGradient grad(0, 2, 0, 24);
        grad.setColorAt(0.0, QColor(QStringLiteral("#3a404b")));
        grad.setColorAt(1.0, QColor(QStringLiteral("#1f2329")));
        pt.setPen(QPen(QColor(QStringLiteral("#3daee9")), 1.4));
        pt.setBrush(grad);
        pt.drawRoundedRect(QRectF(3, 3, 20, 20), 4.5, 4.5);
        pt.setPen(Qt::NoPen); pt.setBrush(QColor(QStringLiteral("#eff0f1")));
        auto pip = [&](qreal x, qreal y) { pt.drawEllipse(QPointF(x, y), 1.8, 1.8); };
        if (face == 1 || face == 3 || face == 5) pip(13, 13);
        if (face >= 2) { pip(8, 8); pip(18, 18); }
        if (face >= 4) { pip(18, 8); pip(8, 18); }
        if (face == 6) { pip(8, 13); pip(18, 13); }
        return QIcon(pm);
    };
    auto* curFace = new int(QRandomGenerator::global()->bounded(1, 7));
    auto* wRandNameBtn = new QPushButton(renderDieFace(*curFace, 0.0), QString(), leftCard);
    wRandNameBtn->setIconSize(QSize(24, 24));
    wRandNameBtn->setToolTip(i18n("Roll the die for a new random GTSnap name"));
    wRandNameBtn->setFixedSize(32, 30);
    wRandNameBtn->setStyleSheet(QStringLiteral("QPushButton { padding: 1px; }"));
    auto* rollTimer = new QTimer(wRandNameBtn);
    auto* rollStep = new int(0);
    connect(rollTimer, &QTimer::timeout, wRandNameBtn, [rollTimer, rollStep, curFace, wRandNameBtn, wSnapNameIn, makeRunOnName, renderDieFace]() {
        (*rollStep)++;
        if (*rollStep < 10) {
            *curFace = QRandomGenerator::global()->bounded(1, 7);
            wRandNameBtn->setIcon(renderDieFace(*curFace, (*rollStep) * 36.0));
            wSnapNameIn->setText(makeRunOnName());
        } else {
            rollTimer->stop();
            *curFace = QRandomGenerator::global()->bounded(1, 7);
            wRandNameBtn->setIcon(renderDieFace(*curFace, 0.0));
            wSnapNameIn->setText(makeRunOnName());
        }
    });
    connect(wRandNameBtn, &QPushButton::clicked, this, [rollTimer, rollStep]() {
        *rollStep = 0; rollTimer->start(32);
    });
    auto* snapNameBox = new QWidget(leftCard);
    auto* snapNameLay = new QHBoxLayout(snapNameBox);
    snapNameLay->setContentsMargins(0, 0, 0, 0); snapNameLay->setSpacing(4);
    snapNameLay->addWidget(wSnapNameIn); snapNameLay->addWidget(wRandNameBtn);
    wTzIn->hide();
    auto* wLocaleIn = new QLineEdit(QStringLiteral("en_US.UTF-8"), wizardCard); wLocaleIn->hide();
    wTotalProg->setFixedSize(250, 18);
    wStepProg->setFixedSize(250, 18);
    progBox->setFixedSize(250, 40);
    leftForm->addRow(i18n("GTSnap Name:"), snapNameBox);
    leftForm->addRow(i18n("Init System:"), wInitCb);
    leftForm->addRow(i18n("Stage3 Variant:"), wProfCb);
    leftForm->addRow(i18n("Boot Profile:"), wBootProfCb);
    leftForm->addRow(i18n("Partition Table:"), wPartTblCb);
    leftForm->addRow(i18n("Root Filesystem:"), wFsTypeCb);
    leftForm->addRow(i18n("Bootloader:"), wBootCb);
    leftForm->addRow(i18n("Progress:"), progBox);
    leftLay->addLayout(leftForm);
    leftLay->addStretch(1);

    auto* rightCard = new QFrame(centerFrame);
    rightCard->setProperty("class", QStringLiteral("wizSubCard"));
    rightCard->setStyleSheet(subCardQss);
    auto* rightCardLay = new QVBoxLayout(rightCard);
    rightCardLay->setContentsMargins(16, 14, 16, 14); rightCardLay->setSpacing(10);
    auto* rightHdr = new QLabel(i18n("<b>Region, Timezone && System Locale</b>"), rightCard);
    rightCardLay->addWidget(rightHdr);

    auto* locForm = new QFormLayout();
    locForm->setVerticalSpacing(8); locForm->setHorizontalSpacing(12);
    locForm->setFieldGrowthPolicy(QFormLayout::FieldsStayAtSizeHint);
    auto* regionCb = new QComboBox(rightCard);
    auto* cityCb = new QComboBox(rightCard);
    auto* localeCb = new QComboBox(rightCard);
    auto* tzPreview = new QLabel(rightCard);
    tzPreview->setWordWrap(true);
    for (QWidget* w : std::initializer_list<QWidget*>{regionCb, cityCb, localeCb}) {
        w->setMinimumHeight(30); w->setMaximumHeight(30); w->setFixedWidth(260);
    }
    QMap<QString, QStringList> tzMap;
    QDirIterator it(QStringLiteral("/usr/share/zoneinfo"), QDir::Files, QDirIterator::Subdirectories);
    while (it.hasNext()) {
        QString rel = it.next().mid(20);
        if (rel.startsWith(QStringLiteral("posix/")) || rel.startsWith(QStringLiteral("right/")) || !rel.contains(QLatin1Char('/'))) continue;
        const QString reg = rel.section(QLatin1Char('/'), 0, 0);
        const QString city = rel.section(QLatin1Char('/'), 1);
        if (reg == QStringLiteral("Etc")) continue;
        tzMap[reg].append(city);
    }
    for (auto k = tzMap.begin(); k != tzMap.end(); ++k) k.value().sort();
    regionCb->addItems(tzMap.keys());
    auto syncTz = [regionCb, cityCb, localeCb, wTzIn, wLocaleIn, tzPreview]() {
        const QString fullTz = regionCb->currentText() + QLatin1Char('/') + cityCb->currentText();
        const QString locCode = localeCb->currentData().toString();
        wTzIn->setText(fullTz);
        wLocaleIn->setText(locCode);
        tzPreview->setText(i18n("<b>Zone:</b> %1<br><b>Locale:</b> %2", fullTz, locCode));
    };
    connect(regionCb, &QComboBox::currentTextChanged, this, [cityCb, tzMap, syncTz](const QString& reg) {
        cityCb->blockSignals(true); cityCb->clear(); cityCb->addItems(tzMap.value(reg)); cityCb->blockSignals(false);
        syncTz();
    });
    connect(cityCb, &QComboBox::currentTextChanged, this, syncTz);
    const QList<QPair<QString, QString>> locales = {
        {QStringLiteral("English (US) — en_US.UTF-8"), QStringLiteral("en_US.UTF-8")},
        {QStringLiteral("English (UK) — en_GB.UTF-8"), QStringLiteral("en_GB.UTF-8")},
        {QStringLiteral("English (CA) — en_CA.UTF-8"), QStringLiteral("en_CA.UTF-8")},
        {QStringLiteral("Deutsch — de_DE.UTF-8"), QStringLiteral("de_DE.UTF-8")},
        {QStringLiteral("Français — fr_FR.UTF-8"), QStringLiteral("fr_FR.UTF-8")},
        {QStringLiteral("Español — es_ES.UTF-8"), QStringLiteral("es_ES.UTF-8")},
        {QStringLiteral("Italiano — it_IT.UTF-8"), QStringLiteral("it_IT.UTF-8")},
        {QStringLiteral("Português (BR) — pt_BR.UTF-8"), QStringLiteral("pt_BR.UTF-8")},
        {QStringLiteral("Nederlands — nl_NL.UTF-8"), QStringLiteral("nl_NL.UTF-8")},
        {QStringLiteral("Polski — pl_PL.UTF-8"), QStringLiteral("pl_PL.UTF-8")},
        {QStringLiteral("Svenska — sv_SE.UTF-8"), QStringLiteral("sv_SE.UTF-8")},
        {QStringLiteral("日本語 — ja_JP.UTF-8"), QStringLiteral("ja_JP.UTF-8")},
        {QStringLiteral("한국어 — ko_KR.UTF-8"), QStringLiteral("ko_KR.UTF-8")},
        {QStringLiteral("中文 (简体) — zh_CN.UTF-8"), QStringLiteral("zh_CN.UTF-8")}
    };
    for (const auto& lp : locales) localeCb->addItem(lp.first, lp.second);
    connect(localeCb, QOverload<int>::of(&QComboBox::currentIndexChanged), this, syncTz);
    int amIdx = regionCb->findText(QStringLiteral("America"));
    if (amIdx >= 0) regionCb->setCurrentIndex(amIdx);
    int nyIdx = cityCb->findText(QStringLiteral("New_York"));
    if (nyIdx >= 0) cityCb->setCurrentIndex(nyIdx);
    syncTz();

    locForm->addRow(i18n("Region:"), regionCb);
    locForm->addRow(i18n("City / Zone:"), cityCb);
    locForm->addRow(i18n("Locale:"), localeCb);
    locForm->addRow(QString(), tzPreview);
    rightCardLay->addLayout(locForm);
    rightCardLay->addStretch(1);

    auto* wPrepDiskBtn = new QPushButton(QIcon::fromTheme(QStringLiteral("utilities-terminal")), i18n("Chroot"), centerFrame);
    auto* wArchChrootBtn = new QPushButton(QIcon::fromTheme(QStringLiteral("system-run")), i18n("Arch-Chroot"), centerFrame);
    auto* wQemuTestBtn = new QPushButton(QIcon::fromTheme(QStringLiteral("computer")), i18n("TESTBOOT"), centerFrame);
    auto* wFinalDdBtn = new QPushButton(QIcon::fromTheme(QStringLiteral("media-flash")), i18n("Final Write"), centerFrame);
    wQemuTestBtn->setEnabled(false);
    wFinalDdBtn->setEnabled(false);
    auto* wStage3Btn = new QPushButton(centerFrame); wStage3Btn->hide();
    auto* wBuildBaseBtn = new QPushButton(centerFrame); wBuildBaseBtn->hide();
    auto* wChrootTermBtn = new QPushButton(centerFrame); wChrootTermBtn->hide();

    auto* wBtnRow = new QHBoxLayout();
    wBtnRow->setSpacing(12);
    wBtnRow->addStretch(1);
    for (QPushButton* b : {wPrepDiskBtn, wArchChrootBtn, wQemuTestBtn, wFinalDdBtn}) {
        b->setMinimumHeight(38); b->setMaximumHeight(38);
        b->setStyleSheet(QStringLiteral("QPushButton { padding: 6px 18px; }"));
        wBtnRow->addWidget(b);
    }
    wBtnRow->addStretch(1);

    auto* midSplit = new QHBoxLayout();
    midSplit->setSpacing(16);
    midSplit->addWidget(leftCard, 1);
    midSplit->addWidget(rightCard, 1);

    wTitle->setAlignment(Qt::AlignCenter);
    wStepStatus->setAlignment(Qt::AlignCenter);
    wStepStatus->setWordWrap(true);
    cfLay->addWidget(wTitle);
    cfLay->addWidget(wStepStatus);
    cfLay->addLayout(midSplit);
    cfLay->addLayout(wBtnRow);

    auto* centerRow = new QHBoxLayout();
    centerRow->addStretch(1);
    centerRow->addWidget(centerFrame, 0);
    centerRow->addStretch(1);

    wLay->setContentsMargins(16, 12, 16, 4);
    wLay->addStretch(1);
    wLay->addLayout(centerRow);
    wLay->addStretch(1);
    wLay->addWidget(drawerBox, 0);
    drawerBox->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
    connect(wLogToggle, &QPushButton::toggled, this, [wLay, drawerBox, wLogToggle, wLiveLog](bool on) {
        wLogToggle->setText(on ? i18n("▾  Feedback  ▾") : i18n("▴  Feedback  ▴"));
        if (on) {
            drawerBox->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
            wLiveLog->setStyleSheet(QStringLiteral("QPlainTextEdit { background-color: #0b0d10; color: #abb2bf; border: 1px solid #2c313a; padding-top: 4px; }"));
            wLiveLog->setMinimumHeight(120); wLiveLog->setMaximumHeight(16777215);
            wLiveLog->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
            wLay->setStretch(0, 0); wLay->setStretch(2, 0);
            wLay->setStretchFactor(drawerBox, 1);
        } else {
                    wLiveLog->setFixedHeight(22);
            wLiveLog->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
            drawerBox->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
            wLay->setStretchFactor(drawerBox, 0);
            wLay->setStretch(0, 1); wLay->setStretch(2, 1);
        }
    });
    modeStack->addWidget(wizardCard);
    modeStack->addWidget(suiteTabs);
    rightLay->addWidget(modeStack, 1);
    shellLay->addWidget(rightCol, 1);

    connect(autoNbdBtn, &QPushButton::clicked, diskPage, &DiskImageWidget::runStreamlinedNoviceInstall);
    connect(stepList, &QListWidget::currentRowChanged, this, [suiteTabs, steps, hintLbl, autoNbdBtn, diskPage](int r) {
        if (r < 0 || r >= steps.size()) return;
        suiteTabs->setCurrentWidget(steps.at(r).page);
        hintLbl->setText(steps.at(r).hint);
        autoNbdBtn->setVisible(steps.at(r).page == diskPage);
    });
    connect(nextStepBtn, &QPushButton::clicked, this, [stepList]() {
        for (int r = stepList->currentRow() + 1; r < stepList->count(); ++r) {
            if (!stepList->item(r)->isHidden()) { stepList->setCurrentRow(r); break; }
        }
    });
    auto applyRole = [this, diskMgrM, qpPage, navCol, stepList, steps, guideBar, modeStack, wizardCard, suiteTabs, wizAct, novAct, expAct](int idx) {
        bool wizard = (idx == 0);
        bool expert = (idx == 2);
        QSettings st(QStringLiteral("WakStab"), QStringLiteral("gentool-ng"));
        st.setValue(QStringLiteral("roleMode"), idx);
        st.setValue(QStringLiteral("expertRole"), expert);
        st.setValue(QStringLiteral("wizardMode"), wizard);
        if (idx == 2 && !expAct) idx = 0;
        if (idx == 0) wizAct->setChecked(true);
        else if (idx == 1) novAct->setChecked(true);
        else if (expAct) expAct->setChecked(true);
        navCol->setVisible(!wizard);
        guideBar->setVisible(idx == 1);
        diskMgrM->menuAction()->setVisible(expert);
        qpPage->setVisible(expert);
        for (auto* tb : findChildren<QToolBar*>()) tb->setVisible(expert);
        modeStack->setCurrentWidget(wizard ? wizardCard : static_cast<QWidget*>(suiteTabs));
        if (auto* vAct = findChild<QAction*>(QStringLiteral("virtual_disks_only"))) vAct->setChecked(!expert);
        for (int i = 0; i < steps.size(); ++i) stepList->item(i)->setHidden(!expert && steps.at(i).expertOnly);
        QTimer::singleShot(10, this, &MainWindow::refreshDevices);
    };
    auto appendWizLog = [wLiveLog](const QString& line) {
        const QString t = line.trimmed();
        if (t.isEmpty()) return;
        const QString esc = t.toHtmlEscaped();
        if (t.contains(QStringLiteral("Complete:")) || t.contains(QStringLiteral("finished!")) ||
            t.contains(QStringLiteral("verified OK")) || t.contains(QStringLiteral("Successfully wrote")) ||
            t.contains(QStringLiteral("re-mounted cleanly"))) {
            wLiveLog->appendHtml(QStringLiteral("<span style='color:#98c379; font-weight:bold;'>%1</span>").arg(esc));
        } else if (t.startsWith(QStringLiteral("==="))) {
            wLiveLog->appendHtml(QStringLiteral("<span style='color:#61afef; font-weight:bold;'>%1</span>").arg(esc));
        } else if (t.startsWith(QStringLiteral("Error:")) || t.contains(QStringLiteral("Failed"), Qt::CaseInsensitive)) {
            wLiveLog->appendHtml(QStringLiteral("<span style='color:#e06c75; font-weight:bold;'>%1</span>").arg(esc));
        } else {
            wLiveLog->appendPlainText(t);
        }
    };
    connect(diskPage, &DiskImageWidget::commandOutput, this, appendWizLog);
    connect(stage3Page, &Stage3Widget::statusMessage, this, [wStepStatus, appendWizLog](const QString& msg) {
        if (!msg.trimmed().isEmpty()) { wStepStatus->setText(msg); appendWizLog(QStringLiteral("[Stage3] ") + msg); }
    });
    connect(stage3Page, &Stage3Widget::progressUpdated, this, [wStepProg, wTotalProg](int pct) {
        wStepProg->setValue(pct);
        wTotalProg->setValue(25 + (pct / 4));
    });
    auto* autoChainFlag = new bool(false);
    connect(wPrepDiskBtn, &QPushButton::clicked, this, [autoChainFlag, diskPage, stage3Page, wQemuTestBtn, wFinalDdBtn, wSnapNameIn, wBootProfCb, wPartTblCb, wFsTypeCb, wTargetIn, wHostIn, wPassIn, wTzIn, wInitCb, wProfCb, wBootCb, wStepStatus, wStepProg, wTotalProg, appendWizLog]() {
        bool ok = false;
        int gb = QInputDialog::getInt(nullptr, i18n("GTSnap Staging Disk Size"), i18n("Virtual staging size (GiB) before dd to target:"), 24, 8, 512, 1, &ok);
        if (!ok) return;
        *autoChainFlag = true;
        const GtSnapPackage snap = GtSnapManager::initWizardWorkspace(
            wSnapNameIn->text(), wInitCb->currentText(), wProfCb->currentText(),
            wBootCb->currentText(), wTzIn->text());
        wTargetIn->setText(snap.mountDir);
        wHostIn->setText(snap.hostname);
        wPassIn->setText(snap.ephemeralPass);
        wQemuTestBtn->setEnabled(false); wFinalDdBtn->setEnabled(false);
        wStepProg->setValue(15);
        appendWizLog(QStringLiteral("=== [Step 1/6] GTSnap %1 (ID: %2, Host: %3) -> %4 GiB staging image ===").arg(snap.name, snap.uuid, snap.hostname).arg(gb));
        wStepStatus->setText(i18n("<b>[1/4]</b> Preparing GTSnap <b>%1</b> (%2)...").arg(snap.name, snap.uuid));
        if (diskPage->prepareStagingRawMount(snap.mountDir, wPartTblCb->currentData().toString(), wFsTypeCb->currentText(), wBootProfCb->currentData().toString(), gb)) {
            wStepProg->setValue(100); wTotalProg->setValue(25);
            appendWizLog(QStringLiteral("[Step 1/6] Complete: Mounted at %1").arg(snap.mountDir));
            const bool sysd = (wInitCb->currentIndex() == 1);
            const bool desk = (wProfCb->currentIndex() == 1);
            const QString variant = desk ? (sysd ? QStringLiteral("desktop-systemd") : QStringLiteral("desktop-openrc"))
                                         : (sysd ? QStringLiteral("systemd") : QStringLiteral("openrc"));
            appendWizLog(QStringLiteral("=== [Step 2/6] Auto-chaining Stage3 (%1) fetch, SHA-512 verify & extract ===").arg(variant));
            wStepStatus->setText(i18n("<b>[2/4]</b> Downloading, verifying & extracting %1 Stage3...").arg(variant));
            stage3Page->startAutomatedStage3(variant, snap.mountDir);
        } else {
            *autoChainFlag = false;
        }
    });
    connect(wStage3Btn, &QPushButton::clicked, this, [stage3Page, wInitCb, wProfCb, wTargetIn, wStepStatus, wStepProg, appendWizLog]() {
        const bool sysd = (wInitCb->currentIndex() == 1);
        const bool desk = (wProfCb->currentIndex() == 1);
        const QString variant = desk ? (sysd ? QStringLiteral("desktop-systemd") : QStringLiteral("desktop-openrc"))
                                     : (sysd ? QStringLiteral("systemd") : QStringLiteral("openrc"));
        wStepProg->setValue(0);
        appendWizLog(QStringLiteral("=== [Step 2/6] Fetching, verifying SHA-512 & extracting %1 Stage3 ===").arg(variant));
        wStepStatus->setText(i18n("<b>Step 2:</b> Fetching, verifying SHA-512, and extracting %1 Stage3 into %2...").arg(variant, wTargetIn->text()));
        stage3Page->startAutomatedStage3(variant, wTargetIn->text().trimmed());
    });
    connect(stage3Page, &Stage3Widget::extractionCompleted, this, [autoChainFlag, wBuildBaseBtn, wChrootTermBtn, wStepStatus, wTargetIn, wStepProg, wTotalProg, appendWizLog](const QString& dir) {
        wStepProg->setValue(100); wTotalProg->setValue(50); wTargetIn->setText(dir);
        appendWizLog(QStringLiteral("[Step 2/6] Complete: Stage3 extracted into %1").arg(dir));
        if (*autoChainFlag) {
            *autoChainFlag = false;
            appendWizLog(QStringLiteral("=== [Step 3/6] Auto-chaining Kernel, Locale & Bootloader build ==="));
            wBuildBaseBtn->click();
            appendWizLog(QStringLiteral("=== [Step 4/6] Auto-chaining into Interactive Chroot Shell ==="));
            wChrootTermBtn->click();
        } else {
            wStepStatus->setText(i18n("<b>Step 2 Complete:</b> Stage3 extracted into %1. Proceed to <b>3. Build Kernel & Base System</b>.").arg(dir));
        }
    });
    connect(wBuildBaseBtn, &QPushButton::clicked, this, [diskPage, wTargetIn, wHostIn, wTzIn, wLocaleIn, wPassIn, wInitCb, wBootCb, wBootProfCb, wStepStatus, wStepProg, wTotalProg, appendWizLog]() {
        wStepProg->setValue(10);
        appendWizLog(QStringLiteral("=== [Step 3/6] Building Kernel, Firmware, Locale & Bootloader in %1 ===").arg(wTargetIn->text()));
        wStepStatus->setText(i18n("<b>Step 3:</b> Building Base System in %1...").arg(wTargetIn->text()));
        diskPage->runGuidedBaseSystemBuild(
            wTargetIn->text(), wHostIn->text(), wTzIn->text(), wLocaleIn->text(), wPassIn->text(),
            (wBootCb->currentIndex() == 2 ? QStringLiteral("systemd-boot") : (wBootCb->currentIndex() == 1 ? QStringLiteral("grub-bios") : QStringLiteral("grub"))),
            wBootProfCb->currentData().toString(),
            wInitCb->currentIndex() == 1
        );
        wStepProg->setValue(100); wTotalProg->setValue(75);
        appendWizLog(QStringLiteral("[Step 3/6] Complete: Base system & bootloader configured."));
        wStepStatus->setText(i18n("<b>Step 3 Complete:</b> Base system ready. Click <b>6. Confirm & Write to Target (dd)</b>."));
    });
    auto* useArchChrootFlag = new bool(false);
    connect(wArchChrootBtn, &QPushButton::clicked, this, [useArchChrootFlag, wPrepDiskBtn]() {
        *useArchChrootFlag = true;
        wPrepDiskBtn->click();
    });
    connect(termPage, &TerminalWidget::buildReadyToDeploy, this, [applyRole, wQemuTestBtn, wFinalDdBtn, wStepStatus, wTotalProg, appendWizLog]() {
        wQemuTestBtn->setEnabled(true);
        wFinalDdBtn->setEnabled(true);
        wTotalProg->setValue(85);
        appendWizLog(QStringLiteral("[Chroot Sign-Off] Complete: Build marked ready to deploy — Test Boot (QEMU) and Final Write unlocked."));
        wStepStatus->setText(i18n("<b>Build Verified & Ready:</b> <b>Test Boot (QEMU)</b> and <b>Final Write</b> are now unlocked."));
        applyRole(0);
    });
    connect(wQemuTestBtn, &QPushButton::clicked, this, [diskPage, wTargetIn, wStepStatus, wStepProg, wTotalProg, appendWizLog]() {
        wStepProg->setValue(25);
        appendWizLog(QStringLiteral("=== [Step 5/6] Unmounting staging image & booting inside QEMU (UEFI + KVM) to verify viability ==="));
        wStepStatus->setText(i18n("<b>Step 5:</b> Booting staging image in QEMU... Close QEMU window when boot is verified to proceed to Step 6."));
        diskPage->testBootStagingInQemu(wTargetIn->text());
        wStepProg->setValue(100); wTotalProg->setValue(90);
        appendWizLog(QStringLiteral("[Step 5/6] Complete: QEMU test session closed and staging image re-mounted."));
        wStepStatus->setText(i18n("<b>Step 5 Complete:</b> Image boot verified. Click <b>6. Confirm & Write to Target (dd)</b> to deploy."));
    });
    connect(wFinalDdBtn, &QPushButton::clicked, this, [diskPage, wTargetIn, wStepStatus, wStepProg, wTotalProg, appendWizLog]() {
        wStepProg->setValue(10);
        appendWizLog(QStringLiteral("=== [Step 6/6] Final confirmation & writing image to target drive ==="));
        diskPage->finalizeDdToTarget(wTargetIn->text());
        wStepProg->setValue(100); wTotalProg->setValue(100);
        appendWizLog(QStringLiteral("[Step 6/6] Wizard finished!"));
        wStepStatus->setText(i18n("<b>Wizard Complete (100%):</b> System image written to target device."));
    });
    connect(wChrootTermBtn, &QPushButton::clicked, this, [useArchChrootFlag, applyRole, stepList, steps, termPage, wTargetIn]() {
        const bool useArch = *useArchChrootFlag;
        *useArchChrootFlag = false;
        const QString dir = wTargetIn->text().trimmed();
        applyRole(1);
        for (int i = 0; i < steps.size(); ++i) if (steps.at(i).page == termPage) stepList->setCurrentRow(i);
        termPage->setWizardSignOffVisible(true);
        termPage->addTerminalTab(dir, useArch ? QStringLiteral("Arch-Chroot") : QStringLiteral("Chroot"));
        if (useArch) {
            termPage->sendCommand(QStringLiteral("if command -v arch-chroot >/dev/null 2>&1; then arch-chroot ") + dir + QStringLiteral(" /bin/bash -c 'env-update; source /etc/profile; exec /bin/bash -i'; else chroot ") + dir + QStringLiteral(" /bin/bash -c 'env-update; source /etc/profile; exec /bin/bash -i'; fi\n"));
        } else {
            termPage->sendCommand(QStringLiteral("chroot ") + dir + QStringLiteral(" /bin/bash -c 'env-update; source /etc/profile; exec /bin/bash -i'\n"));
        }
    });
    connect(wizAct, &QAction::triggered, this, [applyRole]() { applyRole(0); });
    connect(novAct, &QAction::triggered, this, [applyRole]() { applyRole(1); });
    if (expAct) connect(expAct, &QAction::triggered, this, [applyRole]() { applyRole(2); });
    applyRole(initMode);
    stepList->setCurrentRow(0);
    setCentralWidget(shell);
    QTimer::singleShot(450, this, [this]() {
        GtSnapManager::cleanupStaleMountsAndLoops();
        const QList<GtSnapPackage> stale = GtSnapManager::findActiveStagingPackages();
        if (!stale.isEmpty()) {
            QMessageBox box(QMessageBox::Question, i18n("Unfinished GTSnap Staging Detected"),
                i18n("Found %1 unfinished staging build(s) from a previous session.\n\nWould you like to save them as GTSnap packages or destroy them to reclaim disk space?").arg(stale.size()),
                QMessageBox::NoButton, this);
            auto* saveBtn = box.addButton(i18n("Save GTSnap"), QMessageBox::AcceptRole);
            saveBtn->setIcon(QIcon::fromTheme(QStringLiteral("document-save")));
            auto* destroyBtn = box.addButton(i18n("Destroy"), QMessageBox::DestructiveRole);
            destroyBtn->setIcon(QIcon::fromTheme(QStringLiteral("edit-delete")));
            box.setDefaultButton(saveBtn);
            box.exec();
            if (box.clickedButton() == destroyBtn) GtSnapManager::destroyStagingPackages(stale);
        }
    });

connect(m_deviceCombo, QOverload<int>::of(&QComboBox::currentIndexChanged), this, &MainWindow::onDeviceChanged);
connect(m_partitionTree, &QTreeWidget::itemSelectionChanged, this, &MainWindow::onTreeSelectionChanged);
connect(m_partitionTree, &QTreeWidget::customContextMenuRequested, this, &MainWindow::onTreeContextMenu);
connect(m_diskBar, &DiskBarWidget::partitionSelected, this, &MainWindow::onBarPartitionSelected);
}
void MainWindow::setupActions() {
auto* ac = new KActionCollection(this);
KStandardAction::quit(this, &QWidget::close, ac);
auto* refreshAct = ac->addAction(QStringLiteral("refresh_devices"), this, &MainWindow::refreshDevices);
refreshAct->setText(i18n("Refresh Devices"));
refreshAct->setIcon(QIcon::fromTheme(QStringLiteral("view-refresh")));
KActionCollection::setDefaultShortcut(refreshAct, QKeySequence::Refresh);
auto* devSubAct = ac->addAction(QStringLiteral("devices_submenu"));
devSubAct->setText(i18n("Devices"));
m_devicesMenu = new QMenu(this);
devSubAct->setMenu(m_devicesMenu);
m_undoAct = ac->addAction(QStringLiteral("undo_last"), this, &MainWindow::undoLastOperation);
m_undoAct->setText(i18n("Undo Last Operation"));
m_undoAct->setIcon(QIcon::fromTheme(QStringLiteral("edit-undo")));
KActionCollection::setDefaultShortcut(m_undoAct, QKeySequence::Undo);
m_clearAct = ac->addAction(QStringLiteral("clear_all"), this, &MainWindow::clearAllOperations);
m_clearAct->setText(i18n("Clear All Operations"));
m_clearAct->setIcon(QIcon::fromTheme(QStringLiteral("edit-clear")));
m_applyAct = ac->addAction(QStringLiteral("apply_all"), this, &MainWindow::applyAllOperations);
m_applyAct->setText(i18n("Apply All Operations"));
m_applyAct->setIcon(QIcon::fromTheme(QStringLiteral("dialog-ok-apply")));
m_viewInfoAct = ac->addAction(QStringLiteral("view_device_info"));
m_viewInfoAct->setText(i18n("Device Information"));
m_viewInfoAct->setCheckable(true);
connect(m_viewInfoAct, &QAction::toggled, m_deviceInfoPane, &QWidget::setVisible);
m_viewOpsAct = ac->addAction(QStringLiteral("view_pending_ops"));
m_viewOpsAct->setText(i18n("Pending Operations"));
m_viewOpsAct->setCheckable(true);
connect(m_viewOpsAct, &QAction::toggled, m_opsList, &QWidget::setVisible);
auto* fsSupportAct = ac->addAction(QStringLiteral("view_fs_support"));
fsSupportAct->setText(i18n("File System Support"));
connect(fsSupportAct, &QAction::triggered, this, [this]() { FeaturesDialog(m_core, this).exec(); });
m_disklabelAct = ac->addAction(QStringLiteral("create_disklabel"), this, &MainWindow::createPartitionTable);
m_disklabelAct->setText(i18n("Create Partition Table..."));
auto* rescueAct = ac->addAction(QStringLiteral("attempt_rescue"), this, &MainWindow::attemptDataRescue);
rescueAct->setText(i18n("Attempt Data Rescue..."));
rescueAct->setIcon(QIcon::fromTheme(QStringLiteral("system-search")));
m_resizeAct = ac->addAction(QStringLiteral("part_resize"));
m_resizeAct->setText(i18n("Resize/Move..."));
m_resizeAct->setIcon(QIcon::fromTheme(QStringLiteral("transform-scale")));
m_uuidAct = ac->addAction(QStringLiteral("part_uuid"));
m_uuidAct->setText(i18n("New UUID"));
m_newAct = ac->addAction(QStringLiteral("part_new"));
m_newAct->setText(i18n("New..."));
m_newAct->setIcon(QIcon::fromTheme(QStringLiteral("list-add")));
m_delAct = ac->addAction(QStringLiteral("part_delete"));
m_delAct->setText(i18n("Delete"));
m_delAct->setIcon(QIcon::fromTheme(QStringLiteral("edit-delete")));
KActionCollection::setDefaultShortcut(m_delAct, QKeySequence::Delete);
auto* fmtSubAct = ac->addAction(QStringLiteral("part_format"));
fmtSubAct->setText(i18n("Format to"));
fmtSubAct->setIcon(QIcon::fromTheme(QStringLiteral("edit-clear-all")));
m_formatMenu = new QMenu(this);
fmtSubAct->setMenu(m_formatMenu);
m_unmountAct = ac->addAction(QStringLiteral("part_unmount"));
m_unmountAct->setText(i18n("Unmount"));
m_unmountAct->setIcon(QIcon::fromTheme(QStringLiteral("media-eject")));
m_flagsAct = ac->addAction(QStringLiteral("part_flags"));
m_flagsAct->setText(i18n("Manage Flags...")); m_flagsAct->setIcon(QIcon::fromTheme(QStringLiteral("flag")));
m_checkAct = ac->addAction(QStringLiteral("part_check"));
m_checkAct->setText(i18n("Check")); m_checkAct->setIcon(QIcon::fromTheme(QStringLiteral("checkmark")));
m_labelAct = ac->addAction(QStringLiteral("part_label"));
m_labelAct->setText(i18n("Label File System...")); m_labelAct->setIcon(QIcon::fromTheme(QStringLiteral("tag")));
m_nameAct = ac->addAction(QStringLiteral("part_name"));
m_nameAct->setText(i18n("Name Partition..."));
m_partImgAct = ac->addAction(QStringLiteral("part_image"));
m_partImgAct->setText(i18n("Create Sparse Partition Image..."));
m_partImgAct->setIcon(QIcon::fromTheme(QStringLiteral("drive-harddisk")));
m_partRestoreAct = ac->addAction(QStringLiteral("part_restore"));
m_partRestoreAct->setText(i18n("Restore Image to Partition..."));
m_partRestoreAct->setIcon(QIcon::fromTheme(QStringLiteral("document-revert")));
m_partInfoAct = ac->addAction(QStringLiteral("part_info"));
m_partInfoAct->setText(i18n("Information"));
m_partInfoAct->setIcon(QIcon::fromTheme(QStringLiteral("dialog-information")));
auto* mainBar = addToolBar(i18n("Main Toolbar"));
mainBar->setWindowTitle(QStringLiteral("Gentool-NG"));
mainBar->addAction(m_newAct);
mainBar->addAction(m_delAct);
mainBar->addSeparator();
mainBar->addAction(m_resizeAct);
mainBar->addSeparator();
mainBar->addAction(m_undoAct);
mainBar->addAction(m_applyAct);
mainBar->addSeparator();
mainBar->addWidget(new QLabel(i18n(" Device: "), this));
m_deviceCombo = new QComboBox(this);
m_deviceCombo->setMinimumWidth(std::max(340, fontMetrics().horizontalAdvance(QLatin1Char('M')) * 28));
mainBar->addWidget(m_deviceCombo);
}
void MainWindow::refreshDevices() {
statusBar()->showMessage(i18n("Scanning all devices..."));
m_queue.clear();
updateQueueUI();
m_deviceCombo->blockSignals(true);
m_deviceCombo->clear();
m_devicesMenu->clear();
m_partitionTree->clear();
m_diskBar->setDeviceAndPartitions(nullptr, nullptr);
m_deviceInfoPane->setDevice(nullptr);
const int curRole = QSettings(QStringLiteral("WakStab"), QStringLiteral("gentool-ng")).value(QStringLiteral("roleMode"), 0).toInt();
if (curRole == 0) { if (statusBar()) statusBar()->clearMessage(); return; }
static bool s_refreshing = false;
if (s_refreshing) return;
struct Guard { bool& f; ~Guard(){ f = false; } } guard{s_refreshing};
s_refreshing = true;
QProcess::execute(QStringLiteral("sh"), {QStringLiteral("-c"), QStringLiteral("for n in /dev/nbd[0-9]*; do [ -b \"$n\" ] || continue; b=$(basename \"$n\"); if [ $(cat /sys/block/$b/size 2>/dev/null || echo 1) -eq 0 ]; then partx -d --nr 1:16 \"$n\" 2>/dev/null || true; for pt in \"${n}\"p*; do [ -b \"$pt\" ] && delpart \"$n\" \"${pt##*p}\" 2>/dev/null || true; done; fi; done")});
m_core.set_devices(m_devices);
auto* vAct = findChild<QAction*>(QStringLiteral("virtual_disks_only"));
if (!vAct || vAct->isChecked()) {
    m_devices.erase(std::remove_if(m_devices.begin(), m_devices.end(), [](const std::unique_ptr<GParted::Device>& d) {
        QString p = QString::fromStdString(d->get_path().raw());
        return !p.startsWith(QStringLiteral("/dev/nbd")) && !p.startsWith(QStringLiteral("/dev/loop"));
    }), m_devices.end());
}
for (size_t i = 0; i < m_devices.size(); ++i) {
const auto& dev = *m_devices[i];
QString path = QString::fromStdString(dev.get_path().raw());
QString model = QString::fromStdString(dev.model.raw()).trimmed();
QString sizeStr = QString::fromStdString(GParted::Utils::format_size(dev.length, dev.sector_size).raw());
QString label = QStringLiteral("%1 (%2) — %3").arg(path, model, sizeStr);
m_deviceCombo->addItem(QIcon::fromTheme(QStringLiteral("drive-harddisk")), label);
m_devicesMenu->addAction(QIcon::fromTheme(QStringLiteral("drive-harddisk")), label, this, [this, i]() {
m_deviceCombo->setCurrentIndex(static_cast<int>(i));
});
}
m_deviceCombo->blockSignals(false);
if (!m_devices.empty()) {
m_deviceCombo->setCurrentIndex(0);
onDeviceChanged(0);
statusBar()->showMessage(i18np("1 device detected", "%1 devices detected", static_cast<int>(m_devices.size())), 4000);
}
updateActionStates();
}
void MainWindow::onDeviceChanged(int index) {
if (index < 0 || index >= static_cast<int>(m_devices.size())) return;
m_deviceInfoPane->setDevice(m_devices[static_cast<size_t>(index)].get());
rebuildCurrentView();
}
void MainWindow::rebuildCurrentView() {
int idx = m_deviceCombo->currentIndex();
if (idx < 0 || idx >= static_cast<int>(m_devices.size())) return;
const auto& dev = *m_devices[static_cast<size_t>(idx)];
m_queue.applyVisualToDevice(dev, m_visualParts);
m_diskBar->setDeviceAndPartitions(&dev, &m_visualParts);
populatePartitionTree(m_visualParts);
updateActionStates();
}
void MainWindow::createPartitionTable() {
int idx = m_deviceCombo->currentIndex();
if (idx < 0 || idx >= static_cast<int>(m_devices.size())) return;
const auto& dev = *m_devices[static_cast<size_t>(idx)];
QStringList types;
for (const auto& t : GParted::GParted_Core::get_disklabeltypes())
types << QString::fromStdString(t.raw());
bool ok = false;
QString chosen = QInputDialog::getItem(this, i18n("Create Partition Table on %1", QString::fromStdString(dev.get_path().raw())),
i18n("WARNING: This will ERASE ALL DATA on the entire disk!\nSelect new partition table type:"), types, 0, false, &ok);
if (!ok || chosen.isEmpty()) return;
if (m_core.set_disklabel(dev, chosen.toUtf8().constData()))
refreshDevices();
else
KMessageBox::error(this, i18n("Failed to create partition table. Ensure all partitions are unmounted."), i18n("Error"));
}
void MainWindow::populatePartitionTree(const GParted::PartitionVector& parts) {
m_partitionTree->clear();
for (size_t i = 0; i < parts.size(); ++i) {
const auto& part = parts[i];
auto* item = new QTreeWidgetItem(m_partitionTree);
QString partPath = (part.fstype == GParted::FS_UNALLOCATED) ? i18n("unallocated") : QString::fromStdString(part.get_path().raw());
QColor fsColor(QString::fromStdString(GParted::Utils::get_color(part.fstype).raw()));
if (!fsColor.isValid()) fsColor = palette().color(QPalette::Button);
QStringList mounts, flags;
for (const auto& mp : part.get_mountpoints()) mounts << QString::fromStdString(mp.raw());
for (const auto& fl : part.get_flags()) flags << QString::fromStdString(fl.raw());
item->setText(0, partPath);
item->setText(1, QString::fromStdString(part.name.raw()));
item->setIcon(2, makeSwatchIcon(fsColor, part.busy));
item->setText(2, QString::fromStdString(part.get_filesystem_string().raw()));
item->setText(3, mounts.join(QStringLiteral(", ")));
item->setText(4, QString::fromStdString(part.get_filesystem_label().raw()));
item->setText(5, QString::fromStdString(GParted::Utils::format_size(part.get_sector_length(), part.sector_size).raw()));
item->setText(6, (part.sectors_used >= 0) ? QString::fromStdString(GParted::Utils::format_size(part.sectors_used, part.sector_size).raw()) : QStringLiteral("—"));
item->setText(7, (part.sectors_unused >= 0) ? QString::fromStdString(GParted::Utils::format_size(part.sectors_unused, part.sector_size).raw()) : QStringLiteral("—"));
item->setText(8, flags.join(QStringLiteral(", ")));
}
for (int c = 0; c < m_partitionTree->columnCount() - 1; ++c)
m_partitionTree->resizeColumnToContents(c);
}
void MainWindow::onTreeSelectionChanged() {
auto items = m_partitionTree->selectedItems();
m_diskBar->setSelectedIndex(items.isEmpty() ? -1 : m_partitionTree->indexOfTopLevelItem(items.first()));
updateActionStates();
}
void MainWindow::onBarPartitionSelected(int index) {
if (index >= 0 && index < m_partitionTree->topLevelItemCount())
m_partitionTree->setCurrentItem(m_partitionTree->topLevelItem(index));
}
void MainWindow::updateActionStates() {
for (QAction* a : {m_newAct, m_delAct, m_resizeAct, m_unmountAct, m_flagsAct, m_checkAct, m_labelAct, m_nameAct, m_uuidAct, m_partImgAct, m_partRestoreAct, m_partInfoAct}) {
QObject::disconnect(a, &QAction::triggered, nullptr, nullptr);
a->setEnabled(false);
}
m_formatMenu->clear();
m_formatMenu->setEnabled(false);
int devIdx = m_deviceCombo->currentIndex();
auto items = m_partitionTree->selectedItems();
if (devIdx < 0 || devIdx >= static_cast<int>(m_devices.size()) || items.isEmpty()) return;
int row = m_partitionTree->indexOfTopLevelItem(items.first());
if (row < 0 || row >= static_cast<int>(m_visualParts.size())) return;
const auto& dev = *m_devices[static_cast<size_t>(devIdx)];
const auto& part = m_visualParts[static_cast<size_t>(row)];
bool isUnalloc = (part.fstype == GParted::FS_UNALLOCATED);
bool isReal = (!isUnalloc && part.type != GParted::TYPE_EXTENDED);
if (!isUnalloc && part.type != GParted::TYPE_EXTENDED) {
m_partImgAct->setEnabled(true);
connect(m_partImgAct, &QAction::triggered, this, [this, part]() {
ImageDialog(QString::fromStdString(part.get_path().raw()), part.get_byte_length(), ImageDialog::Mode::Sparse, QString(), this).exec();
});
}
if (!isUnalloc && !part.busy && part.type != GParted::TYPE_EXTENDED) {
m_partRestoreAct->setEnabled(true);
connect(m_partRestoreAct, &QAction::triggered, this, [this, part]() {
RestoreDialog dlg(QString::fromStdString(part.get_path().raw()), part.get_byte_length(), false, this);
dlg.exec();
if (dlg.restored()) refreshDevices();
});
}
m_partInfoAct->setEnabled(true);
connect(m_partInfoAct, &QAction::triggered, this, [this, part]() {
QString info = i18n("Path: %1\nFile system: %2\nFirst sector: %3\nLast sector: %4\nTotal sectors: %5\nUUID: %6",
QString::fromStdString(part.get_path().raw()), QString::fromStdString(part.get_filesystem_string().raw()),
QString::number(part.sector_start), QString::number(part.sector_end),
QString::number(part.get_sector_length()), QString::fromStdString(part.uuid.raw()));
KMessageBox::information(this, info, i18n("Partition Information"));
});
if (isUnalloc) {
m_newAct->setEnabled(true);
connect(m_newAct, &QAction::triggered, this, [this, &dev, part]() {
NewPartitionDialog dlg(dev, part, this);
if (dlg.exec() == QDialog::Accepted) { m_queue.addCreate(dev, part, dlg.buildPartition()); updateQueueUI(); rebuildCurrentView(); }
});
return;
}
if (part.busy) {
m_unmountAct->setEnabled(true);
m_unmountAct->setText((part.fstype == GParted::FS_LINUX_SWAP) ? i18n("Swapoff") : i18n("Unmount"));
connect(m_unmountAct, &QAction::triggered, this, [this, part]() {
Glib::ustring out, err;
Glib::ustring cmd = ((part.fstype == GParted::FS_LINUX_SWAP) ? "swapoff -v " : "umount -v ") + Glib::shell_quote(part.get_path());
if (GParted::Utils::execute_command(cmd, out, err, true) == 0) refreshDevices();
else KMessageBox::error(this, QString::fromStdString(err.raw()), i18n("Operation Failed"));
});
return;
}
m_delAct->setEnabled(true);
connect(m_delAct, &QAction::triggered, this, [this, &dev, part]() { m_queue.addDelete(dev, part); updateQueueUI(); rebuildCurrentView(); });
GParted::Sector minStart = part.sector_start;
GParted::Sector maxEnd = part.sector_end;
if (row > 0 && m_visualParts[static_cast<size_t>(row - 1)].fstype == GParted::FS_UNALLOCATED)
minStart = m_visualParts[static_cast<size_t>(row - 1)].sector_start;
if (row + 1 < static_cast<int>(m_visualParts.size()) && m_visualParts[static_cast<size_t>(row + 1)].fstype == GParted::FS_UNALLOCATED)
maxEnd = m_visualParts[static_cast<size_t>(row + 1)].sector_end;
m_resizeAct->setEnabled(true);
connect(m_resizeAct, &QAction::triggered, this, [this, &dev, part, minStart, maxEnd]() {
ResizeMoveDialog dlg(dev, part, minStart, maxEnd, this);
if (dlg.exec() == QDialog::Accepted) {
m_queue.addResizeMove(dev, part, dlg.buildPartition());
updateQueueUI();
rebuildCurrentView();
}
});
m_flagsAct->setEnabled(true);
connect(m_flagsAct, &QAction::triggered, this, [this, part]() { FlagsDialog(m_core, part, this).exec(); refreshDevices(); });
if (dev.disktype == "gpt") {
m_nameAct->setEnabled(true);
connect(m_nameAct, &QAction::triggered, this, [this, &dev, part]() {
bool ok = false;
QString nm = QInputDialog::getText(this, i18n("Name Partition"), i18n("Name:"), QLineEdit::Normal, QString::fromStdString(part.name.raw()), &ok);
if (ok) { m_queue.addName(dev, part, nm); updateQueueUI(); rebuildCurrentView(); }
});
}
if (isReal) {
m_formatMenu->setEnabled(true);
for (const auto& [name, fs] : std::vector<std::pair<QString, GParted::FSType>>{
{"ext4", GParted::FS_EXT4}, {"btrfs", GParted::FS_BTRFS}, {"xfs", GParted::FS_XFS},
{"fat32", GParted::FS_FAT32}, {"exfat", GParted::FS_EXFAT}, {"ntfs", GParted::FS_NTFS}, {"linux-swap", GParted::FS_LINUX_SWAP}}) {
m_formatMenu->addAction(name, this, [this, &dev, part, fs]() { m_queue.addFormat(dev, part, fs); updateQueueUI(); rebuildCurrentView(); });
}
m_checkAct->setEnabled(true);
connect(m_checkAct, &QAction::triggered, this, [this, &dev, part]() { m_queue.addCheck(dev, part); updateQueueUI(); rebuildCurrentView(); });
m_uuidAct->setEnabled(true);
connect(m_uuidAct, &QAction::triggered, this, [this, &dev, part]() { m_queue.addNewUUID(dev, part); updateQueueUI(); rebuildCurrentView(); });
m_labelAct->setEnabled(true);
connect(m_labelAct, &QAction::triggered, this, [this, &dev, part]() {
bool ok = false;
QString lbl = QInputDialog::getText(this, i18n("Label File System"), i18n("New label:"), QLineEdit::Normal, QString::fromStdString(part.get_filesystem_label().raw()), &ok);
if (ok) { m_queue.addLabel(dev, part, lbl); updateQueueUI(); rebuildCurrentView(); }
});
}
}
void MainWindow::onTreeContextMenu(const QPoint& pos) {
if (!m_partitionTree->itemAt(pos)) return;
QMenu menu(this);
for (QAction* a : {m_newAct, m_delAct, m_resizeAct}) menu.addAction(a);
menu.addSeparator();
menu.addMenu(m_formatMenu);
menu.addAction(m_unmountAct);
menu.addSeparator();
for (QAction* a : {m_flagsAct, m_checkAct, m_labelAct, m_nameAct, m_uuidAct}) menu.addAction(a);
menu.addSeparator();
menu.addAction(m_partImgAct);
menu.addAction(m_partRestoreAct);
menu.addAction(m_partInfoAct);
menu.exec(m_partitionTree->viewport()->mapToGlobal(pos));
}
void MainWindow::undoLastOperation() { m_queue.undoLast(); updateQueueUI(); rebuildCurrentView(); }
void MainWindow::clearAllOperations() { m_queue.clear(); updateQueueUI(); rebuildCurrentView(); }
void MainWindow::applyAllOperations() {
if (m_queue.isEmpty()) return;
auto* wAct = findChild<QAction*>(QStringLiteral("wizard_mode"));
bool wiz = (wAct && wAct->isChecked());
if (!wiz) {
    if (KMessageBox::warningContinueCancel(this, i18n("Apply %1 pending operation(s)?", m_queue.count()), i18n("Apply Operations")) != KMessageBox::Continue) return;
    ApplyDialog(m_core, m_queue, this).exec();
    refreshDevices();
    return;
}
if (auto* host = findChild<QWidget*>(QStringLiteral("inlineApplyHost"))) {
    qDeleteAll(host->findChildren<ApplyDialog*>(QString(), Qt::FindDirectChildrenOnly));
    auto* inlineDlg = new ApplyDialog(m_core, m_queue, host, true);
    host->layout()->addWidget(inlineDlg);
    host->show();
    connect(inlineDlg, &ApplyDialog::operationsFinished, this, [this](bool) { refreshDevices(); });
}
}
void MainWindow::updateQueueUI() {
m_opsList->clear();
QStringList items = m_queue.descriptions();
for (int i = 0; i < items.size(); ++i) m_opsList->addItem(QStringLiteral("%1. %2").arg(i + 1).arg(items[i]));
bool hasOps = !m_queue.isEmpty();
m_opsList->setVisible(hasOps);
m_viewOpsAct->setChecked(hasOps);
m_undoAct->setEnabled(hasOps);
m_clearAct->setEnabled(hasOps);
m_applyAct->setEnabled(hasOps);
}
void MainWindow::attemptDataRescue() {
int idx = m_deviceCombo->currentIndex();
if (idx < 0 || idx >= static_cast<int>(m_devices.size())) return;
RescueDialog(*m_devices[static_cast<size_t>(idx)], this).exec();
}

void MainWindow::closeEvent(QCloseEvent* event) {
    const QList<GtSnapPackage> active = GtSnapManager::findActiveStagingPackages();
    if (!active.isEmpty()) {
        QMessageBox box(QMessageBox::Question, i18n("Save or Destroy Staging Build?"),
            i18n("You have %1 active GTSnap staging build(s).\n\nWould you like to save them before exiting or destroy them?").arg(active.size()),
            QMessageBox::NoButton, this);
        auto* saveBtn = box.addButton(i18n("Save & Exit"), QMessageBox::AcceptRole);
        saveBtn->setIcon(QIcon::fromTheme(QStringLiteral("document-save")));
        auto* destroyBtn = box.addButton(i18n("Destroy & Exit"), QMessageBox::DestructiveRole);
        destroyBtn->setIcon(QIcon::fromTheme(QStringLiteral("edit-delete")));
        auto* cancelBtn = box.addButton(QMessageBox::Cancel);
        box.setDefaultButton(saveBtn);
        box.exec();
        if (box.clickedButton() == cancelBtn) { event->ignore(); return; }
        if (box.clickedButton() == destroyBtn) {
            GtSnapManager::destroyStagingPackages(active);
            QMainWindow::closeEvent(event);
            return;
        }
    }
    GtSnapManager::cleanupStaleMountsAndLoops();
    QMainWindow::closeEvent(event);
}
