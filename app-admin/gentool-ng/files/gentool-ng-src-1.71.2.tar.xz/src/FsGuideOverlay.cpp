#include "FsGuideOverlay.h"
#include <QFileInfo>
#include <QHBoxLayout>
#include <QVBoxLayout>

FsGuideOverlay::FsGuideOverlay(QWidget* parent) : QFrame(parent) {
    setObjectName(QStringLiteral("FsGuideOverlay"));
    setFrameShape(QFrame::StyledPanel);
    setMinimumSize(380, 300);
    resize(490, 450);
    setMouseTracking(true);

    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(10, 8, 10, 8);
    root->setSpacing(6);

    auto* hdr = new QHBoxLayout();
    m_titleLbl = new QLabel(QStringLiteral("<b>Wizard Step 1: Partition Layout</b> <i>(Drag header / bottom-right corner)</i>"), this);
    auto* bClose = new QPushButton(QStringLiteral("✕"), this);
    bClose->setFixedSize(24, 24);
    hdr->addWidget(m_titleLbl, 1); hdr->addWidget(bClose);
    root->addLayout(hdr);

    m_diskBanner = new QLabel(QStringLiteral("Select a Target Use profile below to stage partitions."), this);
    m_diskBanner->setWordWrap(true);
    m_diskBanner->setStyleSheet(QStringLiteral("padding: 5px; border-radius: 4px; font-weight: bold;"));
    root->addWidget(m_diskBanner);

    auto* ctrlRow = new QHBoxLayout();
    m_useCombo = new QComboBox(this);
    m_useCombo->addItems({
        QStringLiteral("Desktop Workstation (KDE Plasma / Wayland)"),
        QStringLiteral("Gaming Rig (Steam / Proton / Vulkan)"),
        QStringLiteral("Handheld Console (Steam Deck / Ally / Legion Go)"),
        QStringLiteral("Production Web / Application Server"),
        QStringLiteral("Headless Home Lab / NAS / Container Host"),
        QStringLiteral("Portage Build Host / Binhost (-march=znver5)"),
        QStringLiteral("Minimal Rescue / Recovery & Chroot Image")
    });
    m_opacitySlider = new QSlider(Qt::Horizontal, this);
    m_opacitySlider->setRange(25, 100); m_opacitySlider->setValue(92); m_opacitySlider->setFixedWidth(80);
    m_opacityVal = new QLabel(QStringLiteral("92%"), this);
    ctrlRow->addWidget(m_useCombo, 1); ctrlRow->addWidget(m_opacitySlider); ctrlRow->addWidget(m_opacityVal);
    root->addLayout(ctrlRow);

    m_body = new QTextBrowser(this);
    root->addWidget(m_body, 1);

    auto* footRow = new QHBoxLayout();
    m_bSecondary = new QPushButton(QStringLiteral("Close"), this);
    m_bPrimary = new QPushButton(QIcon::fromTheme(QStringLiteral("dialog-ok-apply")), QStringLiteral("Apply Layout to Disk"), this);
    m_bPrimary->setMinimumHeight(28);
    auto* gripLbl = new QLabel(QStringLiteral("◢"), this);
    gripLbl->setToolTip(QStringLiteral("Drag corner to resize"));
    footRow->addWidget(m_bSecondary); footRow->addWidget(m_bPrimary, 1); footRow->addWidget(gripLbl);
    root->addLayout(footRow);

    connect(bClose, &QPushButton::clicked, this, &QWidget::hide);
    connect(m_useCombo, QOverload<int>::of(&QComboBox::currentIndexChanged), this, &FsGuideOverlay::updateProfile);
    connect(m_opacitySlider, &QSlider::valueChanged, this, &FsGuideOverlay::applyOpacity);
    setStageUi(StageLayout); applyOpacity(92);
}

void FsGuideOverlay::setStageUi(Stage st) {
    m_stage = st;
    m_bPrimary->disconnect(); m_bSecondary->disconnect();
    m_bSecondary->show();
    connect(m_bSecondary, &QPushButton::clicked, this, &QWidget::hide);
    m_useCombo->setVisible(st == StageLayout);

    if (st == StageLayout) {
        m_titleLbl->setText(QStringLiteral("<b>Wizard Step 1/3: Partition Layout</b> <i>(Drag header / ◢)</i>"));
        m_bSecondary->setText(QStringLiteral("Close"));
        m_bPrimary->setText(QStringLiteral("Apply Layout to Disk"));
        connect(m_bPrimary, &QPushButton::clicked, this, [this]() {
            m_lastProfile = m_useCombo->currentIndex();
            Q_EMIT applyLayoutRequested(m_lastProfile);
        });
        updateProfile(m_useCombo->currentIndex());
    } else if (st == StageConfirmApply) {
        m_titleLbl->setText(QStringLiteral("<b>Wizard Step 2/3: Confirm Disk Write</b> <i>(Drag header / ◢)</i>"));
        m_bSecondary->hide();
        m_bPrimary->setText(QStringLiteral("Yes, Write && Format Partitions Now"));
        connect(m_bPrimary, &QPushButton::clicked, this, [this]() { Q_EMIT confirmApplyRequested(m_lastProfile); });
    } else if (st == StageMount) {
        m_titleLbl->setText(QStringLiteral("<b>Wizard Step 3/3: Mount && Enter Chroot</b> <i>(Drag header / ◢)</i>"));
        m_bSecondary->setText(QStringLiteral("Close"));
        m_bPrimary->setText(QStringLiteral("Mount && Enter Chroot Terminal"));
        QString rootPart = (m_lastProfile == 6) ? QStringLiteral("p2") : QStringLiteral("p3");
        QString opts = (m_lastProfile <= 2 || m_lastProfile == 4) ? QStringLiteral("compress=zstd:3,noatime") : QStringLiteral("noatime");
        connect(m_bPrimary, &QPushButton::clicked, this, [this, rootPart, opts]() {
            hide();
            Q_EMIT mountAndEnterChrootRequested(rootPart, opts, true);
        });
    }
}

void FsGuideOverlay::showForDisk(const QString& diskPath) {
    setStageUi(StageLayout);
    if (!diskPath.isEmpty()) m_diskBanner->setText(QStringLiteral("Target: %1 — Choose a profile and click Apply Layout to Disk.").arg(diskPath));
    if (parentWidget()) move(qMax(16, parentWidget()->width() - width() - 24), 56);
    show(); raise();
}
void FsGuideOverlay::showConfirmApply(int opCount, int profileIndex) {
    m_lastProfile = profileIndex; setStageUi(StageConfirmApply);
    m_diskBanner->setText(QStringLiteral("%1 partition operations staged! Ready to write and format?").arg(opCount));
    m_body->setHtml(QStringLiteral("<h4>Ready to Commit Partition Table</h4><p>All partitions for <b>%1</b> are queued below. Clicking <b>Yes, Write &amp; Format Partitions Now</b> formats the disk and advances to Step 3 (Mount &amp; Chroot).</p>").arg(m_useCombo->itemText(profileIndex)));
    if (parentWidget()) move(qMax(16, parentWidget()->width() - width() - 24), 56);
    show(); raise();
}
void FsGuideOverlay::showMountStage(const QString& imagePath, int profileIndex) {
    m_lastProfile = profileIndex; setStageUi(StageMount);
    QString rootPart = (profileIndex == 6) ? QStringLiteral("p2") : QStringLiteral("p3");
    m_diskBanner->setText(QStringLiteral("Formatted %1! Ready to mount %2 and launch chroot shell.").arg(QFileInfo(imagePath).fileName(), rootPart));
    m_body->setHtml(QStringLiteral("<h4>One-Click Chroot Preparation (%1)</h4><ul><li>Mounts partition <code>%2</code> at <code>/mnt/wakstab-chroot</code> and binds <code>/proc</code>, <code>/sys</code>, <code>/dev</code>, and <code>/run</code>.</li><li>Automatically opens a new <b>Chroot</b> terminal tab, runs <code>env-update &amp;&amp; source /etc/profile</code>, and sets a distinct <code>(gentool-chroot)</code> prompt that reverts cleanly when you exit.</li></ul>").arg(m_useCombo->itemText(profileIndex), rootPart));
    if (parentWidget()) move(qMax(16, parentWidget()->width() - width() - 24), 48);
    show(); raise();
}

void FsGuideOverlay::applyOpacity(int pct) {
    m_opacityVal->setText(QStringLiteral("%1%").arg(pct));
    int a = (pct * 255) / 100;
    setStyleSheet(QStringLiteral("QFrame#FsGuideOverlay { background-color: rgba(28, 31, 38, %1); color: #f0f2f5; border: 1px solid rgba(110, 168, 254, 210); border-radius: 8px; } QTextBrowser { background-color: rgba(18, 20, 25, %1); color: #e6e9ef; border: 1px solid #3c4252; border-radius: 4px; padding: 6px; }").arg(a));
}
void FsGuideOverlay::updateProfile(int index) {
    static const char* kStacks[] = {
        "<h4>Desktop Workstation (KDE Plasma / Wayland)</h4><b>Auto-Layout:</b> 1 GiB EFI + 16 GiB Swap + Remaining Btrfs (<code>@</code>, <code>@home</code>, <code>@var-log</code>, <code>compress=zstd:3,noatime</code>).",
        "<h4>Gaming Rig (Steam / Proton / Vulkan)</h4><b>Auto-Layout:</b> 1 GiB EFI + 16 GiB Swap + 48 GiB Btrfs Root + Remaining XFS Games (<code>noatime</code>).",
        "<h4>Handheld Console (Steam Deck / Ally / Legion Go)</h4><b>Auto-Layout:</b> 512 MiB EFI + 8 GiB Swap + Remaining Btrfs Root (<code>@</code>, <code>@home</code>, <code>@extensions</code>).",
        "<h4>Production Web / Application Server</h4><b>Auto-Layout:</b> 512 MiB EFI + 4 GiB Swap + 20 GiB ext4 Root + Remaining XFS <code>/var</code>.",
        "<h4>Headless Home Lab / NAS / Container Host</h4><b>Auto-Layout:</b> 512 MiB EFI + 4 GiB Swap + 24 GiB ext4 OS + Remaining Btrfs Data.",
        "<h4>Portage Build Host / Binhost (-march=znver5)</h4><b>Auto-Layout:</b> 512 MiB EFI + 32 GiB Swap + 32 GiB Btrfs Root + Remaining XFS <code>/var/cache</code>.",
        "<h4>Minimal Rescue / Recovery &amp; Chroot Image</h4><b>Auto-Layout:</b> 512 MiB EFI + Remaining ext4 Root (zero swap overhead)."
    };
    if (index >= 0 && index < 7) m_body->setHtml(QString::fromUtf8(kStacks[index]));
}
void FsGuideOverlay::mousePressEvent(QMouseEvent* ev) {
    if (ev->button() != Qt::LeftButton) return;
    if (ev->pos().x() >= width() - 24 && ev->pos().y() >= height() - 24) {
        m_resizing = true; m_dragOffset = ev->globalPosition().toPoint(); m_startSize = size(); setCursor(Qt::SizeFDiagCursor);
    } else {
        m_dragging = true; m_dragOffset = ev->globalPosition().toPoint() - frameGeometry().topLeft(); setCursor(Qt::ClosedHandCursor);
    }
    ev->accept();
}
void FsGuideOverlay::mouseMoveEvent(QMouseEvent* ev) {
    if (m_resizing && parentWidget()) {
        QPoint delta = ev->globalPosition().toPoint() - m_dragOffset;
        resize(qBound(minimumWidth(), m_startSize.width() + delta.x(), parentWidget()->width() - x()),
               qBound(minimumHeight(), m_startSize.height() + delta.y(), parentWidget()->height() - y()));
        ev->accept();
    } else if (m_dragging && parentWidget()) {
        QPoint next = ev->globalPosition().toPoint() - m_dragOffset;
        move(qBound(0, next.x(), qMax(0, parentWidget()->width() - width())), qBound(0, next.y(), qMax(0, parentWidget()->height() - height())));
        ev->accept();
    } else if (ev->pos().x() >= width() - 24 && ev->pos().y() >= height() - 24) setCursor(Qt::SizeFDiagCursor);
    else setCursor(Qt::OpenHandCursor);
}
void FsGuideOverlay::mouseReleaseEvent(QMouseEvent* ev) {
    if (ev->button() == Qt::LeftButton) { m_dragging = false; m_resizing = false; setCursor(Qt::OpenHandCursor); ev->accept(); }
}
