#pragma once
#include <QCheckBox>
#include <QComboBox>
#include <QLineEdit>
#include <QListWidget>
#include <QPlainTextEdit>
#include <QSpinBox>
#include <QWidget>

class QemuVmWidget : public QWidget {
    Q_OBJECT
public:
    explicit QemuVmWidget(QWidget* parent = nullptr);
public Q_SLOTS:
    void refreshVms();
private:
    QString selectedVmJson() const;
    bool isVmRunning(const QString& vmName, qint64* outPid = nullptr) const;
    void createVm();
    void startVm();
    void stopVm(bool force);
    void cloneVm();
    void destroyVm();
    void logMsg(const QString& msg);

    QString m_vmDir = "/var/lib/libvirt/images/vms";
    QLineEdit *m_nameIn = nullptr, *m_diskIn = nullptr, *m_isoIn = nullptr;
    QSpinBox *m_cpuSpin = nullptr, *m_ramSpin = nullptr;
    QComboBox *m_fwCb = nullptr, *m_gfxCb = nullptr;
    QCheckBox* m_netChk = nullptr;
    QListWidget* m_vmList = nullptr;
    QPlainTextEdit* m_log = nullptr;
};
