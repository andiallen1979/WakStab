#include "TerminalWidget.h"
#include <QApplication>
#include <QClipboard>
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileDialog>
#include <QHBoxLayout>
#include <QIcon>
#include <QInputDialog>
#include <QKeySequence>
#include <QMenu>
#include <QMessageBox>
#include <QShortcut>
#include <QTabBar>
#include <QToolButton>
#include <QVBoxLayout>

#define signals Q_SIGNALS
#define slots Q_SLOTS
#include <qtermwidget.h>
#undef signals
#undef slots

namespace {
void selectWholeBuffer(QTermWidget* term) {
    term->setSelectionStart(0, 0);
    term->setSelectionEnd(term->historyLinesCount() + term->screenLinesCount(), term->screenColumnsCount());
}
} // namespace

TerminalWidget::TerminalWidget(QWidget* parent) : QWidget(parent) {
    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(6, 6, 6, 6);
    root->setSpacing(0);

    m_tabs = new QTabWidget(this);
    m_tabs->setTabPosition(QTabWidget::South);
    m_tabs->setTabsClosable(true);
    m_tabs->setMovable(true);
    m_tabs->setDocumentMode(true);
    m_tabs->tabBar()->setIconSize(QSize(20, 20));

    auto* cornerBox = new QWidget(m_tabs);
    auto* cornerLay = new QHBoxLayout(cornerBox);
    cornerLay->setContentsMargins(2, 4, 6, 0);
    cornerLay->setSpacing(4);
    cornerLay->setAlignment(Qt::AlignVCenter);

    auto makeCornerBtn = [cornerBox](const QString& theme, const QString& fb, const QString& tip) {
        auto* btn = new QToolButton(cornerBox);
        btn->setAutoRaise(true);
        btn->setToolTip(tip);
        btn->setIconSize(QSize(22, 22));
        btn->setFixedSize(28, 28);
        QIcon ic = QIcon::fromTheme(theme);
        if (!ic.isNull()) btn->setIcon(ic);
        else btn->setText(fb);
        return btn;
    };

    auto* bClear = makeCornerBtn(QStringLiteral("edit-clear"), QStringLiteral("⌫"), QStringLiteral("Clear Active Terminal"));
    auto* tabAddBtn = makeCornerBtn(QStringLiteral("list-add"), QStringLiteral("+"), QStringLiteral("New Terminal Tab (Ctrl+Shift+T)"));

    cornerLay->addWidget(bClear, 0, Qt::AlignVCenter);
    cornerLay->addWidget(tabAddBtn, 0, Qt::AlignVCenter);
    m_tabs->setCornerWidget(cornerBox, Qt::BottomLeftCorner);

    root->addWidget(m_tabs, 1);

    auto* newTabShortcut = new QShortcut(QKeySequence(QStringLiteral("Ctrl+Shift+T")), this);
    connect(newTabShortcut, &QShortcut::activated, this, [this]() {
        addTerminalTab();
    });
    connect(tabAddBtn, &QToolButton::clicked, this, [this]() {
        addTerminalTab();
    });
    connect(bClear, &QToolButton::clicked, this, [this]() {
        if (auto* term = qobject_cast<QTermWidget*>(m_tabs->currentWidget())) {
            term->clear();
            term->setFocus();
        }
    });
    connect(m_tabs, &QTabWidget::tabCloseRequested, this, [this](int index) {
        if (m_tabs->count() <= 1) return;
        QWidget* w = m_tabs->widget(index);
        m_tabs->removeTab(index);
        delete w;
    });

    addTerminalTab(QDir::homePath(), QStringLiteral("Shell 1"));
}

void TerminalWidget::addTerminalTab(const QString& workDir, const QString& title) {
    auto* term = new QTermWidget(0, this);
    term->setColorScheme(QStringLiteral("Linux"));
    term->setScrollBarPosition(QTermWidget::ScrollBarRight);
    term->setTerminalFont(QFont(QStringLiteral("Monospace"), 10));
    term->setHistorySize(m_historyLines);
    term->setContextMenuPolicy(Qt::CustomContextMenu);

    QString dir = (!workDir.isEmpty() && QDir(workDir).exists()) ? workDir : QDir::homePath();
    term->setWorkingDirectory(dir);
    term->startShellProgram();

    QString tabTitle = title.isEmpty() ? QStringLiteral("Shell %1").arg(m_tabs->count() + 1) : title;
    int idx = m_tabs->addTab(term, QIcon::fromTheme(QStringLiteral("utilities-terminal")), tabTitle);
    m_tabs->setCurrentIndex(idx);
    term->setFocus();

    connect(term, &QWidget::customContextMenuRequested, this, &TerminalWidget::showTerminalContextMenu);
    connect(term, SIGNAL(finished()), this, SLOT(onTerminalFinished()));
}

void TerminalWidget::showTerminalContextMenu(const QPoint& pos) {
    auto* term = qobject_cast<QTermWidget*>(sender());
    if (!term) return;

    QMenu menu(this);
    QAction* actCopy = menu.addAction(QIcon::fromTheme(QStringLiteral("edit-copy")), QStringLiteral("Copy"), QKeySequence(QStringLiteral("Ctrl+Shift+C")), [term]() {
        term->copyClipboard();
    });
    actCopy->setEnabled(!term->selectedText().isEmpty());

    QAction* actPaste = menu.addAction(QIcon::fromTheme(QStringLiteral("edit-paste")), QStringLiteral("Paste"), QKeySequence(QStringLiteral("Ctrl+Shift+V")), [term]() {
        term->pasteClipboard();
    });
    actPaste->setEnabled(!QApplication::clipboard()->text().isEmpty());

    menu.addAction(QIcon::fromTheme(QStringLiteral("edit-delete")), QStringLiteral("Delete"), [term]() {
        term->sendText(QStringLiteral("\x1b[3~"));
    });

    menu.addSeparator();

    menu.addAction(QIcon::fromTheme(QStringLiteral("edit-select-all")), QStringLiteral("Select All"), [term]() {
        selectWholeBuffer(term);
    });

    menu.addAction(QIcon::fromTheme(QStringLiteral("edit-clear")), QStringLiteral("Clear Scrollback"), [term]() {
        term->clear();
    });

    menu.addAction(QIcon::fromTheme(QStringLiteral("configure")), QStringLiteral("Adjust Scrollback..."), [this, term]() {
        bool ok = false;
        int lines = QInputDialog::getInt(
            this,
            QStringLiteral("Terminal Scrollback History"),
            QStringLiteral("Scrollback buffer lines (-1 for unlimited):"),
            m_historyLines,
            -1,
            1000000,
            500,
            &ok
        );
        if (ok) {
            m_historyLines = lines;
            for (int i = 0; i < m_tabs->count(); ++i) {
                if (auto* t = qobject_cast<QTermWidget*>(m_tabs->widget(i))) {
                    t->setHistorySize(m_historyLines);
                }
            }
            term->setFocus();
        }
    });

    menu.addSeparator();

    menu.addAction(QIcon::fromTheme(QStringLiteral("document-save-as")), QStringLiteral("Log Output to File..."), [this, term]() {
        QString defaultName = QStringLiteral("%1/gentool-terminal-%2.log")
            .arg(QDir::homePath(), QDateTime::currentDateTime().toString(QStringLiteral("yyyyMMdd-HHmmss")));
        QString filePath = QFileDialog::getSaveFileName(
            this,
            QStringLiteral("Save Terminal Output Log"),
            defaultName,
            QStringLiteral("Log Files (*.log *.txt);;All Files (*)")
        );
        if (filePath.isEmpty()) return;

        QString prevClip = QApplication::clipboard()->text();
        selectWholeBuffer(term);
        term->copyClipboard();
        QString captured = QApplication::clipboard()->text();
        QApplication::clipboard()->setText(prevClip);

        QFile outFile(filePath);
        if (!outFile.open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text)) {
            QMessageBox::warning(this, QStringLiteral("Log Failed"), QStringLiteral("Could not open %1 for writing.").arg(filePath));
            return;
        }
        outFile.write(captured.toUtf8());
        outFile.close();
        term->setFocus();
    });

    menu.exec(term->mapToGlobal(pos));
}

void TerminalWidget::onTerminalFinished() {
    auto* term = qobject_cast<QWidget*>(sender());
    if (!term) return;
    int i = m_tabs->indexOf(term);
    if (i >= 0 && m_tabs->count() > 1) {
        m_tabs->removeTab(i);
        term->deleteLater();
    }
}

void TerminalWidget::sendCommand(const QString& cmd) {
    if (auto* term = qobject_cast<QTermWidget*>(m_tabs->currentWidget())) {
        term->sendText(cmd);
        term->setFocus();
    }
}
