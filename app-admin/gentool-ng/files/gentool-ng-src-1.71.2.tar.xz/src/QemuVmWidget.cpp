#include <QTimer>
#include "QemuVmWidget.h"
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QJsonDocument>
#include <QJsonObject>
#include <QLabel>
#include <QMessageBox>
#include <QProcess>
#include <QPushButton>
#include <QSplitter>
#include <QVBoxLayout>
#include <signal.h>

namespace {
QPushButton* vmIconBtn(const QString& icon, const QString& fb, const QString& tip, QWidget* p) {
    auto* b = new QPushButton(p); b->setToolTip(tip); b->setIconSize(QSize(18, 18)); b->setFixedSize(28, 28);
    QIcon ic = QIcon::fromTheme(icon); if (!ic.isNull()) b->setIcon(ic); else b->setText(fb);
    return b;
}
} // namespace

QemuVmWidget::QemuVmWidget(QWidget* parent) : QWidget(parent) {
    QDir().mkpath(m_vmDir); QDir().mkpath("/run/gentool-ng-vms");
    auto* root = new QVBoxLayout(this); root->setContentsMargins(6, 6, 6, 6);
    auto* sp = new QSplitter(Qt::Horizontal, this); root->addWidget(sp, 1);

    auto* lw = new QWidget(sp); auto* ll = new QVBoxLayout(lw); ll->setContentsMargins(0, 0, 0, 0);
    auto* lbar = new QHBoxLayout(); lbar->addWidget(new QLabel("Configured QEMU VMs", lw), 1);
    auto* bRef = vmIconBtn("view-refresh", "↻", "Refresh VM Status", lw); lbar->addWidget(bRef); ll->addLayout(lbar);
    m_vmList = new QListWidget(lw); ll->addWidget(m_vmList, 1);

    auto* rw = new QWidget(sp); auto* rl = new QVBoxLayout(rw); rl->setContentsMargins(0, 0, 0, 0);
    sp->setSizes({340, 820});

    auto* gbNew = new QGroupBox("Create QEMU / KVM Virtual Machine", rw); auto* vNew = new QVBoxLayout(gbNew);
    auto* r1 = new QHBoxLayout();
    m_nameIn = new QLineEdit("fragtoo-vm", gbNew);
    m_cpuSpin = new QSpinBox(gbNew); m_cpuSpin->setRange(1, 64); m_cpuSpin->setValue(4); m_cpuSpin->setSuffix(" vCPU");
    m_ramSpin = new QSpinBox(gbNew); m_ramSpin->setRange(512, 131072); m_ramSpin->setSingleStep(512); m_ramSpin->setValue(4096); m_ramSpin->setSuffix(" MiB");
    m_fwCb = new QComboBox(gbNew); m_fwCb->addItems({"UEFI (OVMF)", "Legacy BIOS"});
    m_gfxCb = new QComboBox(gbNew); m_gfxCb->addItems({"GTK Display", "SPICE", "VNC :1", "Headless"});
    m_netChk = new QCheckBox("User NAT Net", gbNew); m_netChk->setChecked(true);
    r1->addWidget(new QLabel("Name:")); r1->addWidget(m_nameIn, 1); r1->addWidget(m_cpuSpin); r1->addWidget(m_ramSpin);
    r1->addWidget(m_fwCb); r1->addWidget(m_gfxCb); r1->addWidget(m_netChk); vNew->addLayout(r1);

    auto* r2 = new QHBoxLayout();
    m_diskIn = new QLineEdit(gbNew); m_diskIn->setPlaceholderText("/var/lib/libvirt/images/disk.qcow2");
    auto* bDisk = vmIconBtn("folder-open", "📂", "Browse Disk Image", gbNew);
    m_isoIn = new QLineEdit(gbNew); m_isoIn->setPlaceholderText("Optional Boot ISO...");
    auto* bIso = vmIconBtn("media-optical", "💿", "Browse Boot ISO", gbNew);
    auto* bCreate = vmIconBtn("document-new", "+", "Create VM Profile", gbNew);
    r2->addWidget(new QLabel("Disk:")); r2->addWidget(m_diskIn, 1); r2->addWidget(bDisk);
    r2->addWidget(new QLabel("ISO:")); r2->addWidget(m_isoIn, 1); r2->addWidget(bIso); r2->addWidget(bCreate);
    vNew->addLayout(r2); rl->addWidget(gbNew);

    auto* gbCtl = new QGroupBox("VM Lifecycle Controls", rw); auto* lCtl = new QHBoxLayout(gbCtl);
    auto* bStart = vmIconBtn("media-playback-start", "▶", "Start Selected VM", gbCtl);
    auto* bStop = vmIconBtn("media-playback-stop", "⏹", "Graceful ACPI Shutdown", gbCtl);
    auto* bKill = vmIconBtn("process-stop", "⚡", "Force Power Off (SIGKILL)", gbCtl);
    auto* bClone = vmIconBtn("edit-copy", "📋", "Clone VM & Backing Disk", gbCtl);
    auto* bDel = vmIconBtn("edit-delete", "🗑", "Destroy / Delete VM", gbCtl);
    lCtl->addWidget(bStart); lCtl->addWidget(bStop); lCtl->addWidget(bKill); lCtl->addWidget(bClone); lCtl->addWidget(bDel);
    lCtl->addStretch(1); rl->addWidget(gbCtl);

    m_log = new QPlainTextEdit(rw); m_log->setReadOnly(true); m_log->setPlaceholderText("QEMU / KVM hypervisor output...");
    rl->addWidget(m_log, 1);

    connect(bRef, &QPushButton::clicked, this, &QemuVmWidget::refreshVms);
    connect(bDisk, &QPushButton::clicked, this, [this]() {
        QString f = QFileDialog::getOpenFileName(this, "Select Disk Image", "/var/lib/libvirt/images", "Disk Images (*.qcow2 *.raw *.img *.vhdx *.vhd *.vmdk *.vdi)");
        if (!f.isEmpty()) m_diskIn->setText(f);
    });
    connect(bIso, &QPushButton::clicked, this, [this]() {
        QString f = QFileDialog::getOpenFileName(this, "Select Boot ISO", "/var/lib/libvirt/images", "ISO Images (*.iso)");
        if (!f.isEmpty()) m_isoIn->setText(f);
    });
    connect(bCreate, &QPushButton::clicked, this, &QemuVmWidget::createVm);
    connect(bStart, &QPushButton::clicked, this, &QemuVmWidget::startVm);
    connect(bStop, &QPushButton::clicked, this, [this]() { stopVm(false); });
    connect(bKill, &QPushButton::clicked, this, [this]() { stopVm(true); });
    connect(bClone, &QPushButton::clicked, this, &QemuVmWidget::cloneVm);
    connect(bDel, &QPushButton::clicked, this, &QemuVmWidget::destroyVm);
    refreshVms();
}

void QemuVmWidget::logMsg(const QString& m) { m_log->appendPlainText(m); }
QString QemuVmWidget::selectedVmJson() const {
    auto* it = m_vmList->currentItem();
    return it ? it->data(Qt::UserRole).toString() : QString();
}
bool QemuVmWidget::isVmRunning(const QString& vmName, qint64* outPid) const {
    QFile pf("/run/gentool-ng-vms/" + vmName + ".pid");
    if (!pf.open(QIODevice::ReadOnly)) return false;
    qint64 pid = QString::fromUtf8(pf.readAll()).trimmed().toLongLong();
    if (pid > 0 && ::kill(pid, 0) == 0) { if (outPid) *outPid = pid; return true; }
    return false;
}
void QemuVmWidget::refreshVms() {
    m_vmList->clear();
    for (const QFileInfo& fi : QDir(m_vmDir).entryInfoList({"*.json"}, QDir::Files, QDir::Name)) {
        QString nm = fi.completeBaseName();
        auto* it = new QListWidgetItem(QString("%1  [%2]").arg(nm, isVmRunning(nm) ? "RUNNING" : "STOPPED"), m_vmList);
        it->setData(Qt::UserRole, fi.absoluteFilePath());
    }
}

void QemuVmWidget::createVm() {
    QString base = QFileInfo(m_nameIn->text().trimmed()).fileName();
    if (base.isEmpty()) return;
    QString nm = QString("%1-%2").arg(base).arg(QDateTime::currentSecsSinceEpoch());
    QJsonObject obj{{"name", nm}, {"vcpus", m_cpuSpin->value()}, {"ram_mib", m_ramSpin->value()},
                    {"disk", m_diskIn->text().trimmed()}, {"iso", m_isoIn->text().trimmed()},
                    {"firmware", m_fwCb->currentText()}, {"graphics", m_gfxCb->currentText()},
                    {"net", m_netChk->isChecked()}};
    QFile f(m_vmDir + "/" + nm + ".json");
    if (f.open(QIODevice::WriteOnly)) { f.write(QJsonDocument(obj).toJson()); f.close(); }
    logMsg("Created VM profile: " + nm); refreshVms();
}
void QemuVmWidget::startVm() {
    QString jp = selectedVmJson(); if (jp.isEmpty()) return;
    QFile f(jp); if (!f.open(QIODevice::ReadOnly)) return;
    QJsonObject o = QJsonDocument::fromJson(f.readAll()).object();
    QString nm = o["name"].toString();
    if (isVmRunning(nm)) { logMsg(nm + " is already running."); return; }
    QStringList args{"-name", nm, "-enable-kvm", "-machine", "q35", "-cpu", "host",
                     "-smp", QString::number(o["vcpus"].toInt(4)), "-m", QString::number(o["ram_mib"].toInt(4096)),
                     "-pidfile", "/run/gentool-ng-vms/" + nm + ".pid",
                     "-qmp", "unix:/run/gentool-ng-vms/" + nm + ".qmp,server,nowait", "-daemonize"};
    if (o["firmware"].toString().startsWith("UEFI") && QFile::exists("/usr/share/edk2-ovmf/OVMF_CODE.fd"))
        args << "-bios" << "/usr/share/edk2-ovmf/OVMF_CODE.fd";
    QString disk = o["disk"].toString();
    if (!disk.isEmpty()) args << "-drive" << QString("file=%1,if=virtio").arg(disk);
    QString iso = o["iso"].toString();
    if (!iso.isEmpty()) args << "-cdrom" << iso << "-boot" << "d";
    if (o["net"].toBool(true)) args << "-netdev" << "user,id=n0" << "-device" << "virtio-net-pci,netdev=n0";
    QString gfx = o["graphics"].toString();
    if (gfx == "Headless") args << "-nographic";
    else if (gfx == "VNC :1") args << "-vnc" << ":1";
    else if (gfx == "SPICE") args << "-spice" << "port=5930,disable-ticketing=on";
    else args << "-display" << "gtk";
    logMsg("$ qemu-system-x86_64 " + args.join(' '));
    QProcess::startDetached("qemu-system-x86_64", args);
    QTimer::singleShot(600, this, &QemuVmWidget::refreshVms);
}
void QemuVmWidget::stopVm(bool force) {
    QString jp = selectedVmJson(); if (jp.isEmpty()) return;
    QString nm = QFileInfo(jp).completeBaseName(); qint64 pid = 0;
    if (!isVmRunning(nm, &pid)) { logMsg(nm + " is not running."); return; }
    if (force) { ::kill(pid, SIGKILL); QFile::remove("/run/gentool-ng-vms/" + nm + ".pid"); logMsg("Force killed " + nm); }
    else {
        QProcess::execute("sh", {"-c", QString("printf '{\"execute\":\"qmp_capabilities\"}\\n{\"execute\":\"system_powerdown\"}\\n' | socat - UNIX-CONNECT:/run/gentool-ng-vms/%1.qmp 2>/dev/null || kill -TERM %2").arg(nm).arg(pid)});
        logMsg("Sent ACPI shutdown to " + nm);
    }
    QTimer::singleShot(1000, this, &QemuVmWidget::refreshVms);
}
void QemuVmWidget::cloneVm() {
    QString jp = selectedVmJson(); if (jp.isEmpty()) return;
    QFile f(jp); if (!f.open(QIODevice::ReadOnly)) return;
    QJsonObject o = QJsonDocument::fromJson(f.readAll()).object();
    QString newNm = QString("%1-clone-%2").arg(o["name"].toString()).arg(QDateTime::currentSecsSinceEpoch());
    QString oldDisk = o["disk"].toString();
    if (!oldDisk.isEmpty() && QFile::exists(oldDisk)) {
        QFileInfo di(oldDisk);
        QString newDisk = QString("%1/%2-%3.%4").arg(di.absolutePath(), di.completeBaseName()).arg(QDateTime::currentSecsSinceEpoch()).arg(di.suffix());
        QProcess::execute("cp", {"--reflink=auto", oldDisk, newDisk});
        o["disk"] = newDisk;
    }
    o["name"] = newNm;
    QFile out(m_vmDir + "/" + newNm + ".json");
    if (out.open(QIODevice::WriteOnly)) { out.write(QJsonDocument(o).toJson()); out.close(); }
    logMsg("Cloned VM to: " + newNm); refreshVms();
}
void QemuVmWidget::destroyVm() {
    QString jp = selectedVmJson(); if (jp.isEmpty()) return;
    QFile f(jp); if (!f.open(QIODevice::ReadOnly)) return;
    QJsonObject o = QJsonDocument::fromJson(f.readAll()).object();
    QString nm = o["name"].toString(), disk = o["disk"].toString();
    if (QMessageBox::question(this, "Destroy VM", "Destroy VM profile '" + nm + "'?") != QMessageBox::Yes) return;
    if (isVmRunning(nm)) stopVm(true);
    if (!disk.isEmpty() && QFile::exists(disk) && QMessageBox::question(this, "Delete Disk Image", "Also delete associated disk image?\n" + disk) == QMessageBox::Yes)
        QFile::remove(disk);
    QFile::remove(jp); logMsg("Destroyed VM: " + nm); refreshVms();
}
