#pragma once
#include <QComboBox>
#include <QFrame>
#include <QLabel>
#include <QMouseEvent>
#include <QPoint>
#include <QPushButton>
#include <QSize>
#include <QSlider>
#include <QTextBrowser>

class FsGuideOverlay : public QFrame {
    Q_OBJECT
public:
    enum Stage { StageLayout = 0, StageConfirmApply = 1, StageMount = 2 };
    explicit FsGuideOverlay(QWidget* parent = nullptr);
    void showForDisk(const QString& diskPath);
    void showConfirmApply(int opCount, int profileIndex);
    void showMountStage(const QString& imagePath, int profileIndex);
Q_SIGNALS:
    void applyLayoutRequested(int profileIndex);
    void confirmApplyRequested(int profileIndex);
    void mountAndEnterChrootRequested(const QString& rootPart, const QString& mountOpts, bool bindChroot);
protected:
    void mousePressEvent(QMouseEvent* ev) override;
    void mouseMoveEvent(QMouseEvent* ev) override;
    void mouseReleaseEvent(QMouseEvent* ev) override;
private:
    void updateProfile(int index);
    void applyOpacity(int pct);
    void setStageUi(Stage st);

    Stage m_stage = StageLayout;
    int m_lastProfile = 0;
    QLabel *m_titleLbl = nullptr, *m_diskBanner = nullptr, *m_opacityVal = nullptr;
    QComboBox* m_useCombo = nullptr;
    QSlider* m_opacitySlider = nullptr;
    QTextBrowser* m_body = nullptr;
    QPushButton *m_bPrimary = nullptr, *m_bSecondary = nullptr;
    bool m_dragging = false, m_resizing = false;
    QPoint m_dragOffset;
    QSize m_startSize;
};
