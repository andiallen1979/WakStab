#pragma once
#include <QWidget>
#include <QListWidget>
#include <QTreeWidget>
#include <QPushButton>
#include <QLabel>

class EselectWidget : public QWidget {
    Q_OBJECT
public:
    explicit EselectWidget(QWidget *parent = nullptr);
private Q_SLOTS:
    void loadModules();
    void onModuleSelected(QListWidgetItem *item);
    void applySelection();
private:
    QListWidget *m_modList;
    QTreeWidget *m_optTree;
    QPushButton *m_refreshBtn, *m_setBtn;
    QLabel *m_statusLbl;
    QString m_currentModule;
};
