#include "SystemSnapshotWidget.h"
#include <QCryptographicHash>
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QJsonDocument>
#include <QJsonObject>
#include <QMessageBox>
#include <QProcess>
#include <QSplitter>
#include <QTemporaryDir>
#include <QVBoxLayout>
#include <sys/utsname.h>

SystemSnapshotWidget::SystemSnapshotWidget(QWidget* parent) : QWidget(parent) {
    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(6, 6, 6, 6);
    root->setSpacing(6);

    auto* topSplit = new QSplitter(Qt::Horizontal, this);
    root->addWidget(topSplit, 1);

    auto* leftPane = new QWidget(topSplit);
    auto* leftLay = new QVBoxLayout(leftPane);
    leftLay->setContentsMargins(0, 0, 0, 0);

    auto* gbCreate = new QGroupBox(QStringLiteral("1. Capture Portable System Snapshot (.gtsnap)"), leftPane);
    auto* cLay = new QVBoxLayout(gbCreate);

    auto* dirRow = new QHBoxLayout();
    m_outDirIn = new QLineEdit(QStringLiteral("/var/backups/gentool-snapshots"), gbCreate);
    auto* bOutDir = new QPushButton(QIcon::fromTheme(QStringLiteral("folder-open")), QString(), gbCreate);
    bOutDir->setToolTip(QStringLiteral("Choose Snapshot Output Directory"));
    dirRow->addWidget(new QLabel(QStringLiteral("Output Dir:"), gbCreate));
    dirRow->addWidget(m_outDirIn, 1);
    dirRow->addWidget(bOutDir);
    cLay->addLayout(dirRow);

    struct utsname u{};
    uname(&u);
    auto* nameRow = new QHBoxLayout();
    m_snapNameIn = new QLineEdit(QStringLiteral("%1-%2").arg(QString::fromLocal8Bit(u.nodename), QDateTime::currentDateTime().toString(QStringLiteral("yyyyMMdd-HHmm"))), gbCreate);
    auto* bSnap = new QPushButton(QIcon::fromTheme(QStringLiteral("document-save-as")), QStringLiteral("Create .gtsnap"), gbCreate);
    nameRow->addWidget(new QLabel(QStringLiteral("Snapshot Name:"), gbCreate));
    nameRow->addWidget(m_snapNameIn, 1);
    nameRow->addWidget(bSnap);
    cLay->addLayout(nameRow);

    m_chkPortage = new QCheckBox(QStringLiteral("Portage Configuration (/etc/portage: make.conf, package.*, env, patches, sets)"), gbCreate);
    m_chkPortage->setChecked(true);
    m_chkWorld = new QCheckBox(QStringLiteral("World & Set Files (/var/lib/portage/world, world_sets)"), gbCreate);
    m_chkWorld->setChecked(true);
    m_chkOverlay = new QCheckBox(QStringLiteral("Local Overlays (/var/db/repos/WakStab)"), gbCreate);
    m_chkOverlay->setChecked(true);
    m_chkKernel = new QCheckBox(QStringLiteral("Kernel Config (/usr/src/linux/.config & /etc/kernel/config.d)"), gbCreate);
    m_chkKernel->setChecked(true);
    m_chkServices = new QCheckBox(QStringLiteral("Locale, Timezone & Service Runlevels (/etc/locale.gen, timezone, conf.d, runlevels)"), gbCreate);
    m_chkServices->setChecked(true);

    cLay->addWidget(m_chkPortage);
    cLay->addWidget(m_chkWorld);
    cLay->addWidget(m_chkOverlay);
    cLay->addWidget(m_chkKernel);
    cLay->addWidget(m_chkServices);
    leftLay->addWidget(gbCreate);

    auto* gbRestore = new QGroupBox(QStringLiteral("2. Verify & Restore Snapshot (Same or Target Machine)"), leftPane);
    auto* rLay = new QVBoxLayout(gbRestore);

    auto* loadRow = new QHBoxLayout();
    m_loadPathIn = new QLineEdit(gbRestore);
    m_loadPathIn->setPlaceholderText(QStringLiteral("Select a .gtsnap file to verify and inspect..."));
    auto* bBrowseSnap = new QPushButton(QIcon::fromTheme(QStringLiteral("document-open")), QStringLiteral("Open .gtsnap..."), gbRestore);
    loadRow->addWidget(m_loadPathIn, 1);
    loadRow->addWidget(bBrowseSnap);
    rLay->addLayout(loadRow);

    m_verifyLbl = new QLabel(QStringLiteral("Integrity Status: No snapshot loaded."), gbRestore);
    m_verifyLbl->setStyleSheet(QStringLiteral("font-weight: bold; padding: 4px;"));
    rLay->addWidget(m_verifyLbl);

    m_rstPortage = new QCheckBox(QStringLiteral("Restore /etc/portage"), gbRestore);
    m_rstPortage->setChecked(true);
    m_rstWorld = new QCheckBox(QStringLiteral("Restore /var/lib/portage/world & world_sets"), gbRestore);
    m_rstWorld->setChecked(true);
    m_rstOverlay = new QCheckBox(QStringLiteral("Restore /var/db/repos/WakStab overlay"), gbRestore);
    m_rstOverlay->setChecked(true);
    m_rstKernel = new QCheckBox(QStringLiteral("Restore Kernel Config (/etc/kernel/config.d & /usr/src/linux/.config)"), gbRestore);
    m_rstKernel->setChecked(true);
    m_rstServices = new QCheckBox(QStringLiteral("Restore Locale, Timezone & Service State"), gbRestore);
    m_rstServices->setChecked(false);

    rLay->addWidget(m_rstPortage);
    rLay->addWidget(m_rstWorld);
    rLay->addWidget(m_rstOverlay);
    rLay->addWidget(m_rstKernel);
    rLay->addWidget(m_rstServices);

    auto* actRow = new QHBoxLayout();
    m_btnRestore = new QPushButton(QIcon::fromTheme(QStringLiteral("document-revert")), QStringLiteral("Apply Snapshot to System"), gbRestore);
    m_btnRestore->setEnabled(false);
    m_btnRebuild = new QPushButton(QIcon::fromTheme(QStringLiteral("utilities-terminal")), QStringLiteral("Run emerge -e @world in Terminal"), gbRestore);
    actRow->addWidget(m_btnRestore);
    actRow->addWidget(m_btnRebuild);
    rLay->addLayout(actRow);
    leftLay->addWidget(gbRestore);
    leftLay->addStretch(1);

    auto* rightSplit = new QSplitter(Qt::Vertical, topSplit);
    m_manifestView = new QPlainTextEdit(rightSplit);
    m_manifestView->setReadOnly(true);
    m_manifestView->setPlaceholderText(QStringLiteral("Snapshot manifest, hardware profile, and verified file inventory will appear here..."));

    m_logView = new QPlainTextEdit(rightSplit);
    m_logView->setReadOnly(true);
    m_logView->setPlaceholderText(QStringLiteral("Snapshot & restore execution log..."));

    topSplit->setSizes({480, 680});
    rightSplit->setSizes({380, 260});

    connect(bOutDir, &QPushButton::clicked, this, [this]() {
        QString d = QFileDialog::getExistingDirectory(this, QStringLiteral("Select Snapshot Output Directory"), m_outDirIn->text());
        if (!d.isEmpty()) m_outDirIn->setText(d);
    });
    connect(bSnap, &QPushButton::clicked, this, &SystemSnapshotWidget::createSnapshot);
    connect(bBrowseSnap, &QPushButton::clicked, this, &SystemSnapshotWidget::loadSnapshotFile);
    connect(m_btnRestore, &QPushButton::clicked, this, &SystemSnapshotWidget::restoreSnapshot);
    connect(m_btnRebuild, &QPushButton::clicked, this, [this]() {
        Q_EMIT runInTerminalRequested(QStringLiteral("emerge -e @world\n"));
    });
}

void SystemSnapshotWidget::logLine(const QString& msg) {
    m_logView->appendPlainText(QStringLiteral("[%1] %2").arg(QDateTime::currentDateTime().toString(QStringLiteral("HH:mm:ss")), msg));
}

void SystemSnapshotWidget::createSnapshot() {
    QString outDir = m_outDirIn->text().trimmed();
    QString baseName = QFileInfo(m_snapNameIn->text().trimmed()).fileName();
    if (outDir.isEmpty() || baseName.isEmpty()) return;
    if (!baseName.endsWith(QStringLiteral(".gtsnap"))) baseName += QStringLiteral(".gtsnap");

    QTemporaryDir tmp;
    if (!tmp.isValid()) {
        QMessageBox::critical(this, QStringLiteral("Snapshot Error"), QStringLiteral("Failed to create temporary staging directory."));
        return;
    }

    QString stage = tmp.path() + QStringLiteral("/rootfs");
    QDir().mkpath(stage);

    auto copyTree = [&](const QString& src, const QString& relDst) {
        if (!QFileInfo::exists(src)) return;
        QString dst = stage + relDst;
        QDir().mkpath(QFileInfo(dst).absolutePath());
        QProcess::execute(QStringLiteral("cp"), {QStringLiteral("-a"), src, dst});
    };

    QStringList included;
    if (m_chkPortage->isChecked()) {
        copyTree(QStringLiteral("/etc/portage"), QStringLiteral("/etc/portage"));
        included << QStringLiteral("portage-config");
    }
    if (m_chkWorld->isChecked()) {
        copyTree(QStringLiteral("/var/lib/portage/world"), QStringLiteral("/var/lib/portage/world"));
        copyTree(QStringLiteral("/var/lib/portage/world_sets"), QStringLiteral("/var/lib/portage/world_sets"));
        included << QStringLiteral("world-sets");
    }
    if (m_chkOverlay->isChecked()) {
        copyTree(QStringLiteral("/var/db/repos/WakStab"), QStringLiteral("/var/db/repos/WakStab"));
        included << QStringLiteral("wakstab-overlay");
    }
    if (m_chkKernel->isChecked()) {
        copyTree(QStringLiteral("/etc/kernel/config.d"), QStringLiteral("/etc/kernel/config.d"));
        if (QFile::exists(QStringLiteral("/usr/src/linux/.config")))
            copyTree(QStringLiteral("/usr/src/linux/.config"), QStringLiteral("/usr/src/linux/.config"));
        else if (QFile::exists(QStringLiteral("/proc/config.gz"))) {
            QDir().mkpath(stage + QStringLiteral("/usr/src/linux"));
            QProcess::execute(QStringLiteral("sh"), {QStringLiteral("-c"), QStringLiteral("zcat /proc/config.gz > '%1/usr/src/linux/.config'").arg(stage)});
        }
        included << QStringLiteral("kernel-config");
    }
    if (m_chkServices->isChecked()) {
        copyTree(QStringLiteral("/etc/locale.gen"), QStringLiteral("/etc/locale.gen"));
        copyTree(QStringLiteral("/etc/timezone"), QStringLiteral("/etc/timezone"));
        copyTree(QStringLiteral("/etc/conf.d"), QStringLiteral("/etc/conf.d"));
        copyTree(QStringLiteral("/etc/runlevels"), QStringLiteral("/etc/runlevels"));
        copyTree(QStringLiteral("/etc/systemd/system"), QStringLiteral("/etc/systemd/system"));
        included << QStringLiteral("system-services");
    }

    QProcess profProc;
    profProc.start(QStringLiteral("eselect"), {QStringLiteral("profile"), QStringLiteral("show")});
    profProc.waitForFinished(3000);
    QString activeProfile = QString::fromUtf8(profProc.readAllStandardOutput()).trimmed();

    struct utsname u{};
    uname(&u);
    QJsonObject manifest{
        {QStringLiteral("format"), QStringLiteral("gentool-ng-snapshot-v1")},
        {QStringLiteral("created_utc"), QDateTime::currentDateTimeUtc().toString(Qt::ISODate)},
        {QStringLiteral("source_host"), QString::fromLocal8Bit(u.nodename)},
        {QStringLiteral("kernel_release"), QString::fromLocal8Bit(u.release)},
        {QStringLiteral("arch"), QString::fromLocal8Bit(u.machine)},
        {QStringLiteral("eselect_profile"), activeProfile},
        {QStringLiteral("components"), included.join(QStringLiteral(", "))}
    };

    QString archivePath = tmp.path() + QStringLiteral("/payload.tar.zst");
    logLine(QStringLiteral("Compressing staged system state with zstd -19..."));
    int tarRc = QProcess::execute(QStringLiteral("sh"), {
        QStringLiteral("-c"),
        QStringLiteral("tar -C '%1' -cf - . | zstd -19 -T0 -o '%2'").arg(stage, archivePath)
    });
    if (tarRc != 0 || !QFile::exists(archivePath)) {
        QMessageBox::critical(this, QStringLiteral("Snapshot Failed"), QStringLiteral("tar/zstd compression failed."));
        return;
    }

    QFile zf(archivePath);
    if (!zf.open(QIODevice::ReadOnly)) return;
    QByteArray compressedBytes = zf.readAll();
    zf.close();

    QByteArray shaHex = QCryptographicHash::hash(compressedBytes, QCryptographicHash::Sha256).toHex();
    manifest[QStringLiteral("payload_sha256")] = QString::fromLatin1(shaHex);
    manifest[QStringLiteral("compressed_bytes")] = compressedBytes.size();

    QByteArray manifestJson = QJsonDocument(manifest).toJson(QJsonDocument::Compact);
    QByteArray b64Payload = compressedBytes.toBase64(QByteArray::Base64Encoding);

    QString wrapped;
    wrapped += QStringLiteral("-----BEGIN GENTOOL-NG SYSTEM SNAPSHOT-----\n");
    wrapped += QStringLiteral("Manifest: ") + QString::fromUtf8(manifestJson) + QStringLiteral("\n");
    wrapped += QStringLiteral("SHA256: ") + QString::fromLatin1(shaHex) + QStringLiteral("\n\n");
    for (int i = 0; i < b64Payload.size(); i += 76) {
        wrapped += QString::fromLatin1(b64Payload.mid(i, 76)) + QLatin1Char('\n');
    }
    wrapped += QStringLiteral("-----END GENTOOL-NG SYSTEM SNAPSHOT-----\n");

    QDir().mkpath(outDir);
    QString finalPath = outDir + QLatin1Char('/') + baseName;
    QFile outF(finalPath);
    if (!outF.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
        QMessageBox::critical(this, QStringLiteral("Write Error"), QStringLiteral("Cannot write to %1").arg(finalPath));
        return;
    }
    outF.write(wrapped.toUtf8());
    outF.close();

    logLine(QStringLiteral("Saved tamper-evident snapshot: %1 (%2 KiB, SHA256=%3)")
                .arg(finalPath)
                .arg(QFileInfo(finalPath).size() / 1024)
                .arg(QString::fromLatin1(shaHex.left(16)) + QStringLiteral("...")));
    m_loadPathIn->setText(finalPath);
    m_manifestView->setPlainText(QString::fromUtf8(QJsonDocument(manifest).toJson(QJsonDocument::Indented)));
}

bool SystemSnapshotWidget::verifyAndDecodeSnapshot(const QString& snapPath, QByteArray& outTarZst, QString& outManifest, bool& outHashOk) {
    QFile f(snapPath);
    if (!f.open(QIODevice::ReadOnly)) return false;
    QString text = QString::fromUtf8(f.readAll());
    f.close();

    if (!text.contains(QStringLiteral("-----BEGIN GENTOOL-NG SYSTEM SNAPSHOT-----")) ||
        !text.contains(QStringLiteral("-----END GENTOOL-NG SYSTEM SNAPSHOT-----"))) {
        return false;
    }

    QString expectedSha;
    QString manifestLine;
    QByteArray b64Joined;
    bool inBody = false;

    for (const QString& rawLine : text.split(QLatin1Char('\n'))) {
        QString line = rawLine.trimmed();
        if (line == QStringLiteral("-----BEGIN GENTOOL-NG SYSTEM SNAPSHOT-----")) { inBody = true; continue; }
        if (line == QStringLiteral("-----END GENTOOL-NG SYSTEM SNAPSHOT-----")) break;
        if (!inBody) continue;
        if (line.startsWith(QStringLiteral("Manifest: "))) {
            manifestLine = line.mid(10).trimmed();
        } else if (line.startsWith(QStringLiteral("SHA256: "))) {
            expectedSha = line.mid(8).trimmed().toLower();
        } else if (!line.isEmpty()) {
            b64Joined.append(line.toLatin1());
        }
    }

    outTarZst = QByteArray::fromBase64(b64Joined);
    QByteArray actualSha = QCryptographicHash::hash(outTarZst, QCryptographicHash::Sha256).toHex().toLower();
    outHashOk = (!expectedSha.isEmpty() && actualSha == expectedSha.toLatin1());

    QJsonDocument doc = QJsonDocument::fromJson(manifestLine.toUtf8());
    outManifest = doc.isObject()
        ? QString::fromUtf8(doc.toJson(QJsonDocument::Indented))
        : manifestLine;
    return !outTarZst.isEmpty();
}

void SystemSnapshotWidget::loadSnapshotFile() {
    QString path = QFileDialog::getOpenFileName(this, QStringLiteral("Open Gentool-NG System Snapshot"), m_outDirIn->text(), QStringLiteral("Gentool Snapshots (*.gtsnap);;All Files (*)"));
    if (path.isEmpty()) return;

    QByteArray tarZst;
    QString manifestPretty;
    bool hashOk = false;
    if (!verifyAndDecodeSnapshot(path, tarZst, manifestPretty, hashOk)) {
        QMessageBox::critical(this, QStringLiteral("Invalid Snapshot"), QStringLiteral("File is not a valid .gtsnap archive."));
        return;
    }

    m_loadedSnapPath = path;
    m_loadedHashValid = hashOk;
    m_loadPathIn->setText(path);

    if (hashOk) {
        m_verifyLbl->setText(QStringLiteral("Integrity Status: VERIFIED — SHA-256 intact (unmodified)"));
        m_verifyLbl->setStyleSheet(QStringLiteral("font-weight: bold; color: #50fa7b; padding: 4px;"));
        m_btnRestore->setEnabled(true);
    } else {
        m_verifyLbl->setText(QStringLiteral("Integrity Status: FAILED — File was edited or corrupted! Restore locked."));
        m_verifyLbl->setStyleSheet(QStringLiteral("font-weight: bold; color: #ff5555; padding: 4px;"));
        m_btnRestore->setEnabled(false);
    }

    QTemporaryDir tmp;
    QString fileList;
    if (tmp.isValid()) {
        QString zpath = tmp.path() + QStringLiteral("/check.tar.zst");
        QFile zf(zpath);
        if (zf.open(QIODevice::WriteOnly)) { zf.write(tarZst); zf.close(); }
        QProcess lp;
        lp.start(QStringLiteral("sh"), {QStringLiteral("-c"), QStringLiteral("zstd -dc '%1' | tar -tf -").arg(zpath)});
        lp.waitForFinished(5000);
        fileList = QString::fromUtf8(lp.readAllStandardOutput());
    }

    m_manifestView->setPlainText(QStringLiteral("=== MANIFEST ===\n%1\n=== ARCHIVED FILES ===\n%2").arg(manifestPretty, fileList));
    logLine(QStringLiteral("Loaded %1 (SHA-256 verified=%2)").arg(path, hashOk ? QStringLiteral("YES") : QStringLiteral("NO")));
}

void SystemSnapshotWidget::restoreSnapshot() {
    if (m_loadedSnapPath.isEmpty() || !m_loadedHashValid) return;

    if (QMessageBox::warning(
            this,
            QStringLiteral("Confirm System Snapshot Restore"),
            QStringLiteral("This will back up current configs to /var/backups and overwrite selected system files from:\n%1\n\nContinue?").arg(m_loadedSnapPath),
            QMessageBox::Yes | QMessageBox::No) != QMessageBox::Yes) {
        return;
    }

    QByteArray tarZst;
    QString manifestPretty;
    bool hashOk = false;
    if (!verifyAndDecodeSnapshot(m_loadedSnapPath, tarZst, manifestPretty, hashOk) || !hashOk) {
        QMessageBox::critical(this, QStringLiteral("Verification Error"), QStringLiteral("Snapshot SHA-256 check failed during restore."));
        return;
    }

    QDir().mkpath(QStringLiteral("/var/backups"));
    QString preBak = QStringLiteral("/var/backups/gentool-ng-pre-restore-%1.tar.zst").arg(QDateTime::currentDateTime().toString(QStringLiteral("yyyyMMdd-HHmmss")));
    logLine(QStringLiteral("Creating safety backup of current /etc/portage & world at %1...").arg(preBak));
    QProcess::execute(QStringLiteral("sh"), {
        QStringLiteral("-c"),
        QStringLiteral("tar -cf - /etc/portage /var/lib/portage/world /var/lib/portage/world_sets 2>/dev/null | zstd -9 -o '%1'").arg(preBak)
    });

    QTemporaryDir tmp;
    if (!tmp.isValid()) return;
    QString zpath = tmp.path() + QStringLiteral("/restore.tar.zst");
    QString extDir = tmp.path() + QStringLiteral("/extracted");
    QDir().mkpath(extDir);

    QFile zf(zpath);
    if (!zf.open(QIODevice::WriteOnly)) return;
    zf.write(tarZst);
    zf.close();

    QProcess::execute(QStringLiteral("sh"), {QStringLiteral("-c"), QStringLiteral("zstd -dc '%1' | tar -C '%2' -xf -").arg(zpath, extDir)});

    auto syncDir = [&](const QString& relPath, const QString& targetParent) {
        QString src = extDir + relPath;
        if (!QFileInfo::exists(src)) return;
        QDir().mkpath(targetParent);
        QProcess::execute(QStringLiteral("cp"), {QStringLiteral("-a"), src, targetParent});
        logLine(QStringLiteral("Restored %1").arg(relPath));
    };

    if (m_rstPortage->isChecked()) syncDir(QStringLiteral("/etc/portage"), QStringLiteral("/etc/"));
    if (m_rstWorld->isChecked()) {
        syncDir(QStringLiteral("/var/lib/portage/world"), QStringLiteral("/var/lib/portage/"));
        syncDir(QStringLiteral("/var/lib/portage/world_sets"), QStringLiteral("/var/lib/portage/"));
    }
    if (m_rstOverlay->isChecked()) syncDir(QStringLiteral("/var/db/repos/WakStab"), QStringLiteral("/var/db/repos/"));
    if (m_rstKernel->isChecked()) {
        syncDir(QStringLiteral("/etc/kernel/config.d"), QStringLiteral("/etc/kernel/"));
        syncDir(QStringLiteral("/usr/src/linux/.config"), QStringLiteral("/usr/src/linux/"));
    }
    if (m_rstServices->isChecked()) {
        syncDir(QStringLiteral("/etc/locale.gen"), QStringLiteral("/etc/"));
        syncDir(QStringLiteral("/etc/timezone"), QStringLiteral("/etc/"));
        syncDir(QStringLiteral("/etc/conf.d"), QStringLiteral("/etc/"));
        syncDir(QStringLiteral("/etc/runlevels"), QStringLiteral("/etc/"));
        syncDir(QStringLiteral("/etc/systemd/system"), QStringLiteral("/etc/systemd/"));
    }

    logLine(QStringLiteral("Snapshot restore complete! Ready for 'emerge -e @world'."));
    QMessageBox::information(this, QStringLiteral("Restore Complete"), QStringLiteral("System snapshot restored.\nClick 'Run emerge -e @world in Terminal' to rebuild all packages to match this state."));
}
