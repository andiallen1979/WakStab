cmake_minimum_required(VERSION 3.24)
project(gentool-ng VERSION 1.71.2 LANGUAGES CXX)
set(CMAKE_CXX_STANDARD 20)
set(CMAKE_AUTOMOC ON)
set(CMAKE_AUTORCC ON)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
find_package(PkgConfig REQUIRED)
pkg_check_modules(PARTED REQUIRED IMPORTED_TARGET libparted libparted-fs-resize)
pkg_check_modules(UUID REQUIRED IMPORTED_TARGET uuid)
pkg_check_modules(GLIBMM REQUIRED IMPORTED_TARGET glibmm-2.4 sigc++-2.0)
find_package(ECM 6.0 REQUIRED NO_MODULE)
set(CMAKE_MODULE_PATH ${ECM_MODULE_PATH})
find_package(Qt6 6.6 REQUIRED COMPONENTS Core Gui Widgets Network)
find_package(KF6 6.0 REQUIRED COMPONENTS CoreAddons I18n WidgetsAddons XmlGui)
find_package(qtermwidget6 REQUIRED)
set(GPARTED_UPSTREAM_DIR "${CMAKE_SOURCE_DIR}/upstream/gparted")
file(WRITE "${CMAKE_BINARY_DIR}/config.h" "
#pragma once
#define PACKAGE \"gentool-ng\"
#define VERSION \"1.71.2\"
#define GETTEXT_PACKAGE \"gparted\"
#define ENABLE_NLS 1
#include <libintl.h>
#include <sys/stat.h>
#ifndef _
#define _(String) gettext(String)
#endif
#ifndef N_
#define N_(String) (String)
#endif
#ifdef __cplusplus
#include <glibmm/init.h>
namespace { __attribute__((constructor(101))) void gparted_qt_early_glib_init() { Glib::init(); } }
#endif
")
execute_process(COMMAND python3 "${CMAKE_SOURCE_DIR}/scripts/prepare_core.py" "${GPARTED_UPSTREAM_DIR}" "${CMAKE_BINARY_DIR}" RESULT_VARIABLE PY_RES)
if(NOT PY_RES EQUAL 0)
    message(FATAL_ERROR "Failed to generate clean core sources")
endif()
file(GLOB ALL_UPSTREAM_CC "${GPARTED_UPSTREAM_DIR}/src/*.cc")
set(GPARTED_CORE_SOURCES "${CMAKE_BINARY_DIR}/Utils_core.cc" "${CMAKE_BINARY_DIR}/GParted_Core_clean.cc" "${CMAKE_BINARY_DIR}/OperationDetail_clean.cc" "${CMAKE_BINARY_DIR}/CopyBlocks_clean.cc")
foreach(src_file ${ALL_UPSTREAM_CC})
    get_filename_component(fname "${src_file}" NAME)
    if(fname STREQUAL "main.cc" OR fname STREQUAL "Utils.cc" OR fname STREQUAL "GParted_Core.cc" OR fname STREQUAL "OperationDetail.cc" OR fname STREQUAL "CopyBlocks.cc" OR fname MATCHES "^(Win_|Dialog_|DrawingArea|TreeView_|HBoxOperations|Frame_Resizer)")
        continue()
    endif()
    file(READ "${src_file}" content)
    string(FIND "${content}" "gtkmm" has_gtkmm)
    if(has_gtkmm EQUAL -1)
        list(APPEND GPARTED_CORE_SOURCES "${src_file}")
    endif()
endforeach()
add_library(gparted-core STATIC ${GPARTED_CORE_SOURCES})
target_compile_options(gparted-core PUBLIC -include "${CMAKE_BINARY_DIR}/config.h")
target_include_directories(gparted-core PUBLIC "${CMAKE_BINARY_DIR}" "${GPARTED_UPSTREAM_DIR}/include" "${CMAKE_SOURCE_DIR}/src/gtkmm_stubs")
target_link_libraries(gparted-core PUBLIC PkgConfig::PARTED PkgConfig::UUID PkgConfig::GLIBMM)
add_executable(gentool-ng src/main.cpp src/MainWindow.cpp
    src/DeviceManagerWidget.cpp
    src/SystemInfoWidget.cpp
    src/LogManagerWidget.cpp
    src/Stage3Widget.cpp src/PortageConfigWidget.h src/PortageConfigWidget.cpp src/DiskImageWidget.h src/DiskImageWidget.cpp src/QemuVmWidget.h src/QemuVmWidget.cpp src/TerminalWidget.h src/TerminalWidget.cpp src/PlaceholderTabWidget.h src/PlaceholderTabWidget.cpp src/SystemSnapshotWidget.h src/SystemSnapshotWidget.cpp src/FsGuideOverlay.h src/FsGuideOverlay.cpp src/DiskBarWidget.cpp src/OperationQueue.cpp src/ApplyDialog.cpp src/NewPartitionDialog.cpp src/DeviceInfoPane.cpp src/FeaturesDialog.cpp src/FlagsDialog.cpp src/ResizeMoveDialog.cpp src/RescueDialog.cpp src/ImageDialog.cpp src/VirtualDiskDialog.cpp src/RestoreDialog.cpp)
target_compile_definitions(gentool-ng PRIVATE QT_NO_KEYWORDS)
target_link_libraries(gentool-ng PRIVATE gparted-core Qt6::Core Qt6::Gui Qt6::Widgets Qt6::Network KF6::CoreAddons KF6::I18n KF6::WidgetsAddons KF6::XmlGui qtermwidget6)
install(TARGETS gentool-ng DESTINATION bin)
install(PROGRAMS data/gentool-ng-pkexec DESTINATION bin)
install(FILES data/gentool-ng.desktop DESTINATION share/applications)
install(FILES data/org.wakstab.gentool-ng.policy DESTINATION share/polkit-1/actions)
install(FILES data/icons/gentool-ng.svg DESTINATION share/icons/hicolor/scalable/apps)
