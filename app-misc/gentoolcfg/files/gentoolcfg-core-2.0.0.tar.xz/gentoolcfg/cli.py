INFO_LINES = ("gentoolcfg - Unified Gentoo Portage Configurator",)
import os, re, subprocess
from pathlib import Path
from rich.style import Style
from textual.app import App, ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import Button, Checkbox, Footer, Header, Input, Label, Select, TabbedContent, TabPane, TextArea, Tree
from gentoolcfg.portage_io import ENV_PROFILES_DIR, collect_portage_state, ensure_gentoo_os

def write_one(base_dir: Path, rel: str, text: str) -> None:
    dst = base_dir / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    if text.strip(): dst.write_text(text if text.endswith(chr(10)) else (text + chr(10)), encoding="utf-8")
    else: dst.unlink(missing_ok=True)

PROTECTED_KEYS = ("BINPKG_GPG_SIGNING_GPG_HOME", "BINPKG_GPG_SIGNING_KEY", "BINPKG_GPG_VERIFY_GPG_HOME", "SECUREBOOT_SIGN_KEY", "SECUREBOOT_SIGN_CERT", "MODULES_SIGN_KEY", "MODULES_SIGN_CERT")

def filter_make_conf(raw: str, show_cmt: bool, prot_keys: bool) -> str:
    out = []
    for ln in raw.splitlines():
        st = ln.strip()
        if prot_keys and any(st.startswith(f"{k}=") for k in PROTECTED_KEYS): continue
        if not show_cmt and (not st or st.startswith("#")): continue
        out.append(ln)
    return chr(10).join(out)

APP_CSS = """
Screen { layout: vertical; }
#main_split { height: 1fr; }
#left_pane { width: 36%; border: round $accent; padding: 0 1; }
#right_pane { width: 64%; border: round $accent; padding: 0 1; }
#pkg_filter { height: 1; border: none; background: $surface-lighten-1; padding: 0 1; margin-bottom: 1; }
Checkbox { height: 1; border: none; padding: 0; margin: 0; background: transparent; }
Select { height: 3; margin-bottom: 1; }
.bar { height: 1; margin-bottom: 1; }
.bar Input { width: 1fr; height: 1; border: none; background: $surface-lighten-1; padding: 0 1; }
Button { height: 1; min-width: 5; border: none; padding: 0 1; margin-left: 1; }
.env_row { height: 1; }
.env_btn { width: 1fr; height: 1; border: none; background: transparent; content-align: left middle; text-align: left; padding: 0 1; margin: 0; }
.env_btn:hover { background: $accent 25%; }
#pkg_tree, #tabs, #env_split, #env_editor, #mc_editor, #pat_editor { height: 1fr; }
#pat_sel { width: 1fr; height: 3; }
#env_list_pane { width: 42%; border-right: solid $surface-lighten-2; padding-right: 1; }
#env_edit_pane { width: 58%; padding-left: 1; }
#bottom_bar { height: 1; align: right middle; margin-top: 1; }
#chk_comments, #chk_keys { margin-left: 1; }
#modal_box { width: 64; height: auto; max-height: 80%; border: round $accent; background: $surface; padding: 1 2; }
#modal_body { height: auto; max-height: 18; }
#rst_view { height: 14; margin: 1 0; }
#modal_btns { height: 1; align: right middle; margin-top: 1; }
#tab_mc { layers: base overlay; }
#ctx_popup { layer: overlay; width: 18; height: auto; border: round $accent; background: $surface; padding: 0; }
.ctx_btn { width: 100%; height: 1; margin: 0; text-align: left; content-align: left middle; background: transparent; }
.ctx_btn:hover { background: $accent 35%; }
ConfirmModal, UnlockKeysModal { align: center middle; }
"""

class EditorCtxMenu(Vertical):
    def __init__(self, ed: TextArea) -> None:
        super().__init__(id="ctx_popup"); self.ed = ed; self.sel = ed.selected_text
    def compose(self) -> ComposeResult:
        for aid, lbl in (("cut", "Cut"), ("copy", "Copy"), ("paste", "Paste"), ("del", "Delete"), ("all", "Select All")):
            yield Button(lbl, id=f"ctx_{aid}", classes="ctx_btn")
    def on_button_pressed(self, ev: Button.Pressed) -> None:
        from textual.actions import SkipAction
        ev.stop(); a = (ev.button.id or "").replace("ctx_", ""); self.ed.focus()
        try:
            if a == "cut":
                if self.sel: self.app.copy_to_clipboard(self.sel); self.ed.replace("", *self.ed.selection)
            elif a == "copy":
                if self.sel: self.app.copy_to_clipboard(self.sel)
            elif a == "paste": self.ed.action_paste()
            elif a == "del":
                if self.sel: self.ed.replace("", *self.ed.selection)
            elif a == "all": self.ed.select_all()
        except SkipAction: pass
        self.remove()

class MakeConfTextArea(TextArea):
    def on_mouse_down(self, ev) -> None:
        for old in self.parent.query('#ctx_popup'): old.remove()
        if getattr(ev, 'button', 0) == 3:
            ev.stop(); m = EditorCtxMenu(self); m.styles.offset = (max(0, min(ev.x, max(0, self.size.width - 20))), max(0, min(ev.y, max(0, self.size.height - 8)))); self.parent.mount(m)
    def get_line(self, line_index: int):
        line = super().get_line(line_index); raw = line.plain
        if raw.lstrip().startswith("#"): line.stylize(Style(color="#6272a4")); return line
        for m in re.finditer(r"^\s*([A-Za-z_][A-Za-z0-9_]*)", raw): line.stylize(Style(color="#ff5555", bold=True), m.start(1), m.end(1))
        for m in re.finditer(r"=", raw): line.stylize(Style(color="#f1fa8c", bold=True), m.start(), m.end())
        for m in re.finditer(r"['\"]", raw): line.stylize(Style(color="#50fa7b", bold=True), m.start(), m.end())
        for m in re.finditer(r"(?<=[\s'\"])-[A-Za-z0-9_+.:=-]+", raw): line.stylize(Style(color="#55aaff", bold=True), m.start(), m.end())
        return line

def generate_diff_patch(orig_p: str, mod_p: str, out_dir: Path, name: str) -> Path:
    o, m = Path(orig_p).expanduser(), Path(mod_p).expanduser()
    if not o.exists() or not m.exists(): raise ValueError("Both Original and Modified paths must exist.")
    fn = Path(name.strip() or "custom.patch").name
    if not fn.endswith(".patch"): fn += ".patch"
    res = subprocess.run(("diff", "-Naur", str(o), str(m)), capture_output=True, text=True)
    if res.returncode not in (0, 1): raise ValueError(res.stderr.strip() or "diff failed")
    if not res.stdout.strip(): raise ValueError("No differences found between selected paths.")
    out_dir.mkdir(parents=True, exist_ok=True); dst = out_dir / fn
    dst.write_text(res.stdout, encoding="utf-8"); return dst

class CreatePatchModal(ModalScreen):
    BINDINGS = (("escape", "cancel", "Cancel"),)
    def __init__(self, def_name: str = "custom.patch") -> None: super().__init__(); self.def_name = def_name
    def on_mount(self) -> None: self.query_one("#cp_orig", Input).focus()
    def action_cancel(self) -> None: self.dismiss(None)
    def compose(self) -> ComposeResult:
        with Vertical(id="modal_box"):
            yield Label("[b]Create Diff Patch (File or Folder)[/b]")
            yield Input(placeholder="Original file or folder path...", id="cp_orig")
            yield Input(placeholder="Modified file or folder path...", id="cp_mod")
            yield Input(value=self.def_name, placeholder="Patch filename...", id="cp_name")
            with Horizontal(id="modal_btns"):
                yield Button("Create", variant="primary", id="ok"); yield Button("Cancel", id="no")
    def on_button_pressed(self, ev: Button.Pressed) -> None:
        self.dismiss((self.query_one("#cp_orig", Input).value, self.query_one("#cp_mod", Input).value, self.query_one("#cp_name", Input).value) if ev.button.id == "ok" else None)

def trash_or_delete_patch(base_dir: Path, cp: str, pt: dict, temp: bool) -> None:
    src = Path(pt.get("path"))
    if not src.exists(): return
    if temp:
        tdir = base_dir / ".gentoolcfg-patch-trash" / cp; tdir.mkdir(parents=True, exist_ok=True)
        src.replace(tdir / src.name)
    else: src.unlink(missing_ok=True)

def list_trashed_patches(base_dir: Path, cp: str) -> list[Path]:
    tdir = base_dir / ".gentoolcfg-patch-trash" / cp
    return sorted(tdir.glob("*.patch*")) if tdir.is_dir() else []

def restore_trashed_patch(base_dir: Path, cp: str, trashed: Path) -> Path:
    dst_dir = base_dir / "patches" / cp; dst_dir.mkdir(parents=True, exist_ok=True)
    dst = dst_dir / trashed.name; trashed.replace(dst); return dst

class RestorePatchModal(ModalScreen):
    BINDINGS = (("escape", "cancel", "Cancel"),)
    def __init__(self, items: list[Path]) -> None:
        super().__init__(); self.items = list(reversed(items))
    def action_cancel(self) -> None: self.dismiss(None)
    def on_mount(self) -> None: self._preview(self.items.__getitem__(0))
    def _preview(self, p: Path) -> None:
        self.query_one("#rst_view", TextArea).load_text(p.read_text(encoding="utf-8", errors="ignore") if p.is_file() else "")
    def compose(self) -> ComposeResult:
        opts = tuple((p.name, str(p)) for p in self.items)
        with Vertical(id="modal_box"):
            yield Label("[b]Stashed Patches (Preview, Restore, or Permanently Delete)[/b]")
            yield Select(opts, value=opts.__getitem__(0).__getitem__(1), allow_blank=False, id="rst_sel")
            yield TextArea("", read_only=True, id="rst_view")
            with Horizontal(id="modal_btns"):
                yield Button("Restore Selected", variant="primary", id="ok")
                yield Button("Delete Permanently", variant="error", id="del")
                yield Button("Close", id="no")
    def on_select_changed(self, ev: Select.Changed) -> None:
        if ev.select.id == "rst_sel" and ev.value: self._preview(Path(str(ev.value)))
    def on_button_pressed(self, ev: Button.Pressed) -> None:
        val = Path(str(self.query_one("#rst_sel", Select).value))
        self.dismiss((ev.button.id, val) if ev.button.id in ("ok", "del") else None)

class UnlockKeysModal(ModalScreen):
    BINDINGS = (("escape", "cancel", "Cancel"),)
    def on_mount(self) -> None: self.query_one("#yes_in", Input).focus()
    def action_cancel(self) -> None: self.dismiss(False)
    def compose(self) -> ComposeResult:
        with Vertical(id="modal_box"):
            yield Label("[b]WARNING: Unlock Vital Signing Keys[/b]\nType capital [b]YES[/b] to reveal GPG / SecureBoot / Module keys:")
            yield Input(placeholder="Type YES...", id="yes_in")
            with Horizontal(id="modal_btns"):
                yield Button("Unlock", variant="warning", id="ok"); yield Button("Cancel", id="no")
    def on_input_submitted(self, ev: Input.Submitted) -> None: self.dismiss(ev.value.strip() == "YES")
    def on_button_pressed(self, ev: Button.Pressed) -> None: self.dismiss(ev.button.id == "ok" and self.query_one("#yes_in", Input).value.strip() == "YES")

class ConfirmModal(ModalScreen):
    BINDINGS = (("escape", "cancel", "Cancel"),)
    def __init__(self, title: str, body: str, ask: bool = True) -> None:
        super().__init__(); self.m_title = title; self.m_body = body; self.m_ask = ask
    def on_mount(self) -> None: self.query_one(Button).focus()
    def action_cancel(self) -> None: self.dismiss(False)
    def compose(self) -> ComposeResult:
        with Vertical(id="modal_box"):
            yield Label(f"[b]{self.m_title}[/b]")
            with VerticalScroll(id="modal_body"): yield Label(self.m_body)
            with Horizontal(id="modal_btns"):
                if self.m_ask: yield Button("Yes", variant="primary", id="yes"); yield Button("No", id="no")
                else: yield Button("OK", variant="primary", id="ok")
    def on_button_pressed(self, ev: Button.Pressed) -> None: self.dismiss(ev.button.id == "yes")

class CfgStore:
    def __init__(self) -> None:
        self.state = collect_portage_state(); self.pkg_map = {p.get("cp"): p for p in self.state.get("packages", ())}
        self.orig_mc = self.state.get("mc_text", ""); self.cur_mc = self.orig_mc
        for p in self.state.get("packages", ()):
            p.update({"cur_flags": {f.get("flag"): bool(f.get("effective")) for f in p.get("flags", ())}, "orig_flags": {f.get("flag"): bool(f.get("effective")) for f in p.get("flags", ())}, "cur_envs": {e.get("name") for e in p.get("envs", ()) if e.get("initial")}, "orig_envs": {e.get("name") for e in p.get("envs", ()) if e.get("initial")}, "cur_kw": {"amd64": bool(p.get("kw_s")), "~amd64": bool(p.get("kw_t")), "**": bool(p.get("kw_l"))}, "orig_kw": {k for k, v in (("amd64", p.get("kw_s")), ("~amd64", p.get("kw_t")), ("**", p.get("kw_l"))) if v}, "cur_kw_mode": p.get("kw_mode", "ALL"), "orig_kw_mode": p.get("kw_mode", "ALL"), "cur_mask": p.get("mask_mode", "NONE"), "orig_mask": p.get("mask_mode", "NONE"), "cur_unmask": p.get("unmask_mode", "NONE"), "orig_unmask": p.get("unmask_mode", "NONE")})
            for pt in p.get("patches", ()): pt.update({"cur_en": bool(pt.get("enabled")), "orig_en": bool(pt.get("enabled"))})
    def _base(self) -> Path: return Path("/etc/portage") if os.geteuid() == 0 else (Path.cwd() / "portage-preview")
    def _atom(self, cp: str, cpv: str, mode: str) -> str: return f"={cpv}" if mode == "EQ" else (f">={cpv}" if mode == "FWD" else cp)
    def _write_pkg_line(self, sub: str, cp: str, line: str) -> None:
        d = self._base() / sub
        if d.is_file():
            keep = [ln for ln in d.read_text(encoding="utf-8", errors="ignore").splitlines() if cp not in ln.split()]
            if line: keep.append(line)
            d.write_text((chr(10).join(keep) + chr(10)) if keep else "", encoding="utf-8")
        else:
            d.mkdir(parents=True, exist_ok=True); f = d / cp.replace("/", "_")
            f.write_text(line + chr(10), encoding="utf-8") if line else f.unlink(missing_ok=True)
    def save_scope(self, scope: str, pkg: dict | None = None) -> list[str]:
        chg = []
        if scope == "mc" and self.cur_mc != self.orig_mc:
            mc_dst = self._base() / "make.conf"; mc_dst.parent.mkdir(parents=True, exist_ok=True)
            self._rotate_mc_backup(mc_dst)
            mc_dst.write_text(self.cur_mc if self.cur_mc.endswith(chr(10)) else (self.cur_mc + chr(10)), encoding="utf-8")
            self.orig_mc = self.cur_mc; chg.append("MAKE.CONF: updated /etc/portage/make.conf")
        elif pkg:
            cp, cpv = pkg.get("cp"), pkg.get("cpv")
            if scope == "use" and pkg.get("cur_flags") != pkg.get("orig_flags"):
                inst = {f.get("flag"): bool(f.get("installed")) for f in pkg.get("flags", ())}
                toks = [f"{'' if v else '-'}{k}" for k, v in sorted(pkg.get("cur_flags").items()) if v != inst.get(k) or v != pkg.get("orig_flags").get(k)]
                self._write_pkg_line("package.use", cp, f"{cp} {' '.join(toks)}" if toks else "")
                pkg["orig_flags"] = dict(pkg.get("cur_flags")); chg.append(f"USE {cp}: {' '.join(toks) or '(reset)'}")
            elif scope == "env" and pkg.get("cur_envs") != pkg.get("orig_envs"):
                self._write_pkg_line("package.env", cp, f"{cp} {' '.join(sorted(pkg.get('cur_envs')))}" if pkg.get("cur_envs") else "")
                pkg["orig_envs"] = set(pkg.get("cur_envs")); chg.append(f"ENV {cp}: {' '.join(sorted(pkg.get('cur_envs'))) or '(none)'}")
            elif scope == "kw":
                ak = tuple(k for k in ("amd64", "~amd64", "**") if pkg.get("cur_kw", {}).get(k))
                if set(ak) != pkg.get("orig_kw") or pkg.get("cur_kw_mode") != pkg.get("orig_kw_mode"):
                    self._write_pkg_line("package.accept_keywords", cp, f"{self._atom(cp, cpv, pkg.get('cur_kw_mode'))} {' '.join(ak)}" if ak else "")
                    pkg["orig_kw"] = set(ak); pkg["orig_kw_mode"] = pkg.get("cur_kw_mode"); chg.append(f"KW {cp}: {' '.join(ak) or '(none)'}")
                if pkg.get("cur_mask") != pkg.get("orig_mask"):
                    self._write_pkg_line("package.mask", cp, self._atom(cp, cpv, pkg.get("cur_mask")) if pkg.get("cur_mask") != "NONE" else "")
                    pkg["orig_mask"] = pkg.get("cur_mask"); chg.append(f"MASK {cp}: {pkg.get('cur_mask')}")
                if pkg.get("cur_unmask") != pkg.get("orig_unmask"):
                    self._write_pkg_line("package.unmask", cp, self._atom(cp, cpv, pkg.get("cur_unmask")) if pkg.get("cur_unmask") != "NONE" else "")
                    pkg["orig_unmask"] = pkg.get("cur_unmask"); chg.append(f"UNMASK {cp}: {pkg.get('cur_unmask')}")
            elif scope == "pat":
                for pt in pkg.get("patches", ()):
                    if pt.get("cur_en") != pt.get("orig_en"):
                        src_f = Path(pt.get("path")); dst_f = self._base() / "patches" / cp / (pt.get("base_name") if pt.get("cur_en") else f"{pt.get('base_name')}.disabled")
                        dst_f.parent.mkdir(parents=True, exist_ok=True)
                        if src_f.exists() and src_f != dst_f: src_f.replace(dst_f); pt["path"] = str(dst_f)
                        pt["orig_en"] = pt.get("cur_en"); chg.append(f"PATCH {cp}: {pt.get('base_name')}")
                    if pt.get("cur_text") is not None and pt.get("cur_text") != pt.get("orig_text"):
                        dst_f = Path(pt.get("path")); dst_f.parent.mkdir(parents=True, exist_ok=True); dst_f.write_text(pt.get("cur_text"), encoding="utf-8"); pt["orig_text"] = pt.get("cur_text"); chg.append(f"PATCH EDIT {cp}: {pt.get('base_name')}")
        return chg

    def build_sanity_report(self):
        chg, wrn = [], []
        if self.cur_mc != self.orig_mc:
            chg.append("MAKE.CONF: update /etc/portage/make.conf")
            if "ACCEPT_KEYWORDS" in self.cur_mc and "**" in self.cur_mc: wrn.append("WARNING: Global ** in make.conf bypasses binary cache.")
        for p in self.state.get("packages", ()):
            cp = p.get("cp")
            if p.get("cur_flags") != p.get("orig_flags"): chg.append(f"USE {cp}: {' '.join(f'{chr(43) if v else chr(45)}{k}' for k, v in sorted(p.get('cur_flags').items()) if v != p.get('orig_flags').get(k))}")
            if p.get("cur_envs") != p.get("orig_envs"): chg.append(f"ENV {cp}: {' '.join(sorted(p.get('cur_envs'))) or '(none)'}")
            ak = tuple(k for k in ("amd64", "~amd64", "**") if p.get("cur_kw", {}).get(k))
            if set(ak) != p.get("orig_kw") or p.get("cur_kw_mode") != p.get("orig_kw_mode"):
                chg.append(f"KW  {cp}: {' '.join(ak) or '(none)'}")
                if "**" in ak: wrn.append(f"WARNING: '**' live keyword on {cp} bypasses binary cache.")
            if p.get("cur_mask") != p.get("orig_mask"):
                chg.append(f"MASK {cp}: {p.get('cur_mask')}")
                if p.get("cur_mask") != "NONE" and cp.split("/").__getitem__(0) in ("sys-libs", "sys-devel", "sys-apps", "llvm-core"): wrn.append(f"HIGH RISK: Masking core package {cp} may break @world.")
            if p.get("cur_unmask") != p.get("orig_unmask"): chg.append(f"UNMASK {cp}: {p.get('cur_unmask')}")
            for pt in p.get("patches", ()):
                if pt.get("cur_en") != pt.get("orig_en"): chg.append(f"PATCH {cp}: {'enable' if pt.get('cur_en') else 'disable'} {pt.get('base_name')}")
        return chg, wrn
    def _rotate_mc_backup(self, mc_dst: Path) -> None:
        from datetime import datetime
        if not mc_dst.is_file(): return
        raw = mc_dst.read_text(encoding="utf-8", errors="ignore")
        (self._base() / "make.conf.bak").write_text(raw, encoding="utf-8")
        bdir = self._base() / ".gentoolcfg-backups"; bdir.mkdir(parents=True, exist_ok=True)
        (bdir / f"make.conf.{datetime.now().strftime('%Y%m%d-%H%M%S-%f')}.bak").write_text(raw, encoding="utf-8")
        for old in sorted(bdir.glob("make.conf.*.bak"))[:-10]: old.unlink(missing_ok=True)
    def save_all(self) -> int:
        chg, _ = self.build_sanity_report()
        if self.cur_mc != self.orig_mc:
            mc_dst = self._base() / "make.conf"; mc_dst.parent.mkdir(parents=True, exist_ok=True)
            self._rotate_mc_backup(mc_dst)
            mc_dst.write_text(self.cur_mc if self.cur_mc.endswith(chr(10)) else (self.cur_mc + chr(10)), encoding="utf-8")
        for p in self.state.get("packages", ()):
            cp, cpv = p.get("cp"), p.get("cpv")
            if p.get("cur_flags") != p.get("orig_flags"):
                inst = {f.get("flag"): bool(f.get("installed")) for f in p.get("flags", ())}
                toks = [f"{'' if v else '-'}{k}" for k, v in sorted(p.get("cur_flags").items()) if v != inst.get(k) or v != p.get("orig_flags").get(k)]
                self._write_pkg_line("package.use", cp, f"{cp} {' '.join(toks)}" if toks else "")
            if p.get("cur_envs") != p.get("orig_envs"): self._write_pkg_line("package.env", cp, f"{cp} {' '.join(sorted(p.get('cur_envs')))}" if p.get("cur_envs") else "")
            ak = tuple(k for k in ("amd64", "~amd64", "**") if p.get("cur_kw", {}).get(k))
            if set(ak) != p.get("orig_kw") or p.get("cur_kw_mode") != p.get("orig_kw_mode"): self._write_pkg_line("package.accept_keywords", cp, f"{self._atom(cp, cpv, p.get('cur_kw_mode'))} {' '.join(ak)}" if ak else "")
            if p.get("cur_mask") != p.get("orig_mask"): self._write_pkg_line("package.mask", cp, self._atom(cp, cpv, p.get("cur_mask")) if p.get("cur_mask") != "NONE" else "")
            if p.get("cur_unmask") != p.get("orig_unmask"): self._write_pkg_line("package.unmask", cp, self._atom(cp, cpv, p.get("cur_unmask")) if p.get("cur_unmask") != "NONE" else "")
            for pt in p.get("patches", ()):
                if pt.get("cur_en") != pt.get("orig_en"):
                    src_f = Path(pt.get("path")); dst_f = self._base() / "patches" / cp / (pt.get("base_name") if pt.get("cur_en") else f"{pt.get('base_name')}.disabled")
                    dst_f.parent.mkdir(parents=True, exist_ok=True)
                    if src_f.exists() and src_f != dst_f: src_f.replace(dst_f)
        return len(chg)

class GentoolCfgApp(App):
    TITLE = "gentoolcfg"
    CSS = APP_CSS
    BINDINGS = (("ctrl+s", "save_cfg", "Save"), ("ctrl+q", "quit", "Quit"), ("f5", "reload_cfg", "Refresh"))
    def __init__(self) -> None:
        super().__init__(); self.store = CfgStore(); self.cur_pkg = None; self.active_env = ""
    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        with Horizontal(id="main_split"):
            with Vertical(id="left_pane"):
                yield Input(placeholder="Filter packages (name, cat, USE, ENV, KW)...", id="pkg_filter")
                yield Checkbox("Sort by longest genlop -t build time first", id="slow_sort")
                yield Tree("Packages", id="pkg_tree")
                yield Label("Badges: USE | ENV | KW | MASK | UNMASK | PATCH")
            with Vertical(id="right_pane"):
                yield Label("Select a package on the left to inspect and configure.", id="pkg_hdr")
                with TabbedContent(id="tabs"):
                    with TabPane("USE", id="tab_use"):
                        with Horizontal(classes="bar"):
                            yield Input(placeholder="Filter USE flags...", id="use_filter"); yield Button("Refresh", id="btn_refresh"); yield Button("Save USE", variant="primary", id="save_use")
                        yield VerticalScroll(id="use_list")
                    with TabPane("Environment", id="tab_env"):
                        with Horizontal(id="env_split"):
                            with Vertical(id="env_list_pane"):
                                with Horizontal(classes="bar"): yield Label("Assign /etc/portage/env:"); yield Button("Save Env", variant="primary", id="save_env")
                                yield VerticalScroll(id="env_list")
                            with Vertical(id="env_edit_pane"):
                                with Horizontal(classes="bar"):
                                    yield Input(placeholder="profile.conf...", id="env_name"); yield Button("+", id="btn_env_new"); yield Button("Save", id="btn_env_save"); yield Button("Del", id="btn_env_del")
                                yield TextArea("", id="env_editor")
                    with TabPane("Keywords", id="tab_kw"):
                        yield VerticalScroll(id="kw_list")
                        with Horizontal(classes="bar"): yield Button("Save Keywords", variant="primary", id="save_kw")
                    with TabPane("Patches", id="tab_pat"):
                        with Horizontal(classes="bar"):
                            yield Select((("No patches found", "NONE"),), value="NONE", allow_blank=False, id="pat_sel")
                            yield Checkbox("Enabled", value=True, id="pat_en")
                        yield TextArea("", id="pat_editor")
                        with Horizontal(classes="bar", id="pat_bar"):
                            for bid, lbl in (("pt_undo", "Undo"), ("pt_redo", "Redo"), ("pt_cut", "Cut"), ("pt_copy", "Copy"), ("pt_paste", "Paste"), ("pt_del", "Delete"), ("pt_all", "Select All"), ("pt_new", "Create"), ("pt_rm", "Remove"), ("pt_rst", "Restore")): yield Button(lbl, id=bid)
                            yield Checkbox("Comments", value=False, id="pat_cmt")
                            yield Button("Save Patches", variant="primary", id="save_pat")
                    with TabPane("make.conf", id="tab_mc"):
                        yield MakeConfTextArea("", id="mc_editor")
                        with Horizontal(classes="bar", id="mc_bar"):
                            for bid, lbl in (("mc_undo", "Undo"), ("mc_redo", "Redo"), ("mc_cut", "Cut"), ("mc_copy", "Copy"), ("mc_paste", "Paste"), ("mc_del", "Delete"), ("mc_all", "Select All")): yield Button(lbl, id=bid)
                            yield Checkbox("Protect keys", value=True, id="chk_keys")
                            yield Checkbox("Comments", value=False, id="chk_comments")
                            yield Button("Save make.conf", variant="primary", id="save_mc")
        yield Footer()
    def on_mount(self) -> None:
        self.query_one("#pkg_tree", Tree).show_root = False
        self.query_one("#mc_editor", MakeConfTextArea).load_text(filter_make_conf(self.store.cur_mc, False, True))
        self.refresh_tree()
    def _env_dir(self) -> Path: return ENV_PROFILES_DIR if os.geteuid() == 0 else (Path.cwd() / "portage-preview" / "env")
    def _badges(self, p: dict) -> str:
        return " | ".join(([p.get("build_fmt")] if p.get("build_secs", 0) > 0 else []) + (["USE"] if p.get("use_mod") else []) + (["ENV"] if p.get("cur_envs") else []) + (["KW"] if any(p.get("cur_kw", {}).values()) else []) + (["MASK"] if p.get("cur_mask") != "NONE" else []) + (["UNMASK"] if p.get("cur_unmask", "NONE") != "NONE" else []) + (["PATCH"] if p.get("has_patch") else []))
    def refresh_tree(self) -> None:
        tree = self.query_one("#pkg_tree", Tree); tree.clear(); q = self.query_one("#pkg_filter", Input).value.strip().lower(); pkgs = self.store.state.get("packages", ())
        if self.query_one("#slow_sort", Checkbox).value:
            sl = sorted((x for x in pkgs if x.get("build_secs", 0) > 0), key=lambda x: (-x.get("build_secs", 0), x.get("cp")))
            if sl:
                top = tree.root.add(f"Top Slowest Builds ({len(sl)})", expand=True)
                for p in sl:
                    bd = self._badges(p)
                    if not q or q in f"{p.get('cp')} {bd}".lower(): top.add_leaf(f"{p.get('name')}  [{bd}]" if bd else p.get("name"), data=p.get("cp"))
        by_cat = {}
        for p in pkgs: by_cat.setdefault(p.get("cat"), []).append(p)
        for cat in sorted(by_cat):
            ms = [p for p in by_cat.get(cat, ()) if not q or q in f"{p.get('cp')} {self._badges(p)}".lower()]
            if not ms: continue
            node = tree.root.add(f"{cat} ({len(ms)})", expand=bool(q))
            for p in ms:
                bd = self._badges(p); node.add_leaf(f"{p.get('name')}  [{bd}]" if bd else p.get("name"), data=p.get("cp"))

    def on_input_changed(self, ev: Input.Changed) -> None:
        if ev.input.id == "pkg_filter": self.refresh_tree()
        elif ev.input.id == "use_filter": self.rebuild_use()
    def on_tree_node_selected(self, ev: Tree.NodeSelected) -> None:
        cp = ev.node.data
        if not cp: return
        self.cur_pkg = self.store.pkg_map.get(cp)
        if not self.cur_pkg: return
        self.query_one("#pkg_hdr", Label).update(f"[b]{self.cur_pkg.get('cpv')}[/b]   |   Last merge: {self.cur_pkg.get('build_fmt')}")
        self.rebuild_use(); self.rebuild_env(); self.rebuild_kw(); self.rebuild_pat()
    def rebuild_use(self) -> None:
        box = self.query_one("#use_list", VerticalScroll); box.remove_children(); p = self.cur_pkg
        if not p: return
        qf = self.query_one("#use_filter", Input).value.strip().lower()
        shown = 0
        for f in p.get("flags", ()):
            fl = f.get("flag")
            if not qf or qf in fl.lower(): box.mount(Checkbox(f"{fl} *" if f.get("forced") else fl, value=bool(p.get("cur_flags", {}).get(fl)), name=f"use:{fl}")); shown += 1
        if not shown: box.mount(Label("No USE flags found."))
    def rebuild_env(self) -> None:
        box = self.query_one("#env_list", VerticalScroll); box.remove_children(); p = self.cur_pkg
        if not p: return
        for e in p.get("envs", ()):
            en = e.get("name"); box.mount(Horizontal(Checkbox("", value=(en in p.get("cur_envs", set())), name=f"env:{en}"), Button(en, name=f"editenv:{en}", classes="env_btn"), classes="env_row"))
    def rebuild_kw(self) -> None:
        box = self.query_one("#kw_list", VerticalScroll); box.remove_children(); p = self.cur_pkg
        if not p: return
        cur_k = next((k for k in ("**", "~amd64", "amd64") if p.get("cur_kw", {}).get(k)), "NONE")
        box.mount(Label("[b]Accept Keyword:[/b]"), Select((("(none)", "NONE"), ("amd64 (stable)", "amd64"), ("~amd64 (testing)", "~amd64"), ("** (live)", "**")), value=cur_k, allow_blank=False, name="sel:kw"))
        box.mount(Label("[b]Keyword Scope:[/b]"), Select((("All versions", "ALL"), ("Exact version (=)", "EQ"), ("Forward upgrades (>=)", "FWD")), value=p.get("cur_kw_mode", "ALL"), allow_blank=False, name="sel:cur_kw_mode"))
        box.mount(Label("[b]Package Mask:[/b]"), Select((("Unmasked", "NONE"), ("Mask all", "ALL"), ("Mask exact (=)", "EQ"), ("Mask forward (>=)", "FWD")), value=p.get("cur_mask", "NONE"), allow_blank=False, name="sel:cur_mask"))
        box.mount(Label("[b]Package Unmask:[/b]"), Select((("No local unmask", "NONE"), ("Unmask all", "ALL"), ("Unmask exact (=)", "EQ"), ("Unmask forward (>=)", "FWD")), value=p.get("cur_unmask", "NONE"), allow_blank=False, name="sel:cur_unmask"))
    def _cur_pat_obj(self):
        if not self.cur_pkg: return None
        bn = str(self.query_one("#pat_sel", Select).value)
        return next((x for x in self.cur_pkg.get("patches", ()) if x.get("base_name") == bn), None)
    def _load_pat_editor(self) -> None:
        pt = self._cur_pat_obj(); ed = self.query_one("#pat_editor", TextArea); sc = self.query_one("#pat_cmt", Checkbox).value
        if not pt: ed.load_text(""); return
        if "orig_text" not in pt:
            pf = Path(pt.get("path")); pt["orig_text"] = pf.read_text(encoding="utf-8", errors="ignore") if pf.is_file() else ""; pt["cur_text"] = pt["orig_text"]
        self.query_one("#pat_en", Checkbox).value = bool(pt.get("cur_en"))
        ed.load_text(filter_make_conf(pt.get("cur_text", ""), sc, False))
    def _create_patch_tui(self) -> None:
        if not self.cur_pkg: self.notify("Select a package first."); return
        def _done(vals) -> None:
            if not vals: return
            try:
                cp = self.cur_pkg.get("cp"); dst = generate_diff_patch(vals.__getitem__(0), vals.__getitem__(1), self.store._base() / "patches" / cp, vals.__getitem__(2))
                self.cur_pkg.setdefault("patches", []).append({"base_name": dst.name, "path": str(dst), "enabled": True, "cur_en": True, "orig_en": True})
                self.rebuild_pat(); self.query_one("#pat_sel", Select).value = dst.name; self._load_pat_editor(); self.notify(f"Created {dst.name}")
            except Exception as exc: self.notify(f"Error: {exc}")
        import time
        slug = Path(self.cur_pkg.get("cpv", "custom")).name
        self.push_screen(CreatePatchModal(f"{slug}-{int(time.time())}.patch"), _done)
    def _remove_patch_tui(self) -> None:
        pt = self._cur_pat_obj()
        if not pt or not self.cur_pkg: return
        def _do(ok: bool) -> None:
            if not ok: return
            trash_or_delete_patch(self.store._base(), self.cur_pkg.get("cp"), pt, True)
            self.cur_pkg["patches"] = [x for x in self.cur_pkg.get("patches", ()) if x is not pt]
            self.rebuild_pat(); self.refresh_tree()
        self.push_screen(ConfirmModal("Stash Patch", f"Move '{pt.get('base_name')}' to stash?\nPortage will not apply it until restored.", True), _do)
    def _restore_patch_tui(self) -> None:
        if not self.cur_pkg: return
        cp = self.cur_pkg.get("cp"); items = list_trashed_patches(self.store._base(), cp)
        if not items: self.notify("No stashed patches found for this package."); return
        def _done(res) -> None:
            if not res: return
            act, pick = res
            if act == "del": pick.unlink(missing_ok=True); self.notify(f"Deleted {pick.name}"); return
            dst = restore_trashed_patch(self.store._base(), cp, pick)
            en = not dst.name.endswith(".disabled"); bn = dst.name[:-9] if not en else dst.name
            self.cur_pkg.setdefault("patches", []).append({"base_name": bn, "path": str(dst), "enabled": en, "cur_en": en, "orig_en": en})
            self.rebuild_pat(); self.query_one("#pat_sel", Select).value = bn; self._load_pat_editor(); self.refresh_tree()
        self.push_screen(RestorePatchModal(items), _done)
    def rebuild_pat(self) -> None:
        sel = self.query_one("#pat_sel", Select); p = self.cur_pkg
        pts = p.get("patches", ()) if p else ()
        opts = tuple((pt.get("base_name"), pt.get("base_name")) for pt in pts) if pts else (("No patches found", "NONE"),)
        sel.set_options(opts); sel.value = opts.__getitem__(0).__getitem__(1); self._load_pat_editor()
    def on_tabbed_content_tab_activated(self, ev: TabbedContent.TabActivated) -> None:
        for old in self.query('#ctx_popup'): old.remove()
    def on_text_area_changed(self, ev: TextArea.Changed) -> None:
        if ev.text_area.id == "pat_editor" and self.query_one("#pat_cmt", Checkbox).value:
            pt = self._cur_pat_obj()
            if pt: pt["cur_text"] = ev.text_area.text
        if ev.text_area.id == "mc_editor" and self.query_one("#chk_comments", Checkbox).value:
            if not self.query_one("#chk_keys", Checkbox).value: self.store.cur_mc = ev.text_area.text
            else:
                kept = [ln for ln in self.store.cur_mc.splitlines() if any(ln.strip().startswith(f"{k}=") for k in PROTECTED_KEYS)]
                self.store.cur_mc = chr(10).join(kept + ev.text_area.text.splitlines())
    def on_select_changed(self, ev: Select.Changed) -> None:
        nm = ev.select.name or ""
        if ev.select.id == "pat_sel": self._load_pat_editor(); return
        if not self.cur_pkg or not nm.startswith("sel:"): return
        key = nm.split(":", 1).__getitem__(1); val = str(ev.value)
        if key == "kw": self.cur_pkg.update({"cur_kw": {k: (k == val) for k in ("amd64", "~amd64", "**")}})
        else: self.cur_pkg.update({key: val})
    def on_checkbox_changed(self, ev: Checkbox.Changed) -> None:
        if ev.checkbox.id == "slow_sort": self.refresh_tree(); return
        if ev.checkbox.id == "pat_cmt": self._load_pat_editor(); return
        if ev.checkbox.id == "pat_en":
            pt = self._cur_pat_obj()
            if pt: pt["cur_en"] = ev.value
            return
        if ev.checkbox.id in ("chk_comments", "chk_keys"):
            ed = self.query_one("#mc_editor", MakeConfTextArea); sc = self.query_one("#chk_comments", Checkbox).value; pk = self.query_one("#chk_keys", Checkbox).value
            if ev.checkbox.id == "chk_keys" and not ev.value:
                self.push_screen(UnlockKeysModal(), lambda ok: ed.load_text(filter_make_conf(self.store.cur_mc, sc, False)) if ok else setattr(ev.checkbox, "value", True))
            else: ed.load_text(filter_make_conf(self.store.cur_mc, sc, pk))
            return
        nm = ev.checkbox.name or ""; p = self.cur_pkg
        if not p: return
        if nm.startswith("use:"):
            fl = nm.split(":", 1).__getitem__(1); st = ev.value; meta = next((x for x in p.get("flags", ()) if x.get("flag") == fl), {})
            if meta.get("forced") and st != bool(p.get("cur_flags", {}).get(fl)):
                self.push_screen(ConfirmModal("Profile-Locked USE Flag", f"'{fl}' is {meta.get('force_reason')}.\nApply override anyway?"), lambda ok: p.get("cur_flags").update({fl: st}) if ok else setattr(ev.checkbox, "value", not st))
            else: p.get("cur_flags").update({fl: st})
        elif nm.startswith("env:"): en = nm.split(":", 1).__getitem__(1); p.get("cur_envs").add(en) if ev.value else p.get("cur_envs").discard(en)
        elif nm.startswith("pat:"):
            bn = nm.split(":", 1).__getitem__(1)
            for pt in p.get("patches", ()):
                if pt.get("base_name") == bn: pt.update({"cur_en": ev.value})
    def on_button_pressed(self, ev: Button.Pressed) -> None:
        bid = ev.button.id or ""; bnm = ev.button.name or ""
        if bid == "btn_refresh": self.action_reload_cfg()
        elif bid in ("save_use", "save_env", "save_kw", "save_pat", "save_mc"): self._save_tab(bid.replace("save_", ""))
        elif bid == "btn_save": self.action_save_cfg()
        elif bid == "pt_new": self._create_patch_tui(); return
        elif bid == "pt_rm": self._remove_patch_tui(); return
        elif bid == "pt_rst": self._restore_patch_tui(); return
        elif bid.startswith(("mc_", "pt_")):
            from textual.actions import SkipAction
            ed = self.query_one("#pat_editor" if bid.startswith("pt_") else "#mc_editor", TextArea); sel = ed.selected_text; ed.focus(); act = bid.split("_", 1).__getitem__(1)
            try:
                if act == "undo": ed.action_undo()
                elif act == "redo": ed.action_redo()
                elif act == "cut" and sel: self.copy_to_clipboard(sel); ed.replace("", *ed.selection)
                elif act == "copy" and sel: self.copy_to_clipboard(sel)
                elif act == "paste": ed.action_paste()
                elif act == "del" and sel: ed.replace("", *ed.selection)
                elif act == "all": ed.select_all()
            except SkipAction: pass
        elif False:
            from textual.actions import SkipAction
            ed = self.query_one("#mc_editor", MakeConfTextArea); sel = ed.selected_text; ed.focus()
            try:
                if bid == "mc_undo": ed.action_undo()
                elif bid == "mc_redo": ed.action_redo()
                elif bid == "mc_cut" and sel: self.copy_to_clipboard(sel); ed.replace("", *ed.selection)
                elif bid == "mc_copy" and sel: self.copy_to_clipboard(sel)
                elif bid == "mc_paste": ed.action_paste()
                elif bid == "mc_del" and sel: ed.replace("", *ed.selection)
                elif bid == "mc_all": ed.select_all()
            except SkipAction: pass
        elif bid == "btn_env_new":
            self.active_env = ""; self.query_one("#env_name", Input).value = "custom.conf"; self.query_one("#env_editor", TextArea).load_text('MAKEOPTS="-j8 -l8"\nNINJAFLAGS="-j8 -l8"\nCARGO_BUILD_JOBS="8"\n')
        elif bid == "btn_env_save":
            raw = self.query_one("#env_name", Input).value.strip()
            if not raw: return
            fn = Path(raw if raw.endswith(".conf") else f"{raw}.conf").name; d = self._env_dir(); d.mkdir(parents=True, exist_ok=True)
            if self.active_env and self.active_env != fn: (d / self.active_env).unlink(missing_ok=True)
            body = self.query_one("#env_editor", TextArea).text; (d / fn).write_text(body if body.endswith("\n") else (body + "\n"), encoding="utf-8"); self.active_env = fn; self.action_reload_cfg()
        elif bid == "btn_env_del" and self.active_env:
            (self._env_dir() / self.active_env).unlink(missing_ok=True); self.active_env = ""; self.query_one("#env_name", Input).value = ""; self.query_one("#env_editor", TextArea).load_text(""); self.action_reload_cfg()
        elif bnm.startswith("editenv:"):
            fn = bnm.split(":", 1).__getitem__(1); self.active_env = fn; self.query_one("#env_name", Input).value = fn
            lf = self._env_dir() / fn; sf = ENV_PROFILES_DIR / fn; t = lf if lf.is_file() else sf
            self.query_one("#env_editor", TextArea).load_text(t.read_text(encoding="utf-8", errors="ignore") if t.is_file() else "")
    def action_reload_cfg(self) -> None:
        cp = self.cur_pkg.get("cp") if self.cur_pkg else None; self.store = CfgStore()
        self.query_one("#mc_editor", MakeConfTextArea).load_text(filter_make_conf(self.store.cur_mc, self.query_one("#chk_comments", Checkbox).value, self.query_one("#chk_keys", Checkbox).value)); self.refresh_tree()
        if cp and cp in self.store.pkg_map: self.cur_pkg = self.store.pkg_map.get(cp); self.rebuild_use(); self.rebuild_env(); self.rebuild_kw(); self.rebuild_pat()
    def _save_tab(self, sc: str) -> None:
        chg = self.store.save_scope(sc, self.cur_pkg)
        if not chg: self.notify("No pending changes in this tab."); return
        self.refresh_tree(); self.notify("Saved: " + "; ".join(chg))
    def action_save_cfg(self) -> None:
        tid = self.query_one("#tabs", TabbedContent).active or "tab_use"
        self._save_tab(tid.replace("tab_", ""))

def main() -> None:
    try: ensure_gentoo_os(); GentoolCfgApp().run()
    except RuntimeError as exc: raise SystemExit(f"ERROR: {exc}")
