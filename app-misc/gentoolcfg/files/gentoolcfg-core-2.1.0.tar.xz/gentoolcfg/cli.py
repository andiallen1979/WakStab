import os, re, subprocess
from datetime import datetime
from pathlib import Path
from rich.style import Style
from textual.app import App, ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import Button, Checkbox, Footer, Input, Label, ListItem, ListView, Select, TabbedContent, TabPane, TextArea, Tree
from gentoolcfg.extras import KERNEL_CFG_DIR, apply_tty_resolution, detect_drm_modes, kernel_summary, list_backups, list_kernel_snippets, read_build_monitor, unified_diff_lines
from gentoolcfg.portage_io import ENV_PROFILES_DIR, collect_portage_state, ensure_gentoo_os

PROTECTED_KEYS = ("BINPKG_GPG_SIGNING_GPG_HOME", "BINPKG_GPG_SIGNING_KEY", "BINPKG_GPG_VERIFY_GPG_HOME", "SECUREBOOT_SIGN_KEY", "SECUREBOOT_SIGN_CERT", "MODULES_SIGN_KEY", "MODULES_SIGN_CERT")

def write_one(base_dir: Path, rel: str, text: str) -> None:
    dst = base_dir / rel; dst.parent.mkdir(parents=True, exist_ok=True)
    if text.strip(): dst.write_text(text if text.endswith("\n") else (text + "\n"), encoding="utf-8")
    else: dst.unlink(missing_ok=True)

def rotate_backup(base_dir: Path, src: Path, prefix: str) -> None:
    if not src.is_file(): return
    bdir = base_dir / ".gentoolcfg-backups"; bdir.mkdir(parents=True, exist_ok=True)
    raw = src.read_text(encoding="utf-8", errors="ignore")
    (bdir / f"{prefix}.{datetime.now().strftime('%Y%m%d-%H%M%S-%f')}.bak").write_text(raw, encoding="utf-8")
    for old in sorted(bdir.glob(f"{prefix}.*.bak"))[:-10]: old.unlink(missing_ok=True)

def filter_make_conf(raw: str, show_cmt: bool, prot_keys: bool) -> str:
    out = []
    for ln in raw.splitlines():
        st = ln.strip()
        if prot_keys and any(st.startswith(f"{k}=") for k in PROTECTED_KEYS): continue
        if not show_cmt and (not st or st.startswith("#")): continue
        out.append(ln)
    return "\n".join(out)

APP_CSS = """
Screen { layout: vertical; }
#top_menu { height: 1; background: $primary-darken-2; padding: 0 1; }
.m_btn { height: 1; min-width: 6; border: none; background: transparent; padding: 0 1; margin-right: 1; }
.m_btn:hover { background: $accent 40%; }
#main_split { height: 1fr; }
#left_pane { width: 34%; border: round $accent; padding: 0 1; }
#right_pane { width: 66%; border: round $accent; padding: 0 1; }
#pkg_filter, .bar Input { height: 1; border: none; background: $surface-lighten-1; padding: 0 1; }
Checkbox { height: 1; border: none; padding: 0; background: transparent; }
Button { height: 1; min-width: 4; border: none; padding: 0 1; margin-left: 1; }
.flat_link { background: transparent; color: $accent-lighten-2; text-style: underline; }
.bar { height: 1; margin-bottom: 1; }
.right_bar { height: 1; align: right middle; margin-top: 1; }
#pat_sel { width: 28; height: 3; }
#pkg_tree, #tabs, #env_split, #mc_tabs, #pat_tabs, #k_split, TextArea { height: 1fr; }
#env_list_pane, #k_list_pane, .bk_list { width: 36%; border-right: solid $surface-lighten-2; padding-right: 1; }
#env_edit_pane, #k_edit_pane, .bk_diff { width: 64%; padding-left: 1; }
#modal_box { width: 62; height: auto; border: round $accent; background: $surface; padding: 1 2; }
#modal_btns { height: 1; align: right middle; margin-top: 1; }
CreatePatchModal, RestoreConfirmModal, ResolutionModal, UnlockKeysModal, ConfirmModal { align: center middle; }
"""

class MakeConfTextArea(TextArea):
    def get_line(self, line_index: int):
        line = super().get_line(line_index); raw = line.plain
        if raw.lstrip().startswith("#"): line.stylize(Style(color="#6272a4")); return line
        for m in re.finditer(r"^\s*([A-Za-z_][A-Za-z0-9_]*)", raw): line.stylize(Style(color="#ff5555", bold=True), m.start(1), m.end(1))
        for m in re.finditer(r"=", raw): line.stylize(Style(color="#f1fa8c", bold=True), m.start(), m.end())
        for m in re.finditer(r"['\"]", raw): line.stylize(Style(color="#50fa7b", bold=True), m.start(), m.end())
        for m in re.finditer(r"(?<=[\s'\"])-[A-Za-z0-9_+.:=-]+", raw): line.stylize(Style(color="#55aaff", bold=True), m.start(), m.end())
        return line

class DiffTextArea(TextArea):
    def get_line(self, line_index: int):
        line = super().get_line(line_index); raw = line.plain
        if raw.startswith(("+++", "---")): line.stylize(Style(color="#8be9fd", bold=True))
        elif raw.startswith("@@"): line.stylize(Style(color="#bd93f9", bold=True))
        elif raw.startswith("+"): line.stylize(Style(color="#50fa7b", bold=True))
        elif raw.startswith("-"): line.stylize(Style(color="#ff5555", bold=True))
        return line

def generate_diff_patch(orig_p: str, mod_p: str, out_dir: Path, name: str) -> Path:
    o, m = Path(orig_p).expanduser(), Path(mod_p).expanduser()
    if not o.exists() or not m.exists(): raise ValueError("Both Original and Modified paths must exist.")
    fn = Path(name.strip() or "custom.patch").name
    if not fn.endswith(".patch"): fn += ".patch"
    res = subprocess.run(("diff", "-Naur", str(o), str(m)), capture_output=True, text=True)
    if res.returncode not in (0, 1): raise ValueError(res.stderr.strip() or "diff failed")
    if not res.stdout.strip(): raise ValueError("No differences found.")
    out_dir.mkdir(parents=True, exist_ok=True); dst = out_dir / fn; dst.write_text(res.stdout, encoding="utf-8"); return dst

def trash_or_delete_patch(base_dir: Path, cp: str, pt: dict, temp: bool) -> None:
    src = Path(pt.get("path"))
    if not src.exists(): return
    if temp:
        tdir = base_dir / ".gentoolcfg-patch-trash" / cp; tdir.mkdir(parents=True, exist_ok=True); src.replace(tdir / src.name)
    else: src.unlink(missing_ok=True)

def list_trashed_patches(base_dir: Path, cp: str) -> list[Path]:
    tdir = base_dir / ".gentoolcfg-patch-trash" / cp
    return sorted(tdir.glob("*.patch*")) if tdir.is_dir() else []

def restore_trashed_patch(base_dir: Path, cp: str, trashed: Path) -> Path:
    dst_dir = base_dir / "patches" / cp; dst_dir.mkdir(parents=True, exist_ok=True)
    dst = dst_dir / trashed.name; trashed.replace(dst); return dst

class CreatePatchModal(ModalScreen):
    def __init__(self, def_name: str = "custom.patch") -> None: super().__init__(); self.def_name = def_name
    def compose(self) -> ComposeResult:
        with Vertical(id="modal_box"):
            yield Label("[b]Create Diff Patch[/b]"); yield Input(placeholder="Original path...", id="cp_orig")
            yield Input(placeholder="Modified path...", id="cp_mod"); yield Input(value=self.def_name, id="cp_name")
            with Horizontal(id="modal_btns"): yield Button("Create", id="ok"); yield Button("Cancel", id="no")
    def on_button_pressed(self, ev: Button.Pressed) -> None:
        self.dismiss((self.query_one("#cp_orig", Input).value, self.query_one("#cp_mod", Input).value, self.query_one("#cp_name", Input).value) if ev.button.id == "ok" else None)

class RestoreConfirmModal(ModalScreen):
    def __init__(self, items: list[Path]) -> None: super().__init__(); self.items = list(reversed(items))
    def compose(self) -> ComposeResult:
        opts = tuple((p.name, str(p)) for p in self.items)
        with Vertical(id="modal_box"):
            yield Label("[b]Confirm Patch Restoration[/b]"); yield Select(opts, value=opts[0][1], allow_blank=False, id="rst_sel")
            with Horizontal(id="modal_btns"): yield Button("Restore", id="ok"); yield Button("Cancel", id="no")
    def on_button_pressed(self, ev: Button.Pressed) -> None:
        self.dismiss(Path(str(self.query_one("#rst_sel", Select).value)) if ev.button.id == "ok" else None)

class ResolutionModal(ModalScreen):
    def compose(self) -> ComposeResult:
        opts = tuple((m, m) for m in detect_drm_modes())
        with Vertical(id="modal_box"):
            yield Label("[b]TTY Display Resolution[/b]"); yield Select(opts, value=opts[0][1], allow_blank=False, id="res_sel")
            with Horizontal(id="modal_btns"): yield Button("Apply", id="ok"); yield Button("Auto-Native", id="auto"); yield Button("Cancel", id="no")
    def on_button_pressed(self, ev: Button.Pressed) -> None:
        if ev.button.id == "auto": self.dismiss(detect_drm_modes()[0])
        elif ev.button.id == "ok": self.dismiss(str(self.query_one("#res_sel", Select).value))
        else: self.dismiss(None)

class UnlockKeysModal(ModalScreen):
    def compose(self) -> ComposeResult:
        with Vertical(id="modal_box"):
            yield Label("[b]Type capital YES to unlock signing keys:[/b]"); yield Input(placeholder="YES", id="yes_in")
            with Horizontal(id="modal_btns"): yield Button("Unlock", id="ok"); yield Button("Cancel", id="no")
    def on_button_pressed(self, ev: Button.Pressed) -> None: self.dismiss(ev.button.id == "ok" and self.query_one("#yes_in", Input).value.strip() == "YES")

class ConfirmModal(ModalScreen):
    def __init__(self, title: str, body: str) -> None: super().__init__(); self.t = title; self.b = body
    def compose(self) -> ComposeResult:
        with Vertical(id="modal_box"):
            yield Label(f"[b]{self.t}[/b]"); yield Label(self.b)
            with Horizontal(id="modal_btns"): yield Button("Yes", id="yes"); yield Button("No", id="no")
    def on_button_pressed(self, ev: Button.Pressed) -> None: self.dismiss(ev.button.id == "yes")

class CfgStore:
    def __init__(self) -> None:
        self.state = collect_portage_state(); self.pkg_map = {p.get("cp"): p for p in self.state.get("packages", ())}
        self.orig_mc = self.state.get("mc_text", ""); self.cur_mc = self.orig_mc
        for p in self.state.get("packages", ()):
            p.update({"cur_flags": {f.get("flag"): bool(f.get("effective")) for f in p.get("flags", ())}, "orig_flags": {f.get("flag"): bool(f.get("effective")) for f in p.get("flags", ())}, "cur_envs": {e.get("name") for e in p.get("envs", ()) if e.get("initial")}, "orig_envs": {e.get("name") for e in p.get("envs", ()) if e.get("initial")}, "cur_kw": {"amd64": bool(p.get("kw_s")), "~amd64": bool(p.get("kw_t")), "**": bool(p.get("kw_l"))}, "orig_kw": {k for k, v in (("amd64", p.get("kw_s")), ("~amd64", p.get("kw_t")), ("**", p.get("kw_l"))) if v}, "cur_kw_mode": p.get("kw_mode", "ALL"), "orig_kw_mode": p.get("kw_mode", "ALL"), "cur_mask": p.get("mask_mode", "NONE"), "orig_mask": p.get("mask_mode", "NONE"), "cur_unmask": p.get("unmask_mode", "NONE"), "orig_unmask": p.get("unmask_mode", "NONE")})
    def _base(self) -> Path: return Path("/etc/portage") if os.geteuid() == 0 else (Path.cwd() / "portage-preview")
    def _atom(self, cp: str, cpv: str, mode: str) -> str: return f"={cpv}" if mode == "EQ" else (f">={cpv}" if mode == "FWD" else cp)
    def _write_pkg_line(self, sub: str, cp: str, line: str) -> None:
        d = self._base() / sub
        if d.is_file():
            keep = [ln for ln in d.read_text(encoding="utf-8", errors="ignore").splitlines() if cp not in ln.split()]
            if line: keep.append(line)
            d.write_text(("\n".join(keep) + "\n") if keep else "", encoding="utf-8")
        else:
            d.mkdir(parents=True, exist_ok=True); f = d / cp.replace("/", "_")
            f.write_text(line + "\n", encoding="utf-8") if line else f.unlink(missing_ok=True)
    def save_scope(self, scope: str, pkg: dict | None = None) -> list[str]:
        chg = []
        if scope == "mc" and self.cur_mc != self.orig_mc:
            mc_dst = self._base() / "make.conf"; mc_dst.parent.mkdir(parents=True, exist_ok=True)
            rotate_backup(self._base(), mc_dst, "make.conf")
            mc_dst.write_text(self.cur_mc if self.cur_mc.endswith("\n") else (self.cur_mc + "\n"), encoding="utf-8")
            self.orig_mc = self.cur_mc; chg.append("MAKE.CONF: updated /etc/portage/make.conf")
        elif pkg:
            cp, cpv = pkg.get("cp"), pkg.get("cpv")
            if scope == "use" and pkg.get("cur_flags") != pkg.get("orig_flags"):
                inst = {f.get("flag"): bool(f.get("installed")) for f in pkg.get("flags", ())}
                toks = [f"{'' if v else '-'}{k}" for k, v in sorted(pkg.get("cur_flags").items()) if v != inst.get(k) or v != pkg.get("orig_flags").get(k)]
                self._write_pkg_line("package.use", cp, f"{cp} {' '.join(toks)}" if toks else "")
                pkg["orig_flags"] = dict(pkg.get("cur_flags")); chg.append(f"USE {cp}: {' '.join(toks) or '(reset)'}")
            elif scope == "env" and pkg.get("cur_envs") != pkg.get("orig_envs"):
                self._write_pkg_line("package.env", cp, f"{cp} {' '.join(sorted(pkg.get('cur_envs')))}" if pkg.get("cur_envs") else "")
                pkg["orig_envs"] = set(pkg.get("cur_envs")); chg.append(f"ENV {cp}: {' '.join(sorted(pkg.get('cur_envs'))) or '(none)'}")
            elif scope == "kw":
                ak = tuple(k for k in ("amd64", "~amd64", "**") if pkg.get("cur_kw", {}).get(k))
                if set(ak) != pkg.get("orig_kw") or pkg.get("cur_kw_mode") != pkg.get("orig_kw_mode"):
                    self._write_pkg_line("package.accept_keywords", cp, f"{self._atom(cp, cpv, pkg.get('cur_kw_mode'))} {' '.join(ak)}" if ak else "")
                    pkg["orig_kw"] = set(ak); pkg["orig_kw_mode"] = pkg.get("cur_kw_mode"); chg.append(f"KW {cp}: {' '.join(ak) or '(none)'}")
                if pkg.get("cur_mask") != pkg.get("orig_mask"):
                    self._write_pkg_line("package.mask", cp, self._atom(cp, cpv, pkg.get("cur_mask")) if pkg.get("cur_mask") != "NONE" else "")
                    pkg["orig_mask"] = pkg.get("cur_mask"); chg.append(f"MASK {cp}: {pkg.get('cur_mask')}")
                if pkg.get("cur_unmask") != pkg.get("orig_unmask"):
                    self._write_pkg_line("package.unmask", cp, self._atom(cp, cpv, pkg.get("cur_unmask")) if pkg.get("cur_unmask") != "NONE" else "")
                    pkg["orig_unmask"] = pkg.get("cur_unmask"); chg.append(f"UNMASK {cp}: {pkg.get('cur_unmask')}")
        return chg

class GentoolCfgApp(App):
    TITLE, CSS = "gentoolcfg 2.1.0", APP_CSS
    BINDINGS = [("ctrl+s", "save_tab", "Save"), ("ctrl+q", "quit", "Quit"), ("f5", "reload_cfg", "Refresh"), ("ctrl+left", "shrink_left", "Narrow"), ("ctrl+right", "grow_left", "Widen")]
    def __init__(self) -> None:
        super().__init__(); self.store = CfgStore(); self.cur_pkg = None; self.active_env = ""; self.active_kcfg = ""; self.lw = 34
    def compose(self) -> ComposeResult:
        with Horizontal(id="top_menu"):
            for bid, lbl in (("m_ref", "File:Refresh"), ("m_sav", "Save Tab"), ("m_res", "Display:Resolution"), ("m_mon", "Monitor:Now"), ("m_quit", "Quit")):
                yield Button(lbl, id=bid, classes="m_btn")
        with Horizontal(id="main_split"):
            with Vertical(id="left_pane"):
                yield Input(placeholder="Filter packages...", id="pkg_filter"); yield Tree("Packages", id="pkg_tree")
            with Vertical(id="right_pane"):
                yield Label("Select a package on the left.", id="pkg_hdr")
                with TabbedContent(id="tabs"):
                    with TabPane("USE", id="t_use"):
                        with Horizontal(classes="bar"):
                            yield Input(placeholder="Filter USE...", id="use_filter"); yield Button("Save USE", id="sv_use", classes="flat_link")
                        yield VerticalScroll(id="use_list")
                    with TabPane("Environment", id="t_env"):
                        with Horizontal(id="env_split"):
                            with Vertical(id="env_list_pane"):
                                yield VerticalScroll(id="env_list")
                                with Horizontal(classes="right_bar"): yield Button("Save All", id="sv_env", classes="flat_link")
                            with Vertical(id="env_edit_pane"):
                                with Horizontal(classes="bar"):
                                    yield Input(placeholder="profile.conf", id="env_name"); yield Button("+", id="e_new"); yield Button("Save", id="e_sav"); yield Button("Del", id="e_del")
                                yield TextArea("", id="env_editor")
                    with TabPane("Keywords", id="t_kw"):
                        yield VerticalScroll(id="kw_list")
                        with Horizontal(classes="right_bar"): yield Button("Save Keywords", id="sv_kw", classes="flat_link")
                    yield from self._compose_extra()
        yield Footer()

    def _compose_extra(self):
        with TabPane("Patches", id="t_pat"):
            with TabbedContent(id="pat_tabs"):
                with TabPane("Patch Viewer", id="pt_v"):
                    with Horizontal(classes="bar"):
                        yield Select((("No patches", "NONE"),), value="NONE", allow_blank=False, id="pat_sel")
                        for bid, lbl in (("pt_new", "Create"), ("pt_rst", "Restore"), ("pt_rm", "Remove"), ("pt_del", "Delete")): yield Button(lbl, id=bid)
                        yield Checkbox("#", value=False, id="pat_cmt")
                    yield DiffTextArea("", read_only=True, id="pat_editor")
                with TabPane("Backups / Diff", id="pt_b"):
                    with Horizontal(classes="bar"): yield ListView(id="pt_bk_list", classes="bk_list"); yield DiffTextArea("", read_only=True, id="pt_bk_diff", classes="bk_diff")
        with TabPane("make.conf", id="t_mc"):
            with TabbedContent(id="mc_tabs"):
                with TabPane("Editor", id="mc_e"):
                    yield MakeConfTextArea("", id="mc_editor")
                    with Horizontal(classes="bar"):
                        for bid, lbl in (("mc_undo", "Undo"), ("mc_redo", "Redo"), ("mc_cut", "Cut"), ("mc_copy", "Copy"), ("mc_paste", "Paste"), ("mc_all", "All")): yield Button(lbl, id=bid)
                        yield Checkbox("Protect keys", value=True, id="chk_keys"); yield Checkbox("#", value=False, id="chk_comments"); yield Button("Save make.conf", id="sv_mc", classes="flat_link")
                with TabPane("Backups / Diff", id="mc_b"):
                    with Horizontal(classes="bar"): yield ListView(id="mc_bk_list", classes="bk_list"); yield DiffTextArea("", read_only=True, id="mc_bk_diff", classes="bk_diff")
        with TabPane("Build Monitor", id="t_mon"):
            with Horizontal(classes="bar"): yield Checkbox("Auto-refresh (2s)", value=True, id="mon_auto"); yield Button("Refresh Now", id="mon_now")
            yield TextArea("", read_only=True, id="mon_ed")
        with TabPane("Kernel Config", id="t_kern"):
            yield Label(kernel_summary());
            with Horizontal(id="k_split"):
                yield ListView(id="k_list", classes="bk_list")
                with Vertical(id="k_edit_pane"):
                    with Horizontal(classes="bar"):
                        yield Input(placeholder="snippet.config", id="k_name"); yield Button("+", id="k_new"); yield Button("Save", id="k_sav"); yield Button("Del", id="k_del")
                    yield MakeConfTextArea("", id="k_ed")

    def on_mount(self) -> None:
        self.query_one("#pkg_tree", Tree).show_root = False
        if not os.environ.get("DISPLAY") and not os.environ.get("WAYLAND_DISPLAY"):
            self.notify(apply_tty_resolution(detect_drm_modes()[0]))
        self._ref_mc(); self._ref_tree(); self._ref_mon(); self._ref_kern()
        self.set_interval(2.0, lambda: self._ref_mon() if self.query_one("#mon_auto", Checkbox).value and self.query_one("#tabs", TabbedContent).active == "t_mon" else None)
    def action_shrink_left(self) -> None:
        self.lw = max(20, self.lw - 3); self.query_one("#left_pane").styles.width = f"{self.lw}%"; self.query_one("#right_pane").styles.width = f"{100 - self.lw}%"
    def action_grow_left(self) -> None:
        self.lw = min(60, self.lw + 3); self.query_one("#left_pane").styles.width = f"{self.lw}%"; self.query_one("#right_pane").styles.width = f"{100 - self.lw}%"
    def _ref_mon(self) -> None: self.query_one("#mon_ed", TextArea).load_text(read_build_monitor())
    def _ref_kern(self) -> None:
        lv = self.query_one("#k_list", ListView); lv.clear()
        for p in list_kernel_snippets(): lv.append(ListItem(Label(p.name), name=p.name))
    def _ref_mc(self) -> None:
        sc, pk = self.query_one("#chk_comments", Checkbox).value, self.query_one("#chk_keys", Checkbox).value
        self.query_one("#mc_editor", MakeConfTextArea).load_text(filter_make_conf(self.store.cur_mc, sc, pk))
        lv = self.query_one("#mc_bk_list", ListView); lv.clear()
        for p in list_backups(self.store._base(), "make.conf"): lv.append(ListItem(Label(p.name), name=p.name))
    def _ref_tree(self) -> None:
        t = self.query_one("#pkg_tree", Tree); t.clear(); q = self.query_one("#pkg_filter", Input).value.strip().lower(); by_c = {}
        for p in self.store.state.get("packages", ()): by_c.setdefault(p.get("cat"), []).append(p)
        for cat in sorted(by_c):
            ms = [p for p in by_c[cat] if not q or q in p.get("cp", "").lower()]
            if not ms: continue
            nd = t.root.add(f"{cat} ({len(ms)})", expand=bool(q))
            for p in ms: nd.add_leaf(p.get("name"), data=p.get("cp"))
    def _reb_pkg(self) -> None:
        p = self.cur_pkg
        if not p: return
        self.query_one("#pkg_hdr", Label).update(f"[b]{p.get('cpv')}[/b]")
        ul = self.query_one("#use_list", VerticalScroll); ul.remove_children(); qf = self.query_one("#use_filter", Input).value.strip().lower()
        for f in p.get("flags", ()):
            fl = f.get("flag")
            if not qf or qf in fl.lower(): ul.mount(Checkbox(fl, value=bool(p.get("cur_flags", {}).get(fl)), name=f"use:{fl}"))
        el = self.query_one("#env_list", VerticalScroll); el.remove_children()
        for e in p.get("envs", ()):
            en = e.get("name"); el.mount(Horizontal(Checkbox("", value=(en in p.get("cur_envs", set())), name=f"env:{en}"), Button(en, name=f"edenv:{en}")))
        kl = self.query_one("#kw_list", VerticalScroll); kl.remove_children()
        cur_k = next((k for k in ("**", "~amd64", "amd64") if p.get("cur_kw", {}).get(k)), "NONE")
        kl.mount(Label("Accept Keyword:"), Select((("(none)", "NONE"), ("amd64", "amd64"), ("~amd64", "~amd64"), ("**", "**")), value=cur_k, allow_blank=False, name="sel:kw"))
        kl.mount(Label("Keyword Scope:"), Select((("All", "ALL"), ("Exact (=)", "EQ"), ("Forward (>=)", "FWD")), value=p.get("cur_kw_mode", "ALL"), allow_blank=False, name="sel:cur_kw_mode"))
        kl.mount(Label("Package Mask:"), Select((("Unmasked", "NONE"), ("All", "ALL"), ("Exact (=)", "EQ"), ("Forward (>=)", "FWD")), value=p.get("cur_mask", "NONE"), allow_blank=False, name="sel:cur_mask"))
        kl.mount(Label("Package Unmask:"), Select((("None", "NONE"), ("All", "ALL"), ("Exact (=)", "EQ"), ("Forward (>=)", "FWD")), value=p.get("cur_unmask", "NONE"), allow_blank=False, name="sel:cur_unmask"))
        self._reb_pat()

    def _cur_pt(self):
        bn = str(self.query_one("#pat_sel", Select).value)
        return next((x for x in (self.cur_pkg.get("patches", ()) if self.cur_pkg else ()) if x.get("base_name") == bn), None)
    def _reb_pat(self) -> None:
        pts = self.cur_pkg.get("patches", ()) if self.cur_pkg else ()
        opts = tuple((x.get("base_name"), x.get("base_name")) for x in pts) if pts else (("No patches", "NONE"),)
        sel = self.query_one("#pat_sel", Select); sel.set_options(opts); sel.value = opts[0][1]; self._load_pt()
    def _load_pt(self) -> None:
        pt = self._cur_pt(); ed = self.query_one("#pat_editor", DiffTextArea); lv = self.query_one("#pt_bk_list", ListView); lv.clear()
        if not pt or not self.cur_pkg: ed.load_text(""); return
        raw = Path(pt.get("path")).read_text(encoding="utf-8", errors="ignore") if Path(pt.get("path")).is_file() else ""
        ed.load_text(filter_make_conf(raw, self.query_one("#pat_cmt", Checkbox).value, False))
        for p in list_backups(self.store._base(), f"patch-{self.cur_pkg.get('cp').replace('/', '_')}-{pt.get('base_name')}"): lv.append(ListItem(Label(p.name), name=p.name))
    def on_tree_node_selected(self, ev: Tree.NodeSelected) -> None:
        if ev.node.data: self.cur_pkg = self.store.pkg_map.get(ev.node.data); self._reb_pkg()
    def on_input_changed(self, ev: Input.Changed) -> None:
        if ev.input.id == "pkg_filter": self._ref_tree()
        elif ev.input.id == "use_filter": self._reb_pkg()
    def on_list_view_selected(self, ev: ListView.Selected) -> None:
        nm = ev.item.name or ""
        if ev.list_view.id == "mc_bk_list":
            old = (self.store._base() / ".gentoolcfg-backups" / nm).read_text(encoding="utf-8", errors="ignore")
            self.query_one("#mc_bk_diff", DiffTextArea).load_text(unified_diff_lines(old, self.store.cur_mc, nm, "current make.conf"))
        elif ev.list_view.id == "pt_bk_list":
            old = (self.store._base() / ".gentoolcfg-backups" / nm).read_text(encoding="utf-8", errors="ignore")
            self.query_one("#pt_bk_diff", DiffTextArea).load_text(unified_diff_lines(old, self.query_one("#pat_editor", DiffTextArea).text, nm, "current patch"))
        elif ev.list_view.id == "k_list":
            self.active_kcfg = nm; self.query_one("#k_name", Input).value = nm
            self.query_one("#k_ed", MakeConfTextArea).load_text((KERNEL_CFG_DIR / nm).read_text(encoding="utf-8", errors="ignore"))
    def on_select_changed(self, ev: Select.Changed) -> None:
        if ev.select.id == "pat_sel": self._load_pt(); return
        nm = ev.select.name or ""
        if self.cur_pkg and nm.startswith("sel:"):
            k, v = nm.split(":", 1)[1], str(ev.value)
            if k == "kw": self.cur_pkg["cur_kw"] = {x: (x == v) for x in ("amd64", "~amd64", "**")}
            else: self.cur_pkg[k] = v
    def on_checkbox_changed(self, ev: Checkbox.Changed) -> None:
        if ev.checkbox.id == "pat_cmt": self._load_pt(); return
        if ev.checkbox.id in ("chk_comments", "chk_keys"):
            if ev.checkbox.id == "chk_keys" and not ev.value:
                self.push_screen(UnlockKeysModal(), lambda ok: self._ref_mc() if ok else setattr(ev.checkbox, "value", True))
            else: self._ref_mc()
            return
        nm = ev.checkbox.name or ""
        if self.cur_pkg and nm.startswith("use:"): self.cur_pkg["cur_flags"][nm[4:]] = ev.value
        elif self.cur_pkg and nm.startswith("env:"): (self.cur_pkg["cur_envs"].add if ev.value else self.cur_pkg["cur_envs"].discard)(nm[4:])
    def on_text_area_changed(self, ev: TextArea.Changed) -> None:
        if ev.text_area.id == "mc_editor" and self.query_one("#chk_comments", Checkbox).value:
            kept = [] if not self.query_one("#chk_keys", Checkbox).value else [ln for ln in self.store.cur_mc.splitlines() if any(ln.strip().startswith(f"{k}=") for k in PROTECTED_KEYS)]
            self.store.cur_mc = chr(10).join(kept + ev.text_area.text.splitlines())
    def action_reload_cfg(self) -> None: self.store = CfgStore(); self._ref_mc(); self._ref_tree(); self._ref_mon(); self._ref_kern()
    def action_save_tab(self) -> None:
        m = {"t_use": "use", "t_env": "env", "t_kw": "kw", "t_mc": "mc"}.get(self.query_one("#tabs", TabbedContent).active)
        if m: chg = self.store.save_scope(m, self.cur_pkg); self.notify(chr(10).join(chg) if chg else "No pending changes."); self._ref_mc()
    def on_button_pressed(self, ev: Button.Pressed) -> None:
        bid = ev.button.id or ""; bnm = ev.button.name or ""
        if bid == "m_quit": self.exit()
        elif bid == "m_ref": self.action_reload_cfg()
        elif bid == "m_sav": self.action_save_tab()
        elif bid == "m_mon": self._ref_mon()
        elif bid == "m_res": self.push_screen(ResolutionModal(), lambda r: self.notify(apply_tty_resolution(r)) if r else None)
        elif bid.startswith("sv_"): chg = self.store.save_scope(bid[3:], self.cur_pkg); self.notify(chr(10).join(chg) if chg else "No changes."); self._ref_mc()
        elif bnm.startswith("edenv:"):
            self.active_env = bnm[6:]; self.query_one("#env_name", Input).value = self.active_env
            f = ENV_PROFILES_DIR / self.active_env; self.query_one("#env_editor", TextArea).load_text(f.read_text(encoding="utf-8", errors="ignore") if f.is_file() else "")
        elif bid == "e_new": self.active_env = ""; self.query_one("#env_name", Input).value = "custom.conf"; self.query_one("#env_editor", TextArea).load_text('MAKEOPTS="-j8 -l8"' + chr(10))
        elif bid == "e_sav":
            fn = Path(self.query_one("#env_name", Input).value.strip()).name
            if fn: write_one(ENV_PROFILES_DIR, fn if fn.endswith(".conf") else f"{fn}.conf", self.query_one("#env_editor", TextArea).text); self.action_reload_cfg()
        elif bid == "e_del" and self.active_env: (ENV_PROFILES_DIR / self.active_env).unlink(missing_ok=True); self.action_reload_cfg()
        elif bid == "k_new": self.active_kcfg = ""; self.query_one("#k_name", Input).value = "custom.config"; self.query_one("#k_ed", MakeConfTextArea).load_text("CONFIG_EXPERT=y" + chr(10))
        elif bid == "k_sav":
            fn = Path(self.query_one("#k_name", Input).value.strip()).name
            if fn: fn = fn if fn.endswith(".config") else f"{fn}.config"; rotate_backup(self.store._base(), KERNEL_CFG_DIR / fn, f"kcfg-{fn}"); write_one(KERNEL_CFG_DIR, fn, self.query_one("#k_ed", MakeConfTextArea).text); self._ref_kern()
        elif bid == "k_del" and self.active_kcfg: (KERNEL_CFG_DIR / self.active_kcfg).unlink(missing_ok=True); self._ref_kern()
        elif bid == "pt_new" and self.cur_pkg:
            self.push_screen(CreatePatchModal(), lambda r: self._mk_pt(r) if r else None)
        elif bid == "pt_rst" and self.cur_pkg:
            its = list_trashed_patches(self.store._base(), self.cur_pkg.get("cp"))
            if its: self.push_screen(RestoreConfirmModal(its), lambda p: self._do_rst(p) if p else None)
            else: self.notify("No stashed patches.")
        elif bid == "pt_rm" and self._cur_pt():
            pt = self._cur_pt(); self.push_screen(ConfirmModal("Stash Patch", f"Move {pt.get('base_name')} to stash?"), lambda ok: self._do_rm(pt, True) if ok else None)
        elif bid == "pt_del" and self._cur_pt():
            pt = self._cur_pt(); self.push_screen(ConfirmModal("Delete Patch", f"Permanently delete {pt.get('base_name')}?"), lambda ok: self._do_rm(pt, False) if ok else None)
        elif bid.startswith("mc_"):
            ed = self.query_one("#mc_editor", MakeConfTextArea); a = bid[3:]
            if a == "undo": ed.action_undo()
            elif a == "redo": ed.action_redo()
            elif a == "cut" and ed.selected_text: self.copy_to_clipboard(ed.selected_text); ed.replace("", *ed.selection)
            elif a == "copy" and ed.selected_text: self.copy_to_clipboard(ed.selected_text)
            elif a == "paste": ed.action_paste()
            elif a == "all": ed.select_all()
    def _mk_pt(self, r) -> None:
        cp = self.cur_pkg.get("cp"); dst = generate_diff_patch(r[0], r[1], self.store._base() / "patches" / cp, r[2])
        rotate_backup(self.store._base(), dst, f"patch-{cp.replace('/', '_')}-{dst.name}")
        self.cur_pkg.setdefault("patches", []).append({"base_name": dst.name, "path": str(dst), "enabled": True}); self._reb_pat()
    def _do_rst(self, p: Path) -> None:
        dst = restore_trashed_patch(self.store._base(), self.cur_pkg.get("cp"), p)
        self.cur_pkg.setdefault("patches", []).append({"base_name": dst.name, "path": str(dst), "enabled": True}); self._reb_pat()
    def _do_rm(self, pt: dict, temp: bool) -> None:
        rotate_backup(self.store._base(), Path(pt.get("path")), f"patch-{self.cur_pkg.get('cp').replace('/', '_')}-{pt.get('base_name')}")
        trash_or_delete_patch(self.store._base(), self.cur_pkg.get("cp"), pt, temp)
        self.cur_pkg["patches"] = [x for x in self.cur_pkg.get("patches", ()) if x is not pt]; self._reb_pat()

def main() -> None:
    try: ensure_gentoo_os(); GentoolCfgApp().run()
    except RuntimeError as exc: raise SystemExit(f"ERROR: {exc}")
