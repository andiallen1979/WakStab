import os, re, subprocess, sys
from pathlib import Path
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor, QKeySequence, QShortcut, QSyntaxHighlighter, QTextCharFormat
from PyQt6.QtWidgets import QApplication, QCheckBox, QComboBox, QDialog, QFileDialog, QHBoxLayout, QInputDialog, QLabel, QLineEdit, QMainWindow, QMessageBox, QPlainTextEdit, QPushButton, QScrollArea, QSplitter, QTabWidget, QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget
from gentoolcfg.cli import CfgStore, PROTECTED_KEYS, filter_make_conf, generate_diff_patch, list_trashed_patches, restore_trashed_patch, trash_or_delete_patch, write_one
from gentoolcfg.portage_io import ENV_PROFILES_DIR, ensure_gentoo_os

class MakeConfHighlighter(QSyntaxHighlighter):
    def highlightBlock(self, text: str) -> None:
        def fmt(hx, bold=False):
            f = QTextCharFormat(); f.setForeground(QColor(hx)); f.setFontWeight(700 if bold else 400); return f
        if text.lstrip().startswith("#"): self.setFormat(0, len(text), fmt("#6272a4")); return
        for m in re.finditer(r"^\s*([A-Za-z_][A-Za-z0-9_]*)", text): self.setFormat(m.start(1), m.end(1) - m.start(1), fmt("#ff5555", True))
        for m in re.finditer(r"=", text): self.setFormat(m.start(), 1, fmt("#f1fa8c", True))
        for m in re.finditer(r"['\"]", text): self.setFormat(m.start(), 1, fmt("#50fa7b", True))
        for m in re.finditer(r"(?<=[\s'\"])-[A-Za-z0-9_+.:=-]+", text): self.setFormat(m.start(), m.end() - m.start(), fmt("#55aaff", True))


def _flat_link(text: str, fn) -> QPushButton:
    b = QPushButton(text); b.setFlat(True); b.setCursor(Qt.CursorShape.PointingHandCursor)
    b.setStyleSheet("QPushButton { border: none; padding: 2px 6px; color: #3daee9; font-weight: 600; } QPushButton:hover { text-decoration: underline; }")
    b.clicked.connect(fn); return b

def _compact_btn(text: str, fn) -> QPushButton:
    b = QPushButton(text); b.setStyleSheet("padding: 2px 8px;"); b.clicked.connect(fn); return b

class GentoolCfgQt(QMainWindow):
    def __init__(self) -> None:
        super().__init__(); self.setWindowTitle("gentoolcfg"); self.resize(1180, 740)
        self.store = CfgStore(); self.cur_pkg = None; self.active_env = ""; self.dark = True
        root = QWidget(); self.setCentralWidget(root); lay = QVBoxLayout(root)
        sp = QSplitter(Qt.Orientation.Horizontal); lay.addWidget(sp, 1)
        lw = QWidget(); ll = QVBoxLayout(lw); sp.addWidget(lw)
        self.q_in = QLineEdit(); self.q_in.setPlaceholderText("Filter packages..."); self.q_in.textChanged.connect(self._tree); ll.addWidget(self.q_in)
        self.chk_slow = QCheckBox("Sort by longest genlop -t build time first"); self.chk_slow.toggled.connect(self._tree); ll.addWidget(self.chk_slow)
        self.tree = QTreeWidget(); self.tree.setHeaderHidden(True); self.tree.itemSelectionChanged.connect(self._sel); ll.addWidget(self.tree, 1)
        rw = QWidget(); rl = QVBoxLayout(rw); sp.addWidget(rw); sp.setSizes([380, 800])
        self.hdr = QLabel("Select a package on the left."); rl.addWidget(self.hdr)
        self.nb = QTabWidget(); rl.addWidget(self.nb, 1)
        uw = QWidget(); ul = QVBoxLayout(uw); ubar = QHBoxLayout(); self.uf = QLineEdit(); self.uf.setPlaceholderText("Filter USE..."); self.uf.textChanged.connect(self._use); b_ref = QPushButton("Refresh"); b_ref.clicked.connect(self._reload); ubar.addWidget(self.uf); ubar.addWidget(b_ref); bs_u = QPushButton("Save USE"); bs_u.clicked.connect(lambda: self._save_sc("use")); ubar.addWidget(bs_u); ul.addLayout(ubar)
        self.usc = QScrollArea(); self.usc.setWidgetResizable(True); self.ubox = QWidget(); self.ul_in = QVBoxLayout(self.ubox); self.usc.setWidget(self.ubox); ul.addWidget(self.usc, 1); self.nb.addTab(uw, "USE")
        ew = QWidget(); el = QHBoxLayout(ew); el_l = QVBoxLayout(); self.esc = QScrollArea(); self.esc.setWidgetResizable(True); self.ebox = QWidget(); self.el_in = QVBoxLayout(self.ebox); self.esc.setWidget(self.ebox); el_l.addWidget(self.esc, 1); bs_e = QPushButton("Save Env"); bs_e.clicked.connect(lambda: self._save_sc("env")); el_l.addWidget(bs_e); el.addLayout(el_l, 2)
        el_r = QVBoxLayout(); eb = QHBoxLayout(); self.en_in = QLineEdit(); self.en_in.setPlaceholderText("profile.conf"); eb.addWidget(self.en_in)
        for t, fn in (("+", self._env_new), ("Save", self._env_save), ("Del", self._env_del)): b = QPushButton(t); b.clicked.connect(fn); eb.addWidget(b)
        el_r.addLayout(eb); self.eed = QPlainTextEdit(); el_r.addWidget(self.eed, 1); el.addLayout(el_r, 3); self.nb.addTab(ew, "Environment")
        kw_w = QWidget(); kw_outer = QVBoxLayout(kw_w); self.kw_l = QVBoxLayout(); kw_outer.addLayout(self.kw_l, 1); bs_k = QPushButton("Save Keywords"); bs_k.clicked.connect(lambda: self._save_sc("kw")); kw_outer.addWidget(bs_k); self.nb.addTab(kw_w, "Keywords")
        pw = QWidget(); p_outer = QVBoxLayout(pw); p_top = QHBoxLayout()
        self.pat_cb = QComboBox(); self.pat_cb.currentIndexChanged.connect(self._pat_load)
        self.pat_en = QCheckBox("Enabled"); self.pat_en.toggled.connect(self._pat_tog)
        p_top.addWidget(self.pat_cb, 1); p_top.addWidget(self.pat_en); p_outer.addLayout(p_top)
        self.pat_ed = QPlainTextEdit(); self.pat_ed.textChanged.connect(self._pat_chg); p_outer.addWidget(self.pat_ed, 1)
        p_bar = QHBoxLayout()
        for lbl, fn in (("Undo", self.pat_ed.undo), ("Redo", self.pat_ed.redo), ("Cut", self.pat_ed.cut), ("Copy", self.pat_ed.copy), ("Paste", self.pat_ed.paste), ("Delete", lambda: self.pat_ed.textCursor().removeSelectedText()), ("Select All", self.pat_ed.selectAll), ("Create", self._create_patch_qt), ("Remove", self._remove_patch_qt), ("Restore", self._restore_patch_qt)):
            b = QPushButton(lbl); b.clicked.connect(fn); p_bar.addWidget(b)
        p_bar.addStretch(1); self.pat_cmt = QCheckBox("Show comments"); self.pat_cmt.setChecked(False); self.pat_cmt.toggled.connect(self._pat_load)
        bs_p = QPushButton("Save Patches"); bs_p.clicked.connect(lambda: self._save_sc("pat"))
        p_bar.addWidget(self.pat_cmt); p_bar.addWidget(bs_p); p_outer.addLayout(p_bar); self.nb.addTab(pw, "Patches")
        mc_w = QWidget(); mc_v = QVBoxLayout(mc_w); self.mc_ed = QPlainTextEdit(); self.mc_hl = MakeConfHighlighter(self.mc_ed.document()); mc_v.addWidget(self.mc_ed, 1)
        mbar = QHBoxLayout()
        for lbl, fn in (("Undo", self.mc_ed.undo), ("Redo", self.mc_ed.redo), ("Cut", self.mc_ed.cut), ("Copy", self.mc_ed.copy), ("Paste", self.mc_ed.paste), ("Delete", lambda: self.mc_ed.textCursor().removeSelectedText()), ("Select All", self.mc_ed.selectAll)):
            b = QPushButton(lbl); b.clicked.connect(fn); mbar.addWidget(b)
        self.chk_key = QCheckBox("Protect signing keys"); self.chk_key.setChecked(True); self.chk_cmt = QCheckBox("Show comments"); self.chk_cmt.setChecked(False); self.chk_cmt.toggled.connect(lambda _: self._ref_mc()); self.chk_key.toggled.connect(self._tog_key); self.mc_ed.textChanged.connect(self._mc_chg)
        mbar.addStretch(1); bs_m = QPushButton("Save make.conf"); bs_m.clicked.connect(lambda: self._save_sc("mc")); mbar.addWidget(self.chk_key); mbar.addWidget(self.chk_cmt); mbar.addWidget(bs_m); mc_v.addLayout(mbar); self.nb.addTab(mc_w, "make.conf")
        self.chk_cmt.toggled.connect(lambda _: self._ref_mc()); self.chk_key.toggled.connect(self._tog_key); self.mc_ed.textChanged.connect(self._mc_chg)
        QShortcut(QKeySequence("Ctrl+S"), self, self._save); QShortcut(QKeySequence("Ctrl+Q"), self, self.close); QShortcut(QKeySequence("F5"), self, self._reload)
        self._ref_mc(); self._tree()

    def _theme(self) -> None:
        self.dark = not self.dark
        self.setStyleSheet("" if self.dark else "QWidget { background: #eff0f1; color: #232629; }")
    def _ref_mc(self) -> None:
        self.mc_ed.blockSignals(True); self.mc_ed.setPlainText(filter_make_conf(self.store.cur_mc, self.chk_cmt.isChecked(), self.chk_key.isChecked())); self.mc_ed.blockSignals(False)
    def _tog_key(self, v: bool) -> None:
        if v: self._ref_mc(); return
        ans, ok = QInputDialog.getText(self, "Unlock Signing Keys", "Type capital YES to unlock GPG/SecureBoot/Module keys:")
        if ok and ans.strip() == "YES": self._ref_mc()
        else: self.chk_key.blockSignals(True); self.chk_key.setChecked(True); self.chk_key.blockSignals(False)
    def _mc_chg(self) -> None:
        if not self.chk_cmt.isChecked(): return
        if not self.chk_key.isChecked(): self.store.cur_mc = self.mc_ed.toPlainText()
        else:
            kept = [ln for ln in self.store.cur_mc.splitlines() if any(ln.strip().startswith(f"{k}=") for k in PROTECTED_KEYS)]
            self.store.cur_mc = chr(10).join(kept + self.mc_ed.toPlainText().splitlines())
    def _clr(self, lay) -> None:
        while lay.count():
            it = lay.takeAt(0)
            if it.widget(): it.widget().deleteLater()
    def _tree(self) -> None:
        self.tree.clear(); q = self.q_in.text().strip().lower(); by_c = {}
        for p in self.store.state.get("packages", ()): by_c.setdefault(p.get("cat"), []).append(p)
        for cat in sorted(by_c):
            ms = [p for p in by_c.get(cat, ()) if not q or q in p.get("cp", "").lower()]
            if not ms: continue
            top = QTreeWidgetItem([f"{cat} ({len(ms)})"]); self.tree.addTopLevelItem(top); top.setExpanded(bool(q))
            for p in ms: ch = QTreeWidgetItem([p.get("name")]); ch.setData(0, Qt.ItemDataRole.UserRole, p.get("cp")); top.addChild(ch)
    def _sel(self) -> None:
        its = self.tree.selectedItems(); cp = its.__getitem__(0).data(0, Qt.ItemDataRole.UserRole) if its else None
        if not cp: return
        self.cur_pkg = self.store.pkg_map.get(cp); self.hdr.setText(f"{self.cur_pkg.get('cpv')}   |   Last merge: {self.cur_pkg.get('build_fmt')}")
        self._use(); self._env(); self._kw(); self._pat()
    def _use(self) -> None:
        self._clr(self.ul_in); p = self.cur_pkg; qf = self.uf.text().strip().lower()
        if not p: return
        for f in p.get("flags", ()):
            fl = f.get("flag")
            if qf and qf not in fl.lower(): continue
            cb = QCheckBox(f"{fl} *" if f.get("forced") else fl); cb.setChecked(bool(p.get("cur_flags", {}).get(fl)))
            cb.toggled.connect(lambda v, k=fl: p.get("cur_flags").update({k: v})); self.ul_in.addWidget(cb)
        if self.ul_in.count() == 0: self.ul_in.addWidget(QLabel("No USE flags found."))
        self.ul_in.addStretch(1)
    def _env(self) -> None:
        self._clr(self.el_in); p = self.cur_pkg
        if not p: return
        for e in p.get("envs", ()):
            en = e.get("name"); row = QHBoxLayout(); cb = QCheckBox(); cb.setChecked(en in p.get("cur_envs", set()))
            cb.toggled.connect(lambda v, k=en: p.get("cur_envs").add(k) if v else p.get("cur_envs").discard(k))
            b = QPushButton(en); b.clicked.connect(lambda _, k=en: self._env_load(k)); row.addWidget(cb); row.addWidget(b, 1); w = QWidget(); w.setLayout(row); self.el_in.addWidget(w)
        self.el_in.addStretch(1)
    def _env_dir(self) -> Path: return ENV_PROFILES_DIR if os.geteuid() == 0 else (Path.cwd() / "portage-preview" / "env")
    def _env_load(self, fn: str) -> None:
        self.active_env = fn; self.en_in.setText(fn); f = self._env_dir() / fn; f = f if f.is_file() else (ENV_PROFILES_DIR / fn)
        self.eed.setPlainText(f.read_text(encoding="utf-8", errors="ignore") if f.is_file() else "")
    def _env_new(self) -> None: self.active_env = ""; self.en_in.setText("custom.conf"); self.eed.setPlainText('MAKEOPTS="-j8 -l8"\nNINJAFLAGS="-j8 -l8"\n')
    def _env_save(self) -> None:
        fn = Path(self.en_in.text().strip()).name
        if fn: write_one(self._env_dir(), fn if fn.endswith(".conf") else f"{fn}.conf", self.eed.toPlainText()); self._reload()
    def _env_del(self) -> None:
        if self.active_env: (self._env_dir() / self.active_env).unlink(missing_ok=True); self.active_env = ""; self.en_in.clear(); self.eed.clear(); self._reload()
    def _kw(self) -> None:
        self._clr(self.kw_l); p = self.cur_pkg
        if not p: return
        cur_k = next((k for k in ("**", "~amd64", "amd64") if p.get("cur_kw", {}).get(k)), "NONE")
        for lbl, key, cur, opts in (("Accept Keyword:", "kw", cur_k, (("(none)", "NONE"), ("amd64", "amd64"), ("~amd64", "~amd64"), ("**", "**"))), ("Keyword Scope:", "cur_kw_mode", p.get("cur_kw_mode", "ALL"), (("All versions", "ALL"), ("Exact (=)", "EQ"), ("Forward (>=)", "FWD"))), ("Package Mask:", "cur_mask", p.get("cur_mask", "NONE"), (("Unmasked", "NONE"), ("Mask all", "ALL"), ("Mask exact (=)", "EQ"), ("Mask forward (>=)", "FWD"))), ("Package Unmask:", "cur_unmask", p.get("cur_unmask", "NONE"), (("No local unmask", "NONE"), ("Unmask all", "ALL"), ("Unmask exact (=)", "EQ"), ("Unmask forward (>=)", "FWD")))):
            self.kw_l.addWidget(QLabel(lbl)); cb = QComboBox()
            for t, v in opts: cb.addItem(t, v)
            cb.setCurrentIndex(max(0, cb.findData(cur)))
            cb.currentIndexChanged.connect(lambda _, box=cb, k=key: p.update({"cur_kw": {x: (x == box.currentData()) for x in ("amd64", "~amd64", "**")}}) if k == "kw" else p.update({k: box.currentData()}))
            self.kw_l.addWidget(cb)
        self.kw_l.addStretch(1)
    def _cur_pt(self):
        if not self.cur_pkg: return None
        bn = self.pat_cb.currentData()
        return next((x for x in self.cur_pkg.get("patches", ()) if x.get("base_name") == bn), None)
    def _pat_load(self) -> None:
        pt = self._cur_pt(); self.pat_ed.blockSignals(True)
        if not pt: self.pat_ed.clear(); self.pat_ed.blockSignals(False); return
        if "orig_text" not in pt:
            pf = Path(pt.get("path")); pt["orig_text"] = pf.read_text(encoding="utf-8", errors="ignore") if pf.is_file() else ""; pt["cur_text"] = pt["orig_text"]
        self.pat_en.blockSignals(True); self.pat_en.setChecked(bool(pt.get("cur_en"))); self.pat_en.blockSignals(False)
        self.pat_ed.setPlainText(filter_make_conf(pt.get("cur_text", ""), self.pat_cmt.isChecked(), False)); self.pat_ed.blockSignals(False)
    def _pat_tog(self, v: bool) -> None:
        pt = self._cur_pt()
        if pt: pt.update({"cur_en": v})
    def _pat_chg(self) -> None:
        pt = self._cur_pt()
        if pt and self.pat_cmt.isChecked(): pt.update({"cur_text": self.pat_ed.toPlainText()})
    def _create_patch_qt(self) -> None:
        if not self.cur_pkg: QMessageBox.information(self, "Select Package", "Select a package first."); return
        dlg = QDialog(self); dlg.setWindowTitle("Create Diff Patch"); dlg.resize(560, 190); vl = QVBoxLayout(dlg)
        o_in = QLineEdit(); o_in.setPlaceholderText("Original file or folder..."); m_in = QLineEdit(); m_in.setPlaceholderText("Modified file or folder..."); import time; n_in = QLineEdit(f"{Path(self.cur_pkg.get('cpv', 'custom')).name}-{int(time.time())}.patch")
        for lbl, box in (("Original:", o_in), ("Modified:", m_in)):
            r = QHBoxLayout(); r.addWidget(QLabel(lbl)); r.addWidget(box, 1)
            bf = QPushButton("File..."); bf.clicked.connect(lambda _, b=box: b.setText(QFileDialog.getOpenFileName(dlg, "Select File").__getitem__(0) or b.text()))
            bd = QPushButton("Folder..."); bd.clicked.connect(lambda _, b=box: b.setText(QFileDialog.getExistingDirectory(dlg, "Select Folder") or b.text()))
            r.addWidget(bf); r.addWidget(bd); vl.addLayout(r)
        nr = QHBoxLayout(); nr.addWidget(QLabel("Patch Name:")); nr.addWidget(n_in, 1); vl.addLayout(nr)
        br = QHBoxLayout(); br.addStretch(1); bok = QPushButton("Create"); bca = QPushButton("Cancel"); bok.clicked.connect(dlg.accept); bca.clicked.connect(dlg.reject); br.addWidget(bok); br.addWidget(bca); vl.addLayout(br)
        if dlg.exec() != QDialog.DialogCode.Accepted: return
        try:
            cp = self.cur_pkg.get("cp"); dst = generate_diff_patch(o_in.text(), m_in.text(), self.store._base() / "patches" / cp, n_in.text())
            self.cur_pkg.setdefault("patches", []).append({"base_name": dst.name, "path": str(dst), "enabled": True, "cur_en": True, "orig_en": True})
            self._pat(); self.pat_cb.setCurrentIndex(max(0, self.pat_cb.findData(dst.name))); QMessageBox.information(self, "Patch Created", f"Created {dst.name}")
        except Exception as exc: QMessageBox.warning(self, "Diff Error", str(exc))
    def _remove_patch_qt(self) -> None:
        pt = self._cur_pt()
        if not pt or not self.cur_pkg: return
        if QMessageBox.question(self, "Stash Patch", f"Move '{pt.get('base_name')}' to stash?\nPortage will not apply it until restored.") != QMessageBox.StandardButton.Yes: return
        trash_or_delete_patch(self.store._base(), self.cur_pkg.get("cp"), pt, True)
        self.cur_pkg["patches"] = [x for x in self.cur_pkg.get("patches", ()) if x is not pt]
        self._pat(); self._tree()
    def _restore_patch_qt(self) -> None:
        if not self.cur_pkg: return
        cp = self.cur_pkg.get("cp"); items = list(reversed(list_trashed_patches(self.store._base(), cp)))
        if not items: QMessageBox.information(self, "Stashed Patches", "No stashed patches found for this package."); return
        dlg = QDialog(self); dlg.setWindowTitle("Stashed Patches (Preview, Restore, or Delete)"); dlg.resize(640, 420); vl = QVBoxLayout(dlg)
        cb = QComboBox(); vw = QPlainTextEdit(); vw.setReadOnly(True); act = {"mode": None}
        for p in items: cb.addItem(p.name, str(p))
        cb.currentIndexChanged.connect(lambda _: vw.setPlainText(Path(cb.currentData()).read_text(encoding="utf-8", errors="ignore") if cb.currentData() else ""))
        vw.setPlainText(items.__getitem__(0).read_text(encoding="utf-8", errors="ignore"))
        vl.addWidget(QLabel("Select stashed patch:")); vl.addWidget(cb); vl.addWidget(vw, 1)
        br = QHBoxLayout(); bdel = QPushButton("Delete Permanently"); bok = QPushButton("Restore Selected"); bca = QPushButton("Close")
        bdel.clicked.connect(lambda: (act.update({"mode": "del"}), dlg.accept())); bok.clicked.connect(lambda: (act.update({"mode": "ok"}), dlg.accept())); bca.clicked.connect(dlg.reject)
        br.addWidget(bdel); br.addStretch(1); br.addWidget(bok); br.addWidget(bca); vl.addLayout(br)
        if dlg.exec() != QDialog.DialogCode.Accepted or not act.get("mode"): return
        pick = Path(cb.currentData())
        if act.get("mode") == "del": pick.unlink(missing_ok=True); return
        dst = restore_trashed_patch(self.store._base(), cp, pick)
        en = not dst.name.endswith(".disabled"); bn = dst.name[:-9] if not en else dst.name
        self.cur_pkg.setdefault("patches", []).append({"base_name": bn, "path": str(dst), "enabled": en, "cur_en": en, "orig_en": en})
        self._pat(); self.pat_cb.setCurrentIndex(max(0, self.pat_cb.findData(bn))); self._tree()
    def _pat(self) -> None:
        self.pat_cb.blockSignals(True); self.pat_cb.clear()
        pts = self.cur_pkg.get("patches", ()) if self.cur_pkg else ()
        for pt in pts: self.pat_cb.addItem(pt.get("base_name"), pt.get("base_name"))
        if not pts: self.pat_cb.addItem("No patches found", "NONE")
        self.pat_cb.blockSignals(False); self._pat_load()
    def _reload(self) -> None: self.store = CfgStore(); self._ref_mc(); self._tree()
    def _save_sc(self, sc: str) -> None:
        chg = self.store.save_scope(sc, self.cur_pkg)
        if not chg: QMessageBox.information(self, "No Changes", "No pending changes in this tab."); return
        self._tree(); QMessageBox.information(self, "Saved", "Saved:\n" + "\n".join(chg))
    def _save(self) -> None:
        self._save_sc(("use", "env", "kw", "pat", "mc").__getitem__(self.nb.currentIndex()))

def main() -> None:
    try: ensure_gentoo_os(); app = QApplication(sys.argv); w = GentoolCfgQt(); w.show(); sys.exit(app.exec())
    except RuntimeError as exc: raise SystemExit(f"ERROR: {exc}")

class GentoolCfgQt(QMainWindow):
    def __init__(self) -> None:
        super().__init__(); self.setWindowTitle("gentoolcfg 2.1.0"); self.resize(1220, 760)
        self.store = CfgStore(); self.cur_pkg = None; self.active_env = ""; self.active_kcfg = ""
        root = QWidget(); self.setCentralWidget(root); lay = QVBoxLayout(root)
        sp = QSplitter(Qt.Orientation.Horizontal); lay.addWidget(sp, 1)
        lw = QWidget(); ll = QVBoxLayout(lw); sp.addWidget(lw)
        self.q_in = QLineEdit(); self.q_in.setPlaceholderText("Filter packages...")
        self.q_in.textChanged.connect(self._tree); ll.addWidget(self.q_in)
        self.tree = QTreeWidget(); self.tree.setHeaderHidden(True)
        self.tree.itemSelectionChanged.connect(self._sel); ll.addWidget(self.tree, 1)
        rw = QWidget(); rl = QVBoxLayout(rw); sp.addWidget(rw); sp.setSizes([340, 880])
        self.hdr = QLabel("Select a package on the left."); rl.addWidget(self.hdr)
        self.nb = QTabWidget(); rl.addWidget(self.nb, 1)
        uw = QWidget(); ul = QVBoxLayout(uw); ubar = QHBoxLayout()
        self.uf = QLineEdit(); self.uf.setPlaceholderText("Filter USE..."); self.uf.textChanged.connect(self._use)
        ubar.addWidget(self.uf); ubar.addWidget(_compact_btn("Refresh", self._reload))
        ubar.addWidget(_flat_link("Save USE", lambda: self._save_sc("use"))); ul.addLayout(ubar)
        self.usc = QScrollArea(); self.usc.setWidgetResizable(True); self.ubox = QWidget()
        self.ul_in = QVBoxLayout(self.ubox); self.usc.setWidget(self.ubox); ul.addWidget(self.usc, 1)
        self.nb.addTab(uw, "USE")
        ew = QWidget(); el = QHBoxLayout(ew); el_l = QVBoxLayout()
        self.esc = QScrollArea(); self.esc.setWidgetResizable(True); self.ebox = QWidget()
        self.el_in = QVBoxLayout(self.ebox); self.esc.setWidget(self.ebox); el_l.addWidget(self.esc, 1)
        el_b = QHBoxLayout(); el_b.addStretch(1); el_b.addWidget(_flat_link("Save All", lambda: self._save_sc("env")))
        el_l.addLayout(el_b); el.addLayout(el_l, 2)
        el_r = QVBoxLayout(); eb = QHBoxLayout(); self.en_in = QLineEdit(); self.en_in.setPlaceholderText("profile.conf")
        eb.addWidget(self.en_in)
        for t, fn in (("+", self._env_new), ("Save", self._env_save), ("Del", self._env_del)): eb.addWidget(_compact_btn(t, fn))
        el_r.addLayout(eb); self.eed = QPlainTextEdit(); el_r.addWidget(self.eed, 1)
        el.addLayout(el_r, 3); self.nb.addTab(ew, "Environment")
        kw_w = QWidget(); kw_outer = QVBoxLayout(kw_w); self.kw_l = QVBoxLayout(); kw_outer.addLayout(self.kw_l)
        kw_b = QHBoxLayout(); kw_b.addStretch(1); kw_b.addWidget(_flat_link("Save Keywords", lambda: self._save_sc("kw")))
        kw_outer.addLayout(kw_b); kw_outer.addStretch(1); self.nb.addTab(kw_w, "Keywords")
        self._init_extra_tabs()

    def _init_extra_tabs(self) -> None:
        pw = QWidget(); p_outer = QVBoxLayout(pw); p_tabs = QTabWidget(); p_outer.addWidget(p_tabs, 1)
        pv = QWidget(); pvl = QVBoxLayout(pv); p_top = QHBoxLayout()
        self.pat_cb = QComboBox(); self.pat_cb.setMaximumWidth(260); self.pat_cb.currentIndexChanged.connect(self._pat_load)
        p_top.addWidget(self.pat_cb)
        for t, fn in (("Create", self._create_patch_qt), ("Restore", self._restore_patch_qt), ("Remove", self._remove_patch_qt), ("Delete", self._delete_patch_qt)):
            p_top.addWidget(_compact_btn(t, fn))
        self.pat_cmt = QCheckBox("#"); self.pat_cmt.setToolTip("Show comments"); self.pat_cmt.toggled.connect(self._pat_load)
        p_top.addStretch(1); p_top.addWidget(self.pat_cmt); pvl.addLayout(p_top)
        self.pat_ed = QPlainTextEdit(); self.pat_ed.setReadOnly(True); DiffHighlighter(self.pat_ed.document()); pvl.addWidget(self.pat_ed, 1)
        p_tabs.addTab(pv, "Patch Viewer")
        self.pat_bk_list, self.pat_bk_diff = self._make_diff_pane(p_tabs, self._pat_bk_sel)
        self.nb.addTab(pw, "Patches")
        mc_w = QWidget(); mc_v = QVBoxLayout(mc_w); mc_tabs = QTabWidget(); mc_v.addWidget(mc_tabs, 1)
        mce = QWidget(); mcel = QVBoxLayout(mce); self.mc_ed = QPlainTextEdit(); MakeConfHighlighter(self.mc_ed.document()); mcel.addWidget(self.mc_ed, 1)
        mbar_w = QWidget(); mbar = FlowLayout(mbar_w, 4)
        for lbl, fn in (("Undo", self.mc_ed.undo), ("Redo", self.mc_ed.redo), ("Cut", self.mc_ed.cut), ("Copy", self.mc_ed.copy), ("Paste", self.mc_ed.paste), ("Delete", lambda: self.mc_ed.textCursor().removeSelectedText()), ("Select All", self.mc_ed.selectAll)):
            mbar.addWidget(_compact_btn(lbl, fn))
        self.chk_key = QCheckBox("Protect signing keys"); self.chk_key.setChecked(True); self.chk_key.toggled.connect(self._tog_key)
        self.chk_cmt = QCheckBox("#"); self.chk_cmt.setToolTip("Show comments"); self.chk_cmt.toggled.connect(lambda _: self._ref_mc())
        self.mc_ed.textChanged.connect(self._mc_chg)
        mbar.addWidget(self.chk_key); mbar.addWidget(self.chk_cmt); mbar.addWidget(_flat_link("Save make.conf", lambda: self._save_sc("mc")))
        mcel.addWidget(mbar_w); mc_tabs.addTab(mce, "Editor")
        self.mc_bk_list, self.mc_bk_diff = self._make_diff_pane(mc_tabs, self._mc_bk_sel)
        self.nb.addTab(mc_w, "make.conf")
        bw = QWidget(); bl = QVBoxLayout(bw); bh = QHBoxLayout()
        self.mon_auto = QCheckBox("Auto-refresh (2s)"); self.mon_auto.setChecked(True)
        bh.addWidget(self.mon_auto); bh.addStretch(1); bh.addWidget(_compact_btn("Refresh Now", self._ref_mon)); bl.addLayout(bh)
        self.mon_ed = QPlainTextEdit(); self.mon_ed.setReadOnly(True); bl.addWidget(self.mon_ed, 1); self.nb.addTab(bw, "Build Monitor")
        self._init_kernel_tab()
        self.mon_tmr = QTimer(self); self.mon_tmr.timeout.connect(lambda: self._ref_mon() if self.mon_auto.isChecked() and self.nb.currentIndex() == 5 else None); self.mon_tmr.start(2000)
        QShortcut(QKeySequence("Ctrl+S"), self, self._save); QShortcut(QKeySequence("Ctrl+Q"), self, self.close); QShortcut(QKeySequence("F5"), self, self._reload)
        self._ref_mc(); self._tree(); self._ref_mon()

    def _make_diff_pane(self, tabs: QTabWidget, on_sel) -> tuple[QListWidget, QPlainTextEdit]:
        w = QWidget(); sp = QSplitter(Qt.Orientation.Horizontal); vl = QVBoxLayout(w); vl.addWidget(sp, 1)
        lw = QListWidget(); lw.currentItemChanged.connect(on_sel); sp.addWidget(lw)
        ed = QPlainTextEdit(); ed.setReadOnly(True); DiffHighlighter(ed.document()); sp.addWidget(ed)
        sp.setSizes([240, 560]); tabs.addTab(w, "Backups / Diff"); return lw, ed

    def _init_kernel_tab(self) -> None:
        kw = QWidget(); kl = QVBoxLayout(kw); kl.addWidget(QLabel(kernel_summary()))
        sp = QSplitter(Qt.Orientation.Horizontal); kl.addWidget(sp, 1)
        self.k_list = QListWidget(); self.k_list.currentItemChanged.connect(self._k_load); sp.addWidget(self.k_list)
        rw = QWidget(); rl = QVBoxLayout(rw); kb = QHBoxLayout()
        self.k_name = QLineEdit(); self.k_name.setPlaceholderText("snippet.config"); kb.addWidget(self.k_name, 1)
        for t, fn in (("+", self._k_new), ("Save", self._k_save), ("Del", self._k_del)): kb.addWidget(_compact_btn(t, fn))
        rl.addLayout(kb); self.k_ed = QPlainTextEdit(); MakeConfHighlighter(self.k_ed.document()); rl.addWidget(self.k_ed, 1)
        sp.addWidget(rw); sp.setSizes([220, 580]); self.nb.addTab(kw, "Kernel Config"); self._k_refresh()

    def _k_refresh(self) -> None:
        self.k_list.clear()
        for p in list_kernel_snippets(): self.k_list.addItem(p.name)
    def _k_load(self, cur, _=None) -> None:
        if not cur: return
        self.active_kcfg = cur.text(); self.k_name.setText(self.active_kcfg); f = KERNEL_CFG_DIR / self.active_kcfg
        self.k_ed.setPlainText(f.read_text(encoding="utf-8", errors="ignore") if f.is_file() else "")
    def _k_new(self) -> None: self.active_kcfg = ""; self.k_name.setText("custom.config"); self.k_ed.setPlainText("CONFIG_EXPERT=y\n")
    def _k_save(self) -> None:
        fn = Path(self.k_name.text().strip()).name
        if not fn: return
        fn = fn if fn.endswith(".config") else f"{fn}.config"; dst = KERNEL_CFG_DIR / fn
        if dst.is_file(): rotate_backup(self.store._base(), dst, f"kcfg-{fn}")
        write_one(KERNEL_CFG_DIR, fn, self.k_ed.toPlainText()); self._k_refresh()
    def _k_del(self) -> None:
        if self.active_kcfg: (KERNEL_CFG_DIR / self.active_kcfg).unlink(missing_ok=True); self.active_kcfg = ""; self.k_name.clear(); self.k_ed.clear(); self._k_refresh()
    def _ref_mon(self) -> None: self.mon_ed.setPlainText(read_build_monitor())
    def _clr(self, lay) -> None:
        while lay.count():
            it = lay.takeAt(0)
            if it.widget(): it.widget().deleteLater()
    def _tree(self) -> None:
        self.tree.clear(); q = self.q_in.text().strip().lower(); by_c = {}
        for p in self.store.state.get("packages", ()): by_c.setdefault(p.get("cat"), []).append(p)
        for cat in sorted(by_c):
            ms = [p for p in by_c.get(cat, ()) if not q or q in p.get("cp", "").lower()]
            if not ms: continue
            top = QTreeWidgetItem([f"{cat} ({len(ms)})"]); self.tree.addTopLevelItem(top); top.setExpanded(bool(q))
            for p in ms: ch = QTreeWidgetItem([p.get("name")]); ch.setData(0, Qt.ItemDataRole.UserRole, p.get("cp")); top.addChild(ch)

    def _sel(self) -> None:
        its = self.tree.selectedItems(); cp = its.__getitem__(0).data(0, Qt.ItemDataRole.UserRole) if its else None
        if not cp: return
        self.cur_pkg = self.store.pkg_map.get(cp); self.hdr.setText(f"{self.cur_pkg.get('cpv')}   |   Last merge: {self.cur_pkg.get('build_fmt')}")
        self._use(); self._env(); self._kw(); self._pat()
    def _use(self) -> None:
        self._clr(self.ul_in); p = self.cur_pkg; qf = self.uf.text().strip().lower()
        for f in (p.get("flags", ()) if p else ()):
            fl = f.get("flag")
            if qf and qf not in fl.lower(): continue
            cb = QCheckBox(f"{fl} *" if f.get("forced") else fl); cb.setChecked(bool(p.get("cur_flags", {}).get(fl)))
            cb.toggled.connect(lambda v, k=fl: p.get("cur_flags").update({k: v})); self.ul_in.addWidget(cb)
        self.ul_in.addStretch(1)
    def _env(self) -> None:
        self._clr(self.el_in)
        for e in (self.cur_pkg.get("envs", ()) if self.cur_pkg else ()):
            en = e.get("name"); row = QHBoxLayout(); cb = QCheckBox(); cb.setChecked(en in self.cur_pkg.get("cur_envs", set()))
            cb.toggled.connect(lambda v, k=en: self.cur_pkg.get("cur_envs").add(k) if v else self.cur_pkg.get("cur_envs").discard(k))
            b = QPushButton(en); b.setFlat(True); b.setStyleSheet("text-align: left;"); b.clicked.connect(lambda _, k=en: self._env_load(k))
            row.addWidget(cb); row.addWidget(b, 1); w = QWidget(); w.setLayout(row); self.el_in.addWidget(w)
        self.el_in.addStretch(1)
    def _env_dir(self) -> Path: return ENV_PROFILES_DIR if os.geteuid() == 0 else (Path.cwd() / "portage-preview" / "env")
    def _env_load(self, fn: str) -> None:
        self.active_env = fn; self.en_in.setText(fn); f = self._env_dir() / fn; f = f if f.is_file() else (ENV_PROFILES_DIR / fn)
        self.eed.setPlainText(f.read_text(encoding="utf-8", errors="ignore") if f.is_file() else "")
    def _env_new(self) -> None: self.active_env = ""; self.en_in.setText("custom.conf"); self.eed.setPlainText('MAKEOPTS="-j8 -l8"\n')
    def _env_save(self) -> None:
        fn = Path(self.en_in.text().strip()).name
        if fn: write_one(self._env_dir(), fn if fn.endswith(".conf") else f"{fn}.conf", self.eed.toPlainText()); self._reload()
    def _env_del(self) -> None:
        if self.active_env: (self._env_dir() / self.active_env).unlink(missing_ok=True); self.active_env = ""; self.en_in.clear(); self.eed.clear(); self._reload()
    def _kw(self) -> None:
        self._clr(self.kw_l); p = self.cur_pkg
        if not p: return
        cur_k = next((k for k in ("**", "~amd64", "amd64") if p.get("cur_kw", {}).get(k)), "NONE")
        for lbl, key, cur, opts in (("Accept Keyword:", "kw", cur_k, (("(none)", "NONE"), ("amd64", "amd64"), ("~amd64", "~amd64"), ("**", "**"))), ("Keyword Scope:", "cur_kw_mode", p.get("cur_kw_mode", "ALL"), (("All versions", "ALL"), ("Exact (=)", "EQ"), ("Forward (>=)", "FWD"))), ("Package Mask:", "cur_mask", p.get("cur_mask", "NONE"), (("Unmasked", "NONE"), ("Mask all", "ALL"), ("Mask exact (=)", "EQ"), ("Mask forward (>=)", "FWD"))), ("Package Unmask:", "cur_unmask", p.get("cur_unmask", "NONE"), (("No local unmask", "NONE"), ("Unmask all", "ALL"), ("Unmask exact (=)", "EQ"), ("Unmask forward (>=)", "FWD")))):
            row = QHBoxLayout(); row.addWidget(QLabel(lbl)); cb = QComboBox()
            for t, v in opts: cb.addItem(t, v)
            cb.setCurrentIndex(max(0, cb.findData(cur)))
            cb.currentIndexChanged.connect(lambda _, box=cb, k=key: p.update({"cur_kw": {x: (x == box.currentData()) for x in ("amd64", "~amd64", "**")}}) if k == "kw" else p.update({k: box.currentData()}))
            row.addWidget(cb, 1); w = QWidget(); w.setLayout(row); self.kw_l.addWidget(w)

    def _cur_pt(self):
        bn = self.pat_cb.currentData()
        return next((x for x in (self.cur_pkg.get("patches", ()) if self.cur_pkg else ()) if x.get("base_name") == bn), None)
    def _pat(self) -> None:
        self.pat_cb.blockSignals(True); self.pat_cb.clear()
        pts = self.cur_pkg.get("patches", ()) if self.cur_pkg else ()
        for pt in pts: self.pat_cb.addItem(pt.get("base_name"), pt.get("base_name"))
        if not pts: self.pat_cb.addItem("No patches", "NONE")
        self.pat_cb.blockSignals(False); self._pat_load(); self._ref_pat_bk()
    def _pat_load(self) -> None:
        pt = self._cur_pt(); self.pat_ed.clear()
        if not pt: return
        raw = Path(pt.get("path")).read_text(encoding="utf-8", errors="ignore") if Path(pt.get("path")).is_file() else ""
        self.pat_ed.setPlainText(filter_make_conf(raw, self.pat_cmt.isChecked(), False))
    def _create_patch_qt(self) -> None:
        if not self.cur_pkg: return
        dlg = QDialog(self); dlg.setWindowTitle("Create Diff Patch"); dlg.resize(520, 180); vl = QVBoxLayout(dlg)
        o_in = QLineEdit(); m_in = QLineEdit(); n_in = QLineEdit(f"{Path(self.cur_pkg.get('cpv', 'custom')).name}-{int(time.time())}.patch")
        for lbl, box in (("Original:", o_in), ("Modified:", m_in)):
            r = QHBoxLayout(); r.addWidget(QLabel(lbl)); r.addWidget(box, 1)
            r.addWidget(_compact_btn("File...", lambda b=box: b.setText(QFileDialog.getOpenFileName(dlg, "File").__getitem__(0) or b.text())))
            r.addWidget(_compact_btn("Folder...", lambda b=box: b.setText(QFileDialog.getExistingDirectory(dlg, "Folder") or b.text()))); vl.addLayout(r)
        nr = QHBoxLayout(); nr.addWidget(QLabel("Name:")); nr.addWidget(n_in, 1); vl.addLayout(nr)
        br = QHBoxLayout(); br.addStretch(1); br.addWidget(_compact_btn("Create", dlg.accept)); br.addWidget(_compact_btn("Cancel", dlg.reject)); vl.addLayout(br)
        if dlg.exec() != QDialog.DialogCode.Accepted: return
        try:
            cp = self.cur_pkg.get("cp"); dst = generate_diff_patch(o_in.text(), m_in.text(), self.store._base() / "patches" / cp, n_in.text())
            rotate_backup(self.store._base(), dst, f"patch-{cp.replace('/', '_')}-{dst.name}")
            self.cur_pkg.setdefault("patches", []).append({"base_name": dst.name, "path": str(dst), "enabled": True})
            self._pat(); self.pat_cb.setCurrentIndex(max(0, self.pat_cb.findData(dst.name)))
        except Exception as exc: QMessageBox.warning(self, "Diff Error", str(exc))
    def _restore_patch_qt(self) -> None:
        if not self.cur_pkg: return
        cp = self.cur_pkg.get("cp"); items = list(reversed(list_trashed_patches(self.store._base(), cp)))
        if not items: QMessageBox.information(self, "Restore Patch", "No stashed patches to restore."); return
        pick, ok = QInputDialog.getItem(self, "Confirm Patch Restoration", "Select stashed patch to restore:", [p.name for p in items], 0, False)
        if not ok or not pick: return
        src = next(p for p in items if p.name == pick)
        if QMessageBox.question(self, "Confirm Restore", f"Restore '{pick}' back to active patches?") != QMessageBox.StandardButton.Yes: return
        dst = restore_trashed_patch(self.store._base(), cp, src)
        self.cur_pkg.setdefault("patches", []).append({"base_name": dst.name, "path": str(dst), "enabled": True}); self._pat()
    def _remove_patch_qt(self) -> None:
        pt = self._cur_pt()
        if not pt or not self.cur_pkg: return
        if QMessageBox.question(self, "Stash Patch", f"Move '{pt.get('base_name')}' to stash?") != QMessageBox.StandardButton.Yes: return
        rotate_backup(self.store._base(), Path(pt.get("path")), f"patch-{self.cur_pkg.get('cp').replace('/', '_')}-{pt.get('base_name')}")
        trash_or_delete_patch(self.store._base(), self.cur_pkg.get("cp"), pt, True)
        self.cur_pkg["patches"] = [x for x in self.cur_pkg.get("patches", ()) if x is not pt]; self._pat()
    def _delete_patch_qt(self) -> None:
        pt = self._cur_pt()
        if not pt or not self.cur_pkg: return
        if QMessageBox.question(self, "Delete Permanently", f"Permanently delete '{pt.get('base_name')}'?") != QMessageBox.StandardButton.Yes: return
        trash_or_delete_patch(self.store._base(), self.cur_pkg.get("cp"), pt, False)
        self.cur_pkg["patches"] = [x for x in self.cur_pkg.get("patches", ()) if x is not pt]; self._pat()

    def _ref_mc(self) -> None:
        self.mc_ed.blockSignals(True); self.mc_ed.setPlainText(filter_make_conf(self.store.cur_mc, self.chk_cmt.isChecked(), self.chk_key.isChecked())); self.mc_ed.blockSignals(False); self._ref_mc_bk()
    def _tog_key(self, v: bool) -> None:
        if v: self._ref_mc(); return
        ans, ok = QInputDialog.getText(self, "Unlock Signing Keys", "Type capital YES to unlock:")
        if ok and ans.strip() == "YES": self._ref_mc()
        else: self.chk_key.blockSignals(True); self.chk_key.setChecked(True); self.chk_key.blockSignals(False)
    def _mc_chg(self) -> None:
        if not self.chk_cmt.isChecked(): return
        if not self.chk_key.isChecked(): self.store.cur_mc = self.mc_ed.toPlainText()
        else:
            kept = [ln for ln in self.store.cur_mc.splitlines() if any(ln.strip().startswith(f"{k}=") for k in PROTECTED_KEYS)]
            self.store.cur_mc = "\n".join(kept + self.mc_ed.toPlainText().splitlines())
    def _ref_mc_bk(self) -> None:
        self.mc_bk_list.clear()
        for p in list_backups(self.store._base(), "make.conf"): self.mc_bk_list.addItem(p.name)
    def _mc_bk_sel(self, cur, _=None) -> None:
        if not cur: return
        f = self.store._base() / ".gentoolcfg-backups" / cur.text()
        old_t = filter_make_conf(f.read_text(encoding="utf-8", errors="ignore") if f.is_file() else "", self.chk_cmt.isChecked(), self.chk_key.isChecked())
        cur_t = filter_make_conf(self.store.cur_mc, self.chk_cmt.isChecked(), self.chk_key.isChecked())
        self.mc_bk_diff.setPlainText(unified_diff_lines(old_t, cur_t, cur.text(), "current make.conf"))
    def _ref_pat_bk(self) -> None:
        self.pat_bk_list.clear(); pt = self._cur_pt()
        if not pt or not self.cur_pkg: return
        pref = f"patch-{self.cur_pkg.get('cp').replace('/', '_')}-{pt.get('base_name')}"
        for p in list_backups(self.store._base(), pref): self.pat_bk_list.addItem(p.name)
    def _pat_bk_sel(self, cur, _=None) -> None:
        pt = self._cur_pt()
        if not cur or not pt: return
        f = self.store._base() / ".gentoolcfg-backups" / cur.text()
        old_t = f.read_text(encoding="utf-8", errors="ignore") if f.is_file() else ""
        self.pat_bk_diff.setPlainText(unified_diff_lines(old_t, self.pat_ed.toPlainText(), cur.text(), pt.get("base_name")))
    def _reload(self) -> None: self.store = CfgStore(); self._ref_mc(); self._tree(); self._ref_mon()
    def _save_sc(self, sc: str) -> None:
        chg = self.store.save_scope(sc, self.cur_pkg)
        if not chg: QMessageBox.information(self, "No Changes", "No pending changes in this tab."); return
        self._tree(); self._ref_mc_bk(); QMessageBox.information(self, "Saved", "Saved:\n" + "\n".join(chg))
    def _save(self) -> None:
        idx = self.nb.currentIndex()
        if idx in (0, 1, 2, 4): self._save_sc({0: "use", 1: "env", 2: "kw", 4: "mc"}[idx])

def main() -> None:
    try: ensure_gentoo_os(); app = QApplication(sys.argv); w = GentoolCfgQt(); w.show(); sys.exit(app.exec())
    except RuntimeError as exc: raise SystemExit(f"ERROR: {exc}")
