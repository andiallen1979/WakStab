import os, re, sys
from pathlib import Path
from gentoolcfg.cli import CfgStore, PROTECTED_KEYS, filter_make_conf, generate_diff_patch, list_trashed_patches, restore_trashed_patch, trash_or_delete_patch, write_one
from gentoolcfg.portage_io import ENV_PROFILES_DIR, ensure_gentoo_os

def _launch(ver: str) -> None:
    import gi; gi.require_version("Gtk", ver); gi.require_version("Gdk", ver)
    from gi.repository import Gdk, Gtk
    is_g4 = (ver == "4.0")
    def _add(box, w, exp=False):
        if is_g4:
            if exp: w.set_hexpand(True); w.set_vexpand(True)
            box.append(w)
        else: box.pack_start(w, exp, exp, 2)
    def _clr(box):
        if is_g4:
            while box.get_first_child(): box.remove(box.get_first_child())
        else:
            for c in box.get_children(): box.remove(c)
    def _scroll(w):
        sc = Gtk.ScrolledWindow(); (sc.set_child(w) if is_g4 else sc.add(w)); return sc

    class GentoolCfgGtk(Gtk.Window):
        def __init__(self) -> None:
            self.store = CfgStore(); self.cur_pkg = None; self.active_env = ""; self.dark = True
            super().__init__(title="gentoolcfg"); self.win = self; self.win.set_default_size(1160, 720)
            if not is_g4: self.win.connect("destroy", Gtk.main_quit)
            root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4); (self.win.set_child(root) if is_g4 else self.win.add(root))
            pan = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL); pan.set_position(370); _add(root, pan, True)
            lbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4); (pan.set_start_child(lbox) if is_g4 else pan.pack1(lbox, False, False))
            self.q_in = Gtk.Entry(); self.q_in.set_placeholder_text("Filter packages..."); self.q_in.connect("changed", lambda _: self._tree()); _add(lbox, self.q_in)
            self.l_store = Gtk.TreeStore(str, str); self.l_tv = Gtk.TreeView(model=self.l_store); self.l_tv.set_headers_visible(False); self.l_tv.append_column(Gtk.TreeViewColumn("Pkg", Gtk.CellRendererText(), text=0)); self.l_tv.get_selection().connect("changed", self._on_tv_sel); self.l_tv.connect("row-activated", lambda tv, path, col: tv.collapse_row(path) if tv.row_expanded(path) else tv.expand_row(path, False)); _add(lbox, _scroll(self.l_tv), True)
            rbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4); (pan.set_end_child(rbox) if is_g4 else pan.pack2(rbox, True, False))
            self.hdr = Gtk.Label(label="Select a package on the left."); _add(rbox, self.hdr)
            self.nb = Gtk.Notebook(); _add(rbox, self.nb, True)
            ubox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4); ubar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
            self.uf = Gtk.Entry(); self.uf.set_placeholder_text("Filter USE..."); self.uf.connect("changed", lambda _: self._use()); _add(ubar, self.uf, True)
            bref = Gtk.Button(label="Refresh"); bref.connect("clicked", lambda _: self._reload()); bs_u = Gtk.Button(label="Save USE"); bs_u.connect("clicked", lambda _: self._save_sc("use")); _add(ubar, bref); _add(ubar, bs_u); _add(ubox, ubar)
            self.u_list = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1); _add(ubox, _scroll(self.u_list), True); self.nb.append_page(ubox, Gtk.Label(label="USE"))
            ebox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6); self.e_list = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2); el_wrap = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4); _add(el_wrap, _scroll(self.e_list), True); bs_e = Gtk.Button(label="Save Env"); bs_e.connect("clicked", lambda _: self._save_sc("env")); _add(el_wrap, bs_e); _add(ebox, el_wrap, True)
            er = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4); eb = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
            self.en_in = Gtk.Entry(); self.en_in.set_placeholder_text("profile.conf"); _add(eb, self.en_in, True)
            for lbl, fn in (("+", self._env_new), ("Save", self._env_save), ("Del", self._env_del)): b = Gtk.Button(label=lbl); b.connect("clicked", fn); _add(eb, b)
            _add(er, eb); self.ebuf = Gtk.TextBuffer(); _add(er, _scroll(Gtk.TextView(buffer=self.ebuf)), True); _add(ebox, er, True); self.nb.append_page(ebox, Gtk.Label(label="Environment"))
            self.kw_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6); kw_wrap = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4); _add(kw_wrap, _scroll(self.kw_box), True); bs_k = Gtk.Button(label="Save Keywords"); bs_k.connect("clicked", lambda _: self._save_sc("kw")); _add(kw_wrap, bs_k); self.nb.append_page(kw_wrap, Gtk.Label(label="Keywords"))
            self.p_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4);            p_wrap = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4); p_top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
            self.pat_cb = Gtk.ComboBoxText(); self.pat_cb.connect("changed", lambda _: self._pat_load())
            self.pat_en = Gtk.CheckButton(label="Enabled"); self.pat_en.connect("toggled", lambda w: self._cur_pt().update({"cur_en": w.get_active()}) if self._cur_pt() else None)
            _add(p_top, self.pat_cb, True); _add(p_top, self.pat_en); _add(p_wrap, p_top)
            self.pat_buf = Gtk.TextBuffer(); self.pat_tv = Gtk.TextView(buffer=self.pat_buf); self.pat_buf.connect("changed", self._pat_chg); _add(p_wrap, _scroll(self.pat_tv), True)
            p_bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
            for lbl, fn in (("Undo", lambda _: self.pat_buf.undo() if hasattr(self.pat_buf, "undo") and self.pat_buf.get_can_undo() else None), ("Redo", lambda _: self.pat_buf.redo() if hasattr(self.pat_buf, "redo") and self.pat_buf.get_can_redo() else None), ("Cut", lambda _: self.pat_buf.cut_clipboard(Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD), True) if not is_g4 else self.pat_tv.emit("cut-clipboard")), ("Copy", lambda _: self.pat_buf.copy_clipboard(Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD)) if not is_g4 else self.pat_tv.emit("copy-clipboard")), ("Paste", lambda _: self.pat_buf.paste_clipboard(Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD), None, True) if not is_g4 else self.pat_tv.emit("paste-clipboard")), ("Delete", lambda _: self.pat_buf.delete_selection(True, True)), ("Select All", lambda _: self.pat_buf.select_range(self.pat_buf.get_start_iter(), self.pat_buf.get_end_iter())), ("Create", self._create_patch_gtk), ("Remove", self._remove_patch_gtk), ("Restore", self._restore_patch_gtk)):
                b = Gtk.Button(label=lbl); b.connect("clicked", fn); _add(p_bar, b)
            self.pat_cmt = Gtk.CheckButton(label="Show comments"); self.pat_cmt.set_active(False); self.pat_cmt.connect("toggled", lambda _: self._pat_load())
            bs_p = Gtk.Button(label="Save Patches"); bs_p.connect("clicked", lambda _: self._save_sc("pat"))
            _add(p_bar, self.pat_cmt); _add(p_bar, bs_p); _add(p_wrap, p_bar); self.nb.append_page(p_wrap, Gtk.Label(label="Patches"))
            mc_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4); self.mc_buf = Gtk.TextBuffer()
            for tg, hx in (("var", "#ff5555"), ("eq", "#f1fa8c"), ("qt", "#50fa7b"), ("flg", "#55aaff"), ("cmt", "#6272a4")): self.mc_buf.create_tag(tg, foreground=hx, weight=700)
            self.mc_tv = Gtk.TextView(buffer=self.mc_buf); _add(mc_box, _scroll(self.mc_tv), True)
            mbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4); _add(mc_box, mbar)
            self.nb.append_page(mc_box, Gtk.Label(label="make.conf"))
            bot = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6); _add(bot, Gtk.Label(), True)
            self.chk_key = Gtk.CheckButton(label="Protect signing keys"); self.chk_key.set_active(True)
            self.chk_cmt = Gtk.CheckButton(label="Show comments"); self.chk_cmt.set_active(False)
            self.chk_cmt.connect("toggled", lambda _: self._ref_mc()); self.chk_key.connect("toggled", self._tog_key)
            bs = Gtk.Button(label="Save"); bs.connect("clicked", self._save)
            bs_m = Gtk.Button(label="Save make.conf"); bs_m.connect("clicked", lambda _: self._save_sc("mc"))
            for w in (self.chk_key, self.chk_cmt, bs_m): _add(mbar, w)
            for lbl, fn in (("Undo", lambda _: self.mc_buf.undo() if hasattr(self.mc_buf, "undo") and self.mc_buf.get_can_undo() else None), ("Redo", lambda _: self.mc_buf.redo() if hasattr(self.mc_buf, "redo") and self.mc_buf.get_can_redo() else None), ("Cut", lambda _: self.mc_buf.cut_clipboard(Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD), True) if not is_g4 else self.mc_tv.emit("cut-clipboard")), ("Copy", lambda _: self.mc_buf.copy_clipboard(Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD)) if not is_g4 else self.mc_tv.emit("copy-clipboard")), ("Paste", lambda _: self.mc_buf.paste_clipboard(Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD), None, True) if not is_g4 else self.mc_tv.emit("paste-clipboard")), ("Delete", lambda _: self.mc_buf.delete_selection(True, True)), ("Select All", lambda _: self.mc_buf.select_range(self.mc_buf.get_start_iter(), self.mc_buf.get_end_iter()))):
                b = Gtk.Button(label=lbl); b.connect("clicked", fn); _add(mbar, b)
            self.mc_buf.connect("changed", self._mc_chg); self._ref_mc(); self._tree(); (self.win.present() if is_g4 else self.win.show_all()); self.chk_key.set_visible(False); self.chk_cmt.set_visible(False)
        def _theme(self, _): self.dark = not self.dark; Gtk.Settings.get_default().set_property("gtk-application-prefer-dark-theme", self.dark)
        def _msg(self, t: str, m: str) -> None:
            d = Gtk.MessageDialog(transient_for=self.win, modal=True, message_type=Gtk.MessageType.INFO, buttons=Gtk.ButtonsType.OK, text=f"{t}\n\n{m}")
            (d.connect("response", lambda x, _: x.destroy()) or d.present()) if is_g4 else (d.run(), d.destroy())
        def _hl(self) -> None:
            s, e = self.mc_buf.get_start_iter(), self.mc_buf.get_end_iter(); txt = self.mc_buf.get_text(s, e, True)
            for tg in ("var", "eq", "qt", "flg", "cmt"): self.mc_buf.remove_tag_by_name(tg, s, e)
            for i, ln in enumerate(txt.splitlines()):
                if ln.lstrip().startswith("#"): self.mc_buf.apply_tag_by_name("cmt", self.mc_buf.get_iter_at_line(i), self.mc_buf.get_iter_at_line_offset(i, len(ln))); continue
                for m in re.finditer(r"^\s*([A-Za-z_][A-Za-z0-9_]*)", ln): self.mc_buf.apply_tag_by_name("var", self.mc_buf.get_iter_at_line_offset(i, m.start(1)), self.mc_buf.get_iter_at_line_offset(i, m.end(1)))
                for m in re.finditer(r"=", ln): self.mc_buf.apply_tag_by_name("eq", self.mc_buf.get_iter_at_line_offset(i, m.start()), self.mc_buf.get_iter_at_line_offset(i, m.end()))
                for m in re.finditer(r"['\"]", ln): self.mc_buf.apply_tag_by_name("qt", self.mc_buf.get_iter_at_line_offset(i, m.start()), self.mc_buf.get_iter_at_line_offset(i, m.end()))
                for m in re.finditer(r"(?<=[\s'\"])-[A-Za-z0-9_+.:=-]+", ln): self.mc_buf.apply_tag_by_name("flg", self.mc_buf.get_iter_at_line_offset(i, m.start()), self.mc_buf.get_iter_at_line_offset(i, m.end()))
        def _ref_mc(self) -> None:
            self.mc_buf.set_text(filter_make_conf(self.store.cur_mc, self.chk_cmt.get_active(), self.chk_key.get_active())); self._hl()
        def _tog_key(self, w) -> None:
            if w.get_active(): self._ref_mc(); return
            d = Gtk.Dialog(title="Unlock Signing Keys", transient_for=self.win, modal=True); ent = Gtk.Entry(); ent.set_placeholder_text("Type capital YES...")
            box = d.get_content_area(); _add(box, Gtk.Label(label="Type capital YES to unlock GPG/SecureBoot/Module keys:")); _add(box, ent)
            d.add_buttons("Cancel", Gtk.ResponseType.CANCEL, "Unlock", Gtk.ResponseType.OK)
            def _done(dlg, resp):
                ok = (resp == Gtk.ResponseType.OK and ent.get_text().strip() == "YES"); dlg.destroy()
                self._ref_mc() if ok else w.set_active(True)
            (d.connect("response", _done) or d.present()) if is_g4 else _done(d, (d.show_all() or d.run()))
        def _mc_chg(self, b) -> None:
            self._hl()
            if not self.chk_cmt.get_active(): return
            cur = b.get_text(b.get_start_iter(), b.get_end_iter(), True)
            if not self.chk_key.get_active(): self.store.cur_mc = cur
            else: self.store.cur_mc = chr(10).join([ln for ln in self.store.cur_mc.splitlines() if any(ln.strip().startswith(f"{k}=") for k in PROTECTED_KEYS)] + cur.splitlines())
        def _on_tv_sel(self, sel) -> None:
            m, it = sel.get_selected()
            cp = m.get_value(it, 1) if it else ""
            if cp and cp in self.store.pkg_map: self._sel(self.store.pkg_map.get(cp))
        def _tree(self) -> None:
            self.l_store.clear(); q = self.q_in.get_text().strip().lower(); by_c = {}
            for p in self.store.state.get("packages", ()): by_c.setdefault(p.get("cat"), []).append(p)
            for cat in sorted(by_c):
                ms = [p for p in by_c.get(cat, ()) if not q or q in p.get("cp", "").lower()]
                if not ms: continue
                par = self.l_store.append(None, (f"{cat} ({len(ms)})", ""))
                for p in ms: self.l_store.append(par, (p.get("name"), p.get("cp")))
            if q: self.l_tv.expand_all()
        def _sel(self, p: dict) -> None:
            self.cur_pkg = p; self.hdr.set_text(f"{p.get('cpv')}   |   Last merge: {p.get('build_fmt')}"); self._use(); self._env(); self._kw(); self._pat()
        def _use(self) -> None:
            _clr(self.u_list); p = self.cur_pkg; qf = self.uf.get_text().strip().lower()
            if not p: return
            for f in p.get("flags", ()):
                fl = f.get("flag")
                if qf and qf not in fl.lower(): continue
                cb = Gtk.CheckButton(label=f"{fl} *" if f.get("forced") else fl); cb.set_active(bool(p.get("cur_flags", {}).get(fl)))
                cb.connect("toggled", lambda w, k=fl: p.get("cur_flags").update({k: w.get_active()})); _add(self.u_list, cb)
            if not (self.u_list.get_first_child() if is_g4 else self.u_list.get_children()): _add(self.u_list, Gtk.Label(label="No USE flags found."))
            if not is_g4: self.u_list.show_all()
            if not (self.u_list.get_first_child() if is_g4 else self.u_list.get_children()): _add(self.u_list, Gtk.Label(label="No USE flags found."))
            if not is_g4: self.u_list.show_all()
        def _env(self) -> None:
            _clr(self.e_list); p = self.cur_pkg
            if not p: return
            for e in p.get("envs", ()):
                en = e.get("name"); r = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4); cb = Gtk.CheckButton(); cb.set_active(en in p.get("cur_envs", set()))
                cb.connect("toggled", lambda w, k=en: p.get("cur_envs").add(k) if w.get_active() else p.get("cur_envs").discard(k))
                b = Gtk.Button(label=en); b.connect("clicked", lambda _, k=en: self._env_load(k)); _add(r, cb); _add(r, b, True); _add(self.e_list, r)
            if not is_g4: self.e_list.show_all()
            if not is_g4: self.e_list.show_all()
        def _env_dir(self) -> Path: return ENV_PROFILES_DIR if os.geteuid() == 0 else (Path.cwd() / "portage-preview" / "env")
        def _env_load(self, fn: str) -> None:
            self.active_env = fn; self.en_in.set_text(fn); f = self._env_dir() / fn; f = f if f.is_file() else (ENV_PROFILES_DIR / fn)
            self.ebuf.set_text(f.read_text(encoding="utf-8", errors="ignore") if f.is_file() else "")
        def _env_new(self, _): self.active_env = ""; self.en_in.set_text("custom.conf"); self.ebuf.set_text('MAKEOPTS="-j8 -l8"\nNINJAFLAGS="-j8 -l8"\n')
        def _env_save(self, _):
            fn = Path(self.en_in.get_text().strip()).name
            if fn: write_one(self._env_dir(), fn if fn.endswith(".conf") else f"{fn}.conf", self.ebuf.get_text(self.ebuf.get_start_iter(), self.ebuf.get_end_iter(), True)); self._reload()
        def _env_del(self, _):
            if self.active_env: (self._env_dir() / self.active_env).unlink(missing_ok=True); self.active_env = ""; self.en_in.set_text(""); self.ebuf.set_text(""); self._reload()
        def _kw(self) -> None:
            _clr(self.kw_box); p = self.cur_pkg
            if not p: return
            cur_k = next((k for k in ("**", "~amd64", "amd64") if p.get("cur_kw", {}).get(k)), "NONE")
            for lbl, key, cur, opts in (("Accept Keyword:", "kw", cur_k, (("(none)", "NONE"), ("amd64", "amd64"), ("~amd64", "~amd64"), ("**", "**"))), ("Keyword Scope:", "cur_kw_mode", p.get("cur_kw_mode", "ALL"), (("All versions", "ALL"), ("Exact (=)", "EQ"), ("Forward (>=)", "FWD"))), ("Package Mask:", "cur_mask", p.get("cur_mask", "NONE"), (("Unmasked", "NONE"), ("Mask all", "ALL"), ("Mask exact (=)", "EQ"), ("Mask forward (>=)", "FWD"))), ("Package Unmask:", "cur_unmask", p.get("cur_unmask", "NONE"), (("No local unmask", "NONE"), ("Unmask all", "ALL"), ("Unmask exact (=)", "EQ"), ("Unmask forward (>=)", "FWD")))):
                _add(self.kw_box, Gtk.Label(label=lbl)); cb = Gtk.ComboBoxText()
                for t, v in opts: cb.append(v, t)
                cb.set_active_id(cur)
                cb.connect("changed", lambda w, k=key: p.update({"cur_kw": {x: (x == w.get_active_id()) for x in ("amd64", "~amd64", "**")}}) if k == "kw" else p.update({k: w.get_active_id()}))
                _add(self.kw_box, cb)
            if not is_g4: self.kw_box.show_all()
            if not is_g4: self.kw_box.show_all()
        def _cur_pt(self):
            if not self.cur_pkg: return None
            bn = self.pat_cb.get_active_id()
            return next((x for x in self.cur_pkg.get("patches", ()) if x.get("base_name") == bn), None)
        def _pat_load(self) -> None:
            pt = self._cur_pt()
            if not pt: self.pat_buf.set_text(""); return
            if "orig_text" not in pt:
                pf = Path(pt.get("path")); pt["orig_text"] = pf.read_text(encoding="utf-8", errors="ignore") if pf.is_file() else ""; pt["cur_text"] = pt["orig_text"]
            self.pat_en.set_active(bool(pt.get("cur_en"))); self.pat_buf.set_text(filter_make_conf(pt.get("cur_text", ""), self.pat_cmt.get_active(), False))
        def _pat_chg(self, b) -> None:
            pt = self._cur_pt()
            if pt and self.pat_cmt.get_active(): pt.update({"cur_text": b.get_text(b.get_start_iter(), b.get_end_iter(), True)})
        def _pick_path(self, ent, folder: bool) -> None:
            act = Gtk.FileChooserAction.SELECT_FOLDER if folder else Gtk.FileChooserAction.OPEN
            fc = Gtk.FileChooserDialog(title="Select Folder" if folder else "Select File", transient_for=self.win, action=act)
            fc.add_buttons("Cancel", Gtk.ResponseType.CANCEL, "Select", Gtk.ResponseType.OK)
            def _picked(d, r):
                if r == Gtk.ResponseType.OK and d.get_file(): ent.set_text(d.get_file().get_path() or ent.get_text())
                d.destroy()
            (fc.connect("response", _picked) or fc.present()) if is_g4 else _picked(fc, fc.run())
        def _create_patch_gtk(self, _) -> None:
            if not self.cur_pkg: self._msg("Select Package", "Select a package first."); return
            dlg = Gtk.Dialog(title="Create Diff Patch", transient_for=self.win, modal=True); box = dlg.get_content_area()
            o_in, m_in, n_in = Gtk.Entry(), Gtk.Entry(), Gtk.Entry(); o_in.set_placeholder_text("Original file/folder..."); m_in.set_placeholder_text("Modified file/folder..."); import time; n_in.set_text(f"{Path(self.cur_pkg.get('cpv', 'custom')).name}-{int(time.time())}.patch")
            for lbl, ent in (("Original:", o_in), ("Modified:", m_in)):
                r = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4); _add(r, Gtk.Label(label=lbl)); _add(r, ent, True)
                bf = Gtk.Button(label="File..."); bf.connect("clicked", lambda _, e=ent: self._pick_path(e, False))
                bd = Gtk.Button(label="Folder..."); bd.connect("clicked", lambda _, e=ent: self._pick_path(e, True))
                _add(r, bf); _add(r, bd); _add(box, r)
            nr = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4); _add(nr, Gtk.Label(label="Patch Name:")); _add(nr, n_in, True); _add(box, nr)
            dlg.add_buttons("Cancel", Gtk.ResponseType.CANCEL, "Create", Gtk.ResponseType.OK)
            def _done(d, resp):
                vals = (o_in.get_text(), m_in.get_text(), n_in.get_text()); d.destroy()
                if resp != Gtk.ResponseType.OK: return
                try:
                    cp = self.cur_pkg.get("cp"); dst = generate_diff_patch(vals.__getitem__(0), vals.__getitem__(1), self.store._base() / "patches" / cp, vals.__getitem__(2))
                    self.cur_pkg.setdefault("patches", []).append({"base_name": dst.name, "path": str(dst), "enabled": True, "cur_en": True, "orig_en": True})
                    self._pat(); self.pat_cb.set_active_id(dst.name); self._msg("Patch Created", f"Created {dst.name}")
                except Exception as exc: self._msg("Diff Error", str(exc))
            (dlg.connect("response", _done) or dlg.present()) if is_g4 else _done(dlg, (dlg.show_all() or dlg.run()))
        def _remove_patch_gtk(self, _) -> None:
            pt = self._cur_pt()
            if not pt or not self.cur_pkg: return
            d = Gtk.MessageDialog(transient_for=self.win, modal=True, message_type=Gtk.MessageType.QUESTION, buttons=Gtk.ButtonsType.YES_NO, text=f"Move '{pt.get('base_name')}' to stash?\nPortage will not apply it until restored.")
            def _do(dlg, resp):
                dlg.destroy()
                if resp != Gtk.ResponseType.YES: return
                trash_or_delete_patch(self.store._base(), self.cur_pkg.get("cp"), pt, True)
                self.cur_pkg["patches"] = [x for x in self.cur_pkg.get("patches", ()) if x is not pt]
                self._pat(); self._tree()
            (d.connect("response", _do) or d.present()) if is_g4 else _do(d, d.run())
        def _restore_patch_gtk(self, _) -> None:
            if not self.cur_pkg: return
            cp = self.cur_pkg.get("cp"); items = list(reversed(list_trashed_patches(self.store._base(), cp)))
            if not items: self._msg("Stashed Patches", "No stashed patches found for this package."); return
            dlg = Gtk.Dialog(title="Stashed Patches (Preview, Restore, or Delete)", transient_for=self.win, modal=True); dlg.set_default_size(640, 420)
            box = dlg.get_content_area(); cb = Gtk.ComboBoxText(); vbuf = Gtk.TextBuffer(); vtv = Gtk.TextView(buffer=vbuf); vtv.set_editable(False)
            for p in items: cb.append(str(p), p.name)
            cb.connect("changed", lambda w: vbuf.set_text(Path(w.get_active_id()).read_text(encoding="utf-8", errors="ignore") if w.get_active_id() else ""))
            cb.set_active(0); _add(box, Gtk.Label(label="Select stashed patch:")); _add(box, cb); _add(box, _scroll(vtv), True)
            dlg.add_buttons("Delete Permanently", 2, "Close", Gtk.ResponseType.CANCEL, "Restore Selected", Gtk.ResponseType.OK)
            def _done(d, resp):
                pick = cb.get_active_id(); d.destroy()
                if not pick or resp not in (Gtk.ResponseType.OK, 2): return
                if resp == 2: Path(pick).unlink(missing_ok=True); return
                dst = restore_trashed_patch(self.store._base(), cp, Path(pick))
                en = not dst.name.endswith(".disabled"); bn = dst.name[:-9] if not en else dst.name
                self.cur_pkg.setdefault("patches", []).append({"base_name": bn, "path": str(dst), "enabled": en, "cur_en": en, "orig_en": en})
                self._pat(); self.pat_cb.set_active_id(bn); self._tree()
            (dlg.connect("response", _done) or dlg.present()) if is_g4 else _done(dlg, (dlg.show_all() or dlg.run()))
        def _pat(self) -> None:
            self.pat_cb.remove_all(); pts = self.cur_pkg.get("patches", ()) if self.cur_pkg else ()
            for pt in pts: self.pat_cb.append(pt.get("base_name"), pt.get("base_name"))
            if not pts: self.pat_cb.append("NONE", "No patches found")
            self.pat_cb.set_active(0); self._pat_load()
        def _reload(self) -> None: self.store = CfgStore(); self._ref_mc(); self._tree()
        def _save_sc(self, sc: str) -> None:
            chg = self.store.save_scope(sc, self.cur_pkg)
            if not chg: self._msg("No Changes", "No pending changes in this tab."); return
            self._tree(); self._msg("Saved", "Saved:\n" + "\n".join(chg))
        def _save(self, _) -> None:
            chg, wrn = self.store.build_sanity_report()
            if not chg: self._msg("No Changes", "No pending changes."); return
            n = self.store.save_all(); self._reload(); self._msg("Saved", f"Saved {n} change(s):\n" + "\n".join(chg))
    if is_g4:
        app = Gtk.Application(application_id="org.gentoo.gentoolcfg"); app.connect("activate", lambda a: a.add_window(GentoolCfgGtk())); app.run(None)
    else:
        w = GentoolCfgGtk(); Gtk.main()

def main_gtk3() -> None:
    try: ensure_gentoo_os(); _launch("3.0")
    except RuntimeError as exc: raise SystemExit(f"ERROR: {exc}")

def main_gtk4() -> None:
    try: ensure_gentoo_os(); _launch("4.0")
    except RuntimeError as exc: raise SystemExit(f"ERROR: {exc}")
