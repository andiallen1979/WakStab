#pragma once

#include <QDialog>
#include <QLabel>
#include <QLineEdit>
#include <QProgressBar>
#include <QPushButton>
#include <QString>
#include <atomic>
#include "GParted_Core.h"

class ImageDialog : public QDialog {
    Q_OBJECT
public:
    enum class Mode { Sparse, FullRaw, ZeroFilledCompressed };

    ImageDialog(const QString& sourcePath, GParted::Byte_Value totalBytes,
                Mode mode = Mode::Sparse, const QString& defaultExt = QString(), QWidget* parent = nullptr);
    ~ImageDialog() override;

private:
    void browseOutput();
    void startImaging();

    QString m_sourcePath;
    GParted::Byte_Value m_totalBytes = 0;
    Mode m_mode = Mode::Sparse;
    QString m_defaultExt;
    std::atomic<bool> m_cancel{false};
    std::atomic<bool> m_running{false};

    QLineEdit* m_outEdit = nullptr;
    QProgressBar* m_progress = nullptr;
    QLabel* m_statusLabel = nullptr;
    QPushButton* m_startBtn = nullptr;
    QPushButton* m_closeBtn = nullptr;
};
