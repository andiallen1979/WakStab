#include "MainWindow.h"
#include <KAboutData>
#include <KColorSchemeManager>
#include <KLocalizedString>
#include <QApplication>

int main(int argc, char* argv[]) {
    QApplication app(argc, argv);
    KColorSchemeManager::instance();
    KLocalizedString::setApplicationDomain("qparted");

    KAboutData about(
        QStringLiteral("qparted"),
        i18n("QParted"),
        QStringLiteral("0.1.0"),
        i18n("Native Qt6 / KDE Plasma Partition Editor"),
        KAboutLicense::GPL_V2,
        i18n("(c) 2026 WakStab Repository / GParted Authors"),
        QString(),
        QStringLiteral("https://codeberg.org"));
    KAboutData::setApplicationData(about);

    MainWindow win;
    win.show();
    return app.exec();
}
