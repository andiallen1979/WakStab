#include <KColorSchemeManager>
#include <QIcon>
#include <QIcon>
#include <QFont>
#include <QSettings>
#include <KAboutData>
#include <KLocalizedString>
#include <QApplication>
#include <clocale>
#include <glibmm/init.h>
#include <glibmm/thread.h>
#include "MainWindow.h"

int main(int argc, char* argv[]) {
    std::setlocale(LC_ALL, "");
    Glib::init();
    if (!Glib::thread_supported())
        Glib::thread_init();

    QApplication app(argc, argv);
    KColorSchemeManager::instance();
    {
        QSettings st(QStringLiteral("WakStab"), QStringLiteral("qparted"));
        QString theme = st.value(QStringLiteral("ui/iconTheme")).toString();
        if (!theme.isEmpty()) QIcon::setThemeName(theme);
        int pt = st.value(QStringLiteral("ui/fontSize"), 0).toInt();
        if (pt >= 6 && pt <= 36) {
            QFont f = app.font();
            f.setPointSize(pt);
            app.setFont(f);
        }
    }
    KLocalizedString::setApplicationDomain("qparted");

    KAboutData aboutData(
        QStringLiteral("qparted"),
        i18n("QParted"),
        QStringLiteral("0.1.0"),
        i18n("Native Qt6 / KDE Plasma partition editor powered by GParted Core"),
        KAboutLicense::GPL_V2,
        i18n("(c) 2026 WakStab Repository / GParted Authors"), QString(), QStringLiteral("https://codeberg.org/andiallen1979/WakStab"));
    KAboutData::setApplicationData(aboutData);

    auto* window = new MainWindow();
    window->show();
    return app.exec();
}
