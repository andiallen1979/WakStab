#pragma once

#include <QDialog>
#include <QLabel>
#include <QLineEdit>
#include <QProgressBar>
#include <QPushButton>
#include <QString>
#include <atomic>
#include "GParted_Core.h"

class RestoreDialog : public QDialog {
    Q_OBJECT
public:
    RestoreDialog(const QString& targetPath, GParted::Byte_Value targetBytes, bool isoOnly = false, QWidget* parent = nullptr);
    ~RestoreDialog() override;
    bool restored() const { return m_restored; }

private:
    void browseInput();
    void startRestore();

    QString m_targetPath;
    GParted::Byte_Value m_targetBytes = 0;
    bool m_restored = false;
    bool m_isoOnly = false;
    std::atomic<bool> m_cancel{false};
    std::atomic<bool> m_running{false};

    QLineEdit* m_inEdit = nullptr;
    QProgressBar* m_progress = nullptr;
    QLabel* m_statusLabel = nullptr;
    QPushButton* m_startBtn = nullptr;
    QPushButton* m_closeBtn = nullptr;
};
