#pragma once

#include <QString>
#include <QStringList>
#include <memory>
#include <vector>
#include "Device.h"
#include "Operation.h"
#include "Partition.h"

class OperationQueue {
public:
    void addCreate(const GParted::Device& dev, const GParted::Partition& unalloc, const GParted::Partition& next);
    void addFormat(const GParted::Device& dev, const GParted::Partition& orig, GParted::FSType newFs);
    void addDelete(const GParted::Device& dev, const GParted::Partition& orig);
    void addResizeMove(const GParted::Device& dev, const GParted::Partition& orig, const GParted::Partition& next);
    void addNewUUID(const GParted::Device& dev, const GParted::Partition& orig);
    void addCheck(const GParted::Device& dev, const GParted::Partition& orig);
    void addName(const GParted::Device& dev, const GParted::Partition& orig, const QString& newName);
    void addLabel(const GParted::Device& dev, const GParted::Partition& orig, const QString& newLabel);

    void undoLast();
    void clear();
    bool isEmpty() const { return m_ops.empty(); }
    int count() const { return static_cast<int>(m_ops.size()); }
    QStringList descriptions() const;

    void applyVisualToDevice(const GParted::Device& rawDev, GParted::PartitionVector& outParts) const;
    const std::vector<std::unique_ptr<GParted::Operation>>& operations() const { return m_ops; }

private:
    std::vector<std::unique_ptr<GParted::Operation>> m_ops;
};
