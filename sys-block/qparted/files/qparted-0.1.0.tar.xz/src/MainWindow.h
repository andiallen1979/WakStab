#pragma once

#include <QMainWindow>
#include <QAction>
#include <QComboBox>
#include <QListWidget>
#include <QMenu>
#include <QPoint>
#include <QTreeWidget>
#include <memory>
#include <vector>
#include "GParted_Core.h"
#include "Device.h"
#include "DeviceInfoPane.h"
#include "DiskBarWidget.h"
#include "OperationQueue.h"

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget* parent = nullptr);

private Q_SLOTS:
    void refreshDevices();
    void onDeviceChanged(int index);
    void onTreeSelectionChanged();
    void onBarPartitionSelected(int index);
    void onTreeContextMenu(const QPoint& pos);
    void undoLastOperation();
    void clearAllOperations();
    void applyAllOperations();
    void createPartitionTable();
    void attemptDataRescue();
    void configureFontSize();

private:
    void setupActions();
    void updateActionStates();
    void rebuildCurrentView();
    void updateQueueUI();
    void populatePartitionTree(const GParted::PartitionVector& parts);

    GParted::GParted_Core m_core;
    std::vector<std::unique_ptr<GParted::Device>> m_devices;
    GParted::PartitionVector m_visualParts;
    OperationQueue m_queue;

    QComboBox* m_deviceCombo = nullptr;
    QMenu* m_devicesMenu = nullptr;
    DeviceInfoPane* m_deviceInfoPane = nullptr;
    DiskBarWidget* m_diskBar = nullptr;
    QTreeWidget* m_partitionTree = nullptr;
    QListWidget* m_opsList = nullptr;
    int m_rowHeight = 0;

    QAction *m_undoAct = nullptr, *m_clearAct = nullptr, *m_applyAct = nullptr;
    QAction *m_viewInfoAct = nullptr, *m_viewOpsAct = nullptr, *m_disklabelAct = nullptr;
    QAction *m_newAct = nullptr, *m_resizeAct = nullptr, *m_uuidAct = nullptr, *m_delAct = nullptr, *m_unmountAct = nullptr;
    QAction *m_flagsAct = nullptr, *m_checkAct = nullptr, *m_labelAct = nullptr;
    QAction *m_nameAct = nullptr, *m_partImgAct = nullptr, *m_partInfoAct = nullptr;
    QMenu* m_formatMenu = nullptr;
};
