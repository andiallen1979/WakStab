#pragma once
#include <glibmm/refptr.h>
#include <glibmm/object.h>

namespace Gdk {
class Pixbuf : public Glib::Object {
public:
    static Glib::RefPtr<Pixbuf> create() { return Glib::RefPtr<Pixbuf>(); }
};
} // namespace Gdk
