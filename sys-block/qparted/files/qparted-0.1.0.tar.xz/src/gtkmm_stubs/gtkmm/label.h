#pragma once
#include <glibmm/ustring.h>

namespace Gtk {
enum Align {
    ALIGN_FILL,
    ALIGN_START,
    ALIGN_END,
    ALIGN_CENTER,
    ALIGN_BASELINE
};

class Widget {
public:
    virtual ~Widget() = default;
};

class Label : public Widget {
public:
    explicit Label(const Glib::ustring& = "") {}
};
} // namespace Gtk
