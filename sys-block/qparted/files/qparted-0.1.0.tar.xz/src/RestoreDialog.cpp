#include "RestoreDialog.h"
#include "Utils.h"
#include <KLocalizedString>
#include <KMessageBox>
#include <QFileDialog>
#include <QFileInfo>
#include <QHBoxLayout>
#include <QMetaObject>
#include <QProcess>
#include <QStandardPaths>
#include <QVBoxLayout>
#include <cstdio>
#include <fcntl.h>
#include <thread>
#include <unistd.h>
#include <vector>

RestoreDialog::RestoreDialog(const QString& targetPath, GParted::Byte_Value targetBytes, bool isoOnly, QWidget* parent)
    : QDialog(parent), m_targetPath(targetPath), m_targetBytes(targetBytes), m_isoOnly(isoOnly) {
    setWindowTitle(m_isoOnly ? i18n("Write ISO Image to %1", m_targetPath) : i18n("Restore Image to %1", m_targetPath));
    resize(560, 220);

    auto* layout = new QVBoxLayout(this);
    QString capStr = QString::fromStdString(GParted::Utils::format_size(m_targetBytes / 512, 512).raw());
    layout->addWidget(new QLabel(i18n("Target: <b>%1</b> (Capacity: %2 — supports RAW, Sparse, ZST, GZ, XZ, QCOW2, VDI, VHD/VHDX, VMDK)", m_targetPath, capStr), this));

    auto* row = new QHBoxLayout();
    m_inEdit = new QLineEdit(this);
    m_inEdit->setPlaceholderText(i18n("Select source image file to restore..."));
    auto* browseBtn = new QPushButton(i18n("Browse..."), this);
    row->addWidget(m_inEdit, 1);
    row->addWidget(browseBtn);
    layout->addLayout(row);

    m_progress = new QProgressBar(this);
    m_progress->setRange(0, 1000);
    layout->addWidget(m_progress);

    m_statusLabel = new QLabel(i18n("Ready."), this);
    layout->addWidget(m_statusLabel);

    auto* btns = new QHBoxLayout();
    btns->addStretch(1);
    m_startBtn = new QPushButton(QIcon::fromTheme(QStringLiteral("dialog-ok-apply")), i18n("Restore Image"), this);
    m_closeBtn = new QPushButton(i18n("Close"), this);
    btns->addWidget(m_startBtn);
    btns->addWidget(m_closeBtn);
    layout->addLayout(btns);

    connect(browseBtn, &QPushButton::clicked, this, &RestoreDialog::browseInput);
    connect(m_startBtn, &QPushButton::clicked, this, &RestoreDialog::startRestore);
    connect(m_closeBtn, &QPushButton::clicked, this, [this]() { if (m_running) m_cancel = true; else reject(); });
}

RestoreDialog::~RestoreDialog() { m_cancel = true; }

void RestoreDialog::browseInput() {
    QString f = QFileDialog::getOpenFileName(this, i18n("Select Image to Restore"), QString(),
        m_isoOnly ? i18n("ISO Images (*.iso);;All Files (*)") : i18n("All Disk Images (*.iso *.img *.raw *.img.zst *.zst *.img.gz *.gz *.img.xz *.xz *.qcow2 *.vdi *.vhdx *.vhd *.vmdk);;All Files (*)"));
    if (!f.isEmpty()) m_inEdit->setText(f);
}

void RestoreDialog::startRestore() {
    QString inPath = m_inEdit->text().trimmed();
    QFileInfo fi(inPath);
    if (inPath.isEmpty() || !fi.exists() || m_running) return;

    if (KMessageBox::warningContinueCancel(this,
            i18n("WARNING: Restoring '%1' onto '%2' will PERMANENTLY OVERWRITE ALL DATA on %2!\n\nEnsure all partitions on %2 are unmounted before continuing.", fi.fileName(), m_targetPath),
            i18n("Confirm Image Restore")) != KMessageBox::Continue) return;

    m_running = true; m_cancel = false;
    m_startBtn->setEnabled(false); m_closeBtn->setText(i18n("Cancel"));
    m_statusLabel->setText(i18n("Restoring %1 to %2...", fi.fileName(), m_targetPath));

    std::thread([this, inPath, dst = m_targetPath.toUtf8()]() {
        QString lower = inPath.toLower();
        bool isVirt = lower.endsWith(QStringLiteral(".qcow2")) || lower.endsWith(QStringLiteral(".vdi")) ||
                      lower.endsWith(QStringLiteral(".vhdx")) || lower.endsWith(QStringLiteral(".vhd")) || lower.endsWith(QStringLiteral(".vmdk"));
        if (isVirt) {
            QString qimg = QStandardPaths::findExecutable(QStringLiteral("qemu-img"));
            int rc = !qimg.isEmpty() ? QProcess::execute(qimg, {QStringLiteral("convert"), QStringLiteral("-p"), QStringLiteral("-O"), QStringLiteral("raw"), inPath, m_targetPath}) : -1;
            QProcess::execute(QStringLiteral("blockdev"), {QStringLiteral("--rereadpt"), m_targetPath});
            QMetaObject::invokeMethod(this, [this, rc]() {
                m_progress->setValue(rc == 0 ? 1000 : 0);
                m_statusLabel->setText(rc == 0 ? i18n("Virtual disk image restored successfully!") : i18n("Restore failed (ensure app-emulation/qemu is installed and target is unmounted)."));
                if (rc == 0) m_restored = true;
                m_startBtn->setEnabled(true); m_closeBtn->setText(i18n("Close")); m_running = false;
            }, Qt::QueuedConnection);
            return;
        }
        int outFd = ::open(dst.constData(), O_WRONLY | O_CLOEXEC);
        int inFd = -1; FILE* pipeIn = nullptr;
        QString qIn = QString(inPath).replace(QLatin1Char('"'), QStringLiteral("\\\""));
        if (lower.endsWith(QStringLiteral(".zst"))) pipeIn = ::popen(QStringLiteral("zstd -d -c \"%1\"").arg(qIn).toUtf8().constData(), "r");
        else if (lower.endsWith(QStringLiteral(".gz"))) pipeIn = ::popen(QStringLiteral("gzip -d -c \"%1\"").arg(qIn).toUtf8().constData(), "r");
        else if (lower.endsWith(QStringLiteral(".xz"))) pipeIn = ::popen(QStringLiteral("xz -d -c \"%1\"").arg(qIn).toUtf8().constData(), "r");
        else inFd = ::open(inPath.toUtf8().constData(), O_RDONLY | O_CLOEXEC);

        if (outFd < 0 || (inFd < 0 && !pipeIn)) {
            if (outFd >= 0) ::close(outFd);
            if (inFd >= 0) ::close(inFd);
            if (pipeIn) ::pclose(pipeIn);
            QMetaObject::invokeMethod(this, [this]() { m_statusLabel->setText(i18n("Error opening source image or target device.")); m_startBtn->setEnabled(true); m_closeBtn->setText(i18n("Close")); m_running = false; }, Qt::QueuedConnection);
            return;
        }
        constexpr size_t kChunk = 4 * 1024 * 1024;
        std::vector<char> buf(kChunk);
        uint64_t written = 0;
        while (!m_cancel) {
            ssize_t n = pipeIn ? static_cast<ssize_t>(::fread(buf.data(), 1, kChunk, pipeIn)) : ::read(inFd, buf.data(), kChunk);
            if (n <= 0) break;
            ssize_t w = ::write(outFd, buf.data(), static_cast<size_t>(n));
            if (w <= 0) break;
            written += static_cast<uint64_t>(w);
            int permille = (m_targetBytes > 0) ? std::min(1000, static_cast<int>((written * 1000ULL) / static_cast<uint64_t>(m_targetBytes))) : 0;
            QMetaObject::invokeMethod(this, [this, permille, written]() {
                m_progress->setValue(permille);
                m_statusLabel->setText(i18n("Restored: %1 MiB", written / (1024 * 1024)));
            }, Qt::QueuedConnection);
        }
        ::fsync(outFd); ::close(outFd);
        if (inFd >= 0) ::close(inFd);
        if (pipeIn) ::pclose(pipeIn);
        QProcess::execute(QStringLiteral("blockdev"), {QStringLiteral("--rereadpt"), m_targetPath});
        QMetaObject::invokeMethod(this, [this, written]() {
            m_progress->setValue(m_cancel ? 0 : 1000);
            m_statusLabel->setText(m_cancel ? i18n("Cancelled.") : i18n("Restore complete! Wrote %1 MiB to %2.", written / (1024 * 1024), m_targetPath));
            if (!m_cancel) m_restored = true;
            m_startBtn->setEnabled(true); m_closeBtn->setText(i18n("Close")); m_running = false;
        }, Qt::QueuedConnection);
    }).detach();
}
