#include "FlagsDialog.h"
#include <KLocalizedString>
#include <QDialogButtonBox>
#include <QLabel>
#include <QVBoxLayout>
FlagsDialog::FlagsDialog(GParted::GParted_Core& core, const GParted::Partition& part, QWidget* parent)
: QDialog(parent), m_core(core), m_part(part) {
setWindowTitle(i18n("Manage flags on %1", QString::fromStdString(part.get_path().raw())));
resize(340, 380);
auto* layout = new QVBoxLayout(this);
layout->addWidget(new QLabel(i18n("Toggle partition flags immediately:"), this));
m_list = new QListWidget(this);
auto flags = m_core.get_available_flags(m_part);
for (const auto& [name, state] : flags) {
auto* item = new QListWidgetItem(QString::fromStdString(name.raw()), m_list);
item->setFlags(item->flags() | Qt::ItemIsUserCheckable);
item->setCheckState(state ? Qt::Checked : Qt::Unchecked);
}
layout->addWidget(m_list, 1);
connect(m_list, &QListWidget::itemChanged, this, [this](QListWidgetItem* item) {
bool checked = (item->checkState() == Qt::Checked);
m_core.toggle_flag(m_part, item->text().toUtf8().constData(), checked);
});
auto* btns = new QDialogButtonBox(QDialogButtonBox::Close, this);
connect(btns, &QDialogButtonBox::rejected, this, &QDialog::reject);
layout->addWidget(btns);
}
