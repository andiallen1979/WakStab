#pragma once

#include <QDialog>
#include <QLabel>
#include <QProgressBar>
#include <QPushButton>
#include <QTextEdit>
#include "GParted_Core.h"
#include "OperationQueue.h"

class ApplyDialog : public QDialog {
    Q_OBJECT
public:
    ApplyDialog(GParted::GParted_Core& core, OperationQueue& queue, QWidget* parent = nullptr);

private:
    void runOperations();

    GParted::GParted_Core& m_core;
    OperationQueue& m_queue;
    QLabel* m_statusLabel = nullptr;
    QProgressBar* m_progressBar = nullptr;
    QTextEdit* m_logView = nullptr;
    QPushButton* m_closeBtn = nullptr;
};
