#pragma once

#include <QDialog>
#include <QLabel>
#include <QProcess>
#include <QPushButton>
#include <QTextEdit>
#include "Device.h"

class RescueDialog : public QDialog {
    Q_OBJECT
public:
    RescueDialog(const GParted::Device& dev, QWidget* parent = nullptr);
    ~RescueDialog() override;

private:
    void startScan(const QString& tool, const QStringList& args);

    QString m_devPath;
    QLabel* m_statusLabel = nullptr;
    QTextEdit* m_output = nullptr;
    QPushButton* m_gpartBtn = nullptr;
    QPushButton* m_testdiskBtn = nullptr;
    QProcess* m_proc = nullptr;
};
