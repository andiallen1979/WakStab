#include "ImageDialog.h"
#include "Utils.h"
#include <KLocalizedString>
#include <QFileDialog>
#include <QHBoxLayout>
#include <QMetaObject>
#include <QStandardPaths>
#include <QVBoxLayout>
#include <cstdio>
#include <fcntl.h>
#include <mntent.h>
#include <sys/stat.h>
#include <thread>
#include <unistd.h>
#include <vector>

namespace {
void zeroFillMountedTargets(const QString& devPath, const std::atomic<bool>& cancel) {
    FILE* mtab = ::setmntent("/proc/mounts", "r");
    if (!mtab) return;
    QStringList mounts;
    while (struct mntent* ent = ::getmntent(mtab)) {
        QString fsname = QString::fromLocal8Bit(ent->mnt_fsname);
        if (fsname == devPath || fsname.startsWith(devPath + QLatin1Char('p')) ||
            (fsname.startsWith(devPath) && fsname.size() > devPath.size() && fsname[devPath.size()].isDigit()))
            mounts << QString::fromLocal8Bit(ent->mnt_dir);
    }
    ::endmntent(mtab);
    std::vector<char> zeros(4 * 1024 * 1024, 0);
    for (const QString& mnt : mounts) {
        if (cancel) break;
        QByteArray zf = (mnt + QStringLiteral("/zerofill.txt")).toLocal8Bit();
        int fd = ::open(zf.constData(), O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0600);
        if (fd < 0) continue;
        while (!cancel && ::write(fd, zeros.data(), zeros.size()) > 0) {}
        ::fsync(fd); ::close(fd); ::unlink(zf.constData());
    }
}
} // namespace

ImageDialog::ImageDialog(const QString& sourcePath, GParted::Byte_Value totalBytes, Mode mode, const QString& defaultExt, QWidget* parent)
    : QDialog(parent), m_sourcePath(sourcePath), m_totalBytes(totalBytes), m_mode(mode), m_defaultExt(defaultExt) {
    setWindowTitle(i18n("Create Image of %1", m_sourcePath));
    resize(560, 215);
    auto* layout = new QVBoxLayout(this);
    layout->addWidget(new QLabel(i18n("Source: <b>%1</b>", m_sourcePath), this));
    auto* row = new QHBoxLayout();
    m_outEdit = new QLineEdit(this);
    QString baseName = m_sourcePath.section(QLatin1Char('/'), -1);
    QString ext = !m_defaultExt.isEmpty() ? m_defaultExt : ((mode == Mode::ZeroFilledCompressed) ? QStringLiteral(".img.zst") : QStringLiteral(".img"));
    m_outEdit->setText(QStringLiteral("/usr/share/qparted/images/%1%2").arg(baseName, ext));
    auto* browseBtn = new QPushButton(i18n("Browse..."), this);
    row->addWidget(m_outEdit, 1); row->addWidget(browseBtn); layout->addLayout(row);
    m_progress = new QProgressBar(this); m_progress->setRange(0, 1000); layout->addWidget(m_progress);
    m_statusLabel = new QLabel(i18n("Ready."), this); layout->addWidget(m_statusLabel);
    auto* btns = new QHBoxLayout(); btns->addStretch(1);
    m_startBtn = new QPushButton(QIcon::fromTheme(QStringLiteral("dialog-ok-apply")), i18n("Start"), this);
    m_closeBtn = new QPushButton(i18n("Close"), this);
    btns->addWidget(m_startBtn); btns->addWidget(m_closeBtn); layout->addLayout(btns);
    connect(browseBtn, &QPushButton::clicked, this, &ImageDialog::browseOutput);
    connect(m_startBtn, &QPushButton::clicked, this, &ImageDialog::startImaging);
    connect(m_closeBtn, &QPushButton::clicked, this, [this]() { if (m_running) m_cancel = true; else reject(); });
}

ImageDialog::~ImageDialog() { m_cancel = true; }

void ImageDialog::browseOutput() {
    QString filter = (m_defaultExt == QStringLiteral(".iso")) ? i18n("ISO Images (*.iso);;All Files (*)")
        : (m_mode == Mode::ZeroFilledCompressed) ? i18n("Compressed Images (*.img.zst *.img.gz *.img.xz);;All Files (*)")
        : i18n("Disk Images (*.img *.raw);;All Files (*)");
    QString f = QFileDialog::getSaveFileName(this, i18n("Save Image"), m_outEdit->text(), filter);
    if (!f.isEmpty()) m_outEdit->setText(f);
}

void ImageDialog::startImaging() {
    QString outPath = m_outEdit->text().trimmed();
    if (outPath.isEmpty() || m_running) return;
    m_running = true; m_cancel = false; m_startBtn->setEnabled(false); m_closeBtn->setText(i18n("Cancel"));
    std::thread([this, src = m_sourcePath.toUtf8(), dst = outPath.toUtf8()]() {
        if (m_mode == Mode::ZeroFilledCompressed) zeroFillMountedTargets(m_sourcePath, m_cancel);
        int inFd = ::open(src.constData(), O_RDONLY | O_CLOEXEC), outFd = -1; FILE* pipeOut = nullptr;
        if (m_mode == Mode::ZeroFilledCompressed) {
            QString cmd = !QStandardPaths::findExecutable(QStringLiteral("zstd")).isEmpty()
                ? QStringLiteral("zstd -T0 -3 -f -o \"%1\"").arg(QString::fromUtf8(dst)) : QStringLiteral("gzip -c > \"%1\"").arg(QString::fromUtf8(dst));
            pipeOut = ::popen(cmd.toUtf8().constData(), "w");
        } else outFd = ::open(dst.constData(), O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0644);
        if (inFd < 0 || (outFd < 0 && !pipeOut)) {
            if (inFd >= 0) ::close(inFd);
            if (outFd >= 0) ::close(outFd);
            if (pipeOut) ::pclose(pipeOut);
            QMetaObject::invokeMethod(this, [this]() { m_statusLabel->setText(i18n("Error opening source or destination.")); m_startBtn->setEnabled(true); m_closeBtn->setText(i18n("Close")); m_running = false; }, Qt::QueuedConnection);
            return;
        }
        std::vector<uint64_t> buf((4 * 1024 * 1024) / sizeof(uint64_t), 0);
        uint64_t processed = 0, skipped = 0;
        while (!m_cancel) {
            ssize_t n = ::read(inFd, buf.data(), buf.size() * sizeof(uint64_t));
            if (n <= 0) break;
            if (pipeOut) ::fwrite(buf.data(), 1, static_cast<size_t>(n), pipeOut);
            else if (m_mode == Mode::Sparse) {
                bool zero = true;
                for (size_t i = 0; i < static_cast<size_t>(n) / 8; ++i) if (buf[i] != 0) { zero = false; break; }
                if (zero) { ::lseek(outFd, n, SEEK_CUR); skipped += static_cast<uint64_t>(n); }
                else if (::write(outFd, buf.data(), static_cast<size_t>(n)) < 0) break;
            } else if (::write(outFd, buf.data(), static_cast<size_t>(n)) < 0) break;
            processed += static_cast<uint64_t>(n);
            int pm = (m_totalBytes > 0) ? static_cast<int>((processed * 1000ULL) / static_cast<uint64_t>(m_totalBytes)) : 0;
            QMetaObject::invokeMethod(this, [this, pm, processed, skipped]() { m_progress->setValue(pm); m_statusLabel->setText(i18n("Processed: %1 MiB (Sparse skipped: %2 MiB)", processed / 1048576, skipped / 1048576)); }, Qt::QueuedConnection);
        }
        if (outFd >= 0 && !m_cancel) ::ftruncate(outFd, static_cast<off_t>(processed));
        if (outFd >= 0) ::close(outFd);
        if (pipeOut) ::pclose(pipeOut);
        ::close(inFd);
        QMetaObject::invokeMethod(this, [this, processed]() { m_progress->setValue(m_cancel ? 0 : 1000); m_statusLabel->setText(m_cancel ? i18n("Cancelled.") : i18n("Done! (%1 MiB)", processed / 1048576)); m_startBtn->setEnabled(true); m_closeBtn->setText(i18n("Close")); m_running = false; }, Qt::QueuedConnection);
    }).detach();
}
