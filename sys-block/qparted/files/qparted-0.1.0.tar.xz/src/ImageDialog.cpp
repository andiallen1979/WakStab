#include "ImageDialog.h"
#include "Utils.h"
#include <KLocalizedString>
#include <QFileDialog>
#include <QHBoxLayout>
#include <QMetaObject>
#include <QStandardPaths>
#include <QVBoxLayout>
#include <cstdio>
#include <fcntl.h>
#include <mntent.h>
#include <sys/stat.h>
#include <thread>
#include <unistd.h>
#include <vector>

namespace {
void zeroFillMountedTargets(const QString& devPath, const std::atomic<bool>& cancel) {
    FILE* mtab = ::setmntent("/proc/mounts", "r");
    if (!mtab) return;
    QStringList mounts;
    while (struct mntent* ent = ::getmntent(mtab)) {
        QString fsname = QString::fromLocal8Bit(ent->mnt_fsname);
        if (fsname == devPath || fsname.startsWith(devPath + QLatin1Char('p')) ||
            (fsname.startsWith(devPath) && fsname.size() > devPath.size() && fsname[devPath.size()].isDigit())) {
            mounts << QString::fromLocal8Bit(ent->mnt_dir);
        }
    }
    ::endmntent(mtab);

    std::vector<char> zeros(4 * 1024 * 1024, 0);
    for (const QString& mnt : mounts) {
        if (cancel) break;
        QByteArray zf = (mnt + QStringLiteral("/zerofill.txt")).toLocal8Bit();
        int fd = ::open(zf.constData(), O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0600);
        if (fd < 0) continue;
        while (!cancel) {
            ssize_t w = ::write(fd, zeros.data(), zeros.size());
            if (w <= 0) break;
        }
        ::fsync(fd);
        ::close(fd);
        ::unlink(zf.constData());
    }
}
} // namespace

ImageDialog::ImageDialog(const QString& sourcePath, GParted::Byte_Value totalBytes, Mode mode, const QString& defaultExt, QWidget* parent)
    : QDialog(parent), m_sourcePath(sourcePath), m_totalBytes(totalBytes), m_mode(mode), m_defaultExt(defaultExt) {
    QString modeTitle = (mode == Mode::Sparse) ? i18n("Create Sparse Image of %1", m_sourcePath)
        : (mode == Mode::FullRaw) ? i18n("Create Full Raw Image of %1", m_sourcePath)
        : i18n("Create Zero-Filled Compressed Image of %1", m_sourcePath);
    setWindowTitle(modeTitle);
    resize(560, 215);

    auto* layout = new QVBoxLayout(this);
    QString logicalStr = QString::fromStdString(GParted::Utils::format_size(m_totalBytes / 512, 512).raw());
    layout->addWidget(new QLabel(i18n("Source: <b>%1</b> (Size: %2)", m_sourcePath, logicalStr), this));

    auto* row = new QHBoxLayout();
    m_outEdit = new QLineEdit(this);
    QString baseName = m_sourcePath.section(QLatin1Char('/'), -1);
    QString ext = !m_defaultExt.isEmpty() ? m_defaultExt : ((mode == Mode::ZeroFilledCompressed) ? QStringLiteral(".img.zst") : QStringLiteral(".img"));
    m_outEdit->setText(QStringLiteral("/tmp/%1%2").arg(baseName, ext));
    auto* browseBtn = new QPushButton(i18n("Browse..."), this);
    row->addWidget(m_outEdit, 1);
    row->addWidget(browseBtn);
    layout->addLayout(row);

    m_progress = new QProgressBar(this);
    m_progress->setRange(0, 1000);
    layout->addWidget(m_progress);

    m_statusLabel = new QLabel(i18n("Ready."), this);
    layout->addWidget(m_statusLabel);

    auto* btns = new QHBoxLayout();
    btns->addStretch(1);
    m_startBtn = new QPushButton(QIcon::fromTheme(QStringLiteral("dialog-ok-apply")), i18n("Start"), this);
    m_closeBtn = new QPushButton(i18n("Close"), this);
    btns->addWidget(m_startBtn);
    btns->addWidget(m_closeBtn);
    layout->addLayout(btns);

    connect(browseBtn, &QPushButton::clicked, this, &ImageDialog::browseOutput);
    connect(m_startBtn, &QPushButton::clicked, this, &ImageDialog::startImaging);
    connect(m_closeBtn, &QPushButton::clicked, this, [this]() { if (m_running) m_cancel = true; else reject(); });
}

ImageDialog::~ImageDialog() { m_cancel = true; }

void ImageDialog::browseOutput() {
    QString filter = (m_mode == Mode::ZeroFilledCompressed)
        ? i18n("Compressed Disk Images (*.img.zst *.img.gz *.img.xz);;All Files (*)")
        : (m_defaultExt == QStringLiteral(".iso")) ? i18n("ISO Images (*.iso);;All Files (*)") : i18n("Disk Images (*.img *.raw);;All Files (*)");
    QString f = QFileDialog::getSaveFileName(this, i18n("Save Image"), m_outEdit->text(), filter);
    if (!f.isEmpty()) m_outEdit->setText(f);
}

void ImageDialog::startImaging() {
    QString outPath = m_outEdit->text().trimmed();
    if (outPath.isEmpty() || m_running) return;
    m_running = true; m_cancel = false;
    m_startBtn->setEnabled(false); m_closeBtn->setText(i18n("Cancel"));

    std::thread([this, src = m_sourcePath.toUtf8(), dst = outPath.toUtf8()]() {
        if (m_mode == Mode::ZeroFilledCompressed) {
            QMetaObject::invokeMethod(this, [this]() { m_statusLabel->setText(i18n("Zero-filling free space via zerofill.txt...")); }, Qt::QueuedConnection);
            zeroFillMountedTargets(m_sourcePath, m_cancel);
        }
        int inFd = ::open(src.constData(), O_RDONLY | O_CLOEXEC);
        int outFd = -1; FILE* pipeOut = nullptr;
        if (m_mode == Mode::ZeroFilledCompressed) {
            QString zstd = QStandardPaths::findExecutable(QStringLiteral("zstd"));
            QString pigz = QStandardPaths::findExecutable(QStringLiteral("pigz"));
            QString cmd = !zstd.isEmpty() ? QStringLiteral("zstd -T0 -3 -f -o \"%1\"").arg(QString::fromUtf8(dst))
                : (!pigz.isEmpty() ? QStringLiteral("pigz -c > \"%1\"").arg(QString::fromUtf8(dst)) : QStringLiteral("xz -T0 -c > \"%1\"").arg(QString::fromUtf8(dst)));
            pipeOut = ::popen(cmd.toUtf8().constData(), "w");
        } else {
            outFd = ::open(dst.constData(), O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0644);
        }
        if (inFd < 0 || (outFd < 0 && !pipeOut)) {
            if (inFd >= 0) ::close(inFd);
            if (outFd >= 0) ::close(outFd);
            if (pipeOut) ::pclose(pipeOut);
            QMetaObject::invokeMethod(this, [this]() { m_statusLabel->setText(i18n("Error opening source or destination.")); m_startBtn->setEnabled(true); m_closeBtn->setText(i18n("Close")); m_running = false; }, Qt::QueuedConnection);
            return;
        }
        constexpr size_t kChunk = 4 * 1024 * 1024;
        std::vector<uint64_t> buf(kChunk / sizeof(uint64_t), 0);
        uint64_t processed = 0, sparseSkipped = 0;
        while (!m_cancel) {
            ssize_t n = ::read(inFd, buf.data(), kChunk);
            if (n <= 0) break;
            if (pipeOut) {
                ::fwrite(buf.data(), 1, static_cast<size_t>(n), pipeOut);
            } else if (m_mode == Mode::Sparse) {
                size_t words = static_cast<size_t>(n) / sizeof(uint64_t);
                bool allZero = true;
                for (size_t i = 0; i < words; ++i) if (buf[i] != 0) { allZero = false; break; }
                for (size_t i = words * sizeof(uint64_t); allZero && i < static_cast<size_t>(n); ++i)
                    if (reinterpret_cast<const uint8_t*>(buf.data())[i] != 0) allZero = false;
                if (allZero) { ::lseek(outFd, n, SEEK_CUR); sparseSkipped += static_cast<uint64_t>(n); }
                else { ::write(outFd, buf.data(), static_cast<size_t>(n)); }
            } else {
                ::write(outFd, buf.data(), static_cast<size_t>(n));
            }
            processed += static_cast<uint64_t>(n);
            int permille = (m_totalBytes > 0) ? static_cast<int>((processed * 1000ULL) / static_cast<uint64_t>(m_totalBytes)) : 0;
            QMetaObject::invokeMethod(this, [this, permille, processed, sparseSkipped]() {
                m_progress->setValue(permille);
                m_statusLabel->setText((m_mode == Mode::Sparse)
                    ? i18n("Processed: %1 MiB | Zero-skipped: %2 MiB", processed / (1024 * 1024), sparseSkipped / (1024 * 1024))
                    : i18n("Written: %1 MiB", processed / (1024 * 1024)));
            }, Qt::QueuedConnection);
        }
        if (outFd >= 0 && !m_cancel) ::ftruncate(outFd, static_cast<off_t>(processed));
        if (outFd >= 0) ::close(outFd);
        if (pipeOut) ::pclose(pipeOut);
        ::close(inFd);
        struct stat st{}; ::stat(dst.constData(), &st);
        uint64_t actualBytes = static_cast<uint64_t>(st.st_blocks) * 512ULL;
        QMetaObject::invokeMethod(this, [this, actualBytes, processed]() {
            m_progress->setValue(m_cancel ? 0 : 1000);
            m_statusLabel->setText(m_cancel ? i18n("Cancelled.")
                : i18n("Done! Source: %1 MiB | File disk usage: %2 MiB", processed / (1024 * 1024), actualBytes / (1024 * 1024)));
            m_startBtn->setEnabled(true); m_closeBtn->setText(i18n("Close")); m_running = false;
        }, Qt::QueuedConnection);
    }).detach();
}
