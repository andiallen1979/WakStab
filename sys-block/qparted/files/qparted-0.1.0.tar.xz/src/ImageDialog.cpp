#include "ImageDialog.h"
#include "Utils.h"
#include <KLocalizedString>
#include <QFileDialog>
#include <QHBoxLayout>
#include <QMetaObject>
#include <QVBoxLayout>
#include <fcntl.h>
#include <sys/stat.h>
#include <thread>
#include <unistd.h>
#include <vector>

ImageDialog::ImageDialog(const QString& sourcePath, GParted::Byte_Value totalBytes, QWidget* parent)
    : QDialog(parent), m_sourcePath(sourcePath), m_totalBytes(totalBytes) {
    setWindowTitle(i18n("Create Sparse Image of %1", m_sourcePath));
    resize(540, 210);

    auto* layout = new QVBoxLayout(this);
    QString logicalStr = QString::fromStdString(GParted::Utils::format_size(m_totalBytes / 512, 512).raw());
    layout->addWidget(new QLabel(i18n("Source: <b>%1</b> (Logical size: %2 — zero blocks stored as sparse holes)", m_sourcePath, logicalStr), this));

    auto* row = new QHBoxLayout();
    m_outEdit = new QLineEdit(this);
    m_outEdit->setText(QStringLiteral("/tmp/%1.img").arg(m_sourcePath.section(QLatin1Char('/'), -1)));
    auto* browseBtn = new QPushButton(i18n("Browse..."), this);
    row->addWidget(m_outEdit, 1);
    row->addWidget(browseBtn);
    layout->addLayout(row);

    m_progress = new QProgressBar(this);
    m_progress->setRange(0, 1000);
    layout->addWidget(m_progress);

    m_statusLabel = new QLabel(i18n("Ready."), this);
    layout->addWidget(m_statusLabel);

    auto* btns = new QHBoxLayout();
    btns->addStretch(1);
    m_startBtn = new QPushButton(QIcon::fromTheme(QStringLiteral("dialog-ok-apply")), i18n("Create Sparse Image"), this);
    m_closeBtn = new QPushButton(i18n("Close"), this);
    btns->addWidget(m_startBtn);
    btns->addWidget(m_closeBtn);
    layout->addLayout(btns);

    connect(browseBtn, &QPushButton::clicked, this, &ImageDialog::browseOutput);
    connect(m_startBtn, &QPushButton::clicked, this, &ImageDialog::startImaging);
    connect(m_closeBtn, &QPushButton::clicked, this, [this]() { if (m_running) m_cancel = true; else reject(); });
}

ImageDialog::~ImageDialog() { m_cancel = true; }

void ImageDialog::browseOutput() {
    QString f = QFileDialog::getSaveFileName(this, i18n("Save Sparse Image"), m_outEdit->text(), i18n("Disk Images (*.img *.raw);;All Files (*)"));
    if (!f.isEmpty()) m_outEdit->setText(f);
}

void ImageDialog::startImaging() {
    QString outPath = m_outEdit->text().trimmed();
    if (outPath.isEmpty() || m_running) return;
    m_running = true; m_cancel = false;
    m_startBtn->setEnabled(false); m_closeBtn->setText(i18n("Cancel"));
    m_statusLabel->setText(i18n("Imaging %1...", m_sourcePath));

    std::thread([this, src = m_sourcePath.toUtf8(), dst = outPath.toUtf8()]() {
        int inFd = ::open(src.constData(), O_RDONLY | O_CLOEXEC);
        int outFd = ::open(dst.constData(), O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0644);
        if (inFd < 0 || outFd < 0) {
            if (inFd >= 0) ::close(inFd);
            if (outFd >= 0) ::close(outFd);
            QMetaObject::invokeMethod(this, [this]() {
                m_statusLabel->setText(i18n("Error: Could not open source or destination."));
                m_startBtn->setEnabled(true); m_closeBtn->setText(i18n("Close")); m_running = false;
            }, Qt::QueuedConnection);
            return;
        }
        constexpr size_t kChunk = 4 * 1024 * 1024;
        std::vector<uint64_t> buf(kChunk / sizeof(uint64_t), 0);
        uint64_t processed = 0, sparseSkipped = 0;
        while (!m_cancel) {
            ssize_t n = ::read(inFd, buf.data(), kChunk);
            if (n <= 0) break;
            size_t words = static_cast<size_t>(n) / sizeof(uint64_t);
            bool allZero = true;
            for (size_t i = 0; i < words; ++i) if (buf[i] != 0) { allZero = false; break; }
            for (size_t i = words * sizeof(uint64_t); allZero && i < static_cast<size_t>(n); ++i)
                if (reinterpret_cast<const uint8_t*>(buf.data())[i] != 0) allZero = false;
            if (allZero) { ::lseek(outFd, n, SEEK_CUR); sparseSkipped += static_cast<uint64_t>(n); }
            else { ::write(outFd, buf.data(), static_cast<size_t>(n)); }
            processed += static_cast<uint64_t>(n);
            int permille = (m_totalBytes > 0) ? static_cast<int>((processed * 1000ULL) / static_cast<uint64_t>(m_totalBytes)) : 0;
            QMetaObject::invokeMethod(this, [this, permille, processed, sparseSkipped]() {
                m_progress->setValue(permille);
                m_statusLabel->setText(i18n("Processed: %1 MiB | Zero-skipped (sparse): %2 MiB", processed / (1024 * 1024), sparseSkipped / (1024 * 1024)));
            }, Qt::QueuedConnection);
        }
        if (!m_cancel) ::ftruncate(outFd, static_cast<off_t>(processed));
        struct stat st{}; ::fstat(outFd, &st);
        uint64_t actualBytes = static_cast<uint64_t>(st.st_blocks) * 512ULL;
        ::close(inFd); ::close(outFd);
        QMetaObject::invokeMethod(this, [this, actualBytes, processed]() {
            m_progress->setValue(m_cancel ? 0 : 1000);
            m_statusLabel->setText(m_cancel ? i18n("Cancelled.")
                : i18n("Done! Logical size: %1 MiB | Actual disk usage: %2 MiB", processed / (1024 * 1024), actualBytes / (1024 * 1024)));
            m_startBtn->setEnabled(true); m_closeBtn->setText(i18n("Close")); m_running = false;
        }, Qt::QueuedConnection);
    }).detach();
}
