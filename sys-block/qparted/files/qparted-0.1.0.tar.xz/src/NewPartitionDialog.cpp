#include "NewPartitionDialog.h"
#include "Utils.h"
#include <KLocalizedString>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QVBoxLayout>
#include <algorithm>
NewPartitionDialog::NewPartitionDialog(const GParted::Device& dev, const GParted::Partition& unallocated, QWidget* parent)
: QDialog(parent), m_dev(dev), m_unalloc(unallocated) {
setWindowTitle(i18n("Create New Partition"));
resize(400, 220);
auto* layout = new QVBoxLayout(this);
auto* form = new QFormLayout();
const GParted::Byte_Value bytes = m_unalloc.get_byte_length();
const int maxMib = std::max(1, static_cast<int>(bytes / GParted::MEBIBYTE));
m_sizeSpin = new QSpinBox(this);
m_sizeSpin->setRange(1, maxMib);
m_sizeSpin->setValue(maxMib);
m_sizeSpin->setSuffix(QStringLiteral(" MiB"));
form->addRow(i18n("New size:"), m_sizeSpin);
m_typeCombo = new QComboBox(this);
m_typeCombo->addItem(i18n("Primary Partition"), static_cast<int>(GParted::TYPE_PRIMARY));
if (m_unalloc.inside_extended) {
m_typeCombo->clear();
m_typeCombo->addItem(i18n("Logical Partition"), static_cast<int>(GParted::TYPE_LOGICAL));
} else if (m_dev.disktype == "msdos") {
m_typeCombo->addItem(i18n("Extended Partition"), static_cast<int>(GParted::TYPE_EXTENDED));
}
form->addRow(i18n("Create as:"), m_typeCombo);
m_fsCombo = new QComboBox(this);
const std::vector<std::pair<QString, GParted::FSType>> fsItems = {
{QStringLiteral("ext4"), GParted::FS_EXT4}, {QStringLiteral("btrfs"), GParted::FS_BTRFS},
{QStringLiteral("xfs"), GParted::FS_XFS}, {QStringLiteral("fat32"), GParted::FS_FAT32},
{QStringLiteral("exfat"), GParted::FS_EXFAT}, {QStringLiteral("ntfs"), GParted::FS_NTFS},
{QStringLiteral("linux-swap"), GParted::FS_LINUX_SWAP}, {QStringLiteral("unformatted"), GParted::FS_UNFORMATTED}
};
for (const auto& [name, fstype] : fsItems)
m_fsCombo->addItem(name, static_cast<int>(fstype));
form->addRow(i18n("File system:"), m_fsCombo);
m_labelEdit = new QLineEdit(this);
form->addRow(i18n("Label:"), m_labelEdit);
layout->addLayout(form);
auto* buttons = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
connect(buttons, &QDialogButtonBox::accepted, this, &QDialog::accept);
connect(buttons, &QDialogButtonBox::rejected, this, &QDialog::reject);
layout->addWidget(buttons);
}
GParted::Partition NewPartitionDialog::buildPartition() const {
auto ptype = static_cast<GParted::PartitionType>(m_typeCombo->currentData().toInt());
auto fstype = (ptype == GParted::TYPE_EXTENDED)
? GParted::FS_EXTENDED : static_cast<GParted::FSType>(m_fsCombo->currentData().toInt());
GParted::Sector alignSec = std::max<GParted::Sector>(1, GParted::MEBIBYTE / m_dev.sector_size);
GParted::Sector reqSectors = (static_cast<GParted::Sector>(m_sizeSpin->value()) * GParted::MEBIBYTE) / m_dev.sector_size;
GParted::Sector start = ((m_unalloc.sector_start + alignSec - 1) / alignSec) * alignSec;
GParted::Sector maxSafeEnd = ((m_unalloc.sector_end + 1) / alignSec) * alignSec - 1;
if (maxSafeEnd <= start) maxSafeEnd = m_unalloc.sector_end;
GParted::Sector alignedLen = std::max<GParted::Sector>(alignSec, (reqSectors / alignSec) * alignSec);
GParted::Sector end = std::min(maxSafeEnd, start + alignedLen - 1);
GParted::Partition part;
part.Set(m_dev.get_path(), QStringLiteral("New Partition #1").toUtf8().constData(),
1, ptype, fstype, start, end, m_dev.sector_size, m_unalloc.inside_extended, false);
part.alignment = GParted::ALIGN_MEBIBYTE;
if (!m_labelEdit->text().isEmpty() && ptype != GParted::TYPE_EXTENDED)
part.set_filesystem_label(m_labelEdit->text().toUtf8().constData());
return part;
}
