#include "ResizeMoveDialog.h"
#include "Utils.h"
#include <KLocalizedString>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QMouseEvent>
#include <QPainter>
#include <QVBoxLayout>
#include <algorithm>
#include <functional>

class ResizeBarWidget : public QWidget {
public:
    int totalMib = 100, minUsedMib = 1, beforeMib = 0, sizeMib = 100;
    QColor fsColor = QColor(114, 159, 207);
    std::function<void(int, int)> onChanged;

    explicit ResizeBarWidget(QWidget* parent = nullptr) : QWidget(parent) {
        setMinimumHeight(56);
        setMouseTracking(true);
    }

protected:
    void paintEvent(QPaintEvent*) override {
        QPainter p(this);
        p.setRenderHint(QPainter::Antialiasing, true);
        QRectF track = rect().adjusted(8, 10, -8, -10);
        p.setPen(QPen(palette().color(QPalette::Mid), 1.0));
        p.setBrush(palette().color(QPalette::Base));
        p.drawRoundedRect(track, 5.0, 5.0);

        double scale = track.width() / std::max(1, totalMib);
        double x = track.left() + beforeMib * scale;
        double w = std::max(14.0, sizeMib * scale);
        m_partRect = QRectF(x, track.top() + 3, std::min(w, track.right() - x), track.height() - 6);

        p.setPen(QPen(palette().color(QPalette::Highlight), 2.0));
        bool isDark = palette().color(QPalette::Window).lightness() < 128;
        p.setBrush(isDark ? fsColor.darker(135) : fsColor.lighter(115));
        p.drawRoundedRect(m_partRect, 4.0, 4.0);

        // Left & right resize handles
        p.setBrush(palette().color(QPalette::Highlight));
        p.drawRect(QRectF(m_partRect.left(), m_partRect.top() + 6, 5, m_partRect.height() - 12));
        p.drawRect(QRectF(m_partRect.right() - 5, m_partRect.top() + 6, 5, m_partRect.height() - 12));
    }

    void mousePressEvent(QMouseEvent* e) override {
        double px = e->position().x();
        m_dragStartX = px;
        m_origBefore = beforeMib;
        m_origSize = sizeMib;
        if (std::abs(px - m_partRect.left()) <= 10.0) m_mode = 1;
        else if (std::abs(px - m_partRect.right()) <= 10.0) m_mode = 2;
        else if (m_partRect.contains(e->position())) m_mode = 3;
        else m_mode = 0;
    }

    void mouseMoveEvent(QMouseEvent* e) override {
        double px = e->position().x();
        if (m_mode == 0) {
            bool edge = (std::abs(px - m_partRect.left()) <= 10.0 || std::abs(px - m_partRect.right()) <= 10.0);
            setCursor(edge ? Qt::SizeHorCursor : (m_partRect.contains(e->position()) ? Qt::OpenHandCursor : Qt::ArrowCursor));
            return;
        }
        double trackW = std::max(1.0, width() - 16.0);
        int deltaMib = static_cast<int>(((px - m_dragStartX) / trackW) * totalMib);
        int nb = m_origBefore, ns = m_origSize;

        if (m_mode == 1) { // Left edge resize
            nb = std::clamp(m_origBefore + deltaMib, 0, m_origBefore + m_origSize - minUsedMib);
            ns = (m_origBefore + m_origSize) - nb;
        } else if (m_mode == 2) { // Right edge resize
            ns = std::clamp(m_origSize + deltaMib, minUsedMib, totalMib - m_origBefore);
        } else if (m_mode == 3) { // Move entire block
            nb = std::clamp(m_origBefore + deltaMib, 0, totalMib - m_origSize);
        }
        if (onChanged) onChanged(nb, ns);
    }

    void mouseReleaseEvent(QMouseEvent*) override { m_mode = 0; }

private:
    QRectF m_partRect;
    int m_mode = 0, m_origBefore = 0, m_origSize = 0;
    double m_dragStartX = 0.0;
};

ResizeMoveDialog::ResizeMoveDialog(const GParted::Device& dev, const GParted::Partition& part,
                                   GParted::Sector minStart, GParted::Sector maxEnd, QWidget* parent)
    : QDialog(parent), m_dev(dev), m_orig(part), m_minStart(minStart), m_maxEnd(maxEnd) {
    setWindowTitle(i18n("Resize/Move %1", QString::fromStdString(part.get_path().raw())));
    resize(520, 260);

    const GParted::Sector spanSectors = m_maxEnd - m_minStart + 1;
    m_totalMib = std::max(1, static_cast<int>((spanSectors * m_dev.sector_size) / GParted::MEBIBYTE));
    int usedMib = (part.sectors_used > 0) ? static_cast<int>((part.sectors_used * m_dev.sector_size) / GParted::MEBIBYTE) : 1;
    m_minUsedMib = std::clamp(usedMib, 1, m_totalMib);

    int initBefore = std::max(0, static_cast<int>(((part.sector_start - m_minStart) * m_dev.sector_size) / GParted::MEBIBYTE));
    int initSize = std::clamp(static_cast<int>((part.get_sector_length() * m_dev.sector_size) / GParted::MEBIBYTE), m_minUsedMib, m_totalMib - initBefore);

    auto* layout = new QVBoxLayout(this);
    m_bar = new ResizeBarWidget(this);
    m_bar->totalMib = m_totalMib;
    m_bar->minUsedMib = m_minUsedMib;
    m_bar->fsColor = QColor(QString::fromStdString(GParted::Utils::get_color(part.fstype).raw()));
    layout->addWidget(m_bar);

    auto* form = new QFormLayout();
    m_beforeSpin = new QSpinBox(this);
    m_beforeSpin->setRange(0, m_totalMib - m_minUsedMib);
    m_beforeSpin->setValue(initBefore);
    m_beforeSpin->setSuffix(QStringLiteral(" MiB"));
    form->addRow(i18n("Free space preceding:"), m_beforeSpin);

    m_sizeSpin = new QSpinBox(this);
    m_sizeSpin->setRange(m_minUsedMib, m_totalMib);
    m_sizeSpin->setValue(initSize);
    m_sizeSpin->setSuffix(QStringLiteral(" MiB"));
    form->addRow(i18n("New size:"), m_sizeSpin);

    m_afterSpin = new QSpinBox(this);
    m_afterSpin->setRange(0, m_totalMib - m_minUsedMib);
    m_afterSpin->setValue(std::max(0, m_totalMib - initBefore - initSize));
    m_afterSpin->setSuffix(QStringLiteral(" MiB"));
    form->addRow(i18n("Free space following:"), m_afterSpin);
    layout->addLayout(form);

    m_bar->onChanged = [this](int nb, int ns) {
        m_beforeSpin->blockSignals(true); m_sizeSpin->blockSignals(true); m_afterSpin->blockSignals(true);
        m_beforeSpin->setValue(nb); m_sizeSpin->setValue(ns); m_afterSpin->setValue(std::max(0, m_totalMib - nb - ns));
        m_beforeSpin->blockSignals(false); m_sizeSpin->blockSignals(false); m_afterSpin->blockSignals(false);
        syncFromSpins();
    };
    connect(m_beforeSpin, QOverload<int>::of(&QSpinBox::valueChanged), this, &ResizeMoveDialog::syncFromSpins);
    connect(m_sizeSpin, QOverload<int>::of(&QSpinBox::valueChanged), this, &ResizeMoveDialog::syncFromSpins);
    syncFromSpins();

    auto* btns = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
    connect(btns, &QDialogButtonBox::accepted, this, &QDialog::accept);
    connect(btns, &QDialogButtonBox::rejected, this, &QDialog::reject);
    layout->addWidget(btns);
}

void ResizeMoveDialog::syncFromSpins() {
    int nb = std::clamp(m_beforeSpin->value(), 0, m_totalMib - m_minUsedMib);
    int ns = std::clamp(m_sizeSpin->value(), m_minUsedMib, m_totalMib - nb);
    m_afterSpin->blockSignals(true);
    m_afterSpin->setValue(std::max(0, m_totalMib - nb - ns));
    m_afterSpin->blockSignals(false);
    m_bar->beforeMib = nb;
    m_bar->sizeMib = ns;
    m_bar->update();
}

GParted::Partition ResizeMoveDialog::buildPartition() const {
    GParted::Partition next = m_orig;
    GParted::Sector beforeSec = (static_cast<GParted::Sector>(m_beforeSpin->value()) * GParted::MEBIBYTE) / m_dev.sector_size;
    GParted::Sector sizeSec = (static_cast<GParted::Sector>(m_sizeSpin->value()) * GParted::MEBIBYTE) / m_dev.sector_size;
    next.sector_start = m_minStart + beforeSec;
    next.sector_end = std::min(m_maxEnd, next.sector_start + std::max<GParted::Sector>(1, sizeSec) - 1);
    return next;
}
