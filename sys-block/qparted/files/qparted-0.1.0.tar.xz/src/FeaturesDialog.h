#pragma once

#include <QDialog>
#include "GParted_Core.h"

class FeaturesDialog : public QDialog {
    Q_OBJECT
public:
    explicit FeaturesDialog(GParted::GParted_Core& core, QWidget* parent = nullptr);
};
