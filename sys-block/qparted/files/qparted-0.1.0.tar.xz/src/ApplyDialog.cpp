#include "ApplyDialog.h"
#include <KLocalizedString>
#include <QMetaObject>
#include <QTimer>
#include <QVBoxLayout>
#include <thread>

namespace {
void dumpDetails(const GParted::OperationDetail& detail, QString& out, int depth = 0) {
    QString indent(depth * 2, QLatin1Char(' '));
    QString desc = QString::fromStdString(detail.get_description().raw());
    if (!desc.isEmpty())
        out += indent + QStringLiteral("• ") + desc + QLatin1Char('\n');
    for (const auto& child : detail.get_children()) {
        if (child) dumpDetails(*child, out, depth + 1);
    }
}
} // namespace

ApplyDialog::ApplyDialog(GParted::GParted_Core& core, OperationQueue& queue, QWidget* parent)
    : QDialog(parent), m_core(core), m_queue(queue) {
    setWindowTitle(i18n("Applying Pending Operations"));
    resize(640, 420);
    setModal(true);

    auto* layout = new QVBoxLayout(this);
    m_statusLabel = new QLabel(i18n("Preparing operations..."), this);
    layout->addWidget(m_statusLabel);

    m_progressBar = new QProgressBar(this);
    m_progressBar->setRange(0, m_queue.count());
    m_progressBar->setValue(0);
    layout->addWidget(m_progressBar);

    m_logView = new QTextEdit(this);
    m_logView->setReadOnly(true);
    layout->addWidget(m_logView, 1);

    m_closeBtn = new QPushButton(i18n("Close"), this);
    m_closeBtn->setEnabled(false);
    connect(m_closeBtn, &QPushButton::clicked, this, &QDialog::accept);
    layout->addWidget(m_closeBtn, 0, Qt::AlignRight);

    QTimer::singleShot(100, this, &ApplyDialog::runOperations);
}

void ApplyDialog::runOperations() {
    std::thread([this]() {
        int step = 0;
        bool allOk = true;

        for (const auto& op : m_queue.operations()) {
            op->create_description();
            QString desc = QString::fromStdString(op->m_description.raw());

            QMetaObject::invokeMethod(this, [this, desc, step]() {
                m_statusLabel->setText(i18n("Running (%1/%2): %3", step + 1, m_queue.count(), desc));
                m_logView->append(QStringLiteral("<b>=== %1 ===</b>").arg(desc));
            }, Qt::QueuedConnection);

            bool ok = m_core.apply_operation_to_disk(op.get());
            QString detailsText;
            dumpDetails(op->m_operation_detail, detailsText);

            ++step;
            QMetaObject::invokeMethod(this, [this, detailsText, ok, step]() {
                if (!detailsText.isEmpty())
                    m_logView->append(detailsText.trimmed());
                m_progressBar->setValue(step);
                if (!ok)
                    m_logView->append(QStringLiteral("<font color='red'><b>Operation failed!</b></font>"));
            }, Qt::QueuedConnection);

            if (!ok) {
                allOk = false;
                break;
            }
        }

        QMetaObject::invokeMethod(this, [this, allOk]() {
            m_statusLabel->setText(allOk
                ? i18n("All operations completed successfully.")
                : i18n("Operations stopped due to an error."));
            m_closeBtn->setEnabled(true);
        }, Qt::QueuedConnection);
    }).detach();
}
