#pragma once

#include <QComboBox>
#include <QDialog>
#include <QLineEdit>
#include <QSpinBox>
#include "Device.h"
#include "Partition.h"

class NewPartitionDialog : public QDialog {
    Q_OBJECT
public:
    NewPartitionDialog(const GParted::Device& dev, const GParted::Partition& unallocated, QWidget* parent = nullptr);

    GParted::Partition buildPartition() const;

private:
    const GParted::Device& m_dev;
    GParted::Partition m_unalloc;
    QSpinBox* m_sizeSpin = nullptr;
    QComboBox* m_typeCombo = nullptr;
    QComboBox* m_fsCombo = nullptr;
    QLineEdit* m_labelEdit = nullptr;
};
