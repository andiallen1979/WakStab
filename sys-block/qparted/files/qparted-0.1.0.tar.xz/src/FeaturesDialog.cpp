#include "FeaturesDialog.h"
#include "Utils.h"
#include <KLocalizedString>
#include <QDialogButtonBox>
#include <QHeaderView>
#include <QIcon>
#include <QTreeWidget>
#include <QVBoxLayout>

FeaturesDialog::FeaturesDialog(GParted::GParted_Core& core, QWidget* parent)
    : QDialog(parent) {
    setWindowTitle(i18n("File System Support"));
    resize(820, 480);

    auto* layout = new QVBoxLayout(this);
    auto* tree = new QTreeWidget(this);
    tree->setRootIsDecorated(false);
    tree->setAlternatingRowColors(true);
    tree->setHeaderLabels({
        i18n("File System"), i18n("Create"), i18n("Grow"), i18n("Shrink"),
        i18n("Move"), i18n("Copy"), i18n("Check"), i18n("Label"), i18n("Required Software")
    });

    const QIcon yesIcon = QIcon::fromTheme(QStringLiteral("dialog-ok-apply"));
    const QIcon noIcon = QIcon::fromTheme(QStringLiteral("dialog-cancel"));

    for (const auto& fs : core.get_all_filesystems()) {
        if (fs.fstype == GParted::FS_UNKNOWN || fs.fstype == GParted::FS_UNALLOCATED) continue;
        auto* item = new QTreeWidgetItem(tree);
        item->setText(0, QString::fromStdString(GParted::Utils::get_filesystem_string(fs.fstype).raw()));
        item->setIcon(1, fs.create ? yesIcon : noIcon);
        item->setIcon(2, fs.grow ? yesIcon : noIcon);
        item->setIcon(3, fs.shrink ? yesIcon : noIcon);
        item->setIcon(4, fs.move ? yesIcon : noIcon);
        item->setIcon(5, fs.copy ? yesIcon : noIcon);
        item->setIcon(6, fs.check ? yesIcon : noIcon);
        item->setIcon(7, fs.write_label ? yesIcon : noIcon);
        item->setText(8, QString::fromStdString(GParted::Utils::get_filesystem_software(fs.fstype).raw()));
    }
    tree->header()->setSectionResizeMode(QHeaderView::ResizeToContents);
    layout->addWidget(tree, 1);

    auto* btns = new QDialogButtonBox(QDialogButtonBox::Close, this);
    connect(btns, &QDialogButtonBox::rejected, this, &QDialog::reject);
    layout->addWidget(btns);
}
