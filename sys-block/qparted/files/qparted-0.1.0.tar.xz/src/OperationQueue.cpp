#include "OperationResizeMove.h"
#include "OperationChangeUUID.h"
#include "OperationCheck.h"
#include "OperationNamePartition.h"
#include "OperationCreate.h"
#include "OperationQueue.h"
#include "OperationDelete.h"
#include "OperationFormat.h"
#include "OperationLabelFileSystem.h"

void OperationQueue::addFormat(const GParted::Device& dev, const GParted::Partition& orig, GParted::FSType newFs) {
    GParted::Partition next = orig;
    next.fstype = newFs;
    next.sectors_used = -1;
    next.sectors_unused = -1;
    next.sectors_unallocated = 0;
    m_ops.push_back(std::make_unique<GParted::OperationFormat>(dev, orig, next));
}

void OperationQueue::addDelete(const GParted::Device& dev, const GParted::Partition& orig) {
    m_ops.push_back(std::make_unique<GParted::OperationDelete>(dev, orig));
}

void OperationQueue::addLabel(const GParted::Device& dev, const GParted::Partition& orig, const QString& newLabel) {
    GParted::Partition next = orig;
    next.set_filesystem_label(Glib::ustring(newLabel.toUtf8().constData()));
    m_ops.push_back(std::make_unique<GParted::OperationLabelFileSystem>(dev, orig, next));
}

void OperationQueue::undoLast() {
    if (!m_ops.empty()) m_ops.pop_back();
}

void OperationQueue::clear() {
    m_ops.clear();
}

QStringList OperationQueue::descriptions() const {
    QStringList list;
    for (const auto& op : m_ops) {
        op->create_description();
        list << QString::fromStdString(op->m_description.raw());
    }
    return list;
}

void OperationQueue::applyVisualToDevice(const GParted::Device& rawDev, GParted::PartitionVector& outParts) const {
    outParts = rawDev.partitions;
    for (const auto& op : m_ops) {
        if (op->m_device && op->m_device->get_path() == rawDev.get_path()) {
            op->apply_to_visual(outParts);
        }
    }
}

void OperationQueue::addCreate(const GParted::Device& dev, const GParted::Partition& unalloc, const GParted::Partition& next) {
    m_ops.push_back(std::make_unique<GParted::OperationCreate>(dev, unalloc, next));
}

void OperationQueue::addCheck(const GParted::Device& dev, const GParted::Partition& orig) {
    m_ops.push_back(std::make_unique<GParted::OperationCheck>(dev, orig));
}

void OperationQueue::addName(const GParted::Device& dev, const GParted::Partition& orig, const QString& newName) {
    GParted::Partition next = orig;
    next.name = Glib::ustring(newName.toUtf8().constData());
    m_ops.push_back(std::make_unique<GParted::OperationNamePartition>(dev, orig, next));
}

void OperationQueue::addResizeMove(const GParted::Device& dev, const GParted::Partition& orig, const GParted::Partition& next) {
    m_ops.push_back(std::make_unique<GParted::OperationResizeMove>(dev, orig, next));
}

void OperationQueue::addNewUUID(const GParted::Device& dev, const GParted::Partition& orig) {
    GParted::Partition next = orig;
    next.uuid = GParted::UUID_RANDOM;
    m_ops.push_back(std::make_unique<GParted::OperationChangeUUID>(dev, orig, next));
}
