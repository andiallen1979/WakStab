import pathlib
import re
import sys

up = pathlib.Path(sys.argv[1]) / "src"
bld = pathlib.Path(sys.argv[2])

loop_helper = """
#include <glibmm/main.h>
#include <vector>
namespace {
std::vector<Glib::RefPtr<Glib::MainLoop>>& gparted_loop_stack() {
    static std::vector<Glib::RefPtr<Glib::MainLoop>> stack;
    return stack;
}
int& gparted_pending_quits() {
    static int q = 0;
    return q;
}
void gparted_main_run() {
    if (gparted_pending_quits() > 0) {
        --gparted_pending_quits();
        return;
    }
    auto loop = Glib::MainLoop::create();
    gparted_loop_stack().push_back(loop);
    loop->run();
    gparted_loop_stack().pop_back();
}
void gparted_main_quit() {
    if (!gparted_loop_stack().empty()) {
        gparted_loop_stack().back()->quit();
    } else {
        ++gparted_pending_quits();
    }
}
} // namespace
"""

# 1. Clean GParted_Core.cc
core_src = (up / "GParted_Core.cc").read_text()
core_src = re.sub(r"#include\s*<(?:gtkmm|gdkmm)/[^>]+>\n?", "", core_src)
core_src = core_src.replace('#include "../config.h"', '#include "config.h"\n' + loop_helper)
core_src = core_src.replace("Gtk::Main::run();", "gparted_main_run();")
core_src = core_src.replace("Gtk::Main::quit();", "gparted_main_quit();")

ped_stub = """class PedExceptionMsg
{
public:
\tPedExceptionMsg( PedException & ) {}
\tvoid show_all() {}
\tint run() { return PED_EXCEPTION_UNHANDLED; }
};"""
core_src = re.sub(
    r"class PedExceptionMsg\s*:\s*public\s*Gtk::MessageDialog\s*\{.*?\n\};",
    ped_stub,
    core_src,
    count=1,
    flags=re.DOTALL,
)
(bld / "GParted_Core_clean.cc").write_text(core_src)

# 2. Clean OperationDetail.cc
od_src = (up / "OperationDetail.cc").read_text()
od_src = re.sub(r"#include\s*<(?:gtkmm|gdkmm)/[^>]+>\n?", "", od_src)
od_src = loop_helper + "\n" + od_src
od_src = od_src.replace("Gtk::Main::run();", "gparted_main_run();")
od_src = od_src.replace("Gtk::Main::quit();", "gparted_main_quit();")
od_src = od_src.replace("status.foreground = (Glib::Thread::self() == GParted_Core::mainthread);", "status.foreground = true;")
(bld / "OperationDetail_clean.cc").write_text(od_src)

# 2b. Clean CopyBlocks.cc
cb_src = (up / "CopyBlocks.cc").read_text()
cb_src = re.sub(r"#include\s*<(?:gtkmm|gdkmm)/[^>]+>\n?", "", cb_src)
cb_src = loop_helper + "\n" + cb_src
cb_src = cb_src.replace("Gtk::Main::run();", "gparted_main_run();")
cb_src = cb_src.replace("Gtk::Main::quit();", "gparted_main_quit();")
cb_src = cb_src.replace("Gtk::Main::events_pending()", "g_main_context_pending(nullptr)")
cb_src = cb_src.replace("Gtk::Main::iteration()", "g_main_context_iteration(nullptr, false)")
(bld / "CopyBlocks_clean.cc").write_text(cb_src)

# 3. Clean Utils.cc
utils_src = (up / "Utils.cc").read_text()
utils_src = re.sub(r"#include\s*<(?:gtkmm|gdkmm)/[^>]+>\n?", "", utils_src)
utils_src = loop_helper + "\n" + utils_src
utils_src = utils_src.replace("Gtk::Main::run();", "gparted_main_run();")
utils_src = utils_src.replace("Gtk::Main::quit();", "gparted_main_quit();")
utils_src = utils_src.replace("status.foreground = (Glib::Thread::self() == GParted_Core::mainthread);", "status.foreground = true;")

replacements = [
    (r"Gtk::Label\s*\*\s*Utils::mk_label\s*\([^)]*\)\s*\{.*?\n\}",
     "Gtk::Label* Utils::mk_label(const Glib::ustring&, bool, bool, bool, Gtk::Align) { return nullptr; }"),
    (r"Gtk::Image\s*\*\s*Utils::mk_image\s*\([^)]*\)\s*\{.*?\n\}",
     "Gtk::Image* Utils::mk_image(const Gtk::StockID&, Gtk::IconSize) { return nullptr; }"),
    (r"Glib::RefPtr<Gdk::Pixbuf>\s*Utils::mk_pixbuf\s*\([^)]*\)\s*\{.*?\n\}",
     "Glib::RefPtr<Gdk::Pixbuf> Utils::mk_pixbuf(Gtk::Widget&, const Gtk::StockID&, Gtk::IconSize) { return Glib::RefPtr<Gdk::Pixbuf>(); }"),
    (r"Glib::ustring\s+Utils::get_stock_label\s*\([^)]*\)\s*\{.*?\n\}",
     "Glib::ustring Utils::get_stock_label(const Gtk::StockID& s) { return s.id; }"),
    (r"Glib::RefPtr<Gdk::Pixbuf>\s*Utils::get_color_as_pixbuf\s*\([^)]*\)\s*\{.*?\n\}",
     "Glib::RefPtr<Gdk::Pixbuf> Utils::get_color_as_pixbuf(FSType, int, int) { return Glib::RefPtr<Gdk::Pixbuf>(); }"),
]
for pat, rep in replacements:
    utils_src = re.sub(pat, rep, utils_src, count=1, flags=re.DOTALL)

(bld / "Utils_core.cc").write_text(utils_src)
