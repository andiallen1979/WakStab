#include "DiskBarWidget.h"
#include "Utils.h"
#include <QPainter>
#include <QMouseEvent>
#include <QPalette>
#include <algorithm>
DiskBarWidget::DiskBarWidget(QWidget* parent)
: QWidget(parent) {
int h = std::max(74, fontMetrics().lineSpacing() * 4 + 18);
setFixedHeight(h);
setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
}
void DiskBarWidget::setDeviceAndPartitions(const GParted::Device* device, const GParted::PartitionVector* parts) {
m_device = device;
m_parts = parts;
m_selectedIndex = -1;
update();
}
void DiskBarWidget::setSelectedIndex(int index) {
if (m_selectedIndex != index) {
m_selectedIndex = index;
update();
}
}
void DiskBarWidget::paintEvent(QPaintEvent*) {
QPainter p(this);
p.setRenderHint(QPainter::Antialiasing, true);
const QPalette pal = palette();
const QRectF outer = rect().adjusted(4, 6, -4, -6);
p.setPen(QPen(pal.color(QPalette::Mid), 1.0));
p.setBrush(pal.color(QPalette::Base));
p.drawRoundedRect(outer, 6.0, 6.0);
m_rects.clear();
if (!m_device || (*m_parts).empty() || m_device->length <= 0) {
p.setPen(pal.color(QPalette::PlaceholderText));
p.drawText(outer, Qt::AlignCenter, tr("No partition table or empty device"));
return;
}
const QRectF inner = outer.adjusted(6, 6, -6, -6);
const size_t count = (*m_parts).size();
m_rects.resize(count);
setFixedHeight(std::max(74, fontMetrics().lineSpacing() * 4 + 18));
const double minWidth = std::max(28.0, static_cast<double>(fontMetrics().horizontalAdvance(QStringLiteral("000")) + 12));
const double gap = 3.0;
const double totalGaps = gap * (count > 1 ? static_cast<double>(count - 1) : 0.0);
const double availWidth = std::max(10.0, inner.width() - totalGaps);
std::vector<double> widths(count, minWidth);
double sumMin = minWidth * static_cast<double>(count);
if (availWidth > sumMin) {
double extra = availWidth - sumMin;
double totalSectors = static_cast<double>(m_device->length);
for (size_t i = 0; i < count; ++i) {
double frac = static_cast<double>((*m_parts)[i].get_sector_length()) / totalSectors;
widths[i] += extra * frac;
}
} else {
std::fill(widths.begin(), widths.end(), availWidth / static_cast<double>(count));
}
double x = inner.left();
for (size_t i = 0; i < count; ++i) {
const auto& part = (*m_parts)[i];
QRectF r(x, inner.top(), widths[i], inner.height());
m_rects[i] = r;
QColor fsColor(QString::fromStdString(GParted::Utils::get_color(part.fstype).raw()));
if (!fsColor.isValid())
fsColor = pal.color(QPalette::Button);
p.setPen(Qt::NoPen);
p.setBrush(fsColor.lighter(115));
p.drawRoundedRect(r, 4.0, 4.0);
QRectF card = r.adjusted(4, 4, -4, -4);
if (card.width() > 8.0) {
p.setBrush(pal.color(QPalette::Base));
p.drawRoundedRect(card, 3.0, 3.0);
if (part.sectors_used > 0 && part.get_sector_length() > 0) {
double ratio = std::clamp(
static_cast<double>(part.sectors_used) / static_cast<double>(part.get_sector_length()), 0.0, 1.0);
p.setBrush(QColor(246, 211, 45, 190));
p.drawRoundedRect(QRectF(card.left(), card.top(), card.width() * ratio, card.height()), 2.0, 2.0);
}
if (card.width() > 42.0) {
p.setPen(pal.color(QPalette::Text));
QString lbl = (part.fstype == GParted::FS_UNALLOCATED)
? tr("unallocated") : QString::fromStdString(part.get_path().raw()).section('/', -1);
QString sz = QString::fromStdString(
GParted::Utils::format_size(part.get_sector_length(), part.sector_size).raw());
p.drawText(card.adjusted(4, 2, -4, -2), Qt::AlignCenter, lbl + "\n" + sz);
}
}
if (static_cast<int>(i) == m_selectedIndex) {
QPen selPen(pal.color(QPalette::Highlight), 2.5, Qt::DashLine);
p.setPen(selPen);
p.setBrush(Qt::NoBrush);
p.drawRoundedRect(r.adjusted(1, 1, -1, -1), 4.0, 4.0);
}
x += widths[i] + gap;
}
}
void DiskBarWidget::mousePressEvent(QMouseEvent* event) {
for (size_t i = 0; i < m_rects.size(); ++i) {
if (m_rects[i].contains(event->position())) {
setSelectedIndex(static_cast<int>(i));
Q_EMIT partitionSelected(static_cast<int>(i));
return;
}
}
QWidget::mousePressEvent(event);
}
