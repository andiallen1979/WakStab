#include "DeviceInfoPane.h"
#include "Utils.h"
#include <KLocalizedString>
#include <QVBoxLayout>
DeviceInfoPane::DeviceInfoPane(QWidget* parent)
: QFrame(parent) {
setFrameShape(QFrame::StyledPanel);
int em = fontMetrics().horizontalAdvance(QLatin1Char('M'));
setMinimumWidth(std::max(240, em * 20));
setMaximumWidth(std::max(320, em * 28));
auto* vbox = new QVBoxLayout(this);
auto* title = new QLabel(QStringLiteral("<b>%1</b>").arg(i18n("Device Information")), this);
vbox->addWidget(title);
auto* form = new QFormLayout();
auto addRow = [&](const QString& lbl) {
auto* val = new QLabel(QStringLiteral("—"), this);
val->setTextInteractionFlags(Qt::TextSelectableByMouse);
form->addRow(lbl, val);
return val;
};
m_modelVal = addRow(i18n("Model:"));
m_serialVal = addRow(i18n("Serial:"));
m_sizeVal = addRow(i18n("Size:"));
m_pathVal = addRow(i18n("Path:"));
m_tableVal = addRow(i18n("Partition table:"));
m_headsVal = addRow(i18n("Heads:"));
m_sectorsTrackVal = addRow(i18n("Sectors/track:"));
m_cylindersVal = addRow(i18n("Cylinders:"));
m_totalSectorsVal = addRow(i18n("Total sectors:"));
m_sectorSizeVal = addRow(i18n("Sector size:"));
vbox->addLayout(form);
vbox->addStretch(1);
}
void DeviceInfoPane::setDevice(const GParted::Device* device) {
if (!device) {
for (auto* lbl : {m_modelVal, m_serialVal, m_sizeVal, m_pathVal, m_tableVal,
m_headsVal, m_sectorsTrackVal, m_cylindersVal, m_totalSectorsVal, m_sectorSizeVal})
lbl->setText(QStringLiteral("—"));
return;
}
m_modelVal->setText(QString::fromStdString(device->model.raw()).trimmed());
m_serialVal->setText(QString::fromStdString(device->serial_number.raw()).trimmed());
m_sizeVal->setText(QString::fromStdString(GParted::Utils::format_size(device->length, device->sector_size).raw()));
m_pathVal->setText(QString::fromStdString(device->get_path().raw()));
m_tableVal->setText(QString::fromStdString(device->disktype.raw()));
m_headsVal->setText(QString::number(device->heads));
m_sectorsTrackVal->setText(QString::number(device->sectors));
m_cylindersVal->setText(QString::number(device->cylinders));
m_totalSectorsVal->setText(QString::number(device->length));
m_sectorSizeVal->setText(QString::number(device->sector_size));
}
