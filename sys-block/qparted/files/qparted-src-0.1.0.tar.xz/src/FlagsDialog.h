#pragma once
#include <QDialog>
#include <QListWidget>
#include "GParted_Core.h"
#include "Partition.h"
class FlagsDialog : public QDialog {
Q_OBJECT
public:
FlagsDialog(GParted::GParted_Core& core, const GParted::Partition& part, QWidget* parent = nullptr);
private:
GParted::GParted_Core& m_core;
GParted::Partition m_part;
QListWidget* m_list = nullptr;
};
