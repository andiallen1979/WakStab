#pragma once
#include <QCheckBox>
#include <QComboBox>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QMap>
#include <QPlainTextEdit>
#include <QSet>
#include <QStringList>
#include <QTabWidget>
#include <QTimer>
#include <QTreeWidget>
#include <QVBoxLayout>
#include <QWidget>

struct PkgEntry {
    QString cp, cpv, cat, name;
    QMap<QString, bool> instFlags, curFlags;
    QSet<QString> curEnvs;
    QString curKw = "NONE", curKwMode = "ALL", curMask = "NONE", curUnmask = "NONE";
};

class PortageConfigWidget : public QWidget {
    Q_OBJECT
public:
    explicit PortageConfigWidget(QWidget* parent = nullptr);
public Q_SLOTS:
    void reloadAll();
private:
    void buildTree();
    void onPkgSelected();
    void rebuildUse();
    void rebuildEnv();
    void rebuildKw();
    void rebuildPatches();
    void loadSelectedPatch();
    void refreshMakeConf();
    void refreshBackups();
    void refreshMonitor();
    void refreshKernel();
    void saveScope(const QString& scope);
    void rotateBackup(const QString& srcPath, const QString& prefix);

    QMap<QString, PkgEntry> m_pkgs;
    QString m_curCp, m_rawMc, m_activeEnv, m_activeKcfg;
    bool m_unlockKeys = false;
    QLineEdit *m_pkgFilter = nullptr, *m_useFilter = nullptr, *m_envName = nullptr, *m_kName = nullptr;
    QTreeWidget* m_tree = nullptr;
    QLabel* m_hdr = nullptr;
    QTabWidget* m_tabs = nullptr;
    QWidget *m_useBox = nullptr, *m_envBox = nullptr, *m_kwBox = nullptr;
    QVBoxLayout *m_useLay = nullptr, *m_envLay = nullptr;
    QHBoxLayout* m_kwLay = nullptr;
    QPlainTextEdit *m_envEd = nullptr, *m_patEd = nullptr, *m_patDiff = nullptr, *m_mcEd = nullptr, *m_mcDiff = nullptr, *m_monEd = nullptr, *m_kEd = nullptr;
    QComboBox *m_patCb = nullptr, *m_heldCb = nullptr;
    QCheckBox *m_patCmt = nullptr, *m_mcKey = nullptr, *m_mcCmt = nullptr, *m_monAuto = nullptr;
    QListWidget *m_patBkList = nullptr, *m_mcBkList = nullptr, *m_kList = nullptr;
    QTimer* m_monTimer = nullptr;
};
