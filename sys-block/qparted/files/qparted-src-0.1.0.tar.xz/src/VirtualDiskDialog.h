#pragma once
#include <QComboBox>
#include <QDialog>
#include <QLineEdit>
#include <QListWidget>
#include <QSpinBox>
class VirtualDiskDialog : public QDialog {
Q_OBJECT
public:
explicit VirtualDiskDialog(QWidget* parent = nullptr);
bool devicesChanged() const { return m_changed; }
private:
void refreshAttached();
void createImage();
void mountImage();
void detachSelected(bool deleteFile);
bool m_changed = false;
QLineEdit* m_createPath = nullptr;
QComboBox* m_fmtCombo = nullptr;
QSpinBox* m_sizeSpin = nullptr;
QLineEdit* m_mountPath = nullptr;
QListWidget* m_attachedList = nullptr;
};
