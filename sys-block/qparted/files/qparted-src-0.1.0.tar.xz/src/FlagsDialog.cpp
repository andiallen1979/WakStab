#include "FlagsDialog.h"
#include <KLocalizedString>
#include <QDialogButtonBox>
#include <QLabel>
#include <QMetaObject>
#include <QVBoxLayout>
#include <thread>
FlagsDialog::FlagsDialog(GParted::GParted_Core& core, const GParted::Partition& part, QWidget* parent)
: QDialog(parent), m_core(core), m_part(part) {
setWindowTitle(i18n("Manage flags on %1", QString::fromStdString(part.get_path().raw())));
resize(340, 380);
auto* layout = new QVBoxLayout(this);
auto* statusLbl = new QLabel(i18n("Toggle partition flags:"), this);
layout->addWidget(statusLbl);
m_list = new QListWidget(this);
m_list->blockSignals(true);
auto flags = m_core.get_available_flags(m_part);
for (const auto& [name, state] : flags) {
auto* item = new QListWidgetItem(QString::fromStdString(name.raw()), m_list);
item->setFlags(item->flags() | Qt::ItemIsUserCheckable);
item->setCheckState(state ? Qt::Checked : Qt::Unchecked);
}
m_list->blockSignals(false);
layout->addWidget(m_list, 1);
connect(m_list, &QListWidget::itemChanged, this, [this, statusLbl](QListWidgetItem* item) {
bool checked = (item->checkState() == Qt::Checked);
Glib::ustring flagName = item->text().toUtf8().constData();
m_list->setEnabled(false);
statusLbl->setText(i18n("Applying flag '%1'...", item->text()));
std::thread([this, flagName, checked, statusLbl]() {
bool ok = m_core.toggle_flag(m_part, flagName, checked);
QMetaObject::invokeMethod(this, [this, ok, statusLbl]() {
m_list->setEnabled(true);
statusLbl->setText(ok ? i18n("Toggle partition flags:") : i18n("Warning: Flag update returned an error."));
}, Qt::QueuedConnection);
}).detach();
});
auto* btns = new QDialogButtonBox(QDialogButtonBox::Close, this);
connect(btns, &QDialogButtonBox::rejected, this, &QDialog::reject);
layout->addWidget(btns);
}
