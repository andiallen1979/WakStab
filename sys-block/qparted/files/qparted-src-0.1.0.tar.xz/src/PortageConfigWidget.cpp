#include "PortageConfigWidget.h"
#include <QApplication>
#include <QColorDialog>
#include <QDateTime>
#include <QDir>
#include <QDirIterator>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QInputDialog>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QLabel>
#include <QMessageBox>
#include <QProcess>
#include <QPushButton>
#include <QRegularExpression>
#include <QScrollArea>
#include <QSplitter>
#include <QSyntaxHighlighter>
#include <QTextCharFormat>
#include <sys/utsname.h>

namespace {
class ConfHighlighter : public QSyntaxHighlighter {
public:
    bool isDiff = false;
    ConfHighlighter(QTextDocument* doc, bool diff = false) : QSyntaxHighlighter(doc), isDiff(diff) {}
protected:
    void highlightBlock(const QString& t) override {
        auto fmt = [](const char* c, bool b = true) { QTextCharFormat f; f.setForeground(QColor(c)); if (b) f.setFontWeight(QFont::Bold); return f; };
        if (isDiff) {
            if (t.startsWith("+++") || t.startsWith("---")) setFormat(0, t.size(), fmt("#8be9fd"));
            else if (t.startsWith("@@")) setFormat(0, t.size(), fmt("#bd93f9"));
            else if (t.startsWith("+")) setFormat(0, t.size(), fmt("#50fa7b"));
            else if (t.startsWith("-")) setFormat(0, t.size(), fmt("#ff5555"));
            return;
        }
        if (t.trimmed().startsWith('#')) { setFormat(0, t.size(), fmt("#6272a4", false)); return; }
        auto m = QRegularExpression(QStringLiteral("^\\s*([A-Za-z_][A-Za-z0-9_]*)")).match(t);
        if (m.hasMatch()) setFormat(m.capturedStart(1), m.capturedLength(1), fmt("#ff5555"));
        for (int i = 0; i < t.size(); ++i) if (t[i] == '=' || t[i] == '"' || t[i] == '\'') setFormat(i, 1, fmt(t[i] == '=' ? "#f1fa8c" : "#50fa7b"));
    }
};
QPushButton* iconBtn(const QString& theme, const QString& fb, const QString& tip, QWidget* p) {
    auto* b = new QPushButton(p); b->setToolTip(tip); b->setIconSize(QSize(18, 18)); b->setFixedSize(28, 28);
    QIcon ic = QIcon::fromTheme(theme); if (!ic.isNull()) b->setIcon(ic); else b->setText(fb);
    return b;
}
} // namespace

PortageConfigWidget::PortageConfigWidget(QWidget* parent) : QWidget(parent) {
    auto* topLay = new QVBoxLayout(this); topLay->setContentsMargins(4, 4, 4, 4);
    auto* sp = new QSplitter(Qt::Horizontal, this); topLay->addWidget(sp, 1);
    auto* lw = new QWidget(sp); auto* ll = new QVBoxLayout(lw); ll->setContentsMargins(0, 0, 0, 0);
    m_pkgFilter = new QLineEdit(lw); m_pkgFilter->setPlaceholderText("Filter packages..."); ll->addWidget(m_pkgFilter);
    m_tree = new QTreeWidget(lw); m_tree->setHeaderHidden(true); ll->addWidget(m_tree, 1);
    auto* rw = new QWidget(sp); auto* rl = new QVBoxLayout(rw); rl->setContentsMargins(0, 0, 0, 0);
    sp->setSizes({340, 820});
    m_hdr = new QLabel("Select a package on the left.", rw); rl->addWidget(m_hdr);
    m_tabs = new QTabWidget(rw); m_tabs->setUsesScrollButtons(true); rl->addWidget(m_tabs, 1);

    auto* uw = new QWidget(); auto* ul = new QVBoxLayout(uw); auto* ubar = new QHBoxLayout();
    m_useFilter = new QLineEdit(uw); m_useFilter->setPlaceholderText("Filter USE...");
    auto* bRef = iconBtn("view-refresh", "↻", "Refresh", uw);
    auto* bSvU = iconBtn("document-save", "💾", "Save USE", uw);
    ubar->addWidget(m_useFilter, 1); ubar->addWidget(bRef); ubar->addWidget(bSvU); ul->addLayout(ubar);
    auto* usc = new QScrollArea(uw); usc->setWidgetResizable(true); m_useBox = new QWidget();
    m_useLay = new QVBoxLayout(m_useBox); m_useLay->setSpacing(2); usc->setWidget(m_useBox); ul->addWidget(usc, 1);
    m_tabs->addTab(uw, "USE");

    auto* ew = new QWidget(); auto* el = new QHBoxLayout(ew); auto* ell = new QVBoxLayout();
    auto* esc = new QScrollArea(ew); esc->setWidgetResizable(true); m_envBox = new QWidget();
    m_envLay = new QVBoxLayout(m_envBox); m_envLay->setSpacing(1); esc->setWidget(m_envBox); ell->addWidget(esc, 1);
    auto* elb = new QHBoxLayout(); elb->addStretch(1); auto* bSvE = iconBtn("document-save-all", "💾", "Save All Env Assignments", ew);
    elb->addWidget(bSvE); ell->addLayout(elb); el->addLayout(ell, 2);
    auto* elr = new QVBoxLayout(); auto* eb = new QHBoxLayout();
    m_envName = new QLineEdit(ew); m_envName->setPlaceholderText("profile.conf"); eb->addWidget(m_envName, 1);
    auto* bENew = iconBtn("document-new", "+", "New", ew); auto* bESav = iconBtn("document-save", "💾", "Save", ew);
    auto* bEDel = iconBtn("edit-delete", "🗑", "Delete", ew); auto* bERst = iconBtn("edit-undo", "↩", "Restore", ew);
    eb->addWidget(bENew); eb->addWidget(bESav); eb->addWidget(bEDel); eb->addWidget(bERst);
    elr->addLayout(eb); m_envEd = new QPlainTextEdit(ew); new ConfHighlighter(m_envEd->document()); elr->addWidget(m_envEd, 1);
    el->addLayout(elr, 3); m_tabs->addTab(ew, "Environment");

    auto* kw = new QWidget(); auto* kwO = new QVBoxLayout(kw); m_kwBox = new QWidget(kw);
    m_kwLay = new QHBoxLayout(m_kwBox); m_kwLay->setSpacing(6); kwO->addWidget(m_kwBox); kwO->addStretch(1);
    m_tabs->addTab(kw, "Keywords");

    auto* pw = new QWidget(); auto* pl = new QVBoxLayout(pw); auto* ptabs = new QTabWidget(pw); pl->addWidget(ptabs, 1);
    auto* pv = new QWidget(); auto* pvl = new QVBoxLayout(pv); auto* ptop = new QHBoxLayout();
    auto* gbA = new QGroupBox("Active", pv); auto* la = new QHBoxLayout(gbA);
    m_patCb = new QComboBox(gbA); m_patCb->setMaximumWidth(190);
    auto* bPNew = iconBtn("document-new", "+", "Create Patch", gbA); auto* bPRm = iconBtn("archive-insert", "⏸", "Hold Patch", gbA);
    la->addWidget(m_patCb); la->addWidget(bPNew); la->addWidget(bPRm);
    auto* gbH = new QGroupBox("Held", pv); auto* lh = new QHBoxLayout(gbH);
    m_heldCb = new QComboBox(gbH); m_heldCb->setMaximumWidth(190);
    auto* bPRst = iconBtn("edit-undo", "↩", "Restore Held Patch", gbH); auto* bPDel = iconBtn("edit-delete", "🗑", "Delete Held Patch", gbH);
    lh->addWidget(m_heldCb); lh->addWidget(bPRst); lh->addWidget(bPDel);
    m_patCmt = new QCheckBox("#", pv); ptop->addWidget(gbA); ptop->addWidget(gbH); ptop->addStretch(1); ptop->addWidget(m_patCmt);
    pvl->addLayout(ptop); m_patEd = new QPlainTextEdit(pv); m_patEd->setReadOnly(true); new ConfHighlighter(m_patEd->document(), true);
    pvl->addWidget(m_patEd, 1); ptabs->addTab(pv, "Patch Viewer");
    auto* pbw = new QWidget(); auto* psp = new QSplitter(Qt::Horizontal, pbw); (new QVBoxLayout(pbw))->addWidget(psp);
    m_patBkList = new QListWidget(psp); m_patDiff = new QPlainTextEdit(psp); m_patDiff->setReadOnly(true); new ConfHighlighter(m_patDiff->document(), true);
    psp->setSizes({240, 560}); ptabs->addTab(pbw, "Backups / Diff"); m_tabs->addTab(pw, "Patches");

    auto* mcw = new QWidget(); auto* mcl = new QVBoxLayout(mcw); auto* mctabs = new QTabWidget(mcw); mcl->addWidget(mctabs, 1);
    auto* mce = new QWidget(); auto* mcel = new QVBoxLayout(mce); m_mcEd = new QPlainTextEdit(mce); new ConfHighlighter(m_mcEd->document()); mcel->addWidget(m_mcEd, 1);
    auto* mcbar = new QHBoxLayout(); mcbar->addStretch(1); m_mcKey = new QCheckBox("Protect signing keys", mce); m_mcKey->setChecked(true);
    m_mcCmt = new QCheckBox("#", mce); auto* bSvM = iconBtn("document-save", "💾", "Save make.conf", mce);
    mcbar->addWidget(m_mcKey); mcbar->addWidget(m_mcCmt); mcbar->addWidget(bSvM); mcel->addLayout(mcbar); mctabs->addTab(mce, "Editor");
    auto* mcbw = new QWidget(); auto* mcsp = new QSplitter(Qt::Horizontal, mcbw); (new QVBoxLayout(mcbw))->addWidget(mcsp);
    m_mcBkList = new QListWidget(mcsp); m_mcDiff = new QPlainTextEdit(mcsp); m_mcDiff->setReadOnly(true); new ConfHighlighter(m_mcDiff->document(), true);
    mcsp->setSizes({240, 560}); mctabs->addTab(mcbw, "Backups / Diff"); m_tabs->addTab(mcw, "make.conf");

    auto* bw = new QWidget(); auto* bl = new QVBoxLayout(bw); auto* bh = new QHBoxLayout();
    m_monAuto = new QCheckBox("Auto-refresh (2s)", bw); m_monAuto->setChecked(true);
    auto* bMonRef = iconBtn("view-refresh", "↻", "Refresh Now", bw); bh->addWidget(m_monAuto); bh->addStretch(1); bh->addWidget(bMonRef);
    bl->addLayout(bh); m_monEd = new QPlainTextEdit(bw); m_monEd->setReadOnly(true); bl->addWidget(m_monEd, 1); m_tabs->addTab(bw, "Build Monitor");

    auto* kw2 = new QWidget(); auto* kl2 = new QVBoxLayout(kw2); struct utsname u{}; uname(&u);
    kl2->addWidget(new QLabel(QString("Running Kernel: %1   |   /usr/src/linux -> %2").arg(u.release, QFileInfo("/usr/src/linux").canonicalFilePath()), kw2));
    auto* ksp = new QSplitter(Qt::Horizontal, kw2); kl2->addWidget(ksp, 1); m_kList = new QListWidget(ksp);
    auto* krw = new QWidget(ksp); auto* krl = new QVBoxLayout(krw); auto* kb = new QHBoxLayout();
    m_kName = new QLineEdit(krw); m_kName->setPlaceholderText("snippet.config"); kb->addWidget(m_kName, 1);
    auto* bKNew = iconBtn("document-new", "+", "New", krw); auto* bKSav = iconBtn("document-save", "💾", "Save", krw); auto* bKDel = iconBtn("edit-delete", "🗑", "Delete", krw);
    kb->addWidget(bKNew); kb->addWidget(bKSav); kb->addWidget(bKDel); krl->addLayout(kb);
    m_kEd = new QPlainTextEdit(krw); new ConfHighlighter(m_kEd->document()); krl->addWidget(m_kEd, 1);
    ksp->setSizes({240, 560}); m_tabs->addTab(kw2, "Kernel Config");

    connect(m_pkgFilter, &QLineEdit::textChanged, this, &PortageConfigWidget::buildTree);
    connect(m_useFilter, &QLineEdit::textChanged, this, &PortageConfigWidget::rebuildUse);
    connect(m_tree, &QTreeWidget::itemSelectionChanged, this, &PortageConfigWidget::onPkgSelected);
    connect(bRef, &QPushButton::clicked, this, &PortageConfigWidget::reloadAll);
    connect(bSvU, &QPushButton::clicked, this, [this]() { saveScope("use"); });
    connect(bSvE, &QPushButton::clicked, this, [this]() { saveScope("env"); });
    connect(bSvM, &QPushButton::clicked, this, [this]() { saveScope("mc"); });
    connect(m_mcCmt, &QCheckBox::toggled, this, &PortageConfigWidget::refreshMakeConf);
    connect(m_mcKey, &QCheckBox::toggled, this, [this](bool c) {
        if (!c && !m_unlockKeys) {
            if (QInputDialog::getText(this, "Unlock Signing Keys", "Type capital YES to unlock:") != "YES") { m_mcKey->setChecked(true); return; }
            m_unlockKeys = true;
        }
        refreshMakeConf();
    });
    connect(m_mcEd, &QPlainTextEdit::textChanged, this, [this]() { if (m_mcCmt->isChecked()) m_rawMc = m_mcEd->toPlainText(); });
    connect(bMonRef, &QPushButton::clicked, this, &PortageConfigWidget::refreshMonitor);
    m_monTimer = new QTimer(this);
    connect(m_monTimer, &QTimer::timeout, this, [this]() { if (m_monAuto->isChecked() && m_tabs->currentIndex() == 5) refreshMonitor(); });
    m_monTimer->start(2000);
    connect(m_patCb, &QComboBox::currentIndexChanged, this, &PortageConfigWidget::loadSelectedPatch);
    connect(m_patCmt, &QCheckBox::toggled, this, &PortageConfigWidget::loadSelectedPatch);
    connect(bPNew, &QPushButton::clicked, this, [this]() {
        if (m_curCp.isEmpty()) return;
        QString o = QFileDialog::getOpenFileName(this, "Select Original File"); if (o.isEmpty()) return;
        QString m = QFileDialog::getOpenFileName(this, "Select Modified File"); if (m.isEmpty()) return;
        QProcess pr; pr.start("diff", {"-Naur", o, m}); pr.waitForFinished();
        QByteArray out = pr.readAllStandardOutput(); if (out.isEmpty()) return;
        QString dir = "/etc/portage/patches/" + m_curCp; QDir().mkpath(dir);
        QString fn = QString("custom-%1.patch").arg(QDateTime::currentSecsSinceEpoch());
        QFile f(dir + "/" + fn); if (f.open(QIODevice::WriteOnly)) { f.write(out); f.close(); }
        rotateBackup(dir + "/" + fn, "patch-" + QString(m_curCp).replace('/', '_') + "-" + fn);
        rebuildPatches();
    });
    connect(bPRm, &QPushButton::clicked, this, [this]() {
        QString p = m_patCb->currentData().toString(); if (p.isEmpty() || p == "NONE") return;
        QString tdir = "/etc/portage/.gentoolcfg-patch-trash/" + m_curCp; QDir().mkpath(tdir);
        QFile::rename(p, tdir + "/" + QFileInfo(p).fileName()); rebuildPatches();
    });
    connect(bPRst, &QPushButton::clicked, this, [this]() {
        QString p = m_heldCb->currentData().toString(); if (p.isEmpty() || p == "NONE") return;
        if (QMessageBox::question(this, "Confirm Restore", "Restore held patch " + QFileInfo(p).fileName() + "?") != QMessageBox::Yes) return;
        QString ddir = "/etc/portage/patches/" + m_curCp; QDir().mkpath(ddir);
        QFile::rename(p, ddir + "/" + QFileInfo(p).fileName()); rebuildPatches();
    });
    connect(bPDel, &QPushButton::clicked, this, [this]() {
        QString p = m_heldCb->currentData().toString(); if (p.isEmpty() || p == "NONE") return;
        if (QMessageBox::question(this, "Delete Patch", "Permanently delete " + QFileInfo(p).fileName() + "?") == QMessageBox::Yes) { QFile::remove(p); rebuildPatches(); }
    });

    connect(bENew, &QPushButton::clicked, this, [this]() {
        QString fn = "custom.conf"; int i = 2; while (QFile::exists("/etc/portage/env/" + fn)) fn = QString("custom-%1.conf").arg(i++);
        QDir().mkpath("/etc/portage/env"); QFile f("/etc/portage/env/" + fn);
        if (f.open(QIODevice::WriteOnly)) { f.write("MAKEOPTS=\"-j8 -l8\"\n"); f.close(); }
        reloadAll(); m_activeEnv = fn; m_envName->setText(fn); m_envEd->setPlainText("MAKEOPTS=\"-j8 -l8\"\n");
    });
    connect(bESav, &QPushButton::clicked, this, [this]() {
        QString fn = QFileInfo(m_envName->text().trimmed()).fileName(); if (fn.isEmpty()) return;
        if (!fn.endsWith(".conf")) fn += ".conf";
        QDir().mkpath("/etc/portage/env"); QFile f("/etc/portage/env/" + fn);
        if (f.open(QIODevice::WriteOnly)) { f.write(m_envEd->toPlainText().toUtf8()); f.close(); }
        reloadAll();
    });
    connect(bEDel, &QPushButton::clicked, this, [this]() {
        if (m_activeEnv.isEmpty()) return;
        if (QMessageBox::warning(this, "Delete Env Profile", "Delete " + m_activeEnv + " and strip from /etc/portage/package.env?", QMessageBox::Yes | QMessageBox::No) != QMessageBox::Yes) return;
        QDirIterator it("/etc/portage/package.env", QDir::Files, QDirIterator::Subdirectories);
        while (it.hasNext()) {
            QString fp = it.next(); QFile f(fp); if (!f.open(QIODevice::ReadOnly)) continue;
            QStringList out; bool chg = false;
            for (const QString& ln : QString::fromUtf8(f.readAll()).split('\n')) {
                QStringList tk = ln.simplified().split(' ', Qt::SkipEmptyParts);
                if (tk.size() >= 2 && tk.removeAll(m_activeEnv) > 0) { chg = true; if (tk.size() >= 2) out << tk.join(' '); }
                else if (!ln.isEmpty()) out << ln;
            }
            f.close();
            if (chg) { if (out.isEmpty()) QFile::remove(fp); else if (f.open(QIODevice::WriteOnly | QIODevice::Truncate)) { f.write((out.join('\n') + "\n").toUtf8()); f.close(); } }
        }
        QFile::remove("/etc/portage/env/" + m_activeEnv); m_activeEnv.clear(); m_envName->clear(); m_envEd->clear(); reloadAll();
    });
    connect(m_kList, &QListWidget::currentTextChanged, this, [this](const QString& nm) {
        if (nm.isEmpty()) return; m_activeKcfg = nm; m_kName->setText(nm);
        QFile f("/etc/kernel/config.d/" + nm); if (f.open(QIODevice::ReadOnly)) m_kEd->setPlainText(QString::fromUtf8(f.readAll()));
    });
    connect(bKNew, &QPushButton::clicked, this, [this]() { m_activeKcfg.clear(); m_kName->setText("custom.config"); m_kEd->setPlainText("CONFIG_EXPERT=y\n"); });
    connect(bKSav, &QPushButton::clicked, this, [this]() {
        QString fn = QFileInfo(m_kName->text().trimmed()).fileName(); if (fn.isEmpty()) return;
        if (!fn.endsWith(".config")) fn += ".config";
        QDir().mkpath("/etc/kernel/config.d"); rotateBackup("/etc/kernel/config.d/" + fn, "kcfg-" + fn);
        QFile f("/etc/kernel/config.d/" + fn); if (f.open(QIODevice::WriteOnly)) { f.write(m_kEd->toPlainText().toUtf8()); f.close(); }
        refreshKernel();
    });
    connect(bKDel, &QPushButton::clicked, this, [this]() { if (!m_activeKcfg.isEmpty()) { QFile::remove("/etc/kernel/config.d/" + m_activeKcfg); refreshKernel(); } });
    connect(m_mcBkList, &QListWidget::currentTextChanged, this, [this](const QString& nm) {
        if (nm.isEmpty()) return; QProcess pr; pr.start("diff", {"-u", "/etc/portage/.gentoolcfg-backups/" + nm, "/etc/portage/make.conf"});
        pr.waitForFinished(); m_mcDiff->setPlainText(QString::fromUtf8(pr.readAllStandardOutput()));
    });
    connect(m_patBkList, &QListWidget::currentTextChanged, this, [this](const QString& nm) {
        if (nm.isEmpty() || m_patCb->currentData().toString() == "NONE") return;
        QProcess pr; pr.start("diff", {"-u", "/etc/portage/.gentoolcfg-backups/" + nm, m_patCb->currentData().toString()});
        pr.waitForFinished(); m_patDiff->setPlainText(QString::fromUtf8(pr.readAllStandardOutput()));
    });
    reloadAll();
}

void PortageConfigWidget::rotateBackup(const QString& src, const QString& pref) {
    if (!QFile::exists(src)) return;
    QString bdir = "/etc/portage/.gentoolcfg-backups"; QDir().mkpath(bdir);
    QFile::copy(src, QString("%1/%2.%3.bak").arg(bdir, pref, QDateTime::currentDateTime().toString("yyyyMMdd-hhmmss-zzz")));
}
void PortageConfigWidget::reloadAll() {
    m_pkgs.clear();
    QDir vdb("/var/db/pkg");
    for (const QString& cat : vdb.entryList(QDir::Dirs | QDir::NoDotAndDotDot)) {
        for (const QString& pv : QDir("/var/db/pkg/" + cat).entryList(QDir::Dirs | QDir::NoDotAndDotDot)) {
            QString name = pv; name.remove(QRegularExpression("-[0-9].*$"));
            QString cp = cat + "/" + name; PkgEntry& pe = m_pkgs[cp]; pe.cp = cp; pe.cpv = cat + "/" + pv; pe.cat = cat; pe.name = name;
            QFile iu("/var/db/pkg/" + cat + "/" + pv + "/IUSE"), au("/var/db/pkg/" + cat + "/" + pv + "/USE");
            QSet<QString> act; if (au.open(QIODevice::ReadOnly)) for (const auto& t : QString::fromUtf8(au.readAll()).split(' ', Qt::SkipEmptyParts)) act.insert(t);
            if (iu.open(QIODevice::ReadOnly)) for (QString t : QString::fromUtf8(iu.readAll()).split(' ', Qt::SkipEmptyParts)) {
                t.remove(QRegularExpression("^[+-]+")); if (!t.contains('_')) { pe.instFlags[t] = act.contains(t); pe.curFlags[t] = act.contains(t); }
            }
        }
    }
    auto scanCfg = [](const QString& path, auto fn) {
        if (QFileInfo(path).isFile()) { QFile f(path); if (f.open(QIODevice::ReadOnly)) for (const auto& l : QString::fromUtf8(f.readAll()).split('\n')) fn(l); return; }
        QDirIterator it(path, QDir::Files, QDirIterator::Subdirectories);
        while (it.hasNext()) { QFile f(it.next()); if (f.open(QIODevice::ReadOnly)) for (const auto& l : QString::fromUtf8(f.readAll()).split('\n')) fn(l); }
    };
    scanCfg("/etc/portage/package.use", [&](const QString& raw) {
        QStringList tk = raw.simplified().split(' ', Qt::SkipEmptyParts); if (tk.size() < 2 || tk[0].startsWith('#')) return;
        QString cp = tk[0]; cp.remove(QRegularExpression("^[<>~=]+")); cp = cp.section(':', 0, 0);
        if (m_pkgs.contains(cp)) for (int i = 1; i < tk.size(); ++i) m_pkgs[cp].curFlags[QString(tk[i]).remove('-')] = !tk[i].startsWith('-');
    });
    scanCfg("/etc/portage/package.env", [&](const QString& raw) {
        QStringList tk = raw.simplified().split(' ', Qt::SkipEmptyParts); if (tk.size() < 2 || tk[0].startsWith('#')) return;
        if (m_pkgs.contains(tk[0])) for (int i = 1; i < tk.size(); ++i) m_pkgs[tk[0]].curEnvs.insert(tk[i]);
    });
    QFile mc("/etc/portage/make.conf"); if (mc.open(QIODevice::ReadOnly)) m_rawMc = QString::fromUtf8(mc.readAll());
    refreshMakeConf(); refreshBackups(); refreshMonitor(); refreshKernel(); buildTree();
}
void PortageConfigWidget::buildTree() {
    m_tree->clear(); QString q = m_pkgFilter->text().trimmed().toLower(); QMap<QString, QList<PkgEntry>> byC;
    for (const auto& p : m_pkgs) if (q.isEmpty() || p.cp.toLower().contains(q)) byC[p.cat].append(p);
    for (auto it = byC.begin(); it != byC.end(); ++it) {
        auto* top = new QTreeWidgetItem(m_tree, {QString("%1 (%2)").arg(it.key()).arg(it.value().size())});
        top->setExpanded(!q.isEmpty());
        for (const auto& p : it.value()) { auto* ch = new QTreeWidgetItem(top, {p.name}); ch->setData(0, Qt::UserRole, p.cp); }
    }
}

void PortageConfigWidget::onPkgSelected() {
    auto its = m_tree->selectedItems(); if (its.isEmpty()) return;
    QString cp = its.first()->data(0, Qt::UserRole).toString(); if (cp.isEmpty() || !m_pkgs.contains(cp)) return;
    m_curCp = cp; m_hdr->setText(m_pkgs[cp].cpv);
    rebuildUse(); rebuildEnv(); rebuildKw(); rebuildPatches();
}
void PortageConfigWidget::rebuildUse() {
    while (auto* it = m_useLay->takeAt(0)) { delete it->widget(); delete it; }
    if (!m_pkgs.contains(m_curCp)) return;
    QString q = m_useFilter->text().trimmed().toLower(); PkgEntry& p = m_pkgs[m_curCp];
    for (auto it = p.curFlags.begin(); it != p.curFlags.end(); ++it) {
        if (!q.isEmpty() && !it.key().toLower().contains(q)) continue;
        auto* cb = new QCheckBox(it.key(), m_useBox); cb->setChecked(it.value());
        connect(cb, &QCheckBox::toggled, this, [this, k = it.key()](bool v) { m_pkgs[m_curCp].curFlags[k] = v; });
        m_useLay->addWidget(cb);
    }
    m_useLay->addStretch(1);
}
void PortageConfigWidget::rebuildEnv() {
    while (auto* it = m_envLay->takeAt(0)) { delete it->widget(); delete it; }
    if (!m_pkgs.contains(m_curCp)) return;
    for (const QString& fn : QDir("/etc/portage/env").entryList(QDir::Files, QDir::Name)) {
        auto* w = new QWidget(m_envBox); auto* hl = new QHBoxLayout(w); hl->setContentsMargins(2, 0, 2, 0);
        auto* cb = new QCheckBox(w); cb->setChecked(m_pkgs[m_curCp].curEnvs.contains(fn));
        connect(cb, &QCheckBox::toggled, this, [this, fn](bool v) { if (v) m_pkgs[m_curCp].curEnvs.insert(fn); else m_pkgs[m_curCp].curEnvs.remove(fn); });
        auto* b = new QPushButton(fn, w); b->setFlat(true); b->setStyleSheet("text-align: left; padding: 2px;");
        connect(b, &QPushButton::clicked, this, [this, fn]() {
            m_activeEnv = fn; m_envName->setText(fn); QFile f("/etc/portage/env/" + fn);
            if (f.open(QIODevice::ReadOnly)) m_envEd->setPlainText(QString::fromUtf8(f.readAll()));
        });
        hl->addWidget(cb); hl->addWidget(b, 1); m_envLay->addWidget(w);
    }
    m_envLay->addStretch(1);
}
void PortageConfigWidget::rebuildKw() {
    while (auto* it = m_kwLay->takeAt(0)) { delete it->widget(); delete it; }
    if (!m_pkgs.contains(m_curCp)) return;
    PkgEntry& p = m_pkgs[m_curCp];
    auto* cbK = new QComboBox(m_kwBox); cbK->setMaximumWidth(115); cbK->addItems({"(none)", "amd64", "~amd64", "**"}); cbK->setCurrentText(p.curKw == "NONE" ? "(none)" : p.curKw);
    connect(cbK, &QComboBox::currentTextChanged, this, [this](const QString& t) { m_pkgs[m_curCp].curKw = (t == "(none)" ? "NONE" : t); });
    auto* cbS = new QComboBox(m_kwBox); cbS->setMaximumWidth(135); cbS->addItems({"ALL", "EQ", "FWD"}); cbS->setCurrentText(p.curKwMode);
    connect(cbS, &QComboBox::currentTextChanged, this, [this](const QString& t) { m_pkgs[m_curCp].curKwMode = t; });
    auto* cbSt = new QComboBox(m_kwBox); cbSt->setMaximumWidth(135); cbSt->addItems({"Normal", "Mask All", "Mask (=)", "Mask (>=)", "Unmask All", "Unmask (=)", "Unmask (>=)"});
    auto* bClr = iconBtn("edit-clear", "✕", "Clear Mask/Unmask", m_kwBox); connect(bClr, &QPushButton::clicked, this, [cbSt]() { cbSt->setCurrentIndex(0); });
    auto* bSv = iconBtn("document-save", "💾", "Save Keywords", m_kwBox); connect(bSv, &QPushButton::clicked, this, [this, cbSt]() {
        QString st = cbSt->currentText(); m_pkgs[m_curCp].curMask = st.startsWith("Mask") ? st : "NONE"; m_pkgs[m_curCp].curUnmask = st.startsWith("Unmask") ? st : "NONE"; saveScope("kw");
    });
    m_kwLay->addWidget(new QLabel("Keyword:")); m_kwLay->addWidget(cbK); m_kwLay->addWidget(new QLabel("Scope:")); m_kwLay->addWidget(cbS);
    m_kwLay->addWidget(new QLabel("State:")); m_kwLay->addWidget(cbSt); m_kwLay->addWidget(bClr); m_kwLay->addWidget(bSv); m_kwLay->addStretch(1);
}

void PortageConfigWidget::rebuildPatches() {
    m_patCb->clear(); m_heldCb->clear(); if (m_curCp.isEmpty()) return;
    for (const QFileInfo& fi : QDir("/etc/portage/patches/" + m_curCp).entryInfoList(QDir::Files)) m_patCb->addItem(fi.fileName(), fi.absoluteFilePath());
    if (m_patCb->count() == 0) m_patCb->addItem("No patches", "NONE");
    for (const QFileInfo& fi : QDir("/etc/portage/.gentoolcfg-patch-trash/" + m_curCp).entryInfoList(QDir::Files)) m_heldCb->addItem(fi.fileName(), fi.absoluteFilePath());
    if (m_heldCb->count() == 0) m_heldCb->addItem("No held", "NONE");
    loadSelectedPatch(); refreshBackups();
}
void PortageConfigWidget::loadSelectedPatch() {
    QString p = m_patCb->currentData().toString(); m_patEd->clear(); if (p.isEmpty() || p == "NONE") return;
    QFile f(p); if (!f.open(QIODevice::ReadOnly)) return;
    QStringList out; bool cmt = m_patCmt->isChecked();
    for (const QString& ln : QString::fromUtf8(f.readAll()).split('\n')) if (cmt || !ln.trimmed().startsWith('#')) out << ln;
    m_patEd->setPlainText(out.join('\n'));
}
void PortageConfigWidget::refreshMakeConf() {
    m_mcEd->blockSignals(true); QStringList out; bool cmt = m_mcCmt->isChecked(), prot = m_mcKey->isChecked();
    for (const QString& ln : m_rawMc.split('\n')) {
        QString s = ln.trimmed(); if (!cmt && (s.isEmpty() || s.startsWith('#'))) continue;
        if (prot && (s.startsWith("BINPKG_GPG_") || s.startsWith("SECUREBOOT_SIGN_") || s.startsWith("MODULES_SIGN_"))) continue;
        out << ln;
    }
    m_mcEd->setPlainText(out.join('\n')); m_mcEd->blockSignals(false);
}
void PortageConfigWidget::refreshBackups() {
    m_mcBkList->clear(); m_patBkList->clear();
    for (const QString& fn : QDir("/etc/portage/.gentoolcfg-backups").entryList({"make.conf.*.bak"}, QDir::Files, QDir::Name | QDir::Reversed).mid(0, 10)) m_mcBkList->addItem(fn);
    if (!m_curCp.isEmpty()) for (const QString& fn : QDir("/etc/portage/.gentoolcfg-backups").entryList({"patch-" + QString(m_curCp).replace('/', '_') + "*"}, QDir::Files, QDir::Name | QDir::Reversed).mid(0, 10)) m_patBkList->addItem(fn);
}
void PortageConfigWidget::refreshMonitor() {
    QStringList out; QProcess ps; ps.start("pgrep", {"-af", "emerge|ninja|cargo|make"}); ps.waitForFinished();
    out << "=== ACTIVE BUILD PROCESSES ===" << QString::fromUtf8(ps.readAllStandardOutput()).trimmed();
    QFile el("/var/log/emerge.log"); if (el.open(QIODevice::ReadOnly)) out << "\n=== RECENT EMERGE LOG ===" << QString::fromUtf8(el.readAll()).split('\n').mid(std::max(0, (int)QString::fromUtf8(el.readAll()).split('\n').size() - 15)).join('\n');
    m_monEd->setPlainText(out.join('\n'));
}
void PortageConfigWidget::refreshKernel() {
    m_kList->clear(); QDir().mkpath("/etc/kernel/config.d");
    for (const QString& fn : QDir("/etc/kernel/config.d").entryList({"*.config"}, QDir::Files, QDir::Name)) m_kList->addItem(fn);
}
void PortageConfigWidget::saveScope(const QString& sc) {
    if (sc == "mc") { rotateBackup("/etc/portage/make.conf", "make.conf"); QFile f("/etc/portage/make.conf"); if (f.open(QIODevice::WriteOnly | QIODevice::Truncate)) { f.write((m_rawMc + "\n").toUtf8()); f.close(); } refreshBackups(); }
    else if (m_pkgs.contains(m_curCp)) {
        PkgEntry& p = m_pkgs[m_curCp]; QString slug = QString(m_curCp).replace('/', '_');
        if (sc == "use") {
            QStringList tk; for (auto it = p.curFlags.begin(); it != p.curFlags.end(); ++it) if (it.value() != p.instFlags.value(it.key())) tk << (it.value() ? it.key() : ("-" + it.key()));
            QDir().mkpath("/etc/portage/package.use"); QString fp = "/etc/portage/package.use/" + slug;
            if (tk.isEmpty()) QFile::remove(fp); else { QFile f(fp); if (f.open(QIODevice::WriteOnly)) { f.write((m_curCp + " " + tk.join(' ') + "\n").toUtf8()); f.close(); } }
        } else if (sc == "env") {
            QDir().mkpath("/etc/portage/package.env"); QString fp = "/etc/portage/package.env/" + slug;
            if (p.curEnvs.isEmpty()) QFile::remove(fp); else { QFile f(fp); if (f.open(QIODevice::WriteOnly)) { f.write((m_curCp + " " + QStringList(p.curEnvs.begin(), p.curEnvs.end()).join(' ') + "\n").toUtf8()); f.close(); } }
        } else if (sc == "kw") {
            QDir().mkpath("/etc/portage/package.accept_keywords"); QString fp = "/etc/portage/package.accept_keywords/" + slug;
            QString atom = (p.curKwMode == "EQ") ? ("=" + p.cpv) : (p.curKwMode == "FWD" ? (">=" + p.cpv) : m_curCp);
            if (p.curKw == "NONE") QFile::remove(fp); else { QFile f(fp); if (f.open(QIODevice::WriteOnly)) { f.write((atom + " " + p.curKw + "\n").toUtf8()); f.close(); } }
            QDir().mkpath("/etc/portage/package.mask"); QString mfp = "/etc/portage/package.mask/" + slug;
            if (p.curMask == "NONE") QFile::remove(mfp); else { QFile f(mfp); if (f.open(QIODevice::WriteOnly)) { f.write(((p.curMask.contains("=") ? "=" + p.cpv : (p.curMask.contains(">=") ? ">=" + p.cpv : m_curCp)) + "\n").toUtf8()); f.close(); } }
            QDir().mkpath("/etc/portage/package.unmask"); QString ufp = "/etc/portage/package.unmask/" + slug;
            if (p.curUnmask == "NONE") QFile::remove(ufp); else { QFile f(ufp); if (f.open(QIODevice::WriteOnly)) { f.write(((p.curUnmask.contains("=") ? "=" + p.cpv : (p.curUnmask.contains(">=") ? ">=" + p.cpv : m_curCp)) + "\n").toUtf8()); f.close(); } }
        }
    }
    QMessageBox::information(this, "Saved", "Saved " + sc + " configuration.");
}
