#pragma once
#include <glibmm/ustring.h>
#include <gtkmm/label.h>
namespace Gtk {
struct StockID {
Glib::ustring id;
StockID() = default;
explicit StockID(const Glib::ustring& s) : id(s) {}
};
class IconSize {
public:
int size = 0;
IconSize() = default;
IconSize(int s) : size(s) {}
static bool lookup(IconSize, int& w, int& h) { w = 16; h = 16; return true; }
};
class Image : public Widget {
public:
Image() = default;
Image(const StockID&, IconSize) {}
};
} // namespace Gtk
