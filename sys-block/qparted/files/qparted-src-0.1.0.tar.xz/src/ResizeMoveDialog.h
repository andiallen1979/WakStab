#pragma once
#include <QDialog>
#include <QSpinBox>
#include <QWidget>
#include "Device.h"
#include "Partition.h"
class ResizeBarWidget;
class ResizeMoveDialog : public QDialog {
Q_OBJECT
public:
ResizeMoveDialog(const GParted::Device& dev, const GParted::Partition& part,
GParted::Sector minStart, GParted::Sector maxEnd, QWidget* parent = nullptr);
GParted::Partition buildPartition() const;
private:
void syncFromSpins();
const GParted::Device& m_dev;
GParted::Partition m_orig;
GParted::Sector m_minStart = 0;
GParted::Sector m_maxEnd = 0;
int m_totalMib = 0;
int m_minUsedMib = 1;
ResizeBarWidget* m_bar = nullptr;
QSpinBox* m_beforeSpin = nullptr;
QSpinBox* m_sizeSpin = nullptr;
QSpinBox* m_afterSpin = nullptr;
};
