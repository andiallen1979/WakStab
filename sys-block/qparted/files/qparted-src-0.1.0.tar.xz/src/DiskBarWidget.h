#pragma once
#include <QWidget>
#include <QRectF>
#include <vector>
#include "Device.h"
#include "PartitionVector.h"
class DiskBarWidget : public QWidget {
Q_OBJECT
public:
explicit DiskBarWidget(QWidget* parent = nullptr);
void setDeviceAndPartitions(const GParted::Device* device, const GParted::PartitionVector* parts);
void setSelectedIndex(int index);
Q_SIGNALS:
void partitionSelected(int index);
protected:
void paintEvent(QPaintEvent* event) override;
void mousePressEvent(QMouseEvent* event) override;
private:
const GParted::Device* m_device = nullptr;
const GParted::PartitionVector* m_parts = nullptr;
int m_selectedIndex = -1;
std::vector<QRectF> m_rects;
};
