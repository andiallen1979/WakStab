#pragma once
#include <QFormLayout>
#include <QFrame>
#include <QLabel>
#include "Device.h"
class DeviceInfoPane : public QFrame {
Q_OBJECT
public:
explicit DeviceInfoPane(QWidget* parent = nullptr);
void setDevice(const GParted::Device* device);
private:
QLabel* m_modelVal = nullptr;
QLabel* m_serialVal = nullptr;
QLabel* m_sizeVal = nullptr;
QLabel* m_pathVal = nullptr;
QLabel* m_tableVal = nullptr;
QLabel* m_headsVal = nullptr;
QLabel* m_sectorsTrackVal = nullptr;
QLabel* m_cylindersVal = nullptr;
QLabel* m_totalSectorsVal = nullptr;
QLabel* m_sectorSizeVal = nullptr;
};
