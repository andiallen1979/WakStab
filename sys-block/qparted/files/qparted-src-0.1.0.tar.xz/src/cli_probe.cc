#include <clocale>
#include <glibmm/init.h>
#include <glibmm/thread.h>
#include <iostream>
#include <memory>
#include <vector>
#include "GParted_Core.h"
#include "Device.h"
#include "Partition.h"

int main() {
    std::setlocale(LC_ALL, "");
    Glib::init();
    if (!Glib::thread_supported())
        Glib::thread_init();

    GParted::GParted_Core core;
    core.find_supported_filesystems();

    std::vector<std::unique_ptr<GParted::Device>> devices;
    std::cout << "Probing block devices via libgparted-core..." << std::endl;

    core.set_user_devices({});
    core.set_devices(devices);

    std::cout << "Found " << devices.size() << " device(s)." << std::endl;
    for (const auto& dev : devices) {
        std::cout << "\nDrive: " << dev->get_path()
                  << " (" << dev->model << ", "
                  << (dev->length * dev->sector_size) / (1024LL * 1024 * 1024) << " GiB)\n";

        for (size_t i = 0; i < dev->partitions.size(); ++i) {
            const auto& part = dev->partitions[i];
            std::cout << "  - " << part.get_path()
                      << " | FS: " << part.get_filesystem_string()
                      << " | Sectors: " << part.sector_start << ".." << part.sector_end
                      << " | Label: " << part.get_filesystem_label() << "\n";
        }
    }
    return 0;
}
