#include "RestoreDialog.h"
#include <KLocalizedString>
#include <KMessageBox>
#include <QFileDialog>
#include <QFileInfo>
#include <QHBoxLayout>
#include <QMetaObject>
#include <QProcess>
#include <QStandardPaths>
#include <QVBoxLayout>
#include <cstdio>
#include <fcntl.h>
#include <thread>
#include <unistd.h>
#include <vector>
RestoreDialog::RestoreDialog(const QString& targetPath, GParted::Byte_Value targetBytes, bool isoOnly, QWidget* parent)
: QDialog(parent), m_targetPath(targetPath), m_targetBytes(targetBytes), m_isoOnly(isoOnly) {
setWindowTitle(m_isoOnly ? i18n("Write ISO to %1", m_targetPath) : i18n("Restore Image to %1", m_targetPath));
resize(560, 215);
auto* layout = new QVBoxLayout(this);
layout->addWidget(new QLabel(i18n("Target device: <b>%1</b>", m_targetPath), this));
auto* row = new QHBoxLayout();
m_inEdit = new QLineEdit(this);
auto* browseBtn = new QPushButton(i18n("Browse..."), this);
row->addWidget(m_inEdit, 1); row->addWidget(browseBtn); layout->addLayout(row);
m_progress = new QProgressBar(this); m_progress->setRange(0, 1000); layout->addWidget(m_progress);
m_statusLabel = new QLabel(i18n("Ready."), this); layout->addWidget(m_statusLabel);
auto* btns = new QHBoxLayout(); btns->addStretch(1);
m_startBtn = new QPushButton(QIcon::fromTheme(QStringLiteral("dialog-ok-apply")), i18n("Start"), this);
m_closeBtn = new QPushButton(i18n("Close"), this);
btns->addWidget(m_startBtn); btns->addWidget(m_closeBtn); layout->addLayout(btns);
connect(browseBtn, &QPushButton::clicked, this, &RestoreDialog::browseInput);
connect(m_startBtn, &QPushButton::clicked, this, &RestoreDialog::startRestore);
connect(m_closeBtn, &QPushButton::clicked, this, [this]() { if (m_running) m_cancel = true; else reject(); });
}
RestoreDialog::~RestoreDialog() { m_cancel = true; }
void RestoreDialog::browseInput() {
QString flt = m_isoOnly ? i18n("ISO Images (*.iso);;All Files (*)") : i18n("Disk Images (*.iso *.img *.raw *.zst *.gz *.xz *.qcow2 *.vdi *.vhdx *.vhd *.vmdk);;All Files (*)");
QString f = QFileDialog::getOpenFileName(this, i18n("Select Image"), QStringLiteral("/usr/share/qparted/images"), flt);
if (!f.isEmpty()) m_inEdit->setText(f);
}
void RestoreDialog::startRestore() {
QString inPath = m_inEdit->text().trimmed();
QFileInfo fi(inPath);
if (inPath.isEmpty() || !fi.exists() || m_running) return;
if (KMessageBox::warningContinueCancel(this, i18n("Overwrite ALL data on %1 with %2?", m_targetPath, fi.fileName()), i18n("Confirm Restore")) != KMessageBox::Continue) return;
m_running = true; m_cancel = false; m_startBtn->setEnabled(false); m_closeBtn->setText(i18n("Cancel"));
std::thread([this, inPath, dst = m_targetPath.toUtf8()]() {
QString lo = inPath.toLower();
if (lo.endsWith(QStringLiteral(".qcow2")) || lo.endsWith(QStringLiteral(".vdi")) || lo.endsWith(QStringLiteral(".vhdx")) || lo.endsWith(QStringLiteral(".vhd")) || lo.endsWith(QStringLiteral(".vmdk"))) {
int rc = QProcess::execute(QStringLiteral("qemu-img"), {QStringLiteral("convert"), QStringLiteral("-O"), QStringLiteral("raw"), inPath, m_targetPath});
QProcess::execute(QStringLiteral("blockdev"), {QStringLiteral("--rereadpt"), m_targetPath});
QMetaObject::invokeMethod(this, [this, rc]() { m_progress->setValue(rc == 0 ? 1000 : 0); m_statusLabel->setText(rc == 0 ? i18n("Done!") : i18n("qemu-img failed.")); if (rc == 0) m_restored = true; m_startBtn->setEnabled(true); m_closeBtn->setText(i18n("Close")); m_running = false; }, Qt::QueuedConnection);
return;
}
int outFd = ::open(dst.constData(), O_WRONLY | O_CLOEXEC), inFd = -1; FILE* pipeIn = nullptr;
if (lo.endsWith(QStringLiteral(".zst"))) pipeIn = ::popen(QStringLiteral("zstd -d -c \"%1\"").arg(inPath).toUtf8().constData(), "r");
else if (lo.endsWith(QStringLiteral(".gz"))) pipeIn = ::popen(QStringLiteral("gzip -d -c \"%1\"").arg(inPath).toUtf8().constData(), "r");
else if (lo.endsWith(QStringLiteral(".xz"))) pipeIn = ::popen(QStringLiteral("xz -d -c \"%1\"").arg(inPath).toUtf8().constData(), "r");
else inFd = ::open(inPath.toUtf8().constData(), O_RDONLY | O_CLOEXEC);
std::vector<char> buf(4 * 1024 * 1024); uint64_t wr = 0;
while (outFd >= 0 && (inFd >= 0 || pipeIn) && !m_cancel) {
ssize_t n = pipeIn ? static_cast<ssize_t>(::fread(buf.data(), 1, buf.size(), pipeIn)) : ::read(inFd, buf.data(), buf.size());
if (n <= 0 || ::write(outFd, buf.data(), static_cast<size_t>(n)) <= 0) break;
wr += static_cast<uint64_t>(n);
int pm = (m_targetBytes > 0) ? std::min(1000, static_cast<int>((wr * 1000ULL) / static_cast<uint64_t>(m_targetBytes))) : 0;
QMetaObject::invokeMethod(this, [this, pm, wr]() { m_progress->setValue(pm); m_statusLabel->setText(i18n("Restored: %1 MiB", wr / 1048576)); }, Qt::QueuedConnection);
}
if (outFd >= 0) { ::fsync(outFd); ::close(outFd); }
if (inFd >= 0) ::close(inFd);
if (pipeIn) ::pclose(pipeIn);
QProcess::execute(QStringLiteral("blockdev"), {QStringLiteral("--rereadpt"), m_targetPath});
QMetaObject::invokeMethod(this, [this, wr]() { m_progress->setValue(m_cancel ? 0 : 1000); m_statusLabel->setText(m_cancel ? i18n("Cancelled.") : i18n("Done! (%1 MiB)", wr / 1048576)); if (!m_cancel) m_restored = true; m_startBtn->setEnabled(true); m_closeBtn->setText(i18n("Close")); m_running = false; }, Qt::QueuedConnection);
}).detach();
}
