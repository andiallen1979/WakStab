#include "VirtualDiskDialog.h"
#include <KLocalizedString>
#include <KMessageBox>
#include <QDir>
#include <QFile>
#include <QFileDialog>
#include <QFormLayout>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QProcess>
#include <QPushButton>
#include <QStandardPaths>
#include <QVBoxLayout>
VirtualDiskDialog::VirtualDiskDialog(QWidget* parent) : QDialog(parent) {
setWindowTitle(i18n("Virtual Disk Images (VDI / VHD / VHDX / VMDK / QCOW2 / RAW)"));
resize(640, 440);
auto* root = new QVBoxLayout(this);
auto* createBox = new QGroupBox(i18n("Create New Virtual Disk Image"), this);
auto* cForm = new QFormLayout(createBox);
auto* cRow = new QHBoxLayout();
m_createPath = new QLineEdit(QStringLiteral("/usr/share/qparted/images/disk.qcow2"), this);
auto* cBrowse = new QPushButton(i18n("Browse..."), this);
cRow->addWidget(m_createPath, 1); cRow->addWidget(cBrowse);
cForm->addRow(i18n("Image path:"), cRow);
auto* optRow = new QHBoxLayout();
m_fmtCombo = new QComboBox(this);
m_fmtCombo->addItems({QStringLiteral("qcow2"), QStringLiteral("vdi"), QStringLiteral("vhdx"), QStringLiteral("vpc"), QStringLiteral("vmdk"), QStringLiteral("raw")});
m_sizeSpin = new QSpinBox(this);
m_sizeSpin->setRange(1, 65536); m_sizeSpin->setValue(20); m_sizeSpin->setSuffix(QStringLiteral(" GiB"));
auto* createBtn = new QPushButton(QIcon::fromTheme(QStringLiteral("list-add")), i18n("Create Image"), this);
optRow->addWidget(m_fmtCombo); optRow->addWidget(m_sizeSpin); optRow->addWidget(createBtn);
cForm->addRow(i18n("Format & size:"), optRow);
root->addWidget(createBox);
auto* mountBox = new QGroupBox(i18n("Mount / Attach Virtual Disk as Block Device"), this);
auto* mRow = new QHBoxLayout(mountBox);
m_mountPath = new QLineEdit(this);
m_mountPath->setPlaceholderText(i18n("Select .vdi, .vhd, .vhdx, .vmdk, .qcow2, or .img/.raw file..."));
auto* mBrowse = new QPushButton(i18n("Browse..."), this);
auto* mountBtn = new QPushButton(QIcon::fromTheme(QStringLiteral("media-mount")), i18n("Mount"), this);
mRow->addWidget(m_mountPath, 1); mRow->addWidget(mBrowse); mRow->addWidget(mountBtn);
root->addWidget(mountBox);
auto* attBox = new QGroupBox(i18n("Attached Virtual Disk Devices (/dev/nbd* & /dev/loop*)"), this);
auto* aLay = new QVBoxLayout(attBox);
m_attachedList = new QListWidget(this);
aLay->addWidget(m_attachedList);
auto* bRow = new QHBoxLayout();
auto* unmountBtn = new QPushButton(QIcon::fromTheme(QStringLiteral("media-eject")), i18n("Unmount Selected"), this);
auto* delBtn = new QPushButton(QIcon::fromTheme(QStringLiteral("edit-delete")), i18n("Unmount && Delete File"), this);
auto* closeBtn = new QPushButton(i18n("Close"), this);
bRow->addWidget(unmountBtn); bRow->addWidget(delBtn); bRow->addStretch(1); bRow->addWidget(closeBtn);
aLay->addLayout(bRow);
root->addWidget(attBox, 1);
connect(cBrowse, &QPushButton::clicked, this, [this]() {
QString f = QFileDialog::getSaveFileName(this, i18n("Create Virtual Disk"), m_createPath->text(),
i18n("Virtual Disks (*.qcow2 *.vdi *.vhdx *.vhd *.vmdk *.img *.raw);;All Files (*)"));
if (!f.isEmpty()) m_createPath->setText(f);
});
connect(mBrowse, &QPushButton::clicked, this, [this]() {
QString f = QFileDialog::getOpenFileName(this, i18n("Select Virtual Disk Image"), QStringLiteral("/usr/share/qparted/images"),
i18n("Virtual Disks (*.qcow2 *.vdi *.vhdx *.vhd *.vmdk *.img *.raw);;All Files (*)"));
if (!f.isEmpty()) m_mountPath->setText(f);
});
connect(createBtn, &QPushButton::clicked, this, &VirtualDiskDialog::createImage);
connect(mountBtn, &QPushButton::clicked, this, &VirtualDiskDialog::mountImage);
connect(unmountBtn, &QPushButton::clicked, this, [this]() { detachSelected(false); });
connect(delBtn, &QPushButton::clicked, this, [this]() { detachSelected(true); });
connect(closeBtn, &QPushButton::clicked, this, &QDialog::accept);
refreshAttached();
}
void VirtualDiskDialog::refreshAttached() {
m_attachedList->clear();
for (int i = 0; i < 16; ++i) {
QString pidFile = QStringLiteral("/sys/block/nbd%1/pid").arg(i);
if (QFile::exists(pidFile)) {
QString dev = QStringLiteral("/dev/nbd%1").arg(i);
QString backing;
QProcess ps; ps.start(QStringLiteral("ps"), {QStringLiteral("-p"), [&]() { QFile pf(pidFile); return pf.open(QIODevice::ReadOnly) ? QString::fromUtf8(pf.readAll()).trimmed() : QString(); }(), QStringLiteral("-o"), QStringLiteral("args=")});
if (ps.waitForFinished(1000)) backing = QString::fromLocal8Bit(ps.readAllStandardOutput()).trimmed();
auto* it = new QListWidgetItem(QStringLiteral("%1  (%2)").arg(dev, backing), m_attachedList);
it->setData(Qt::UserRole, dev);
it->setData(Qt::UserRole + 1, backing.section(QLatin1Char(' '), -1));
}
}
QProcess lo; lo.start(QStringLiteral("losetup"), {QStringLiteral("-l"), QStringLiteral("-n"), QStringLiteral("-O"), QStringLiteral("NAME,BACK-FILE")});
if (lo.waitForFinished(1000)) {
for (const QString& line : QString::fromLocal8Bit(lo.readAllStandardOutput()).split(QLatin1Char('\n'), Qt::SkipEmptyParts)) {
QString dev = line.section(QLatin1Char(' '), 0, 0).trimmed();
QString file = line.section(QLatin1Char(' '), 1).trimmed();
auto* it = new QListWidgetItem(QStringLiteral("%1  (%2)").arg(dev, file), m_attachedList);
it->setData(Qt::UserRole, dev); it->setData(Qt::UserRole + 1, file);
}
}
}
void VirtualDiskDialog::createImage() {
QString qimg = QStandardPaths::findExecutable(QStringLiteral("qemu-img"));
if (qimg.isEmpty()) { KMessageBox::error(this, i18n("qemu-img not found. Emerge app-emulation/qemu to create VDI/VHDX/VMDK/QCOW2 images.")); return; }
QString path = m_createPath->text().trimmed();
if (path.isEmpty()) return;
QProcess p; p.start(qimg, {QStringLiteral("create"), QStringLiteral("-f"), m_fmtCombo->currentText(), path, QStringLiteral("%1G").arg(m_sizeSpin->value())});
p.waitForFinished(-1);
if (p.exitCode() == 0) {
m_mountPath->setText(path);
KMessageBox::information(this, i18n("Created %1 (%2 GiB).", path, m_sizeSpin->value()), i18n("Virtual Disk Created"));
} else {
KMessageBox::error(this, QString::fromLocal8Bit(p.readAllStandardError()), i18n("Failed to Create Image"));
}
}
void VirtualDiskDialog::mountImage() {
QString file = m_mountPath->text().trimmed();
if (file.isEmpty() || !QFile::exists(file)) return;
QString qnbd = QStandardPaths::findExecutable(QStringLiteral("qemu-nbd"));
if (!qnbd.isEmpty()) {
QProcess::execute(QStringLiteral("modprobe"), {QStringLiteral("nbd"), QStringLiteral("max_part=16")});
for (int i = 0; i < 16; ++i) {
if (!QFile::exists(QStringLiteral("/sys/block/nbd%1/pid").arg(i))) {
QString dev = QStringLiteral("/dev/nbd%1").arg(i);
QProcess p; p.start(qnbd, {QStringLiteral("--connect=%1").arg(dev), file});
p.waitForFinished(5000);
if (p.exitCode() == 0) { m_changed = true; refreshAttached(); return; }
}
}
}
QProcess lo; lo.start(QStringLiteral("losetup"), {QStringLiteral("--find"), QStringLiteral("--show"), QStringLiteral("--partscan"), file});
lo.waitForFinished(3000);
if (lo.exitCode() == 0) { m_changed = true; refreshAttached(); }
else KMessageBox::error(this, i18n("Failed to attach image. Ensure app-emulation/qemu (qemu-nbd) or loop devices are available."));
}
void VirtualDiskDialog::detachSelected(bool deleteFile) {
auto* it = m_attachedList->currentItem();
if (!it) return;
QString dev = it->data(Qt::UserRole).toString();
QString file = it->data(Qt::UserRole + 1).toString();
if (dev.startsWith(QStringLiteral("/dev/nbd")))
QProcess::execute(QStringLiteral("qemu-nbd"), {QStringLiteral("--disconnect"), dev});
else
QProcess::execute(QStringLiteral("losetup"), {QStringLiteral("-d"), dev});
if (deleteFile && !file.isEmpty() && QFile::exists(file)) {
if (KMessageBox::warningContinueCancel(this, i18n("Permanently delete %1?", file)) == KMessageBox::Continue)
QFile::remove(file);
}
m_changed = true;
refreshAttached();
}
