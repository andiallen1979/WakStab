#include "RescueDialog.h"
#include <KLocalizedString>
#include <QHBoxLayout>
#include <QStandardPaths>
#include <QVBoxLayout>
RescueDialog::RescueDialog(const GParted::Device& dev, QWidget* parent)
: QDialog(parent), m_devPath(QString::fromStdString(dev.get_path().raw())) {
setWindowTitle(i18n("Attempt Data Rescue on %1", m_devPath));
resize(660, 440);
auto* layout = new QVBoxLayout(this);
m_statusLabel = new QLabel(i18n("Select a recovery scanner to search %1 for lost partitions or files:", m_devPath), this);
layout->addWidget(m_statusLabel);
auto* btnRow = new QHBoxLayout();
m_gpartBtn = new QPushButton(QIcon::fromTheme(QStringLiteral("system-search")), i18n("Scan Lost Partitions (gpart)"), this);
m_testdiskBtn = new QPushButton(QIcon::fromTheme(QStringLiteral("drive-harddisk")), i18n("Deep Partition/File Scan (testdisk)"), this);
btnRow->addWidget(m_gpartBtn);
btnRow->addWidget(m_testdiskBtn);
layout->addLayout(btnRow);
m_output = new QTextEdit(this);
m_output->setReadOnly(true);
layout->addWidget(m_output, 1);
auto* closeBtn = new QPushButton(i18n("Close"), this);
connect(closeBtn, &QPushButton::clicked, this, &QDialog::reject);
layout->addWidget(closeBtn, 0, Qt::AlignRight);
connect(m_gpartBtn, &QPushButton::clicked, this, [this]() { startScan(QStringLiteral("gpart"), {m_devPath}); });
connect(m_testdiskBtn, &QPushButton::clicked, this, [this]() { startScan(QStringLiteral("testdisk"), {QStringLiteral("/log"), QStringLiteral("/list"), m_devPath}); });
}
RescueDialog::~RescueDialog() {
if (m_proc && m_proc->state() != QProcess::NotRunning) {
m_proc->kill();
m_proc->waitForFinished(1000);
}
}
void RescueDialog::startScan(const QString& tool, const QStringList& args) {
QString bin = QStandardPaths::findExecutable(tool);
if (bin.isEmpty()) {
m_output->append(i18n("<b>Tool '%1' is not installed.</b> Install <code>sys-block/gpart</code> or <code>app-admin/testdisk</code> on Gentoo to enable this scanner.", tool));
return;
}
if (m_proc) { m_proc->kill(); m_proc->deleteLater(); }
m_proc = new QProcess(this);
m_proc->setProcessChannelMode(QProcess::MergedChannels);
m_gpartBtn->setEnabled(false);
m_testdiskBtn->setEnabled(false);
m_statusLabel->setText(i18n("Scanning %1 with %2...", m_devPath, tool));
m_output->clear();
connect(m_proc, &QProcess::readyReadStandardOutput, this, [this]() {
m_output->append(QString::fromLocal8Bit(m_proc->readAllStandardOutput()).trimmed());
});
connect(m_proc, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished), this, [this](int code, QProcess::ExitStatus) {
m_statusLabel->setText(i18n("Scan finished (exit code %1).", code));
m_gpartBtn->setEnabled(true);
m_testdiskBtn->setEnabled(true);
});
m_proc->start(bin, args);
}
