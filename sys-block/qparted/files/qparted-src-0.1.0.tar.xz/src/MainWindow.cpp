#include "PortageConfigWidget.h"
#include <QTabWidget>
#include "RestoreDialog.h"
#include "VirtualDiskDialog.h"
#include <QApplication>
#include <QDialog>
#include <QDialogButtonBox>
#include <QFontComboBox>
#include <QFormLayout>
#include <QSettings>
#include <QSpinBox>
#include "ImageDialog.h"
#include "RescueDialog.h"
#include <QToolBar>
#include <QApplication>
#include "ResizeMoveDialog.h"
#include <QMenuBar>
#include "MainWindow.h"
#include "ApplyDialog.h"
#include "FeaturesDialog.h"
#include "FlagsDialog.h"
#include "NewPartitionDialog.h"
#include "Utils.h"
#include <KActionCollection>
#include <KLocalizedString>
#include <KMessageBox>
#include <KStandardAction>
#include <KToolBar>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QIcon>
#include <QInputDialog>
#include <QLabel>
#include <QPainter>
#include <QPixmap>
#include <QSplitter>
#include <QStatusBar>
#include <QVBoxLayout>
#include <QWidget>
#include <glibmm/shell.h>
namespace {
QIcon makeSwatchIcon(const QColor& color, bool locked) {
QPixmap pm(16, 16);
pm.fill(Qt::transparent);
QPainter p(&pm);
p.setRenderHint(QPainter::Antialiasing, true);
p.setPen(QPen(Qt::darkGray, 1.0));
p.setBrush(color);
p.drawRoundedRect(1, 1, 14, 14, 3.0, 3.0);
if (locked)
QIcon::fromTheme(QStringLiteral("emblem-locked")).paint(&p, 4, 4, 11, 11);
return QIcon(pm);
}
} // namespace
MainWindow::MainWindow(QWidget* parent)
: QMainWindow(parent) {
setWindowTitle(i18n("QParted"));
setWindowIcon(QIcon::fromTheme(QStringLiteral("drive-harddisk")));
resize(1160, 740);
m_core.find_supported_filesystems();
m_core.set_user_devices({});
auto* central = new QWidget(this);
auto* rootLayout = new QVBoxLayout(central);
rootLayout->setContentsMargins(6, 6, 6, 6);
rootLayout->setSpacing(6);
m_diskBar = new DiskBarWidget(this);
rootLayout->addWidget(m_diskBar);
auto* hSplit = new QSplitter(Qt::Horizontal, this);
m_deviceInfoPane = new DeviceInfoPane(hSplit);
m_deviceInfoPane->setVisible(false);
auto* vSplit = new QSplitter(Qt::Vertical, hSplit);
m_partitionTree = new QTreeWidget(vSplit);
m_partitionTree->setRootIsDecorated(false);
m_partitionTree->setAlternatingRowColors(true);
m_partitionTree->setSelectionMode(QAbstractItemView::SingleSelection);
m_partitionTree->setContextMenuPolicy(Qt::CustomContextMenu);
m_partitionTree->setHeaderLabels({
i18n("Partition"), i18n("Name"), i18n("File System"), i18n("Mount Point"),
i18n("Label"), i18n("Size"), i18n("Used"), i18n("Unused"), i18n("Flags")
});
m_partitionTree->header()->setSectionResizeMode(QHeaderView::Interactive);
m_partitionTree->header()->setSectionsMovable(true);
m_partitionTree->header()->setStretchLastSection(true);
m_partitionTree->setUniformRowHeights(false);
m_opsList = new QListWidget(vSplit);
m_opsList->setMaximumHeight(std::max(130, fontMetrics().lineSpacing() * 6 + 24));
m_opsList->setVisible(false);
vSplit->setStretchFactor(0, 4);
vSplit->setStretchFactor(1, 1);
hSplit->setStretchFactor(1, 1);
rootLayout->addWidget(hSplit, 1);
auto* suiteTabs = new QTabWidget(this);
suiteTabs->addTab(central, QIcon::fromTheme(QStringLiteral("drive-harddisk")), i18n("Partition Manager"));
auto* portageCfg = new PortageConfigWidget(this);
suiteTabs->addTab(portageCfg, QIcon::fromTheme(QStringLiteral("preferences-system")), i18n("Portage Config"));
setCentralWidget(suiteTabs);
setupActions();
auto* ac = findChild<KActionCollection*>();
statusBar();
menuBar()->clear();
QMenu* gpartedM = menuBar()->addMenu(i18n("&QParted"));
gpartedM->addAction(ac->action(QStringLiteral("refresh_devices")));
gpartedM->addMenu(m_devicesMenu)->setText(i18n("Devices"));
gpartedM->addSeparator();
auto* editSub = gpartedM->addMenu(QIcon::fromTheme(QStringLiteral("document-edit")), i18n("Edit"));
editSub->addAction(QIcon::fromTheme(QStringLiteral("preferences-desktop-font")), i18n("Font Settings..."), this, [this]() {
QDialog dlg(this);
dlg.setWindowTitle(i18n("Font Settings"));
auto* form = new QFormLayout(&dlg);
auto* familyBox = new QFontComboBox(&dlg);
auto* sizeSpin = new QSpinBox(&dlg);
sizeSpin->setRange(6, 36);
sizeSpin->setSuffix(QStringLiteral(" pt"));
QFont cur = QApplication::font();
familyBox->setCurrentFont(cur);
sizeSpin->setValue(cur.pointSize() > 0 ? cur.pointSize() : 11);
form->addRow(i18n("Font family:"), familyBox);
form->addRow(i18n("Font size:"), sizeSpin);
auto* btns = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, &dlg);
connect(btns, &QDialogButtonBox::accepted, &dlg, &QDialog::accept);
connect(btns, &QDialogButtonBox::rejected, &dlg, &QDialog::reject);
form->addRow(btns);
if (dlg.exec() != QDialog::Accepted) return;
QFont next = familyBox->currentFont();
next.setPointSize(sizeSpin->value());
QApplication::setFont(next);
setFont(next);
QSettings st(QStringLiteral("WakStab"), QStringLiteral("qparted"));
st.setValue(QStringLiteral("ui/fontFamily"), next.family());
st.setValue(QStringLiteral("ui/fontSize"), next.pointSize());
st.sync();
rebuildCurrentView();
});
editSub->addSeparator();
editSub->addAction(m_undoAct);
editSub->addAction(m_clearAct);
editSub->addAction(m_applyAct);
auto* viewSub = gpartedM->addMenu(QIcon::fromTheme(QStringLiteral("view-choose")), i18n("View"));
viewSub->addAction(m_viewInfoAct);
viewSub->addAction(m_viewOpsAct);
viewSub->addSeparator();
viewSub->addAction(ac->action(QStringLiteral("view_fs_support")));
gpartedM->addSeparator();
gpartedM->addAction(ac->action(QStringLiteral("file_quit")));
QMenu* devM = menuBar()->addMenu(i18n("&Device"));
devM->addAction(m_disklabelAct);
devM->addSeparator();
devM->addAction(QIcon::fromTheme(QStringLiteral("drive-harddisk")), i18n("Create Sparse Disk Image..."), this, [this]() {
int idx = m_deviceCombo->currentIndex();
if (idx < 0 || idx >= static_cast<int>(m_devices.size())) return;
const auto& dev = *m_devices[static_cast<size_t>(idx)];
ImageDialog(QString::fromStdString(dev.get_path().raw()), dev.length * dev.sector_size, ImageDialog::Mode::Sparse, QString(), this).exec();
});
devM->addAction(QIcon::fromTheme(QStringLiteral("drive-harddisk")), i18n("Create Full Disk Image..."), this, [this]() {
int idx = m_deviceCombo->currentIndex();
if (idx < 0 || idx >= static_cast<int>(m_devices.size())) return;
const auto& dev = *m_devices[static_cast<size_t>(idx)];
ImageDialog(QString::fromStdString(dev.get_path().raw()), dev.length * dev.sector_size, ImageDialog::Mode::FullRaw, QString(), this).exec();
});
devM->addAction(QIcon::fromTheme(QStringLiteral("archive-insert")), i18n("Create Zero-Filled Compressed Image..."), this, [this]() {
int idx = m_deviceCombo->currentIndex();
if (idx < 0 || idx >= static_cast<int>(m_devices.size())) return;
const auto& dev = *m_devices[static_cast<size_t>(idx)];
ImageDialog(QString::fromStdString(dev.get_path().raw()), dev.length * dev.sector_size, ImageDialog::Mode::ZeroFilledCompressed, QString(), this).exec();
});
devM->addAction(QIcon::fromTheme(QStringLiteral("document-revert")), i18n("Restore Image to Disk..."), this, [this]() {
int idx = m_deviceCombo->currentIndex();
if (idx < 0 || idx >= static_cast<int>(m_devices.size())) return;
const auto& dev = *m_devices[static_cast<size_t>(idx)];
RestoreDialog dlg(QString::fromStdString(dev.get_path().raw()), dev.length * dev.sector_size, false, this);
dlg.exec();
if (dlg.restored()) connect(suiteTabs, &QTabWidget::currentChanged, this, [this](int idx) {
    if (auto* tb = findChild<QToolBar*>()) tb->setVisible(idx == 0);
});
refreshDevices();
});
devM->addSeparator();
devM->addAction(QIcon::fromTheme(QStringLiteral("media-optical")), i18n("Write ISO Image to Drive / SD Card..."), this, [this]() {
int idx = m_deviceCombo->currentIndex();
if (idx < 0 || idx >= static_cast<int>(m_devices.size())) return;
const auto& dev = *m_devices[static_cast<size_t>(idx)];
RestoreDialog dlg(QString::fromStdString(dev.get_path().raw()), dev.length * dev.sector_size, true, this);
dlg.exec();
if (dlg.restored()) refreshDevices();
});
devM->addAction(QIcon::fromTheme(QStringLiteral("media-optical-recordable")), i18n("Create ISO Image from Drive / SD Card..."), this, [this]() {
int idx = m_deviceCombo->currentIndex();
if (idx < 0 || idx >= static_cast<int>(m_devices.size())) return;
const auto& dev = *m_devices[static_cast<size_t>(idx)];
ImageDialog(QString::fromStdString(dev.get_path().raw()), dev.length * dev.sector_size, ImageDialog::Mode::FullRaw, QStringLiteral(".iso"), this).exec();
});
devM->addSeparator();
devM->addAction(ac->action(QStringLiteral("attempt_rescue")));
devM->addSeparator();
devM->addAction(QIcon::fromTheme(QStringLiteral("media-optical")), i18n("Virtual Disk Images (VDI / VHD / VMDK / QCOW2 / RAW)..."), this, [this]() {
VirtualDiskDialog dlg(this);
dlg.exec();
if (dlg.devicesChanged()) {
refreshDevices();
if (!m_devices.empty()) m_deviceCombo->setCurrentIndex(static_cast<int>(m_devices.size()) - 1);
}
});
QMenu* partM = menuBar()->addMenu(i18n("&Partition"));
partM->addAction(m_newAct);
partM->addAction(m_delAct);
partM->addSeparator();
partM->addAction(m_resizeAct);
partM->addSeparator();
partM->addMenu(m_formatMenu)->setText(i18n("Format to"));
partM->addAction(m_unmountAct);
partM->addSeparator();
partM->addAction(m_flagsAct);
partM->addAction(m_checkAct);
partM->addAction(m_labelAct);
partM->addAction(m_nameAct);
partM->addAction(m_uuidAct);
partM->addSeparator();
partM->addAction(m_partImgAct);
partM->addAction(m_partRestoreAct);
partM->addAction(m_partInfoAct);
auto* helpM = menuBar()->addMenu(i18n("&Help")); helpM->addAction(i18n("About QParted"), this, [this]() { KMessageBox::information(this, i18n("QParted 0.1.0 (WakStab Overlay)\nNative Qt6 / KDE Plasma 6 Partition Editor\nPackage: sys-block/qparted (WakStab Overlay)\nRepository: https://codeberg.org/andiallen1979/WakStab\nPowered by GParted Core & KDE Frameworks 6"), i18n("About QParted")); });
menuBar()->show();
connect(m_deviceCombo, QOverload<int>::of(&QComboBox::currentIndexChanged), this, &MainWindow::onDeviceChanged);
connect(m_partitionTree, &QTreeWidget::itemSelectionChanged, this, &MainWindow::onTreeSelectionChanged);
connect(m_partitionTree, &QTreeWidget::customContextMenuRequested, this, &MainWindow::onTreeContextMenu);
connect(m_diskBar, &DiskBarWidget::partitionSelected, this, &MainWindow::onBarPartitionSelected);
refreshDevices();
}
void MainWindow::setupActions() {
auto* ac = new KActionCollection(this);
KStandardAction::quit(this, &QWidget::close, ac);
auto* refreshAct = ac->addAction(QStringLiteral("refresh_devices"), this, &MainWindow::refreshDevices);
refreshAct->setText(i18n("Refresh Devices"));
refreshAct->setIcon(QIcon::fromTheme(QStringLiteral("view-refresh")));
KActionCollection::setDefaultShortcut(refreshAct, QKeySequence::Refresh);
auto* devSubAct = ac->addAction(QStringLiteral("devices_submenu"));
devSubAct->setText(i18n("Devices"));
m_devicesMenu = new QMenu(this);
devSubAct->setMenu(m_devicesMenu);
m_undoAct = ac->addAction(QStringLiteral("undo_last"), this, &MainWindow::undoLastOperation);
m_undoAct->setText(i18n("Undo Last Operation"));
m_undoAct->setIcon(QIcon::fromTheme(QStringLiteral("edit-undo")));
KActionCollection::setDefaultShortcut(m_undoAct, QKeySequence::Undo);
m_clearAct = ac->addAction(QStringLiteral("clear_all"), this, &MainWindow::clearAllOperations);
m_clearAct->setText(i18n("Clear All Operations"));
m_clearAct->setIcon(QIcon::fromTheme(QStringLiteral("edit-clear")));
m_applyAct = ac->addAction(QStringLiteral("apply_all"), this, &MainWindow::applyAllOperations);
m_applyAct->setText(i18n("Apply All Operations"));
m_applyAct->setIcon(QIcon::fromTheme(QStringLiteral("dialog-ok-apply")));
m_viewInfoAct = ac->addAction(QStringLiteral("view_device_info"));
m_viewInfoAct->setText(i18n("Device Information"));
m_viewInfoAct->setCheckable(true);
connect(m_viewInfoAct, &QAction::toggled, m_deviceInfoPane, &QWidget::setVisible);
m_viewOpsAct = ac->addAction(QStringLiteral("view_pending_ops"));
m_viewOpsAct->setText(i18n("Pending Operations"));
m_viewOpsAct->setCheckable(true);
connect(m_viewOpsAct, &QAction::toggled, m_opsList, &QWidget::setVisible);
auto* fsSupportAct = ac->addAction(QStringLiteral("view_fs_support"));
fsSupportAct->setText(i18n("File System Support"));
connect(fsSupportAct, &QAction::triggered, this, [this]() { FeaturesDialog(m_core, this).exec(); });
m_disklabelAct = ac->addAction(QStringLiteral("create_disklabel"), this, &MainWindow::createPartitionTable);
m_disklabelAct->setText(i18n("Create Partition Table..."));
auto* rescueAct = ac->addAction(QStringLiteral("attempt_rescue"), this, &MainWindow::attemptDataRescue);
rescueAct->setText(i18n("Attempt Data Rescue..."));
rescueAct->setIcon(QIcon::fromTheme(QStringLiteral("system-search")));
m_resizeAct = ac->addAction(QStringLiteral("part_resize"));
m_resizeAct->setText(i18n("Resize/Move..."));
m_resizeAct->setIcon(QIcon::fromTheme(QStringLiteral("transform-scale")));
m_uuidAct = ac->addAction(QStringLiteral("part_uuid"));
m_uuidAct->setText(i18n("New UUID"));
m_newAct = ac->addAction(QStringLiteral("part_new"));
m_newAct->setText(i18n("New..."));
m_newAct->setIcon(QIcon::fromTheme(QStringLiteral("list-add")));
m_delAct = ac->addAction(QStringLiteral("part_delete"));
m_delAct->setText(i18n("Delete"));
m_delAct->setIcon(QIcon::fromTheme(QStringLiteral("edit-delete")));
KActionCollection::setDefaultShortcut(m_delAct, QKeySequence::Delete);
auto* fmtSubAct = ac->addAction(QStringLiteral("part_format"));
fmtSubAct->setText(i18n("Format to"));
fmtSubAct->setIcon(QIcon::fromTheme(QStringLiteral("edit-clear-all")));
m_formatMenu = new QMenu(this);
fmtSubAct->setMenu(m_formatMenu);
m_unmountAct = ac->addAction(QStringLiteral("part_unmount"));
m_unmountAct->setText(i18n("Unmount"));
m_unmountAct->setIcon(QIcon::fromTheme(QStringLiteral("media-eject")));
m_flagsAct = ac->addAction(QStringLiteral("part_flags"));
m_flagsAct->setText(i18n("Manage Flags...")); m_flagsAct->setIcon(QIcon::fromTheme(QStringLiteral("flag")));
m_checkAct = ac->addAction(QStringLiteral("part_check"));
m_checkAct->setText(i18n("Check")); m_checkAct->setIcon(QIcon::fromTheme(QStringLiteral("checkmark")));
m_labelAct = ac->addAction(QStringLiteral("part_label"));
m_labelAct->setText(i18n("Label File System...")); m_labelAct->setIcon(QIcon::fromTheme(QStringLiteral("tag")));
m_nameAct = ac->addAction(QStringLiteral("part_name"));
m_nameAct->setText(i18n("Name Partition..."));
m_partImgAct = ac->addAction(QStringLiteral("part_image"));
m_partImgAct->setText(i18n("Create Sparse Partition Image..."));
m_partImgAct->setIcon(QIcon::fromTheme(QStringLiteral("drive-harddisk")));
m_partRestoreAct = ac->addAction(QStringLiteral("part_restore"));
m_partRestoreAct->setText(i18n("Restore Image to Partition..."));
m_partRestoreAct->setIcon(QIcon::fromTheme(QStringLiteral("document-revert")));
m_partInfoAct = ac->addAction(QStringLiteral("part_info"));
m_partInfoAct->setText(i18n("Information"));
m_partInfoAct->setIcon(QIcon::fromTheme(QStringLiteral("dialog-information")));
auto* mainBar = addToolBar(i18n("Main Toolbar"));
mainBar->setWindowTitle(i18n("Main Toolbar"));
mainBar->addAction(m_newAct);
mainBar->addAction(m_delAct);
mainBar->addSeparator();
mainBar->addAction(m_resizeAct);
mainBar->addSeparator();
mainBar->addAction(m_undoAct);
mainBar->addAction(m_applyAct);
mainBar->addSeparator();
mainBar->addWidget(new QLabel(i18n(" Device: "), this));
m_deviceCombo = new QComboBox(this);
m_deviceCombo->setMinimumWidth(std::max(340, fontMetrics().horizontalAdvance(QLatin1Char('M')) * 28));
mainBar->addWidget(m_deviceCombo);
}
void MainWindow::refreshDevices() {
statusBar()->showMessage(i18n("Scanning all devices..."));
m_queue.clear();
updateQueueUI();
m_deviceCombo->blockSignals(true);
m_deviceCombo->clear();
m_devicesMenu->clear();
m_partitionTree->clear();
m_diskBar->setDeviceAndPartitions(nullptr, nullptr);
m_deviceInfoPane->setDevice(nullptr);
m_core.set_devices(m_devices);
for (size_t i = 0; i < m_devices.size(); ++i) {
const auto& dev = *m_devices[i];
QString path = QString::fromStdString(dev.get_path().raw());
QString model = QString::fromStdString(dev.model.raw()).trimmed();
QString sizeStr = QString::fromStdString(GParted::Utils::format_size(dev.length, dev.sector_size).raw());
QString label = QStringLiteral("%1 (%2) — %3").arg(path, model, sizeStr);
m_deviceCombo->addItem(QIcon::fromTheme(QStringLiteral("drive-harddisk")), label);
m_devicesMenu->addAction(QIcon::fromTheme(QStringLiteral("drive-harddisk")), label, this, [this, i]() {
m_deviceCombo->setCurrentIndex(static_cast<int>(i));
});
}
m_deviceCombo->blockSignals(false);
if (!m_devices.empty()) {
m_deviceCombo->setCurrentIndex(0);
onDeviceChanged(0);
statusBar()->showMessage(i18np("1 device detected", "%1 devices detected", static_cast<int>(m_devices.size())), 4000);
}
updateActionStates();
}
void MainWindow::onDeviceChanged(int index) {
if (index < 0 || index >= static_cast<int>(m_devices.size())) return;
m_deviceInfoPane->setDevice(m_devices[static_cast<size_t>(index)].get());
rebuildCurrentView();
}
void MainWindow::rebuildCurrentView() {
int idx = m_deviceCombo->currentIndex();
if (idx < 0 || idx >= static_cast<int>(m_devices.size())) return;
const auto& dev = *m_devices[static_cast<size_t>(idx)];
m_queue.applyVisualToDevice(dev, m_visualParts);
m_diskBar->setDeviceAndPartitions(&dev, &m_visualParts);
populatePartitionTree(m_visualParts);
updateActionStates();
}
void MainWindow::createPartitionTable() {
int idx = m_deviceCombo->currentIndex();
if (idx < 0 || idx >= static_cast<int>(m_devices.size())) return;
const auto& dev = *m_devices[static_cast<size_t>(idx)];
QStringList types;
for (const auto& t : GParted::GParted_Core::get_disklabeltypes())
types << QString::fromStdString(t.raw());
bool ok = false;
QString chosen = QInputDialog::getItem(this, i18n("Create Partition Table on %1", QString::fromStdString(dev.get_path().raw())),
i18n("WARNING: This will ERASE ALL DATA on the entire disk!\nSelect new partition table type:"), types, 0, false, &ok);
if (!ok || chosen.isEmpty()) return;
if (m_core.set_disklabel(dev, chosen.toUtf8().constData()))
refreshDevices();
else
KMessageBox::error(this, i18n("Failed to create partition table. Ensure all partitions are unmounted."), i18n("Error"));
}
void MainWindow::populatePartitionTree(const GParted::PartitionVector& parts) {
m_partitionTree->clear();
for (size_t i = 0; i < parts.size(); ++i) {
const auto& part = parts[i];
auto* item = new QTreeWidgetItem(m_partitionTree);
QString partPath = (part.fstype == GParted::FS_UNALLOCATED) ? i18n("unallocated") : QString::fromStdString(part.get_path().raw());
QColor fsColor(QString::fromStdString(GParted::Utils::get_color(part.fstype).raw()));
if (!fsColor.isValid()) fsColor = palette().color(QPalette::Button);
QStringList mounts, flags;
for (const auto& mp : part.get_mountpoints()) mounts << QString::fromStdString(mp.raw());
for (const auto& fl : part.get_flags()) flags << QString::fromStdString(fl.raw());
item->setText(0, partPath);
item->setText(1, QString::fromStdString(part.name.raw()));
item->setIcon(2, makeSwatchIcon(fsColor, part.busy));
item->setText(2, QString::fromStdString(part.get_filesystem_string().raw()));
item->setText(3, mounts.join(QStringLiteral(", ")));
item->setText(4, QString::fromStdString(part.get_filesystem_label().raw()));
item->setText(5, QString::fromStdString(GParted::Utils::format_size(part.get_sector_length(), part.sector_size).raw()));
item->setText(6, (part.sectors_used >= 0) ? QString::fromStdString(GParted::Utils::format_size(part.sectors_used, part.sector_size).raw()) : QStringLiteral("—"));
item->setText(7, (part.sectors_unused >= 0) ? QString::fromStdString(GParted::Utils::format_size(part.sectors_unused, part.sector_size).raw()) : QStringLiteral("—"));
item->setText(8, flags.join(QStringLiteral(", ")));
}
for (int c = 0; c < m_partitionTree->columnCount() - 1; ++c)
m_partitionTree->resizeColumnToContents(c);
}
void MainWindow::onTreeSelectionChanged() {
auto items = m_partitionTree->selectedItems();
m_diskBar->setSelectedIndex(items.isEmpty() ? -1 : m_partitionTree->indexOfTopLevelItem(items.first()));
updateActionStates();
}
void MainWindow::onBarPartitionSelected(int index) {
if (index >= 0 && index < m_partitionTree->topLevelItemCount())
m_partitionTree->setCurrentItem(m_partitionTree->topLevelItem(index));
}
void MainWindow::updateActionStates() {
for (QAction* a : {m_newAct, m_delAct, m_resizeAct, m_unmountAct, m_flagsAct, m_checkAct, m_labelAct, m_nameAct, m_uuidAct, m_partImgAct, m_partRestoreAct, m_partInfoAct}) {
QObject::disconnect(a, &QAction::triggered, nullptr, nullptr);
a->setEnabled(false);
}
m_formatMenu->clear();
m_formatMenu->setEnabled(false);
int devIdx = m_deviceCombo->currentIndex();
auto items = m_partitionTree->selectedItems();
if (devIdx < 0 || devIdx >= static_cast<int>(m_devices.size()) || items.isEmpty()) return;
int row = m_partitionTree->indexOfTopLevelItem(items.first());
if (row < 0 || row >= static_cast<int>(m_visualParts.size())) return;
const auto& dev = *m_devices[static_cast<size_t>(devIdx)];
const auto& part = m_visualParts[static_cast<size_t>(row)];
bool isUnalloc = (part.fstype == GParted::FS_UNALLOCATED);
bool isReal = (!isUnalloc && part.type != GParted::TYPE_EXTENDED);
if (!isUnalloc && part.type != GParted::TYPE_EXTENDED) {
m_partImgAct->setEnabled(true);
connect(m_partImgAct, &QAction::triggered, this, [this, part]() {
ImageDialog(QString::fromStdString(part.get_path().raw()), part.get_byte_length(), ImageDialog::Mode::Sparse, QString(), this).exec();
});
}
if (!isUnalloc && !part.busy && part.type != GParted::TYPE_EXTENDED) {
m_partRestoreAct->setEnabled(true);
connect(m_partRestoreAct, &QAction::triggered, this, [this, part]() {
RestoreDialog dlg(QString::fromStdString(part.get_path().raw()), part.get_byte_length(), false, this);
dlg.exec();
if (dlg.restored()) refreshDevices();
});
}
m_partInfoAct->setEnabled(true);
connect(m_partInfoAct, &QAction::triggered, this, [this, part]() {
QString info = i18n("Path: %1\nFile system: %2\nFirst sector: %3\nLast sector: %4\nTotal sectors: %5\nUUID: %6",
QString::fromStdString(part.get_path().raw()), QString::fromStdString(part.get_filesystem_string().raw()),
QString::number(part.sector_start), QString::number(part.sector_end),
QString::number(part.get_sector_length()), QString::fromStdString(part.uuid.raw()));
KMessageBox::information(this, info, i18n("Partition Information"));
});
if (isUnalloc) {
m_newAct->setEnabled(true);
connect(m_newAct, &QAction::triggered, this, [this, &dev, part]() {
NewPartitionDialog dlg(dev, part, this);
if (dlg.exec() == QDialog::Accepted) { m_queue.addCreate(dev, part, dlg.buildPartition()); updateQueueUI(); rebuildCurrentView(); }
});
return;
}
if (part.busy) {
m_unmountAct->setEnabled(true);
m_unmountAct->setText((part.fstype == GParted::FS_LINUX_SWAP) ? i18n("Swapoff") : i18n("Unmount"));
connect(m_unmountAct, &QAction::triggered, this, [this, part]() {
Glib::ustring out, err;
Glib::ustring cmd = ((part.fstype == GParted::FS_LINUX_SWAP) ? "swapoff -v " : "umount -v ") + Glib::shell_quote(part.get_path());
if (GParted::Utils::execute_command(cmd, out, err, true) == 0) refreshDevices();
else KMessageBox::error(this, QString::fromStdString(err.raw()), i18n("Operation Failed"));
});
return;
}
m_delAct->setEnabled(true);
connect(m_delAct, &QAction::triggered, this, [this, &dev, part]() { m_queue.addDelete(dev, part); updateQueueUI(); rebuildCurrentView(); });
GParted::Sector minStart = part.sector_start;
GParted::Sector maxEnd = part.sector_end;
if (row > 0 && m_visualParts[static_cast<size_t>(row - 1)].fstype == GParted::FS_UNALLOCATED)
minStart = m_visualParts[static_cast<size_t>(row - 1)].sector_start;
if (row + 1 < static_cast<int>(m_visualParts.size()) && m_visualParts[static_cast<size_t>(row + 1)].fstype == GParted::FS_UNALLOCATED)
maxEnd = m_visualParts[static_cast<size_t>(row + 1)].sector_end;
m_resizeAct->setEnabled(true);
connect(m_resizeAct, &QAction::triggered, this, [this, &dev, part, minStart, maxEnd]() {
ResizeMoveDialog dlg(dev, part, minStart, maxEnd, this);
if (dlg.exec() == QDialog::Accepted) {
m_queue.addResizeMove(dev, part, dlg.buildPartition());
updateQueueUI();
rebuildCurrentView();
}
});
m_flagsAct->setEnabled(true);
connect(m_flagsAct, &QAction::triggered, this, [this, part]() { FlagsDialog(m_core, part, this).exec(); refreshDevices(); });
if (dev.disktype == "gpt") {
m_nameAct->setEnabled(true);
connect(m_nameAct, &QAction::triggered, this, [this, &dev, part]() {
bool ok = false;
QString nm = QInputDialog::getText(this, i18n("Name Partition"), i18n("Name:"), QLineEdit::Normal, QString::fromStdString(part.name.raw()), &ok);
if (ok) { m_queue.addName(dev, part, nm); updateQueueUI(); rebuildCurrentView(); }
});
}
if (isReal) {
m_formatMenu->setEnabled(true);
for (const auto& [name, fs] : std::vector<std::pair<QString, GParted::FSType>>{
{"ext4", GParted::FS_EXT4}, {"btrfs", GParted::FS_BTRFS}, {"xfs", GParted::FS_XFS},
{"fat32", GParted::FS_FAT32}, {"exfat", GParted::FS_EXFAT}, {"ntfs", GParted::FS_NTFS}, {"linux-swap", GParted::FS_LINUX_SWAP}}) {
m_formatMenu->addAction(name, this, [this, &dev, part, fs]() { m_queue.addFormat(dev, part, fs); updateQueueUI(); rebuildCurrentView(); });
}
m_checkAct->setEnabled(true);
connect(m_checkAct, &QAction::triggered, this, [this, &dev, part]() { m_queue.addCheck(dev, part); updateQueueUI(); rebuildCurrentView(); });
m_uuidAct->setEnabled(true);
connect(m_uuidAct, &QAction::triggered, this, [this, &dev, part]() { m_queue.addNewUUID(dev, part); updateQueueUI(); rebuildCurrentView(); });
m_labelAct->setEnabled(true);
connect(m_labelAct, &QAction::triggered, this, [this, &dev, part]() {
bool ok = false;
QString lbl = QInputDialog::getText(this, i18n("Label File System"), i18n("New label:"), QLineEdit::Normal, QString::fromStdString(part.get_filesystem_label().raw()), &ok);
if (ok) { m_queue.addLabel(dev, part, lbl); updateQueueUI(); rebuildCurrentView(); }
});
}
}
void MainWindow::onTreeContextMenu(const QPoint& pos) {
if (!m_partitionTree->itemAt(pos)) return;
QMenu menu(this);
for (QAction* a : {m_newAct, m_delAct, m_resizeAct}) menu.addAction(a);
menu.addSeparator();
menu.addMenu(m_formatMenu);
menu.addAction(m_unmountAct);
menu.addSeparator();
for (QAction* a : {m_flagsAct, m_checkAct, m_labelAct, m_nameAct, m_uuidAct}) menu.addAction(a);
menu.addSeparator();
menu.addAction(m_partImgAct);
menu.addAction(m_partRestoreAct);
menu.addAction(m_partInfoAct);
menu.exec(m_partitionTree->viewport()->mapToGlobal(pos));
}
void MainWindow::undoLastOperation() { m_queue.undoLast(); updateQueueUI(); rebuildCurrentView(); }
void MainWindow::clearAllOperations() { m_queue.clear(); updateQueueUI(); rebuildCurrentView(); }
void MainWindow::applyAllOperations() {
if (m_queue.isEmpty()) return;
if (KMessageBox::warningContinueCancel(this, i18n("Apply %1 pending operation(s)?", m_queue.count()), i18n("Apply Operations")) != KMessageBox::Continue) return;
ApplyDialog(m_core, m_queue, this).exec();
refreshDevices();
}
void MainWindow::updateQueueUI() {
m_opsList->clear();
QStringList items = m_queue.descriptions();
for (int i = 0; i < items.size(); ++i) m_opsList->addItem(QStringLiteral("%1. %2").arg(i + 1).arg(items[i]));
bool hasOps = !m_queue.isEmpty();
m_opsList->setVisible(hasOps);
m_viewOpsAct->setChecked(hasOps);
m_undoAct->setEnabled(hasOps);
m_clearAct->setEnabled(hasOps);
m_applyAct->setEnabled(hasOps);
}
void MainWindow::attemptDataRescue() {
int idx = m_deviceCombo->currentIndex();
if (idx < 0 || idx >= static_cast<int>(m_devices.size())) return;
RescueDialog(*m_devices[static_cast<size_t>(idx)], this).exec();
}
