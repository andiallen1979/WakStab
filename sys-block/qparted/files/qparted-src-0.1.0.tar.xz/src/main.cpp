#include <QFont>
#include <QSettings>
#include "MainWindow.h"
#include <KAboutData>
#include <KColorSchemeManager>
#include <KLocalizedString>
#include <QApplication>
int main(int argc, char* argv[]) {
QApplication app(argc, argv);
{
QSettings st(QStringLiteral("WakStab"), QStringLiteral("qparted"));
QFont f = app.font();
QString fam = st.value(QStringLiteral("ui/fontFamily")).toString();
if (!fam.isEmpty()) f.setFamily(fam);
int pt = st.value(QStringLiteral("ui/fontSize"), 11).toInt();
if (pt >= 6 && pt <= 36) f.setPointSize(pt);
app.setFont(f);
}
KColorSchemeManager::instance();
KLocalizedString::setApplicationDomain("qparted");
KAboutData about(
QStringLiteral("qparted"),
i18n("QParted"),
QStringLiteral("0.1.0"),
i18n("Native Qt6 / KDE Plasma Partition Editor"),
KAboutLicense::GPL_V2,
i18n("(c) 2026 WakStab Repository / GParted Authors"),
QString(),
QStringLiteral("https://fragtoo.com"));
KAboutData::setApplicationData(about);
app.setDesktopFileName(QStringLiteral("qparted"));
MainWindow win;
win.show();
return app.exec();
}
